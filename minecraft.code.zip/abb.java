/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class abb
/*    */   extends aav
/*    */ {
/*    */   public abb(int paramInt) {
/* 12 */     super(paramInt);
/*    */ 
/*    */     
/* 15 */     this.K.clear();
/* 16 */     this.A = (byte)apa.I.cz;
/* 17 */     this.B = (byte)apa.I.cz;
/*    */     
/* 19 */     this.I.z = -999;
/* 20 */     this.I.C = 2;
/* 21 */     this.I.E = 50;
/* 22 */     this.I.F = 10;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 27 */     super.a(paramaab, paramRandom, paramInt1, paramInt2);
/*    */     
/* 29 */     if (paramRandom.nextInt(1000) == 0) {
/* 30 */       int i = paramInt1 + paramRandom.nextInt(16) + 8;
/* 31 */       int j = paramInt2 + paramRandom.nextInt(16) + 8;
/* 32 */       adi adi = new adi();
/* 33 */       adi.a(paramaab, paramRandom, i, paramaab.f(i, j) + 1, j);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */