/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aob
/*    */   extends alb
/*    */ {
/*    */   private lx b;
/*    */   
/*    */   protected aob(int paramInt) {
/* 11 */     super(paramInt, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 16 */     if (paramInt2 >= 6) {
/* 17 */       return this.b;
/*    */     }
/* 19 */     return this.cQ;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 25 */     super.a(paramly);
/* 26 */     this.b = paramly.a("rail_turn");
/*    */   }
/*    */ 
/*    */   
/*    */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 31 */     if (paramInt6 > 0 && apa.r[paramInt6].f() && (
/* 32 */       new alc(this, paramaab, paramInt1, paramInt2, paramInt3)).a() == 3)
/* 33 */       a(paramaab, paramInt1, paramInt2, paramInt3, false); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aob.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */