/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aco
/*    */   extends acn
/*    */ {
/*    */   public void b() {
/* 12 */     this.d = new abd(aav.j, 1.0F, 0.0F);
/* 13 */     this.e = true;
/* 14 */     this.f = true;
/* 15 */     this.h = -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public arc b(float paramFloat1, float paramFloat2) {
/* 20 */     return this.a.U().a(0.20000000298023224D, 0.029999999329447746D, 0.029999999329447746D);
/*    */   }
/*    */ 
/*    */   
/*    */   protected void a() {
/* 25 */     float f = 0.1F;
/* 26 */     for (byte b = 0; b <= 15; b++) {
/* 27 */       float f1 = 1.0F - b / 15.0F;
/* 28 */       this.g[b] = (1.0F - f1) / (f1 * 3.0F + 1.0F) * (1.0F - f) + f;
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public abt c() {
/* 34 */     return new acu(this.a, this.a.G());
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean d() {
/* 39 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(int paramInt1, int paramInt2) {
/* 44 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public float a(long paramLong, float paramFloat) {
/* 49 */     return 0.5F;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean e() {
/* 54 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b(int paramInt1, int paramInt2) {
/* 59 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String l() {
/* 64 */     return "Nether";
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aco.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */