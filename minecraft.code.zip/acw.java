/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class acw
/*    */ {
/* 12 */   protected int a = 8;
/* 13 */   protected Random b = new Random();
/*    */   protected aab c;
/*    */   
/*    */   public void a(abt paramabt, aab paramaab, int paramInt1, int paramInt2, byte[] paramArrayOfbyte) {
/* 17 */     int i = this.a;
/* 18 */     this.c = paramaab;
/*    */     
/* 20 */     this.b.setSeed(paramaab.G());
/* 21 */     long l1 = this.b.nextLong();
/* 22 */     long l2 = this.b.nextLong();
/*    */     
/* 24 */     for (int j = paramInt1 - i; j <= paramInt1 + i; j++) {
/* 25 */       for (int k = paramInt2 - i; k <= paramInt2 + i; k++) {
/* 26 */         long l3 = j * l1;
/* 27 */         long l4 = k * l2;
/* 28 */         this.b.setSeed(l3 ^ l4 ^ paramaab.G());
/* 29 */         a(paramaab, j, k, paramInt1, paramInt2, paramArrayOfbyte);
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfbyte) {}
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */