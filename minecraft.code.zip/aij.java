/*    */ 
/*    */ 
/*    */ public class aij
/*    */   extends ait
/*    */ {
/*    */   public aij(long paramLong, ait paramait) {
/*  7 */     super(paramLong);
/*  8 */     this.a = paramait;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 13 */     int i = paramInt1 - 1;
/* 14 */     int j = paramInt2 - 1;
/* 15 */     int k = paramInt3 + 2;
/* 16 */     int m = paramInt4 + 2;
/* 17 */     int[] arrayOfInt1 = this.a.a(i, j, k, m);
/*    */     
/* 19 */     int[] arrayOfInt2 = air.a(paramInt3 * paramInt4);
/* 20 */     for (byte b = 0; b < paramInt4; b++) {
/* 21 */       for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 22 */         int n = arrayOfInt1[b1 + 0 + (b + 0) * k];
/* 23 */         int i1 = arrayOfInt1[b1 + 2 + (b + 0) * k];
/* 24 */         int i2 = arrayOfInt1[b1 + 0 + (b + 2) * k];
/* 25 */         int i3 = arrayOfInt1[b1 + 2 + (b + 2) * k];
/* 26 */         int i4 = arrayOfInt1[b1 + 1 + (b + 1) * k];
/* 27 */         a((b1 + paramInt1), (b + paramInt2));
/* 28 */         if (i4 == 0 && (n != 0 || i1 != 0 || i2 != 0 || i3 != 0))
/* 29 */         { byte b2 = 1;
/* 30 */           int i5 = 1;
/* 31 */           if (n != 0 && a(b2++) == 0) i5 = n; 
/* 32 */           if (i1 != 0 && a(b2++) == 0) i5 = i1; 
/* 33 */           if (i2 != 0 && a(b2++) == 0) i5 = i2; 
/* 34 */           if (i3 != 0 && a(b2++) == 0) i5 = i3; 
/* 35 */           if (a(3) == 0)
/* 36 */           { arrayOfInt2[b1 + b * paramInt3] = i5; }
/*    */           
/* 38 */           else if (i5 == aav.n.N) { arrayOfInt2[b1 + b * paramInt3] = aav.l.N; }
/* 39 */           else { arrayOfInt2[b1 + b * paramInt3] = 0; }
/*    */            }
/* 41 */         else if (i4 > 0 && (n == 0 || i1 == 0 || i2 == 0 || i3 == 0))
/* 42 */         { if (a(5) == 0)
/* 43 */           { if (i4 == aav.n.N) { arrayOfInt2[b1 + b * paramInt3] = aav.l.N; }
/* 44 */             else { arrayOfInt2[b1 + b * paramInt3] = 0; }  }
/* 45 */           else { arrayOfInt2[b1 + b * paramInt3] = i4; }
/*    */            }
/* 47 */         else { arrayOfInt2[b1 + b * paramInt3] = i4; }
/*    */       
/*    */       } 
/*    */     } 
/* 51 */     return arrayOfInt2;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aij.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */