/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class anw
/*     */   extends alb
/*     */ {
/*     */   protected lx b;
/*     */   
/*     */   protected anw(int paramInt) {
/*  11 */     super(paramInt, true);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  16 */     if ((paramInt2 & 0x8) == 0) {
/*  17 */       return this.cQ;
/*     */     }
/*  19 */     return this.b;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  25 */     super.a(paramly);
/*  26 */     this.b = paramly.a(B() + "_powered");
/*     */   }
/*     */   
/*     */   protected boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, int paramInt5) {
/*  30 */     if (paramInt5 >= 8) {
/*  31 */       return false;
/*     */     }
/*     */     
/*  34 */     int i = paramInt4 & 0x7;
/*     */     
/*  36 */     boolean bool = true;
/*  37 */     switch (i) {
/*     */       case 0:
/*  39 */         if (paramBoolean) {
/*  40 */           paramInt3++; break;
/*     */         } 
/*  42 */         paramInt3--;
/*     */         break;
/*     */       
/*     */       case 1:
/*  46 */         if (paramBoolean) {
/*  47 */           paramInt1--; break;
/*     */         } 
/*  49 */         paramInt1++;
/*     */         break;
/*     */       
/*     */       case 2:
/*  53 */         if (paramBoolean) {
/*  54 */           paramInt1--;
/*     */         } else {
/*  56 */           paramInt1++;
/*  57 */           paramInt2++;
/*  58 */           bool = false;
/*     */         } 
/*  60 */         i = 1;
/*     */         break;
/*     */       case 3:
/*  63 */         if (paramBoolean) {
/*  64 */           paramInt1--;
/*  65 */           paramInt2++;
/*  66 */           bool = false;
/*     */         } else {
/*  68 */           paramInt1++;
/*     */         } 
/*  70 */         i = 1;
/*     */         break;
/*     */       case 4:
/*  73 */         if (paramBoolean) {
/*  74 */           paramInt3++;
/*     */         } else {
/*  76 */           paramInt3--;
/*  77 */           paramInt2++;
/*  78 */           bool = false;
/*     */         } 
/*  80 */         i = 0;
/*     */         break;
/*     */       case 5:
/*  83 */         if (paramBoolean) {
/*  84 */           paramInt3++;
/*  85 */           paramInt2++;
/*  86 */           bool = false;
/*     */         } else {
/*  88 */           paramInt3--;
/*     */         } 
/*  90 */         i = 0;
/*     */         break;
/*     */     } 
/*     */     
/*  94 */     if (a(paramaab, paramInt1, paramInt2, paramInt3, paramBoolean, paramInt5, i)) {
/*  95 */       return true;
/*     */     }
/*  97 */     if (bool && a(paramaab, paramInt1, paramInt2 - 1, paramInt3, paramBoolean, paramInt5, i)) {
/*  98 */       return true;
/*     */     }
/* 100 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean, int paramInt4, int paramInt5) {
/* 104 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3);
/*     */     
/* 106 */     if (i == this.cz) {
/* 107 */       int j = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 108 */       int k = j & 0x7;
/*     */       
/* 110 */       if (paramInt5 == 1 && (k == 0 || k == 4 || k == 5)) {
/* 111 */         return false;
/*     */       }
/* 113 */       if (paramInt5 == 0 && (k == 1 || k == 2 || k == 3)) {
/* 114 */         return false;
/*     */       }
/*     */       
/* 117 */       if ((j & 0x8) != 0) {
/* 118 */         if (paramaab.C(paramInt1, paramInt2, paramInt3)) {
/* 119 */           return true;
/*     */         }
/* 121 */         return a(paramaab, paramInt1, paramInt2, paramInt3, j, paramBoolean, paramInt4 + 1);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 126 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 131 */     boolean bool = paramaab.C(paramInt1, paramInt2, paramInt3);
/* 132 */     bool = (bool || a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, true, 0) || a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, false, 0));
/*     */     
/* 134 */     boolean bool1 = false;
/* 135 */     if (bool && (paramInt4 & 0x8) == 0) {
/* 136 */       paramaab.b(paramInt1, paramInt2, paramInt3, paramInt5 | 0x8, 3);
/* 137 */       bool1 = true;
/* 138 */     } else if (!bool && (paramInt4 & 0x8) != 0) {
/* 139 */       paramaab.b(paramInt1, paramInt2, paramInt3, paramInt5, 3);
/* 140 */       bool1 = true;
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 146 */     if (bool1) {
/* 147 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/* 148 */       if (paramInt5 == 2 || paramInt5 == 3 || paramInt5 == 4 || paramInt5 == 5)
/* 149 */         paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */