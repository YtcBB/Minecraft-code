/*     */ import java.util.Collections;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.regex.Matcher;
/*     */ import java.util.regex.Pattern;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ac
/*     */ {
/*  18 */   private static final Pattern a = Pattern.compile("^@([parf])(?:\\[([\\w=,!-]*)\\])?$");
/*  19 */   private static final Pattern b = Pattern.compile("\\G([-!]?\\w*)(?:$|,)");
/*  20 */   private static final Pattern c = Pattern.compile("\\G(\\w+)=([-!]?\\w*)(?:$|,)");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static jc a(ab paramab, String paramString) {
/*  43 */     jc[] arrayOfJc = c(paramab, paramString);
/*     */     
/*  45 */     if (arrayOfJc == null || arrayOfJc.length != 1) return null;
/*     */     
/*  47 */     return arrayOfJc[0];
/*     */   }
/*     */   
/*     */   public static String b(ab paramab, String paramString) {
/*  51 */     jc[] arrayOfJc = c(paramab, paramString);
/*  52 */     if (arrayOfJc == null || arrayOfJc.length == 0) return null; 
/*  53 */     String[] arrayOfString = new String[arrayOfJc.length];
/*     */     
/*  55 */     for (byte b = 0; b < arrayOfString.length; b++) {
/*  56 */       arrayOfString[b] = arrayOfJc[b].ax();
/*     */     }
/*     */     
/*  59 */     return x.a((Object[])arrayOfString);
/*     */   }
/*     */   
/*     */   public static jc[] c(ab paramab, String paramString) {
/*  63 */     Matcher matcher = a.matcher(paramString);
/*     */     
/*  65 */     if (matcher.matches()) {
/*  66 */       Map map1 = h(matcher.group(2));
/*  67 */       String str1 = matcher.group(1);
/*  68 */       int i = c(str1);
/*  69 */       int j = d(str1);
/*  70 */       int k = f(str1);
/*  71 */       int m = e(str1);
/*  72 */       int n = g(str1);
/*  73 */       int i1 = aaj.a.a();
/*  74 */       t t = paramab.b();
/*  75 */       Map map2 = a(map1);
/*  76 */       String str2 = null;
/*  77 */       String str3 = null;
/*     */       
/*  79 */       if (map1.containsKey("rm")) i = kx.a((String)map1.get("rm"), i); 
/*  80 */       if (map1.containsKey("r")) j = kx.a((String)map1.get("r"), j); 
/*  81 */       if (map1.containsKey("lm")) k = kx.a((String)map1.get("lm"), k); 
/*  82 */       if (map1.containsKey("l")) m = kx.a((String)map1.get("l"), m); 
/*  83 */       if (map1.containsKey("x")) t.a = kx.a((String)map1.get("x"), t.a); 
/*  84 */       if (map1.containsKey("y")) t.b = kx.a((String)map1.get("y"), t.b); 
/*  85 */       if (map1.containsKey("z")) t.c = kx.a((String)map1.get("z"), t.c); 
/*  86 */       if (map1.containsKey("m")) i1 = kx.a((String)map1.get("m"), i1); 
/*  87 */       if (map1.containsKey("c")) n = kx.a((String)map1.get("c"), n); 
/*  88 */       if (map1.containsKey("team")) str3 = (String)map1.get("team"); 
/*  89 */       if (map1.containsKey("name")) str2 = (String)map1.get("name");
/*     */       
/*  91 */       if (str1.equals("p") || str1.equals("a")) {
/*  92 */         List list = MinecraftServer.D().ad().a(t, i, j, n, i1, k, m, map2, str2, str3);
/*  93 */         return (list == null || list.isEmpty()) ? new jc[0] : (jc[])list.toArray((Object[])new jc[0]);
/*  94 */       }  if (str1.equals("r")) {
/*  95 */         List<?> list = MinecraftServer.D().ad().a(t, i, j, 0, i1, k, m, map2, str2, str3);
/*  96 */         Collections.shuffle(list);
/*  97 */         list = list.subList(0, Math.min(n, list.size()));
/*  98 */         return (list == null || list.isEmpty()) ? new jc[0] : list.<jc>toArray(new jc[0]);
/*     */       } 
/* 100 */       return null;
/*     */     } 
/*     */     
/* 103 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static Map a(Map paramMap) {
/* 108 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/*     */     
/* 110 */     for (String str : paramMap.keySet()) {
/* 111 */       if (str.startsWith("score_") && str.length() > "score_".length()) {
/* 112 */         String str1 = str.substring("score_".length());
/* 113 */         hashMap.put(str1, Integer.valueOf(kx.a((String)paramMap.get(str), 1)));
/*     */       } 
/*     */     } 
/*     */     
/* 117 */     return hashMap;
/*     */   }
/*     */   
/*     */   public static boolean a(String paramString) {
/* 121 */     Matcher matcher = a.matcher(paramString);
/*     */     
/* 123 */     if (matcher.matches()) {
/* 124 */       Map map = h(matcher.group(2));
/* 125 */       String str = matcher.group(1);
/* 126 */       int i = g(str);
/* 127 */       if (map.containsKey("c")) i = kx.a((String)map.get("c"), i); 
/* 128 */       return (i != 1);
/*     */     } 
/*     */     
/* 131 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean a(String paramString1, String paramString2) {
/* 135 */     Matcher matcher = a.matcher(paramString1);
/*     */     
/* 137 */     if (matcher.matches()) {
/* 138 */       String str = matcher.group(1);
/* 139 */       if (paramString2 != null && !paramString2.equals(str)) return false;
/*     */       
/* 141 */       return true;
/*     */     } 
/*     */     
/* 144 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean b(String paramString) {
/* 148 */     return a(paramString, (String)null);
/*     */   }
/*     */   
/*     */   private static final int c(String paramString) {
/* 152 */     return 0;
/*     */   }
/*     */   
/*     */   private static final int d(String paramString) {
/* 156 */     return 0;
/*     */   }
/*     */   
/*     */   private static final int e(String paramString) {
/* 160 */     return Integer.MAX_VALUE;
/*     */   }
/*     */   
/*     */   private static final int f(String paramString) {
/* 164 */     return 0;
/*     */   }
/*     */   
/*     */   private static final int g(String paramString) {
/* 168 */     if (paramString.equals("a")) {
/* 169 */       return 0;
/*     */     }
/* 171 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static Map h(String paramString) {
/* 176 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/* 177 */     if (paramString == null) return hashMap; 
/* 178 */     Matcher matcher = b.matcher(paramString);
/* 179 */     byte b = 0;
/* 180 */     int i = -1;
/*     */     
/* 182 */     while (matcher.find()) {
/* 183 */       String str = null;
/*     */       
/* 185 */       switch (b++) {
/*     */         case 0:
/* 187 */           str = "x";
/*     */           break;
/*     */         case 1:
/* 190 */           str = "y";
/*     */           break;
/*     */         case 2:
/* 193 */           str = "z";
/*     */           break;
/*     */         case 3:
/* 196 */           str = "r";
/*     */           break;
/*     */       } 
/*     */       
/* 200 */       if (str != null && matcher.group(1).length() > 0) hashMap.put(str, matcher.group(1)); 
/* 201 */       i = matcher.end();
/*     */     } 
/*     */     
/* 204 */     if (i < paramString.length()) {
/* 205 */       matcher = c.matcher((i == -1) ? paramString : paramString.substring(i));
/*     */       
/* 207 */       while (matcher.find()) {
/* 208 */         hashMap.put(matcher.group(1), matcher.group(2));
/*     */       }
/*     */     } 
/*     */     
/* 212 */     return hashMap;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ac.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */