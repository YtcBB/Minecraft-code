/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class apv
/*    */   extends apa
/*    */ {
/*    */   private lx a;
/*    */   private lx b;
/*    */   
/*    */   protected apv(int paramInt) {
/* 16 */     super(paramInt, aif.d);
/* 17 */     a(ve.c);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 22 */     if (paramInt1 == 1) return this.a; 
/* 23 */     if (paramInt1 == 0) return apa.B.m(paramInt1); 
/* 24 */     if (paramInt1 == 2 || paramInt1 == 4) return this.b; 
/* 25 */     return this.cQ;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 30 */     this.cQ = paramly.a("workbench_side");
/* 31 */     this.a = paramly.a("workbench_top");
/* 32 */     this.b = paramly.a("workbench_front");
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 37 */     if (paramaab.I) {
/* 38 */       return true;
/*    */     }
/* 40 */     paramsq.b(paramInt1, paramInt2, paramInt3);
/* 41 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */