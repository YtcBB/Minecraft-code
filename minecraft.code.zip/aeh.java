/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aeh
/*     */ {
/*  21 */   private final List a = new ArrayList();
/*  22 */   private final Map b = new HashMap<Object, Object>();
/*  23 */   private int c = 0;
/*     */   
/*     */   public int a() {
/*  26 */     return this.c;
/*     */   }
/*     */   
/*     */   public void a(int paramInt) {
/*  30 */     this.c = paramInt;
/*     */   }
/*     */   
/*     */   public Map b() {
/*  34 */     return this.b;
/*     */   }
/*     */   
/*     */   public List c() {
/*  38 */     return this.a;
/*     */   }
/*     */   
/*     */   public void d() {
/*  42 */     int i = 0;
/*     */     
/*  44 */     for (aei aei : this.a) {
/*  45 */       aei.d(i);
/*  46 */       i += aei.a();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  52 */     StringBuilder stringBuilder = new StringBuilder();
/*     */     
/*  54 */     stringBuilder.append(2);
/*  55 */     stringBuilder.append(";");
/*     */     byte b;
/*  57 */     for (b = 0; b < this.a.size(); b++) {
/*  58 */       if (b > 0) stringBuilder.append(","); 
/*  59 */       stringBuilder.append(((aei)this.a.get(b)).toString());
/*     */     } 
/*     */     
/*  62 */     stringBuilder.append(";");
/*  63 */     stringBuilder.append(this.c);
/*     */     
/*  65 */     if (!this.b.isEmpty()) {
/*  66 */       stringBuilder.append(";");
/*  67 */       b = 0;
/*     */       
/*  69 */       for (Map.Entry entry : this.b.entrySet()) {
/*  70 */         if (b++ > 0) stringBuilder.append(","); 
/*  71 */         stringBuilder.append(((String)entry.getKey()).toLowerCase());
/*     */         
/*  73 */         Map map = (Map)entry.getValue();
/*  74 */         if (!map.isEmpty()) {
/*  75 */           stringBuilder.append("(");
/*  76 */           byte b1 = 0;
/*     */           
/*  78 */           for (Map.Entry entry1 : map.entrySet()) {
/*  79 */             if (b1++ > 0) stringBuilder.append(" "); 
/*  80 */             stringBuilder.append((String)entry1.getKey());
/*  81 */             stringBuilder.append("=");
/*  82 */             stringBuilder.append((String)entry1.getValue());
/*     */           } 
/*     */           
/*  85 */           stringBuilder.append(")");
/*     */         } 
/*     */       } 
/*     */     } else {
/*  89 */       stringBuilder.append(";");
/*     */     } 
/*     */     
/*  92 */     return stringBuilder.toString();
/*     */   }
/*     */   private static aei a(String paramString, int paramInt) {
/*     */     int j;
/*  96 */     String[] arrayOfString = paramString.split("x", 2);
/*  97 */     int i = 1;
/*     */     
/*  99 */     int k = 0;
/*     */     
/* 101 */     if (arrayOfString.length == 2) {
/*     */       try {
/* 103 */         i = Integer.parseInt(arrayOfString[0]);
/* 104 */         if (paramInt + i >= 256) i = 256 - paramInt; 
/* 105 */         if (i < 0) i = 0; 
/* 106 */       } catch (Throwable throwable) {
/* 107 */         return null;
/*     */       } 
/*     */     }
/*     */     
/*     */     try {
/* 112 */       String str = arrayOfString[arrayOfString.length - 1];
/* 113 */       arrayOfString = str.split(":", 2);
/* 114 */       j = Integer.parseInt(arrayOfString[0]);
/* 115 */       if (arrayOfString.length > 1) k = Integer.parseInt(arrayOfString[1]);
/*     */       
/* 117 */       if (apa.r[j] == null) {
/* 118 */         j = 0;
/* 119 */         k = 0;
/*     */       } 
/*     */       
/* 122 */       if (k < 0 || k > 15) k = 0; 
/* 123 */     } catch (Throwable throwable) {
/* 124 */       return null;
/*     */     } 
/*     */     
/* 127 */     aei aei = new aei(i, j, k);
/* 128 */     aei.d(paramInt);
/* 129 */     return aei;
/*     */   }
/*     */   
/*     */   private static List b(String paramString) {
/* 133 */     if (paramString == null || paramString.length() < 1) return null;
/*     */     
/* 135 */     ArrayList<aei> arrayList = new ArrayList();
/* 136 */     String[] arrayOfString = paramString.split(",");
/* 137 */     int i = 0;
/*     */     
/* 139 */     for (String str : arrayOfString) {
/* 140 */       aei aei = a(str, i);
/* 141 */       if (aei == null) return null; 
/* 142 */       arrayList.add(aei);
/* 143 */       i += aei.a();
/*     */     } 
/*     */     
/* 146 */     return arrayList;
/*     */   }
/*     */   
/*     */   public static aeh a(String paramString) {
/* 150 */     if (paramString == null) return e(); 
/* 151 */     String[] arrayOfString = paramString.split(";", -1);
/* 152 */     byte b1 = (arrayOfString.length == 1) ? 0 : kx.a(arrayOfString[0], 0);
/* 153 */     if (!b1 || b1 > 2) return e();
/*     */     
/* 155 */     aeh aeh1 = new aeh();
/* 156 */     byte b2 = (arrayOfString.length == 1) ? 0 : 1;
/* 157 */     List list = b(arrayOfString[b2++]);
/*     */     
/* 159 */     if (list == null || list.isEmpty()) {
/* 160 */       return e();
/*     */     }
/*     */     
/* 163 */     aeh1.c().addAll(list);
/* 164 */     aeh1.d();
/*     */     
/* 166 */     int i = aav.c.N;
/* 167 */     if (b1 > 0 && arrayOfString.length > b2) i = kx.a(arrayOfString[b2++], i); 
/* 168 */     aeh1.a(i);
/*     */     
/* 170 */     if (b1 > 0 && arrayOfString.length > b2) {
/* 171 */       String[] arrayOfString1 = arrayOfString[b2++].toLowerCase().split(",");
/*     */       
/* 173 */       for (String str : arrayOfString1) {
/* 174 */         String[] arrayOfString2 = str.split("\\(", 2);
/* 175 */         HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/*     */         
/* 177 */         if (arrayOfString2[0].length() > 0) {
/* 178 */           aeh1.b().put(arrayOfString2[0], hashMap);
/*     */           
/* 180 */           if (arrayOfString2.length > 1 && arrayOfString2[1].endsWith(")") && arrayOfString2[1].length() > 1) {
/* 181 */             String[] arrayOfString3 = arrayOfString2[1].substring(0, arrayOfString2[1].length() - 1).split(" ");
/*     */             
/* 183 */             for (byte b = 0; b < arrayOfString3.length; b++) {
/* 184 */               String[] arrayOfString4 = arrayOfString3[b].split("=", 2);
/* 185 */               if (arrayOfString4.length == 2) hashMap.put(arrayOfString4[0], arrayOfString4[1]); 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 191 */       aeh1.b().put("village", new HashMap<Object, Object>());
/*     */     } 
/*     */     
/* 194 */     return aeh1;
/*     */   }
/*     */   
/*     */   public static aeh e() {
/* 198 */     aeh aeh1 = new aeh();
/*     */     
/* 200 */     aeh1.a(aav.c.N);
/* 201 */     aeh1.c().add(new aei(1, apa.D.cz));
/* 202 */     aeh1.c().add(new aei(2, apa.z.cz));
/* 203 */     aeh1.c().add(new aei(1, apa.y.cz));
/* 204 */     aeh1.d();
/* 205 */     aeh1.b().put("village", new HashMap<Object, Object>());
/*     */     
/* 207 */     return aeh1;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aeh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */