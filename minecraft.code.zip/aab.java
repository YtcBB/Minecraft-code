/*      */ import java.util.ArrayList;
/*      */ import java.util.Calendar;
/*      */ import java.util.Collection;
/*      */ import java.util.HashSet;
/*      */ import java.util.Iterator;
/*      */ import java.util.List;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public abstract class aab
/*      */   implements aak
/*      */ {
/*      */   public boolean d = false;
/*   46 */   public List e = new ArrayList();
/*   47 */   protected List f = new ArrayList();
/*   48 */   public List g = new ArrayList();
/*   49 */   private List a = new ArrayList();
/*   50 */   private List b = new ArrayList();
/*   51 */   public List h = new ArrayList();
/*   52 */   public List i = new ArrayList();
/*      */   
/*   54 */   private long c = 16777215L;
/*      */   
/*   56 */   public int j = 0;
/*      */   
/*   58 */   protected int k = (new Random()).nextInt();
/*   59 */   protected final int l = 1013904223; protected float m; protected float n;
/*      */   protected float o;
/*      */   protected float p;
/*   62 */   public int q = 0;
/*      */   
/*      */   public int r;
/*   65 */   public Random s = new Random();
/*      */   
/*      */   public final acn t;
/*   68 */   protected List u = new ArrayList();
/*      */   
/*      */   protected abt v;
/*      */   
/*      */   protected final akf w;
/*      */   
/*      */   protected ajv x;
/*      */   
/*      */   public boolean y;
/*      */   
/*      */   public aku z;
/*      */   public final qe A;
/*   80 */   protected final qd B = new qd(this);
/*      */   public final la C;
/*   82 */   private final ard J = new ard(300, 2000);
/*   83 */   private final Calendar K = Calendar.getInstance();
/*   84 */   protected arj D = new arj(); private final ku L; private ArrayList M; private boolean N; protected boolean E; protected boolean F; protected Set G; private int O; int[] H;
/*      */   public boolean I;
/*      */   
/*      */   public aav a(int paramInt1, int paramInt2) {
/*   88 */     if (f(paramInt1, 0, paramInt2)) {
/*   89 */       abw abw = d(paramInt1, paramInt2);
/*   90 */       if (abw != null) {
/*   91 */         return abw.a(paramInt1 & 0xF, paramInt2 & 0xF, this.t.d);
/*      */       }
/*      */     } 
/*   94 */     return this.t.d.a(paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */   public aba u() {
/*   98 */     return this.t.d;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void a(aai paramaai) {
/*  186 */     this.x.d(true);
/*      */   }
/*      */   
/*      */   public void f() {
/*  190 */     E(8, 64, 8);
/*      */   }
/*      */   
/*      */   public int b(int paramInt1, int paramInt2) {
/*  194 */     byte b = 63;
/*  195 */     while (!c(paramInt1, b + 1, paramInt2)) {
/*  196 */       b++;
/*      */     }
/*  198 */     return a(paramInt1, b, paramInt2);
/*      */   }
/*      */   
/*      */   public int a(int paramInt1, int paramInt2, int paramInt3) {
/*  202 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) {
/*  203 */       return 0;
/*      */     }
/*  205 */     if (paramInt2 < 0) return 0; 
/*  206 */     if (paramInt2 >= 256) return 0; 
/*  207 */     abw abw = null;
/*      */     
/*      */     try {
/*  210 */       abw = e(paramInt1 >> 4, paramInt3 >> 4);
/*  211 */       return abw.a(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*  212 */     } catch (Throwable throwable) {
/*  213 */       b b = b.a(throwable, "Exception getting block type in world");
/*  214 */       m m = b.a("Requested block coordinates");
/*      */       
/*  216 */       m.a("Found chunk", Boolean.valueOf((abw == null)));
/*  217 */       m.a("Location", m.a(paramInt1, paramInt2, paramInt3));
/*      */       
/*  219 */       throw new u(b);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean c(int paramInt1, int paramInt2, int paramInt3) {
/*  233 */     return (a(paramInt1, paramInt2, paramInt3) == 0);
/*      */   }
/*      */   
/*      */   public boolean d(int paramInt1, int paramInt2, int paramInt3) {
/*  237 */     int i = a(paramInt1, paramInt2, paramInt3);
/*  238 */     if (apa.r[i] != null && apa.r[i].t()) {
/*  239 */       return true;
/*      */     }
/*  241 */     return false;
/*      */   }
/*      */   
/*      */   public int e(int paramInt1, int paramInt2, int paramInt3) {
/*  245 */     int i = a(paramInt1, paramInt2, paramInt3);
/*  246 */     if (apa.r[i] != null) {
/*  247 */       return apa.r[i].d();
/*      */     }
/*  249 */     return -1;
/*      */   }
/*      */   
/*      */   public boolean f(int paramInt1, int paramInt2, int paramInt3) {
/*  253 */     if (paramInt2 < 0 || paramInt2 >= 256) return false; 
/*  254 */     return c(paramInt1 >> 4, paramInt3 >> 4);
/*      */   }
/*      */   
/*      */   public boolean b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  258 */     return e(paramInt1 - paramInt4, paramInt2 - paramInt4, paramInt3 - paramInt4, paramInt1 + paramInt4, paramInt2 + paramInt4, paramInt3 + paramInt4);
/*      */   }
/*      */   
/*      */   public boolean e(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  262 */     if (paramInt5 < 0 || paramInt2 >= 256) return false;
/*      */     
/*  264 */     paramInt1 >>= 4;
/*  265 */     paramInt3 >>= 4;
/*  266 */     paramInt4 >>= 4;
/*  267 */     paramInt6 >>= 4;
/*      */     
/*  269 */     for (int i = paramInt1; i <= paramInt4; i++) {
/*  270 */       for (int j = paramInt3; j <= paramInt6; j++) {
/*  271 */         if (!c(i, j)) return false; 
/*      */       } 
/*  273 */     }  return true;
/*      */   }
/*      */   
/*      */   protected boolean c(int paramInt1, int paramInt2) {
/*  277 */     return this.v.a(paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */   public abw d(int paramInt1, int paramInt2) {
/*  281 */     return e(paramInt1 >> 4, paramInt2 >> 4);
/*      */   }
/*      */   
/*      */   public abw e(int paramInt1, int paramInt2) {
/*  285 */     return this.v.d(paramInt1, paramInt2);
/*      */   }
/*      */   
/*      */   public boolean f(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  289 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) {
/*  290 */       return false;
/*      */     }
/*  292 */     if (paramInt2 < 0) return false; 
/*  293 */     if (paramInt2 >= 256) return false;
/*      */     
/*  295 */     abw abw = e(paramInt1 >> 4, paramInt3 >> 4);
/*  296 */     int i = 0;
/*  297 */     if ((paramInt6 & 0x1) != 0) {
/*  298 */       i = abw.a(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*      */     }
/*      */ 
/*      */     
/*  302 */     boolean bool = abw.a(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF, paramInt4, paramInt5);
/*  303 */     this.C.a("checkLight");
/*  304 */     A(paramInt1, paramInt2, paramInt3);
/*  305 */     this.C.b();
/*      */     
/*  307 */     if (bool) {
/*  308 */       if ((paramInt6 & 0x2) != 0 && (!this.I || (paramInt6 & 0x4) == 0)) {
/*  309 */         j(paramInt1, paramInt2, paramInt3);
/*      */       }
/*  311 */       if (!this.I && (paramInt6 & 0x1) != 0) {
/*  312 */         d(paramInt1, paramInt2, paramInt3, i);
/*  313 */         apa apa = apa.r[paramInt4];
/*  314 */         if (apa != null && apa.q_()) m(paramInt1, paramInt2, paramInt3, paramInt4); 
/*      */       } 
/*      */     } 
/*  317 */     return bool;
/*      */   }
/*      */   
/*      */   public aif g(int paramInt1, int paramInt2, int paramInt3) {
/*  321 */     int i = a(paramInt1, paramInt2, paramInt3);
/*  322 */     if (i == 0) return aif.a; 
/*  323 */     return (apa.r[i]).cO;
/*      */   }
/*      */   
/*      */   public int h(int paramInt1, int paramInt2, int paramInt3) {
/*  327 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) {
/*  328 */       return 0;
/*      */     }
/*  330 */     if (paramInt2 < 0) return 0; 
/*  331 */     if (paramInt2 >= 256) return 0; 
/*  332 */     abw abw = e(paramInt1 >> 4, paramInt3 >> 4);
/*  333 */     paramInt1 &= 0xF;
/*  334 */     paramInt3 &= 0xF;
/*  335 */     return abw.c(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */   
/*      */   public boolean b(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  339 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) {
/*  340 */       return false;
/*      */     }
/*  342 */     if (paramInt2 < 0) return false; 
/*  343 */     if (paramInt2 >= 256) return false; 
/*  344 */     abw abw = e(paramInt1 >> 4, paramInt3 >> 4);
/*  345 */     int i = paramInt1 & 0xF;
/*  346 */     int j = paramInt3 & 0xF;
/*  347 */     boolean bool = abw.b(i, paramInt2, j, paramInt4);
/*      */     
/*  349 */     if (bool) {
/*  350 */       int k = abw.a(i, paramInt2, j);
/*  351 */       if ((paramInt5 & 0x2) != 0 && (!this.I || (paramInt5 & 0x4) == 0)) {
/*  352 */         j(paramInt1, paramInt2, paramInt3);
/*      */       }
/*  354 */       if (!this.I && (paramInt5 & 0x1) != 0) {
/*  355 */         d(paramInt1, paramInt2, paramInt3, k);
/*  356 */         apa apa = apa.r[k];
/*  357 */         if (apa != null && apa.q_()) m(paramInt1, paramInt2, paramInt3, k); 
/*      */       } 
/*      */     } 
/*  360 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean i(int paramInt1, int paramInt2, int paramInt3) {
/*  372 */     return f(paramInt1, paramInt2, paramInt3, 0, 0, 3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean a(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/*  386 */     int i = a(paramInt1, paramInt2, paramInt3);
/*  387 */     if (i > 0) {
/*  388 */       int j = h(paramInt1, paramInt2, paramInt3);
/*  389 */       e(2001, paramInt1, paramInt2, paramInt3, i + (j << 12));
/*  390 */       if (paramBoolean) {
/*  391 */         apa.r[i].c(this, paramInt1, paramInt2, paramInt3, j, 0);
/*      */       }
/*  393 */       return f(paramInt1, paramInt2, paramInt3, 0, 0, 3);
/*      */     } 
/*  395 */     return false;
/*      */   }
/*      */   
/*      */   public boolean c(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  399 */     return f(paramInt1, paramInt2, paramInt3, paramInt4, 0, 3);
/*      */   }
/*      */   
/*      */   public void j(int paramInt1, int paramInt2, int paramInt3) {
/*  403 */     for (byte b = 0; b < this.u.size(); b++) {
/*  404 */       ((aag)this.u.get(b)).a(paramInt1, paramInt2, paramInt3);
/*      */     }
/*      */   }
/*      */   
/*      */   public void d(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  409 */     f(paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public void e(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  413 */     if (paramInt3 > paramInt4) {
/*  414 */       int i = paramInt4;
/*  415 */       paramInt4 = paramInt3;
/*  416 */       paramInt3 = i;
/*      */     } 
/*  418 */     if (!this.t.f) {
/*  419 */       for (int i = paramInt3; i <= paramInt4; i++) {
/*  420 */         c(aam.a, paramInt1, i, paramInt2);
/*      */       }
/*      */     }
/*  423 */     g(paramInt1, paramInt3, paramInt2, paramInt1, paramInt4, paramInt2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void g(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  433 */     for (byte b = 0; b < this.u.size(); b++) {
/*  434 */       ((aag)this.u.get(b)).a(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6);
/*      */     }
/*      */   }
/*      */   
/*      */   public void f(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  439 */     g(paramInt1 - 1, paramInt2, paramInt3, paramInt4);
/*  440 */     g(paramInt1 + 1, paramInt2, paramInt3, paramInt4);
/*  441 */     g(paramInt1, paramInt2 - 1, paramInt3, paramInt4);
/*  442 */     g(paramInt1, paramInt2 + 1, paramInt3, paramInt4);
/*  443 */     g(paramInt1, paramInt2, paramInt3 - 1, paramInt4);
/*  444 */     g(paramInt1, paramInt2, paramInt3 + 1, paramInt4);
/*      */   }
/*      */   
/*      */   public void c(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  448 */     if (paramInt5 != 4) g(paramInt1 - 1, paramInt2, paramInt3, paramInt4); 
/*  449 */     if (paramInt5 != 5) g(paramInt1 + 1, paramInt2, paramInt3, paramInt4); 
/*  450 */     if (paramInt5 != 0) g(paramInt1, paramInt2 - 1, paramInt3, paramInt4); 
/*  451 */     if (paramInt5 != 1) g(paramInt1, paramInt2 + 1, paramInt3, paramInt4); 
/*  452 */     if (paramInt5 != 2) g(paramInt1, paramInt2, paramInt3 - 1, paramInt4); 
/*  453 */     if (paramInt5 != 3) g(paramInt1, paramInt2, paramInt3 + 1, paramInt4); 
/*      */   }
/*      */   
/*      */   public void g(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  457 */     if (this.I)
/*  458 */       return;  int i = a(paramInt1, paramInt2, paramInt3);
/*  459 */     apa apa = apa.r[i];
/*      */     
/*  461 */     if (apa != null) {
/*      */       try {
/*  463 */         apa.a(this, paramInt1, paramInt2, paramInt3, paramInt4);
/*  464 */       } catch (Throwable throwable) {
/*  465 */         byte b1; b b = b.a(throwable, "Exception while updating neighbours");
/*  466 */         m m = b.a("Block being updated");
/*      */ 
/*      */         
/*      */         try {
/*  470 */           b1 = h(paramInt1, paramInt2, paramInt3);
/*  471 */         } catch (Throwable throwable1) {
/*  472 */           b1 = -1;
/*      */         } 
/*      */         
/*  475 */         m.a("Source block type", new aac(this, paramInt4));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  485 */         m.a(m, paramInt1, paramInt2, paramInt3, i, b1);
/*      */         
/*  487 */         throw new u(b);
/*      */       } 
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  493 */     return false;
/*      */   }
/*      */   
/*      */   public boolean l(int paramInt1, int paramInt2, int paramInt3) {
/*  497 */     return e(paramInt1 >> 4, paramInt3 >> 4).d(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*      */   }
/*      */   
/*      */   public int m(int paramInt1, int paramInt2, int paramInt3) {
/*  501 */     if (paramInt2 < 0) return 0; 
/*  502 */     if (paramInt2 >= 256) paramInt2 = 255; 
/*  503 */     return e(paramInt1 >> 4, paramInt3 >> 4).c(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF, 0);
/*      */   }
/*      */   
/*      */   public int n(int paramInt1, int paramInt2, int paramInt3) {
/*  507 */     return b(paramInt1, paramInt2, paramInt3, true);
/*      */   }
/*      */   
/*      */   public int b(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/*  511 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) {
/*  512 */       return 15;
/*      */     }
/*      */     
/*  515 */     if (paramBoolean) {
/*  516 */       int i = a(paramInt1, paramInt2, paramInt3);
/*  517 */       if (apa.w[i]) {
/*  518 */         int j = b(paramInt1, paramInt2 + 1, paramInt3, false);
/*  519 */         int k = b(paramInt1 + 1, paramInt2, paramInt3, false);
/*  520 */         int m = b(paramInt1 - 1, paramInt2, paramInt3, false);
/*  521 */         int n = b(paramInt1, paramInt2, paramInt3 + 1, false);
/*  522 */         int i1 = b(paramInt1, paramInt2, paramInt3 - 1, false);
/*  523 */         if (k > j) j = k; 
/*  524 */         if (m > j) j = m; 
/*  525 */         if (n > j) j = n; 
/*  526 */         if (i1 > j) j = i1; 
/*  527 */         return j;
/*      */       } 
/*      */     } 
/*      */     
/*  531 */     if (paramInt2 < 0) return 0; 
/*  532 */     if (paramInt2 >= 256) paramInt2 = 255;
/*      */     
/*  534 */     abw abw = e(paramInt1 >> 4, paramInt3 >> 4);
/*  535 */     paramInt1 &= 0xF;
/*  536 */     paramInt3 &= 0xF;
/*  537 */     return abw.c(paramInt1, paramInt2, paramInt3, this.j);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int f(int paramInt1, int paramInt2) {
/*  556 */     if (paramInt1 < -30000000 || paramInt2 < -30000000 || paramInt1 >= 30000000 || paramInt2 >= 30000000) {
/*  557 */       return 0;
/*      */     }
/*  559 */     if (!c(paramInt1 >> 4, paramInt2 >> 4)) return 0;
/*      */     
/*  561 */     abw abw = e(paramInt1 >> 4, paramInt2 >> 4);
/*  562 */     return abw.b(paramInt1 & 0xF, paramInt2 & 0xF);
/*      */   }
/*      */   
/*      */   public int g(int paramInt1, int paramInt2) {
/*  566 */     if (paramInt1 < -30000000 || paramInt2 < -30000000 || paramInt1 >= 30000000 || paramInt2 >= 30000000) {
/*  567 */       return 0;
/*      */     }
/*  569 */     if (!c(paramInt1 >> 4, paramInt2 >> 4)) return 0;
/*      */     
/*  571 */     abw abw = e(paramInt1 >> 4, paramInt2 >> 4);
/*  572 */     return abw.p;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int a(aam paramaam, int paramInt1, int paramInt2, int paramInt3) {
/*  593 */     if (this.t.f && paramaam == aam.a) return 0;
/*      */     
/*  595 */     if (paramInt2 < 0) paramInt2 = 0; 
/*  596 */     if (paramInt2 >= 256) {
/*  597 */       return paramaam.c;
/*      */     }
/*  599 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) {
/*  600 */       return paramaam.c;
/*      */     }
/*  602 */     int i = paramInt1 >> 4;
/*  603 */     int j = paramInt3 >> 4;
/*  604 */     if (!c(i, j)) return paramaam.c;
/*      */     
/*  606 */     if (apa.w[a(paramInt1, paramInt2, paramInt3)]) {
/*  607 */       int k = b(paramaam, paramInt1, paramInt2 + 1, paramInt3);
/*  608 */       int m = b(paramaam, paramInt1 + 1, paramInt2, paramInt3);
/*  609 */       int n = b(paramaam, paramInt1 - 1, paramInt2, paramInt3);
/*  610 */       int i1 = b(paramaam, paramInt1, paramInt2, paramInt3 + 1);
/*  611 */       int i2 = b(paramaam, paramInt1, paramInt2, paramInt3 - 1);
/*  612 */       if (m > k) k = m; 
/*  613 */       if (n > k) k = n; 
/*  614 */       if (i1 > k) k = i1; 
/*  615 */       if (i2 > k) k = i2; 
/*  616 */       return k;
/*      */     } 
/*      */     
/*  619 */     abw abw = e(i, j);
/*  620 */     return abw.a(paramaam, paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*      */   }
/*      */   
/*      */   public int b(aam paramaam, int paramInt1, int paramInt2, int paramInt3) {
/*  624 */     if (paramInt2 < 0) paramInt2 = 0; 
/*  625 */     if (paramInt2 >= 256) paramInt2 = 255; 
/*  626 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) {
/*  627 */       return paramaam.c;
/*      */     }
/*  629 */     int i = paramInt1 >> 4;
/*  630 */     int j = paramInt3 >> 4;
/*  631 */     if (!c(i, j)) return paramaam.c; 
/*  632 */     abw abw = e(i, j);
/*  633 */     return abw.a(paramaam, paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*      */   }
/*      */   
/*      */   public void b(aam paramaam, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  637 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) {
/*      */       return;
/*      */     }
/*  640 */     if (paramInt2 < 0)
/*  641 */       return;  if (paramInt2 >= 256)
/*  642 */       return;  if (!c(paramInt1 >> 4, paramInt3 >> 4))
/*  643 */       return;  abw abw = e(paramInt1 >> 4, paramInt3 >> 4);
/*  644 */     abw.a(paramaam, paramInt1 & 0xF, paramInt2, paramInt3 & 0xF, paramInt4);
/*  645 */     for (byte b = 0; b < this.u.size(); b++) {
/*  646 */       ((aag)this.u.get(b)).b(paramInt1, paramInt2, paramInt3);
/*      */     }
/*      */   }
/*      */   
/*      */   public void p(int paramInt1, int paramInt2, int paramInt3) {
/*  651 */     for (byte b = 0; b < this.u.size(); b++) {
/*  652 */       ((aag)this.u.get(b)).b(paramInt1, paramInt2, paramInt3);
/*      */     }
/*      */   }
/*      */   
/*      */   public int h(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  657 */     int i = a(aam.a, paramInt1, paramInt2, paramInt3);
/*  658 */     int j = a(aam.b, paramInt1, paramInt2, paramInt3);
/*  659 */     if (j < paramInt4) j = paramInt4; 
/*  660 */     return i << 20 | j << 4;
/*      */   }
/*      */   
/*      */   public float i(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  664 */     int i = n(paramInt1, paramInt2, paramInt3);
/*  665 */     if (i < paramInt4) i = paramInt4; 
/*  666 */     return this.t.g[i];
/*      */   }
/*      */   
/*      */   public float q(int paramInt1, int paramInt2, int paramInt3) {
/*  670 */     return this.t.g[n(paramInt1, paramInt2, paramInt3)];
/*      */   }
/*      */   
/*      */   public boolean v() {
/*  674 */     return (this.j < 4);
/*      */   }
/*      */   
/*      */   public ara a(arc paramarc1, arc paramarc2) {
/*  678 */     return a(paramarc1, paramarc2, false, false);
/*      */   }
/*      */   
/*      */   public ara a(arc paramarc1, arc paramarc2, boolean paramBoolean) {
/*  682 */     return a(paramarc1, paramarc2, paramBoolean, false);
/*      */   }
/*      */   
/*      */   public ara a(arc paramarc1, arc paramarc2, boolean paramBoolean1, boolean paramBoolean2) {
/*  686 */     if (Double.isNaN(paramarc1.c) || Double.isNaN(paramarc1.d) || Double.isNaN(paramarc1.e)) return null; 
/*  687 */     if (Double.isNaN(paramarc2.c) || Double.isNaN(paramarc2.d) || Double.isNaN(paramarc2.e)) return null;
/*      */     
/*  689 */     int i = kx.c(paramarc2.c);
/*  690 */     int j = kx.c(paramarc2.d);
/*  691 */     int k = kx.c(paramarc2.e);
/*      */     
/*  693 */     int m = kx.c(paramarc1.c);
/*  694 */     int n = kx.c(paramarc1.d);
/*  695 */     int i1 = kx.c(paramarc1.e);
/*      */ 
/*      */     
/*  698 */     int i2 = a(m, n, i1);
/*  699 */     int i3 = h(m, n, i1);
/*  700 */     apa apa = apa.r[i2];
/*  701 */     if (!paramBoolean2 || apa == null || apa.b(this, m, n, i1) != null)
/*      */     {
/*      */       
/*  704 */       if (i2 > 0 && apa.a(i3, paramBoolean1)) {
/*  705 */         ara ara = apa.a(this, m, n, i1, paramarc1, paramarc2);
/*  706 */         if (ara != null) return ara;
/*      */       
/*      */       } 
/*      */     }
/*  710 */     i2 = 200;
/*  711 */     while (i2-- >= 0) {
/*  712 */       if (Double.isNaN(paramarc1.c) || Double.isNaN(paramarc1.d) || Double.isNaN(paramarc1.e)) return null; 
/*  713 */       if (m == i && n == j && i1 == k) return null;
/*      */       
/*  715 */       i3 = 1;
/*  716 */       boolean bool1 = true;
/*  717 */       boolean bool2 = true;
/*      */       
/*  719 */       double d1 = 999.0D;
/*  720 */       double d2 = 999.0D;
/*  721 */       double d3 = 999.0D;
/*      */       
/*  723 */       if (i > m) { d1 = m + 1.0D; }
/*  724 */       else if (i < m) { d1 = m + 0.0D; }
/*  725 */       else { i3 = 0; }
/*      */       
/*  727 */       if (j > n) { d2 = n + 1.0D; }
/*  728 */       else if (j < n) { d2 = n + 0.0D; }
/*  729 */       else { bool1 = false; }
/*      */       
/*  731 */       if (k > i1) { d3 = i1 + 1.0D; }
/*  732 */       else if (k < i1) { d3 = i1 + 0.0D; }
/*  733 */       else { bool2 = false; }
/*      */       
/*  735 */       double d4 = 999.0D;
/*  736 */       double d5 = 999.0D;
/*  737 */       double d6 = 999.0D;
/*      */       
/*  739 */       double d7 = paramarc2.c - paramarc1.c;
/*  740 */       double d8 = paramarc2.d - paramarc1.d;
/*  741 */       double d9 = paramarc2.e - paramarc1.e;
/*      */       
/*  743 */       if (i3 != 0) d4 = (d1 - paramarc1.c) / d7; 
/*  744 */       if (bool1) d5 = (d2 - paramarc1.d) / d8; 
/*  745 */       if (bool2) d6 = (d3 - paramarc1.e) / d9;
/*      */       
/*  747 */       byte b = 0;
/*  748 */       if (d4 < d5 && d4 < d6) {
/*  749 */         if (i > m) { b = 4; }
/*  750 */         else { b = 5; }
/*      */         
/*  752 */         paramarc1.c = d1;
/*  753 */         paramarc1.d += d8 * d4;
/*  754 */         paramarc1.e += d9 * d4;
/*  755 */       } else if (d5 < d6) {
/*  756 */         if (j > n) { b = 0; }
/*  757 */         else { b = 1; }
/*      */         
/*  759 */         paramarc1.c += d7 * d5;
/*  760 */         paramarc1.d = d2;
/*  761 */         paramarc1.e += d9 * d5;
/*      */       } else {
/*  763 */         if (k > i1) { b = 2; }
/*  764 */         else { b = 3; }
/*      */         
/*  766 */         paramarc1.c += d7 * d6;
/*  767 */         paramarc1.d += d8 * d6;
/*  768 */         paramarc1.e = d3;
/*      */       } 
/*      */       
/*  771 */       arc arc1 = U().a(paramarc1.c, paramarc1.d, paramarc1.e);
/*  772 */       m = (int)(arc1.c = kx.c(paramarc1.c));
/*  773 */       if (b == 5) {
/*  774 */         m--;
/*  775 */         arc1.c++;
/*      */       } 
/*  777 */       n = (int)(arc1.d = kx.c(paramarc1.d));
/*  778 */       if (b == 1) {
/*  779 */         n--;
/*  780 */         arc1.d++;
/*      */       } 
/*  782 */       i1 = (int)(arc1.e = kx.c(paramarc1.e));
/*  783 */       if (b == 3) {
/*  784 */         i1--;
/*  785 */         arc1.e++;
/*      */       } 
/*      */       
/*  788 */       int i4 = a(m, n, i1);
/*  789 */       int i5 = h(m, n, i1);
/*  790 */       apa apa1 = apa.r[i4];
/*  791 */       if (paramBoolean2 && apa1 != null && apa1.b(this, m, n, i1) == null) {
/*      */         continue;
/*      */       }
/*  794 */       if (i4 > 0 && apa1.a(i5, paramBoolean1)) {
/*  795 */         ara ara = apa1.a(this, m, n, i1, paramarc1, paramarc2);
/*  796 */         if (ara != null) return ara; 
/*      */       } 
/*      */     } 
/*  799 */     return null;
/*      */   }
/*      */   
/*      */   public void a(mp parammp, String paramString, float paramFloat1, float paramFloat2) {
/*  803 */     if (parammp == null || paramString == null)
/*  804 */       return;  for (byte b = 0; b < this.u.size(); b++) {
/*  805 */       ((aag)this.u.get(b)).a(paramString, parammp.u, parammp.v - parammp.N, parammp.w, paramFloat1, paramFloat2);
/*      */     }
/*      */   }
/*      */   
/*      */   public void a(sq paramsq, String paramString, float paramFloat1, float paramFloat2) {
/*  810 */     if (paramsq == null || paramString == null)
/*  811 */       return;  for (byte b = 0; b < this.u.size(); b++) {
/*  812 */       ((aag)this.u.get(b)).a(paramsq, paramString, paramsq.u, paramsq.v - paramsq.N, paramsq.w, paramFloat1, paramFloat2);
/*      */     }
/*      */   }
/*      */   
/*      */   public void a(double paramDouble1, double paramDouble2, double paramDouble3, String paramString, float paramFloat1, float paramFloat2) {
/*  817 */     if (paramString == null)
/*  818 */       return;  for (byte b = 0; b < this.u.size(); b++) {
/*  819 */       ((aag)this.u.get(b)).a(paramString, paramDouble1, paramDouble2, paramDouble3, paramFloat1, paramFloat2);
/*      */     }
/*      */   }
/*      */ 
/*      */   
/*      */   public void a(double paramDouble1, double paramDouble2, double paramDouble3, String paramString, float paramFloat1, float paramFloat2, boolean paramBoolean) {}
/*      */   
/*      */   public void a(String paramString, int paramInt1, int paramInt2, int paramInt3) {
/*  827 */     for (byte b = 0; b < this.u.size(); b++) {
/*  828 */       ((aag)this.u.get(b)).a(paramString, paramInt1, paramInt2, paramInt3);
/*      */     }
/*      */   }
/*      */   
/*      */   public void a(String paramString, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6) {
/*  833 */     for (byte b = 0; b < this.u.size(); b++)
/*  834 */       ((aag)this.u.get(b)).a(paramString, paramDouble1, paramDouble2, paramDouble3, paramDouble4, paramDouble5, paramDouble6); 
/*      */   }
/*      */   
/*      */   public boolean c(mp parammp) {
/*  838 */     this.i.add(parammp);
/*  839 */     return true;
/*      */   }
/*      */   
/*      */   public boolean d(mp parammp) {
/*  843 */     int i = kx.c(parammp.u / 16.0D);
/*  844 */     int j = kx.c(parammp.w / 16.0D);
/*      */     
/*  846 */     boolean bool = parammp.p;
/*  847 */     if (parammp instanceof sq) {
/*  848 */       bool = true;
/*      */     }
/*      */     
/*  851 */     if (bool || c(i, j)) {
/*  852 */       if (parammp instanceof sq) {
/*  853 */         sq sq = (sq)parammp;
/*  854 */         this.h.add(sq);
/*  855 */         c();
/*      */       } 
/*  857 */       e(i, j).a(parammp);
/*  858 */       this.e.add(parammp);
/*  859 */       a(parammp);
/*  860 */       return true;
/*      */     } 
/*  862 */     return false;
/*      */   }
/*      */   
/*      */   protected void a(mp parammp) {
/*  866 */     for (byte b = 0; b < this.u.size(); b++) {
/*  867 */       ((aag)this.u.get(b)).a(parammp);
/*      */     }
/*      */   }
/*      */   
/*      */   protected void b(mp parammp) {
/*  872 */     for (byte b = 0; b < this.u.size(); b++) {
/*  873 */       ((aag)this.u.get(b)).b(parammp);
/*      */     }
/*      */   }
/*      */   
/*      */   public void e(mp parammp) {
/*  878 */     if (parammp.n != null) {
/*  879 */       parammp.n.a((mp)null);
/*      */     }
/*  881 */     if (parammp.o != null) {
/*  882 */       parammp.a((mp)null);
/*      */     }
/*  884 */     parammp.w();
/*  885 */     if (parammp instanceof sq) {
/*  886 */       this.h.remove(parammp);
/*  887 */       c();
/*      */     } 
/*      */   }
/*      */   
/*      */   public void f(mp parammp) {
/*  892 */     parammp.w();
/*      */     
/*  894 */     if (parammp instanceof sq) {
/*  895 */       this.h.remove(parammp);
/*  896 */       c();
/*      */     } 
/*      */     
/*  899 */     int i = parammp.aj;
/*  900 */     int j = parammp.al;
/*  901 */     if (parammp.ai && c(i, j)) {
/*  902 */       e(i, j).b(parammp);
/*      */     }
/*      */     
/*  905 */     this.e.remove(parammp);
/*  906 */     b(parammp);
/*      */   }
/*      */   
/*      */   public void a(aag paramaag) {
/*  910 */     this.u.add(paramaag);
/*      */   }
/*      */   
/*      */   public void b(aag paramaag) {
/*  914 */     this.u.remove(paramaag);
/*      */   }
/*      */   
/*  917 */   public aab(akf paramakf, String paramString, acn paramacn, aai paramaai, la paramla, ku paramku) { this.M = new ArrayList();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1745 */     this.E = true;
/* 1746 */     this.F = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1830 */     this.G = new HashSet();
/*      */     
/* 1832 */     this.O = this.s.nextInt(12000);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1955 */     this.H = new int[32768];
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2076 */     this.I = false; this.w = paramakf; this.C = paramla; this.x = new ajv(paramaai, paramString); this.t = paramacn; this.z = new aku(paramakf); this.L = paramku; qe qe1 = (qe)this.z.a(qe.class, "villages"); if (qe1 == null) { this.A = new qe(this); this.z.a("villages", this.A); } else { this.A = qe1; this.A.a(this); }  paramacn.a(this); this.v = j(); z(); a(); } public aab(akf paramakf, String paramString, aai paramaai, acn paramacn, la paramla, ku paramku) { this.M = new ArrayList(); this.E = true; this.F = true; this.G = new HashSet(); this.O = this.s.nextInt(12000); this.H = new int[32768]; this.I = false; this.w = paramakf; this.C = paramla; this.z = new aku(paramakf); this.L = paramku; this.x = paramakf.d(); if (paramacn != null) { this.t = paramacn; } else if (this.x != null && this.x.j() != 0) { this.t = acn.a(this.x.j()); } else { this.t = acn.a(0); }  if (this.x == null) { this.x = new ajv(paramaai, paramString); } else { this.x.a(paramString); }  this.t.a(this); this.v = j(); if (!this.x.w()) { try { a(paramaai); } catch (Throwable throwable) { b b = b.a(throwable, "Exception initializing level"); try { a(b); } catch (Throwable throwable1) {} throw new u(b); }  this.x.d(true); }  qe qe1 = (qe)this.z.a(qe.class, "villages"); if (qe1 == null) { this.A = new qe(this); this.z.a("villages", this.A); } else { this.A = qe1; this.A.a(this); }  z(); a(); }
/*      */   public List a(mp parammp, aqx paramaqx) { this.M.clear(); int i = kx.c(paramaqx.a); int j = kx.c(paramaqx.d + 1.0D); int k = kx.c(paramaqx.b); int m = kx.c(paramaqx.e + 1.0D); int n = kx.c(paramaqx.c); int i1 = kx.c(paramaqx.f + 1.0D); for (int i2 = i; i2 < j; i2++) { for (int i3 = n; i3 < i1; i3++) { if (f(i2, 64, i3)) for (int i4 = k - 1; i4 < m; i4++) { apa apa = apa.r[a(i2, i4, i3)]; if (apa != null) apa.a(this, i2, i4, i3, paramaqx, this.M, parammp);  }   }  }  double d = 0.25D; List<mp> list = b(parammp, paramaqx.b(d, d, d)); for (byte b = 0; b < list.size(); b++) { aqx aqx1 = ((mp)list.get(b)).D(); if (aqx1 != null && aqx1.a(paramaqx)) this.M.add(aqx1);  aqx1 = parammp.g(list.get(b)); if (aqx1 != null && aqx1.a(paramaqx)) this.M.add(aqx1);  }  return this.M; }
/*      */   public List a(aqx paramaqx) { this.M.clear(); int i = kx.c(paramaqx.a); int j = kx.c(paramaqx.d + 1.0D); int k = kx.c(paramaqx.b); int m = kx.c(paramaqx.e + 1.0D); int n = kx.c(paramaqx.c); int i1 = kx.c(paramaqx.f + 1.0D); for (int i2 = i; i2 < j; i2++) { for (int i3 = n; i3 < i1; i3++) { if (f(i2, 64, i3)) for (int i4 = k - 1; i4 < m; i4++) { apa apa = apa.r[a(i2, i4, i3)]; if (apa != null) apa.a(this, i2, i4, i3, paramaqx, this.M, (mp)null);  }   }  }  return this.M; }
/* 2079 */   public int a(float paramFloat) { float f1 = c(paramFloat); float f2 = 1.0F - kx.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.5F; if (f2 < 0.0F) f2 = 0.0F;  if (f2 > 1.0F) f2 = 1.0F;  f2 = 1.0F - f2; f2 = (float)(f2 * (1.0D - (i(paramFloat) * 5.0F) / 16.0D)); f2 = (float)(f2 * (1.0D - (h(paramFloat) * 5.0F) / 16.0D)); f2 = 1.0F - f2; return (int)(f2 * 11.0F); } public float b(float paramFloat) { float f1 = c(paramFloat); float f2 = 1.0F - kx.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.2F; if (f2 < 0.0F) f2 = 0.0F;  if (f2 > 1.0F) f2 = 1.0F;  f2 = 1.0F - f2; f2 = (float)(f2 * (1.0D - (i(paramFloat) * 5.0F) / 16.0D)); f2 = (float)(f2 * (1.0D - (h(paramFloat) * 5.0F) / 16.0D)); return f2 * 0.8F + 0.2F; } public arc a(mp parammp, float paramFloat) { float f1 = c(paramFloat); float f2 = kx.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.5F; if (f2 < 0.0F) f2 = 0.0F;  if (f2 > 1.0F) f2 = 1.0F;  int i = kx.c(parammp.u); int j = kx.c(parammp.w); aav aav = a(i, j); float f3 = aav.j(); int k = aav.a(f3); float f4 = (k >> 16 & 0xFF) / 255.0F; float f5 = (k >> 8 & 0xFF) / 255.0F; float f6 = (k & 0xFF) / 255.0F; f4 *= f2; f5 *= f2; f6 *= f2; float f7 = i(paramFloat); if (f7 > 0.0F) { float f9 = (f4 * 0.3F + f5 * 0.59F + f6 * 0.11F) * 0.6F; float f10 = 1.0F - f7 * 0.75F; f4 = f4 * f10 + f9 * (1.0F - f10); f5 = f5 * f10 + f9 * (1.0F - f10); f6 = f6 * f10 + f9 * (1.0F - f10); }  float f8 = h(paramFloat); if (f8 > 0.0F) { float f9 = (f4 * 0.3F + f5 * 0.59F + f6 * 0.11F) * 0.2F; float f10 = 1.0F - f8 * 0.75F; f4 = f4 * f10 + f9 * (1.0F - f10); f5 = f5 * f10 + f9 * (1.0F - f10); f6 = f6 * f10 + f9 * (1.0F - f10); }  if (this.q > 0) { float f = this.q - paramFloat; if (f > 1.0F) f = 1.0F;  f *= 0.45F; f4 = f4 * (1.0F - f) + 0.8F * f; f5 = f5 * (1.0F - f) + 0.8F * f; f6 = f6 * (1.0F - f) + 1.0F * f; }  return U().a(f4, f5, f6); } public float c(float paramFloat) { return this.t.a(this.x.g(), paramFloat); } public int w() { return this.t.a(this.x.g()); } public float d(float paramFloat) { float f = c(paramFloat); return f * 3.1415927F * 2.0F; } public arc e(float paramFloat) { float f1 = c(paramFloat); float f2 = kx.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.5F; if (f2 < 0.0F) f2 = 0.0F;  if (f2 > 1.0F) f2 = 1.0F;  float f3 = (float)(this.c >> 16L & 0xFFL) / 255.0F; float f4 = (float)(this.c >> 8L & 0xFFL) / 255.0F; float f5 = (float)(this.c & 0xFFL) / 255.0F; float f6 = i(paramFloat); if (f6 > 0.0F) { float f8 = (f3 * 0.3F + f4 * 0.59F + f5 * 0.11F) * 0.6F; float f9 = 1.0F - f6 * 0.95F; f3 = f3 * f9 + f8 * (1.0F - f9); f4 = f4 * f9 + f8 * (1.0F - f9); f5 = f5 * f9 + f8 * (1.0F - f9); }  f3 *= f2 * 0.9F + 0.1F; f4 *= f2 * 0.9F + 0.1F; f5 *= f2 * 0.85F + 0.15F; float f7 = h(paramFloat); if (f7 > 0.0F) { float f8 = (f3 * 0.3F + f4 * 0.59F + f5 * 0.11F) * 0.2F; float f9 = 1.0F - f7 * 0.95F; f3 = f3 * f9 + f8 * (1.0F - f9); f4 = f4 * f9 + f8 * (1.0F - f9); f5 = f5 * f9 + f8 * (1.0F - f9); }  return U().a(f3, f4, f5); } public arc f(float paramFloat) { float f = c(paramFloat); return this.t.b(f, paramFloat); } public int h(int paramInt1, int paramInt2) { return d(paramInt1, paramInt2).d(paramInt1 & 0xF, paramInt2 & 0xF); } public int i(int paramInt1, int paramInt2) { abw abw = d(paramInt1, paramInt2); int i = abw.h() + 15; paramInt1 &= 0xF; paramInt2 &= 0xF; while (i > 0) { int j = abw.a(paramInt1, i, paramInt2); if (j == 0 || !(apa.r[j]).cO.c() || (apa.r[j]).cO == aif.j) { i--; continue; }  return i + 1; }  return -1; } public float g(float paramFloat) { float f1 = c(paramFloat); float f2 = 1.0F - kx.b(f1 * 3.1415927F * 2.0F) * 2.0F + 0.25F; if (f2 < 0.0F) f2 = 0.0F;  if (f2 > 1.0F) f2 = 1.0F;  return f2 * f2 * 0.5F; } public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {} public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {} public void b(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {} public void h() { this.C.a("entities"); this.C.a("global"); byte b; for (b = 0; b < this.i.size(); b++) { mp mp = this.i.get(b); try { mp.ac++; mp.l_(); } catch (Throwable throwable) { b b1 = b.a(throwable, "Ticking entity"); m m = b1.a("Entity being ticked"); if (mp == null) { m.a("Entity", "~~NULL~~"); } else { mp.a(m); }  throw new u(b1); }  if (mp.M) this.i.remove(b--);  }  this.C.c("remove"); this.e.removeAll(this.f); for (b = 0; b < this.f.size(); b++) { mp mp = this.f.get(b); int i = mp.aj; int j = mp.al; if (mp.ai && c(i, j)) e(i, j).b(mp);  }  for (b = 0; b < this.f.size(); b++) b(this.f.get(b));  this.f.clear(); this.C.c("regular"); for (b = 0; b < this.e.size(); b++) { mp mp = this.e.get(b); if (mp.o != null) if (mp.o.M || mp.o.n != mp) { mp.o.n = null; mp.o = null; } else { continue; }   this.C.a("tick"); if (!mp.M) try { g(mp); } catch (Throwable throwable) { b b1 = b.a(throwable, "Ticking entity"); m m = b1.a("Entity being ticked"); mp.a(m); throw new u(b1); }   this.C.b(); this.C.a("remove"); if (mp.M) { int i = mp.aj; int j = mp.al; if (mp.ai && c(i, j)) e(i, j).b(mp);  this.e.remove(b--); b(mp); }  this.C.b(); continue; }  this.C.c("tileEntities"); this.N = true; Iterator<aqp> iterator = this.g.iterator(); while (iterator.hasNext()) { aqp aqp = iterator.next(); if (!aqp.r() && aqp.o() && f(aqp.l, aqp.m, aqp.n)) try { aqp.h(); } catch (Throwable throwable) { b b1 = b.a(throwable, "Ticking tile entity"); m m = b1.a("Tile entity being ticked"); aqp.a(m); throw new u(b1); }   if (aqp.r()) { iterator.remove(); if (c(aqp.l >> 4, aqp.n >> 4)) { abw abw = e(aqp.l >> 4, aqp.n >> 4); if (abw != null) abw.f(aqp.l & 0xF, aqp.m, aqp.n & 0xF);  }  }  }  this.N = false; if (!this.b.isEmpty()) { this.g.removeAll(this.b); this.b.clear(); }  this.C.c("pendingTileEntities"); if (!this.a.isEmpty()) { for (byte b1 = 0; b1 < this.a.size(); b1++) { aqp aqp = this.a.get(b1); if (!aqp.r()) { if (!this.g.contains(aqp)) this.g.add(aqp);  if (c(aqp.l >> 4, aqp.n >> 4)) { abw abw = e(aqp.l >> 4, aqp.n >> 4); if (abw != null) abw.a(aqp.l & 0xF, aqp.m, aqp.n & 0xF, aqp);  }  j(aqp.l, aqp.m, aqp.n); }  }  this.a.clear(); }  this.C.b(); this.C.b(); } public void a(Collection paramCollection) { if (this.N) { this.a.addAll(paramCollection); } else { this.g.addAll(paramCollection); }  } public void g(mp parammp) { a(parammp, true); } public void a(mp parammp, boolean paramBoolean) { int i = kx.c(parammp.u); int j = kx.c(parammp.w); byte b = 32; if (paramBoolean && !e(i - b, 0, j - b, i + b, 0, j + b)) return;  parammp.U = parammp.u; parammp.V = parammp.v; parammp.W = parammp.w; parammp.C = parammp.A; parammp.D = parammp.B; if (paramBoolean && parammp.ai) if (parammp.o != null) { parammp.T(); } else { parammp.ac++; parammp.l_(); }   this.C.a("chunkCheck"); if (Double.isNaN(parammp.u) || Double.isInfinite(parammp.u)) parammp.u = parammp.U;  if (Double.isNaN(parammp.v) || Double.isInfinite(parammp.v)) parammp.v = parammp.V;  if (Double.isNaN(parammp.w) || Double.isInfinite(parammp.w)) parammp.w = parammp.W;  if (Double.isNaN(parammp.B) || Double.isInfinite(parammp.B)) parammp.B = parammp.D;  if (Double.isNaN(parammp.A) || Double.isInfinite(parammp.A)) parammp.A = parammp.C;  int k = kx.c(parammp.u / 16.0D); int m = kx.c(parammp.v / 16.0D); int n = kx.c(parammp.w / 16.0D); if (!parammp.ai || parammp.aj != k || parammp.ak != m || parammp.al != n) { if (parammp.ai && c(parammp.aj, parammp.al)) e(parammp.aj, parammp.al).a(parammp, parammp.ak);  if (c(k, n)) { parammp.ai = true; e(k, n).a(parammp); } else { parammp.ai = false; }  }  this.C.b(); if (paramBoolean && parammp.ai && parammp.n != null) if (parammp.n.M || parammp.n.o != parammp) { parammp.n.o = null; parammp.n = null; } else { g(parammp.n); }   } public boolean b(aqx paramaqx) { return a(paramaqx, (mp)null); } public boolean a(aqx paramaqx, mp parammp) { List<mp> list = b((mp)null, paramaqx); for (byte b = 0; b < list.size(); b++) { mp mp1 = list.get(b); if (!mp1.M && mp1.m && mp1 != parammp) return false;  }  return true; } public boolean c(aqx paramaqx) { int i = kx.c(paramaqx.a); int j = kx.c(paramaqx.d + 1.0D); int k = kx.c(paramaqx.b); int m = kx.c(paramaqx.e + 1.0D); int n = kx.c(paramaqx.c); int i1 = kx.c(paramaqx.f + 1.0D); if (paramaqx.a < 0.0D) i--;  if (paramaqx.b < 0.0D) k--;  if (paramaqx.c < 0.0D) n--;  for (int i2 = i; i2 < j; i2++) { for (int i3 = k; i3 < m; i3++) { for (int i4 = n; i4 < i1; i4++) { apa apa = apa.r[a(i2, i3, i4)]; if (apa != null) return true;  }  }  }  return false; } public boolean d(aqx paramaqx) { int i = kx.c(paramaqx.a); int j = kx.c(paramaqx.d + 1.0D); int k = kx.c(paramaqx.b); int m = kx.c(paramaqx.e + 1.0D); int n = kx.c(paramaqx.c); int i1 = kx.c(paramaqx.f + 1.0D); if (paramaqx.a < 0.0D) i--;  if (paramaqx.b < 0.0D) k--;  if (paramaqx.c < 0.0D) n--;  for (int i2 = i; i2 < j; i2++) { for (int i3 = k; i3 < m; i3++) { for (int i4 = n; i4 < i1; i4++) { apa apa = apa.r[a(i2, i3, i4)]; if (apa != null && apa.cO.d()) return true;  }  }  }  return false; } public boolean e(aqx paramaqx) { int i = kx.c(paramaqx.a); int j = kx.c(paramaqx.d + 1.0D); int k = kx.c(paramaqx.b); int m = kx.c(paramaqx.e + 1.0D); int n = kx.c(paramaqx.c); int i1 = kx.c(paramaqx.f + 1.0D); if (e(i, k, n, j, m, i1)) for (int i2 = i; i2 < j; i2++) { for (int i3 = k; i3 < m; i3++) { for (int i4 = n; i4 < i1; i4++) { int i5 = a(i2, i3, i4); if (i5 == apa.av.cz || i5 == apa.G.cz || i5 == apa.H.cz) return true;  }  }  }   return false; } public boolean a(aqx paramaqx, aif paramaif, mp parammp) { int i = kx.c(paramaqx.a); int j = kx.c(paramaqx.d + 1.0D); int k = kx.c(paramaqx.b); int m = kx.c(paramaqx.e + 1.0D); int n = kx.c(paramaqx.c); int i1 = kx.c(paramaqx.f + 1.0D); if (!e(i, k, n, j, m, i1)) return false;  boolean bool = false; arc arc = U().a(0.0D, 0.0D, 0.0D); for (int i2 = i; i2 < j; i2++) { for (int i3 = k; i3 < m; i3++) { for (int i4 = n; i4 < i1; i4++) { apa apa = apa.r[a(i2, i3, i4)]; if (apa != null && apa.cO == paramaif) { double d = ((i3 + 1) - ane.d(h(i2, i3, i4))); if (m >= d) { bool = true; apa.a(this, i2, i3, i4, parammp, arc); }  }  }  }  }  if (arc.b() > 0.0D && parammp.aw()) { arc = arc.a(); double d = 0.014D; parammp.x += arc.c * d; parammp.y += arc.d * d; parammp.z += arc.e * d; }  return bool; } public boolean a(aqx paramaqx, aif paramaif) { int i = kx.c(paramaqx.a); int j = kx.c(paramaqx.d + 1.0D); int k = kx.c(paramaqx.b); int m = kx.c(paramaqx.e + 1.0D); int n = kx.c(paramaqx.c); int i1 = kx.c(paramaqx.f + 1.0D); for (int i2 = i; i2 < j; i2++) { for (int i3 = k; i3 < m; i3++) { for (int i4 = n; i4 < i1; i4++) { apa apa = apa.r[a(i2, i3, i4)]; if (apa != null && apa.cO == paramaif) return true;  }  }  }  return false; } public boolean b(aqx paramaqx, aif paramaif) { int i = kx.c(paramaqx.a); int j = kx.c(paramaqx.d + 1.0D); int k = kx.c(paramaqx.b); int m = kx.c(paramaqx.e + 1.0D); int n = kx.c(paramaqx.c); int i1 = kx.c(paramaqx.f + 1.0D); for (int i2 = i; i2 < j; i2++) { for (int i3 = k; i3 < m; i3++) { for (int i4 = n; i4 < i1; i4++) { apa apa = apa.r[a(i2, i3, i4)]; if (apa != null && apa.cO == paramaif) { int i5 = h(i2, i3, i4); double d = (i3 + 1); if (i5 < 8) d = (i3 + 1) - i5 / 8.0D;  if (d >= paramaqx.b) return true;  }  }  }  }  return false; } public zw a(mp parammp, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat, boolean paramBoolean) { return a(parammp, paramDouble1, paramDouble2, paramDouble3, paramFloat, false, paramBoolean); } public zw a(mp parammp, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat, boolean paramBoolean1, boolean paramBoolean2) { zw zw = new zw(this, parammp, paramDouble1, paramDouble2, paramDouble3, paramFloat); zw.a = paramBoolean1; zw.b = paramBoolean2; zw.a(); zw.a(true); return zw; } public float a(arc paramarc, aqx paramaqx) { double d1 = 1.0D / ((paramaqx.d - paramaqx.a) * 2.0D + 1.0D); double d2 = 1.0D / ((paramaqx.e - paramaqx.b) * 2.0D + 1.0D); double d3 = 1.0D / ((paramaqx.f - paramaqx.c) * 2.0D + 1.0D); byte b1 = 0; byte b2 = 0; float f; for (f = 0.0F; f <= 1.0F; f = (float)(f + d1)) { float f1; for (f1 = 0.0F; f1 <= 1.0F; f1 = (float)(f1 + d2)) { float f2; for (f2 = 0.0F; f2 <= 1.0F; f2 = (float)(f2 + d3)) { double d4 = paramaqx.a + (paramaqx.d - paramaqx.a) * f; double d5 = paramaqx.b + (paramaqx.e - paramaqx.b) * f1; double d6 = paramaqx.c + (paramaqx.f - paramaqx.c) * f2; if (a(U().a(d4, d5, d6), paramarc) == null) b1++;  b2++; }  }  }  return b1 / b2; } public List b(mp parammp, aqx paramaqx) { return a(parammp, paramaqx, (my)null); }
/*      */   public boolean a(sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { if (paramInt4 == 0) paramInt2--;  if (paramInt4 == 1) paramInt2++;  if (paramInt4 == 2) paramInt3--;  if (paramInt4 == 3) paramInt3++;  if (paramInt4 == 4) paramInt1--;  if (paramInt4 == 5) paramInt1++;  if (a(paramInt1, paramInt2, paramInt3) == apa.av.cz) { a(paramsq, 1004, paramInt1, paramInt2, paramInt3, 0); i(paramInt1, paramInt2, paramInt3); return true; }  return false; }
/*      */   public String x() { return "All: " + this.e.size(); }
/*      */   public String y() { return this.v.e(); }
/* 2083 */   public aqp r(int paramInt1, int paramInt2, int paramInt3) { if (paramInt2 < 0 || paramInt2 >= 256) return null;  aqp aqp = null; if (this.N) for (byte b = 0; b < this.a.size(); b++) { aqp aqp1 = this.a.get(b); if (!aqp1.r() && aqp1.l == paramInt1 && aqp1.m == paramInt2 && aqp1.n == paramInt3) { aqp = aqp1; break; }  }   if (aqp == null) { abw abw = e(paramInt1 >> 4, paramInt3 >> 4); if (abw != null) aqp = abw.e(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);  }  if (aqp == null) for (byte b = 0; b < this.a.size(); b++) { aqp aqp1 = this.a.get(b); if (!aqp1.r() && aqp1.l == paramInt1 && aqp1.m == paramInt2 && aqp1.n == paramInt3) { aqp = aqp1; break; }  }   return aqp; } public void a(int paramInt1, int paramInt2, int paramInt3, aqp paramaqp) { if (paramaqp != null && !paramaqp.r()) if (this.N) { paramaqp.l = paramInt1; paramaqp.m = paramInt2; paramaqp.n = paramInt3; Iterator<aqp> iterator = this.a.iterator(); while (iterator.hasNext()) { aqp aqp1 = iterator.next(); if (aqp1.l == paramInt1 && aqp1.m == paramInt2 && aqp1.n == paramInt3) { aqp1.w_(); iterator.remove(); }  }  this.a.add(paramaqp); } else { this.g.add(paramaqp); abw abw = e(paramInt1 >> 4, paramInt3 >> 4); if (abw != null) abw.a(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF, paramaqp);  }   } public void s(int paramInt1, int paramInt2, int paramInt3) { aqp aqp = r(paramInt1, paramInt2, paramInt3); if (aqp != null && this.N) { aqp.w_(); this.a.remove(aqp); } else { if (aqp != null) { this.a.remove(aqp); this.g.remove(aqp); }  abw abw = e(paramInt1 >> 4, paramInt3 >> 4); if (abw != null) abw.f(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);  }  } public void a(aqp paramaqp) { this.b.add(paramaqp); } public boolean t(int paramInt1, int paramInt2, int paramInt3) { apa apa = apa.r[a(paramInt1, paramInt2, paramInt3)]; if (apa == null) return false;  return apa.c(); } public boolean u(int paramInt1, int paramInt2, int paramInt3) { return apa.l(a(paramInt1, paramInt2, paramInt3)); } public boolean v(int paramInt1, int paramInt2, int paramInt3) { int i = a(paramInt1, paramInt2, paramInt3); if (i == 0 || apa.r[i] == null) return false;  aqx aqx = apa.r[i].b(this, paramInt1, paramInt2, paramInt3); return (aqx != null && aqx.b() >= 1.0D); } public boolean w(int paramInt1, int paramInt2, int paramInt3) { apa apa = apa.r[a(paramInt1, paramInt2, paramInt3)]; return a(apa, h(paramInt1, paramInt2, paramInt3)); } public boolean a(apa paramapa, int paramInt) { if (paramapa == null) return false;  if (paramapa.cO.k() && paramapa.b()) return true;  if (paramapa instanceof aoq) return ((paramInt & 0x4) == 4);  if (paramapa instanceof amr) return ((paramInt & 0x8) == 8);  if (paramapa instanceof amw) return true;  if (paramapa instanceof apg) return ((paramInt & 0x7) == 7);  return false; } public boolean c(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) { if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 >= 30000000) return paramBoolean;  abw abw = this.v.d(paramInt1 >> 4, paramInt3 >> 4); if (abw == null || abw.g()) return paramBoolean;  apa apa = apa.r[a(paramInt1, paramInt2, paramInt3)]; if (apa == null) return false;  return (apa.cO.k() && apa.b()); } public void z() { int i = a(1.0F); if (i != this.j) this.j = i;  } public void a(boolean paramBoolean1, boolean paramBoolean2) { this.E = paramBoolean1; this.F = paramBoolean2; } public void b() { o(); } private void a() { if (this.x.p()) { this.n = 1.0F; if (this.x.n()) this.p = 1.0F;  }  } protected void o() { if (this.t.f) return;  int i = this.x.o(); if (i <= 0) { if (this.x.n()) { this.x.f(this.s.nextInt(12000) + 3600); } else { this.x.f(this.s.nextInt(168000) + 12000); }  } else { i--; this.x.f(i); if (i <= 0) this.x.a(!this.x.n());  }  int j = this.x.q(); if (j <= 0) { if (this.x.p()) { this.x.g(this.s.nextInt(12000) + 12000); } else { this.x.g(this.s.nextInt(168000) + 12000); }  } else { j--; this.x.g(j); if (j <= 0) this.x.b(!this.x.p());  }  this.m = this.n; if (this.x.p()) { this.n = (float)(this.n + 0.01D); } else { this.n = (float)(this.n - 0.01D); }  if (this.n < 0.0F) this.n = 0.0F;  if (this.n > 1.0F) this.n = 1.0F;  this.o = this.p; if (this.x.n()) { this.p = (float)(this.p + 0.01D); } else { this.p = (float)(this.p - 0.01D); }  if (this.p < 0.0F) this.p = 0.0F;  if (this.p > 1.0F) this.p = 1.0F;  } public void A() { this.x.g(1); } protected void B() { this.G.clear(); this.C.a("buildList"); int i; for (i = 0; i < this.h.size(); i++) { sq sq = this.h.get(i); int j = kx.c(sq.u / 16.0D); int k = kx.c(sq.w / 16.0D); byte b1 = 7; for (byte b2 = -b1; b2 <= b1; b2++) { for (byte b = -b1; b <= b1; b++) this.G.add(new zu(b2 + j, b + k));  }  }  this.C.b(); if (this.O > 0) this.O--;  this.C.a("playerCheckLight"); if (!this.h.isEmpty()) { i = this.s.nextInt(this.h.size()); sq sq = this.h.get(i); int j = kx.c(sq.u) + this.s.nextInt(11) - 5; int k = kx.c(sq.v) + this.s.nextInt(11) - 5; int m = kx.c(sq.w) + this.s.nextInt(11) - 5; A(j, k, m); }  this.C.b(); } protected void a(int paramInt1, int paramInt2, abw paramabw) { this.C.c("moodSound"); if (this.O == 0 && !this.I) { this.k = this.k * 3 + 1013904223; int i = this.k >> 2; int j = i & 0xF; int k = i >> 8 & 0xF; int m = i >> 16 & 0x7F; int n = paramabw.a(j, m, k); j += paramInt1; k += paramInt2; if (n == 0 && m(j, m, k) <= this.s.nextInt(8) && b(aam.a, j, m, k) <= 0) { sq sq = a(j + 0.5D, m + 0.5D, k + 0.5D, 8.0D); if (sq != null && sq.e(j + 0.5D, m + 0.5D, k + 0.5D) > 4.0D) { a(j + 0.5D, m + 0.5D, k + 0.5D, "ambient.cave.cave", 0.7F, 0.8F + this.s.nextFloat() * 0.2F); this.O = this.s.nextInt(12000) + 6000; }  }  }  this.C.c("checkLight"); paramabw.o(); } protected void g() { B(); } public boolean x(int paramInt1, int paramInt2, int paramInt3) { return d(paramInt1, paramInt2, paramInt3, false); } public boolean y(int paramInt1, int paramInt2, int paramInt3) { return d(paramInt1, paramInt2, paramInt3, true); } public boolean d(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) { aav aav = a(paramInt1, paramInt3); float f = aav.j(); if (f > 0.15F) return false;  if (paramInt2 >= 0 && paramInt2 < 256 && b(aam.b, paramInt1, paramInt2, paramInt3) < 10) { int i = a(paramInt1, paramInt2, paramInt3); if ((i == apa.F.cz || i == apa.E.cz) && h(paramInt1, paramInt2, paramInt3) == 0) { if (!paramBoolean) return true;  boolean bool = true; if (bool && g(paramInt1 - 1, paramInt2, paramInt3) != aif.h) bool = false;  if (bool && g(paramInt1 + 1, paramInt2, paramInt3) != aif.h) bool = false;  if (bool && g(paramInt1, paramInt2, paramInt3 - 1) != aif.h) bool = false;  if (bool && g(paramInt1, paramInt2, paramInt3 + 1) != aif.h) bool = false;  if (!bool) return true;  }  }  return false; } public boolean z(int paramInt1, int paramInt2, int paramInt3) { aav aav = a(paramInt1, paramInt3); float f = aav.j(); if (f > 0.15F) return false;  if (paramInt2 >= 0 && paramInt2 < 256 && b(aam.b, paramInt1, paramInt2, paramInt3) < 10) { int i = a(paramInt1, paramInt2 - 1, paramInt3); int j = a(paramInt1, paramInt2, paramInt3); if (j == 0 && apa.aW.c(this, paramInt1, paramInt2, paramInt3) && i != 0 && i != apa.aX.cz && (apa.r[i]).cO.c()) return true;  }  return false; } public void A(int paramInt1, int paramInt2, int paramInt3) { if (!this.t.f) c(aam.a, paramInt1, paramInt2, paramInt3);  c(aam.b, paramInt1, paramInt2, paramInt3); } private int a(int paramInt1, int paramInt2, int paramInt3, aam paramaam) { if (paramaam == aam.a && l(paramInt1, paramInt2, paramInt3)) return 15;  int i = a(paramInt1, paramInt2, paramInt3); int j = (paramaam == aam.a) ? 0 : apa.v[i]; int k = apa.t[i]; if (k >= 15 && apa.v[i] > 0) k = 1;  if (k < 1) k = 1;  if (k >= 15) return 0;  if (j >= 14) return j;  for (byte b = 0; b < 6; b++) { int m = paramInt1 + s.b[b]; int n = paramInt2 + s.c[b]; int i1 = paramInt3 + s.d[b]; int i2 = b(paramaam, m, n, i1) - k; if (i2 > j) j = i2;  if (j >= 14) return j;  }  return j; } public void c(aam paramaam, int paramInt1, int paramInt2, int paramInt3) { if (!b(paramInt1, paramInt2, paramInt3, 17)) return;  byte b1 = 0; byte b2 = 0; this.C.a("getBrightness"); int i = b(paramaam, paramInt1, paramInt2, paramInt3); int j = a(paramInt1, paramInt2, paramInt3, paramaam); if (j > i) { this.H[b2++] = 133152; } else if (j < i) { this.H[b2++] = 0x20820 | i << 18; while (b1 < b2) { int k = this.H[b1++]; int m = (k & 0x3F) - 32 + paramInt1; int n = (k >> 6 & 0x3F) - 32 + paramInt2; int i1 = (k >> 12 & 0x3F) - 32 + paramInt3; int i2 = k >> 18 & 0xF; int i3 = b(paramaam, m, n, i1); if (i3 == i2) { b(paramaam, m, n, i1, 0); if (i2 > 0) { int i4 = kx.a(m - paramInt1); int i5 = kx.a(n - paramInt2); int i6 = kx.a(i1 - paramInt3); if (i4 + i5 + i6 < 17) for (byte b = 0; b < 6; b++) { int i7 = m + s.b[b]; int i8 = n + s.c[b]; int i9 = i1 + s.d[b]; int i10 = Math.max(1, apa.t[a(i7, i8, i9)]); i3 = b(paramaam, i7, i8, i9); if (i3 == i2 - i10 && b2 < this.H.length) this.H[b2++] = i7 - paramInt1 + 32 | i8 - paramInt2 + 32 << 6 | i9 - paramInt3 + 32 << 12 | i2 - i10 << 18;  }   }  }  }  b1 = 0; }  this.C.b(); this.C.a("checkedPosition < toCheckCount"); while (b1 < b2) { int k = this.H[b1++]; int m = (k & 0x3F) - 32 + paramInt1; int n = (k >> 6 & 0x3F) - 32 + paramInt2; int i1 = (k >> 12 & 0x3F) - 32 + paramInt3; int i2 = b(paramaam, m, n, i1); int i3 = a(m, n, i1, paramaam); if (i3 != i2) { b(paramaam, m, n, i1, i3); if (i3 > i2) { int i4 = Math.abs(m - paramInt1); int i5 = Math.abs(n - paramInt2); int i6 = Math.abs(i1 - paramInt3); boolean bool = (b2 < this.H.length - 6) ? true : false; if (i4 + i5 + i6 < 17 && bool) { if (b(paramaam, m - 1, n, i1) < i3) this.H[b2++] = m - 1 - paramInt1 + 32 + (n - paramInt2 + 32 << 6) + (i1 - paramInt3 + 32 << 12);  if (b(paramaam, m + 1, n, i1) < i3) this.H[b2++] = m + 1 - paramInt1 + 32 + (n - paramInt2 + 32 << 6) + (i1 - paramInt3 + 32 << 12);  if (b(paramaam, m, n - 1, i1) < i3) this.H[b2++] = m - paramInt1 + 32 + (n - 1 - paramInt2 + 32 << 6) + (i1 - paramInt3 + 32 << 12);  if (b(paramaam, m, n + 1, i1) < i3) this.H[b2++] = m - paramInt1 + 32 + (n + 1 - paramInt2 + 32 << 6) + (i1 - paramInt3 + 32 << 12);  if (b(paramaam, m, n, i1 - 1) < i3) this.H[b2++] = m - paramInt1 + 32 + (n - paramInt2 + 32 << 6) + (i1 - 1 - paramInt3 + 32 << 12);  if (b(paramaam, m, n, i1 + 1) < i3) this.H[b2++] = m - paramInt1 + 32 + (n - paramInt2 + 32 << 6) + (i1 + 1 - paramInt3 + 32 << 12);  }  }  }  }  this.C.b(); } public boolean a(boolean paramBoolean) { return false; } public List a(abw paramabw, boolean paramBoolean) { return null; } public List a(mp parammp, aqx paramaqx, my parammy) { ArrayList arrayList = new ArrayList();
/* 2084 */     int i = kx.c((paramaqx.a - 2.0D) / 16.0D);
/* 2085 */     int j = kx.c((paramaqx.d + 2.0D) / 16.0D);
/* 2086 */     int k = kx.c((paramaqx.c - 2.0D) / 16.0D);
/* 2087 */     int m = kx.c((paramaqx.f + 2.0D) / 16.0D);
/* 2088 */     for (int n = i; n <= j; n++) {
/* 2089 */       for (int i1 = k; i1 <= m; i1++) {
/* 2090 */         if (c(n, i1))
/* 2091 */           e(n, i1).a(parammp, paramaqx, arrayList, parammy); 
/*      */       } 
/*      */     } 
/* 2094 */     return arrayList; }
/*      */ 
/*      */   
/*      */   public List a(Class paramClass, aqx paramaqx) {
/* 2098 */     return a(paramClass, paramaqx, (my)null);
/*      */   }
/*      */   
/*      */   public List a(Class paramClass, aqx paramaqx, my parammy) {
/* 2102 */     int i = kx.c((paramaqx.a - 2.0D) / 16.0D);
/* 2103 */     int j = kx.c((paramaqx.d + 2.0D) / 16.0D);
/* 2104 */     int k = kx.c((paramaqx.c - 2.0D) / 16.0D);
/* 2105 */     int m = kx.c((paramaqx.f + 2.0D) / 16.0D);
/* 2106 */     ArrayList arrayList = new ArrayList();
/*      */     
/* 2108 */     for (int n = i; n <= j; n++) {
/* 2109 */       for (int i1 = k; i1 <= m; i1++) {
/* 2110 */         if (c(n, i1)) {
/* 2111 */           e(n, i1).a(paramClass, paramaqx, arrayList, parammy);
/*      */         }
/*      */       } 
/*      */     } 
/*      */     
/* 2116 */     return arrayList;
/*      */   }
/*      */   
/*      */   public mp a(Class paramClass, aqx paramaqx, mp parammp) {
/* 2120 */     List<mp> list = a(paramClass, paramaqx);
/* 2121 */     mp mp1 = null;
/* 2122 */     double d = Double.MAX_VALUE;
/* 2123 */     for (byte b = 0; b < list.size(); b++) {
/* 2124 */       mp mp2 = list.get(b);
/* 2125 */       if (mp2 != parammp) {
/* 2126 */         double d1 = parammp.e(mp2);
/* 2127 */         if (d1 <= d)
/* 2128 */         { mp1 = mp2;
/* 2129 */           d = d1; } 
/*      */       } 
/* 2131 */     }  return mp1;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public List C() {
/* 2137 */     return this.e;
/*      */   }
/*      */   
/*      */   public void b(int paramInt1, int paramInt2, int paramInt3, aqp paramaqp) {
/* 2141 */     if (f(paramInt1, paramInt2, paramInt3)) {
/* 2142 */       d(paramInt1, paramInt3).e();
/*      */     }
/*      */   }
/*      */   
/*      */   public int a(Class paramClass) {
/* 2147 */     byte b1 = 0;
/* 2148 */     for (byte b2 = 0; b2 < this.e.size(); b2++) {
/* 2149 */       mp mp = this.e.get(b2);
/* 2150 */       if ((!(mp instanceof ng) || !((ng)mp).bU()) && 
/* 2151 */         paramClass.isAssignableFrom(mp.getClass())) b1++; 
/*      */     } 
/* 2153 */     return b1;
/*      */   }
/*      */   
/*      */   public void a(List<mp> paramList) {
/* 2157 */     this.e.addAll(paramList);
/* 2158 */     for (byte b = 0; b < paramList.size(); b++) {
/* 2159 */       a(paramList.get(b));
/*      */     }
/*      */   }
/*      */   
/*      */   public void b(List paramList) {
/* 2164 */     this.f.addAll(paramList);
/*      */   }
/*      */   
/*      */   public boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean, int paramInt5, mp parammp, wm paramwm) {
/* 2168 */     int i = a(paramInt2, paramInt3, paramInt4);
/* 2169 */     apa apa1 = apa.r[i];
/* 2170 */     apa apa2 = apa.r[paramInt1];
/* 2171 */     aqx aqx = apa2.b(this, paramInt2, paramInt3, paramInt4);
/* 2172 */     if (paramBoolean) aqx = null; 
/* 2173 */     if (aqx != null && !a(aqx, parammp)) return false;
/*      */     
/* 2175 */     if (apa1 != null && (apa1 == apa.E || apa1 == apa.F || apa1 == apa.G || apa1 == apa.H || apa1 == apa.av || apa1.cO.j()))
/*      */     {
/*      */       
/* 2178 */       apa1 = null;
/*      */     }
/*      */     
/* 2181 */     if (apa1 != null && apa1.cO == aif.q && apa2 == apa.cl) return true;
/*      */     
/* 2183 */     if (paramInt1 > 0 && apa1 == null && 
/* 2184 */       apa2.a(this, paramInt2, paramInt3, paramInt4, paramInt5, paramwm)) {
/* 2185 */       return true;
/*      */     }
/*      */ 
/*      */     
/* 2189 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public aji a(mp parammp1, mp parammp2, float paramFloat, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/* 2197 */     this.C.a("pathfind");
/* 2198 */     int i = kx.c(parammp1.u);
/* 2199 */     int j = kx.c(parammp1.v + 1.0D);
/* 2200 */     int k = kx.c(parammp1.w);
/*      */     
/* 2202 */     int m = (int)(paramFloat + 16.0F);
/* 2203 */     int n = i - m;
/* 2204 */     int i1 = j - m;
/* 2205 */     int i2 = k - m;
/* 2206 */     int i3 = i + m;
/* 2207 */     int i4 = j + m;
/* 2208 */     int i5 = k + m;
/* 2209 */     aaq aaq = new aaq(this, n, i1, i2, i3, i4, i5, 0);
/* 2210 */     aji aji = (new ajj(aaq, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4)).a(parammp1, parammp2, paramFloat);
/* 2211 */     this.C.b();
/* 2212 */     return aji;
/*      */   }
/*      */   
/*      */   public aji a(mp parammp, int paramInt1, int paramInt2, int paramInt3, float paramFloat, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/* 2216 */     this.C.a("pathfind");
/* 2217 */     int i = kx.c(parammp.u);
/* 2218 */     int j = kx.c(parammp.v);
/* 2219 */     int k = kx.c(parammp.w);
/*      */     
/* 2221 */     int m = (int)(paramFloat + 8.0F);
/* 2222 */     int n = i - m;
/* 2223 */     int i1 = j - m;
/* 2224 */     int i2 = k - m;
/* 2225 */     int i3 = i + m;
/* 2226 */     int i4 = j + m;
/* 2227 */     int i5 = k + m;
/* 2228 */     aaq aaq = new aaq(this, n, i1, i2, i3, i4, i5, 0);
/* 2229 */     aji aji = (new ajj(aaq, paramBoolean1, paramBoolean2, paramBoolean3, paramBoolean4)).a(parammp, paramInt1, paramInt2, paramInt3, paramFloat);
/* 2230 */     this.C.b();
/* 2231 */     return aji;
/*      */   }
/*      */   
/*      */   public int j(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 2235 */     int i = a(paramInt1, paramInt2, paramInt3);
/* 2236 */     if (i == 0) return 0; 
/* 2237 */     return apa.r[i].c(this, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public int B(int paramInt1, int paramInt2, int paramInt3) {
/* 2241 */     int i = 0;
/* 2242 */     i = Math.max(i, j(paramInt1, paramInt2 - 1, paramInt3, 0));
/* 2243 */     if (i >= 15) return i; 
/* 2244 */     i = Math.max(i, j(paramInt1, paramInt2 + 1, paramInt3, 1));
/* 2245 */     if (i >= 15) return i; 
/* 2246 */     i = Math.max(i, j(paramInt1, paramInt2, paramInt3 - 1, 2));
/* 2247 */     if (i >= 15) return i; 
/* 2248 */     i = Math.max(i, j(paramInt1, paramInt2, paramInt3 + 1, 3));
/* 2249 */     if (i >= 15) return i; 
/* 2250 */     i = Math.max(i, j(paramInt1 - 1, paramInt2, paramInt3, 4));
/* 2251 */     if (i >= 15) return i; 
/* 2252 */     i = Math.max(i, j(paramInt1 + 1, paramInt2, paramInt3, 5));
/* 2253 */     if (i >= 15) return i; 
/* 2254 */     return i;
/*      */   }
/*      */   
/*      */   public boolean k(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 2258 */     return (l(paramInt1, paramInt2, paramInt3, paramInt4) > 0);
/*      */   }
/*      */   
/*      */   public int l(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 2262 */     if (u(paramInt1, paramInt2, paramInt3)) {
/* 2263 */       return B(paramInt1, paramInt2, paramInt3);
/*      */     }
/* 2265 */     int i = a(paramInt1, paramInt2, paramInt3);
/* 2266 */     if (i == 0) return 0; 
/* 2267 */     return apa.r[i].b(this, paramInt1, paramInt2, paramInt3, paramInt4);
/*      */   }
/*      */   
/*      */   public boolean C(int paramInt1, int paramInt2, int paramInt3) {
/* 2271 */     if (l(paramInt1, paramInt2 - 1, paramInt3, 0) > 0) return true; 
/* 2272 */     if (l(paramInt1, paramInt2 + 1, paramInt3, 1) > 0) return true; 
/* 2273 */     if (l(paramInt1, paramInt2, paramInt3 - 1, 2) > 0) return true; 
/* 2274 */     if (l(paramInt1, paramInt2, paramInt3 + 1, 3) > 0) return true; 
/* 2275 */     if (l(paramInt1 - 1, paramInt2, paramInt3, 4) > 0) return true; 
/* 2276 */     if (l(paramInt1 + 1, paramInt2, paramInt3, 5) > 0) return true; 
/* 2277 */     return false;
/*      */   }
/*      */   
/*      */   public int D(int paramInt1, int paramInt2, int paramInt3) {
/* 2281 */     int i = 0;
/*      */     
/* 2283 */     for (byte b = 0; b < 6; b++) {
/* 2284 */       int j = l(paramInt1 + s.b[b], paramInt2 + s.c[b], paramInt3 + s.d[b], b);
/*      */       
/* 2286 */       if (j >= 15) return 15; 
/* 2287 */       if (j > i) i = j;
/*      */     
/*      */     } 
/* 2290 */     return i;
/*      */   }
/*      */   
/*      */   public sq a(mp parammp, double paramDouble) {
/* 2294 */     return a(parammp.u, parammp.v, parammp.w, paramDouble);
/*      */   }
/*      */   
/*      */   public sq a(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 2298 */     double d = -1.0D;
/* 2299 */     sq sq = null;
/* 2300 */     for (byte b = 0; b < this.h.size(); b++) {
/* 2301 */       sq sq1 = this.h.get(b);
/* 2302 */       double d1 = sq1.e(paramDouble1, paramDouble2, paramDouble3);
/* 2303 */       if ((paramDouble4 < 0.0D || d1 < paramDouble4 * paramDouble4) && (d == -1.0D || d1 < d)) {
/* 2304 */         d = d1;
/* 2305 */         sq = sq1;
/*      */       } 
/*      */     } 
/* 2308 */     return sq;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public sq b(mp parammp, double paramDouble) {
/* 2326 */     return b(parammp.u, parammp.v, parammp.w, paramDouble);
/*      */   }
/*      */   
/*      */   public sq b(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4) {
/* 2330 */     double d = -1.0D;
/* 2331 */     sq sq = null;
/* 2332 */     for (byte b = 0; b < this.h.size(); b++) {
/* 2333 */       sq sq1 = this.h.get(b);
/* 2334 */       if (!sq1.ce.a && sq1.R()) {
/*      */ 
/*      */         
/* 2337 */         double d1 = sq1.e(paramDouble1, paramDouble2, paramDouble3);
/* 2338 */         double d2 = paramDouble4;
/*      */ 
/*      */         
/* 2341 */         if (sq1.ag()) {
/* 2342 */           d2 *= 0.800000011920929D;
/*      */         }
/* 2344 */         if (sq1.ai()) {
/* 2345 */           float f = sq1.cc();
/* 2346 */           if (f < 0.1F) {
/* 2347 */             f = 0.1F;
/*      */           }
/* 2349 */           d2 *= (0.7F * f);
/*      */         } 
/* 2351 */         if ((paramDouble4 < 0.0D || d1 < d2 * d2) && (d == -1.0D || d1 < d)) {
/* 2352 */           d = d1;
/* 2353 */           sq = sq1;
/*      */         } 
/*      */       } 
/* 2356 */     }  return sq;
/*      */   }
/*      */   
/*      */   public sq a(String paramString) {
/* 2360 */     for (byte b = 0; b < this.h.size(); b++) {
/* 2361 */       if (paramString.equals(((sq)this.h.get(b)).bS)) {
/* 2362 */         return this.h.get(b);
/*      */       }
/*      */     } 
/* 2365 */     return null;
/*      */   }
/*      */ 
/*      */   
/*      */   public void E() {}
/*      */   
/*      */   public void F() {
/* 2372 */     this.w.c();
/*      */   }
/*      */   
/*      */   public void a(long paramLong) {
/* 2376 */     this.x.b(paramLong);
/*      */   }
/*      */   
/*      */   public long G() {
/* 2380 */     return this.x.b();
/*      */   }
/*      */   
/*      */   public long H() {
/* 2384 */     return this.x.f();
/*      */   }
/*      */   
/*      */   public long I() {
/* 2388 */     return this.x.g();
/*      */   }
/*      */   
/*      */   public void b(long paramLong) {
/* 2392 */     this.x.c(paramLong);
/*      */   }
/*      */   
/*      */   public t J() {
/* 2396 */     return new t(this.x.c(), this.x.d(), this.x.e());
/*      */   }
/*      */   
/*      */   public void E(int paramInt1, int paramInt2, int paramInt3) {
/* 2400 */     this.x.a(paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void h(mp parammp) {
/* 2408 */     int i = kx.c(parammp.u / 16.0D);
/* 2409 */     int j = kx.c(parammp.w / 16.0D);
/* 2410 */     byte b = 2;
/* 2411 */     for (int k = i - b; k <= i + b; k++) {
/* 2412 */       for (int m = j - b; m <= j + b; m++) {
/* 2413 */         e(k, m);
/*      */       }
/*      */     } 
/*      */     
/* 2417 */     if (!this.e.contains(parammp)) {
/* 2418 */       this.e.add(parammp);
/*      */     }
/*      */   }
/*      */   
/*      */   public boolean a(sq paramsq, int paramInt1, int paramInt2, int paramInt3) {
/* 2423 */     return true;
/*      */   }
/*      */ 
/*      */   
/*      */   public void a(mp parammp, byte paramByte) {}
/*      */   
/*      */   public abt K() {
/* 2430 */     return this.v;
/*      */   }
/*      */   
/*      */   public void d(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 2434 */     if (paramInt4 > 0) apa.r[paramInt4].b(this, paramInt1, paramInt2, paramInt3, paramInt5, paramInt6); 
/*      */   }
/*      */   
/*      */   public akf L() {
/* 2438 */     return this.w;
/*      */   }
/*      */   
/*      */   public ajv M() {
/* 2442 */     return this.x;
/*      */   }
/*      */   
/*      */   public zy N() {
/* 2446 */     return this.x.x();
/*      */   }
/*      */ 
/*      */   
/*      */   public void c() {}
/*      */   
/*      */   public float h(float paramFloat) {
/* 2453 */     return (this.o + (this.p - this.o) * paramFloat) * i(paramFloat);
/*      */   }
/*      */   
/*      */   public float i(float paramFloat) {
/* 2457 */     return this.m + (this.n - this.m) * paramFloat;
/*      */   }
/*      */   
/*      */   public void j(float paramFloat) {
/* 2461 */     this.m = paramFloat;
/* 2462 */     this.n = paramFloat;
/*      */   }
/*      */   
/*      */   public boolean O() {
/* 2466 */     return (h(1.0F) > 0.9D);
/*      */   }
/*      */   
/*      */   public boolean P() {
/* 2470 */     return (i(1.0F) > 0.2D);
/*      */   }
/*      */   
/*      */   public boolean F(int paramInt1, int paramInt2, int paramInt3) {
/* 2474 */     if (!P()) return false; 
/* 2475 */     if (!l(paramInt1, paramInt2, paramInt3)) return false; 
/* 2476 */     if (h(paramInt1, paramInt3) > paramInt2) return false;
/*      */     
/* 2478 */     aav aav = a(paramInt1, paramInt3);
/* 2479 */     if (aav.c()) return false; 
/* 2480 */     return aav.d();
/*      */   }
/*      */   
/*      */   public boolean G(int paramInt1, int paramInt2, int paramInt3) {
/* 2484 */     aav aav = a(paramInt1, paramInt3);
/* 2485 */     return aav.e();
/*      */   }
/*      */   
/*      */   public void a(String paramString, ajo paramajo) {
/* 2489 */     this.z.a(paramString, paramajo);
/*      */   }
/*      */   
/*      */   public ajo a(Class paramClass, String paramString) {
/* 2493 */     return this.z.a(paramClass, paramString);
/*      */   }
/*      */   
/*      */   public int b(String paramString) {
/* 2497 */     return this.z.a(paramString);
/*      */   }
/*      */   
/*      */   public void d(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 2501 */     for (byte b = 0; b < this.u.size(); b++) {
/* 2502 */       ((aag)this.u.get(b)).a(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     }
/*      */   }
/*      */   
/*      */   public void e(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 2507 */     a((sq)null, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */   }
/*      */   
/*      */   public void a(sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*      */     try {
/* 2512 */       for (byte b = 0; b < this.u.size(); b++) {
/* 2513 */         ((aag)this.u.get(b)).a(paramsq, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */       }
/* 2515 */     } catch (Throwable throwable) {
/* 2516 */       b b = b.a(throwable, "Playing level event");
/* 2517 */       m m = b.a("Level event being played");
/*      */       
/* 2519 */       m.a("Block coordinates", m.a(paramInt2, paramInt3, paramInt4));
/* 2520 */       m.a("Event source", paramsq);
/* 2521 */       m.a("Event type", Integer.valueOf(paramInt1));
/* 2522 */       m.a("Event data", Integer.valueOf(paramInt5));
/*      */       
/* 2524 */       throw new u(b);
/*      */     } 
/*      */   }
/*      */   
/*      */   public int Q() {
/* 2529 */     return 256;
/*      */   }
/*      */   
/*      */   public int R() {
/* 2533 */     return this.t.f ? 128 : 256;
/*      */   }
/*      */   
/*      */   public gy a(ri paramri) {
/* 2537 */     return null;
/*      */   }
/*      */   
/*      */   public Random H(int paramInt1, int paramInt2, int paramInt3) {
/* 2541 */     long l = paramInt1 * 341873128712L + paramInt2 * 132897987541L + M().b() + paramInt3;
/* 2542 */     this.s.setSeed(l);
/* 2543 */     return this.s;
/*      */   }
/*      */   
/*      */   public aat b(String paramString, int paramInt1, int paramInt2, int paramInt3) {
/* 2547 */     return K().a(this, paramString, paramInt1, paramInt2, paramInt3);
/*      */   }
/*      */   
/*      */   public boolean S() {
/* 2551 */     return false;
/*      */   }
/*      */   
/*      */   public double T() {
/* 2555 */     if (this.x.u() == aal.c) {
/* 2556 */       return 0.0D;
/*      */     }
/* 2558 */     return 63.0D;
/*      */   }
/*      */   
/*      */   public m a(b paramb) {
/* 2562 */     m m = paramb.a("Affected level", 1);
/*      */     
/* 2564 */     m.a("Level name", (this.x == null) ? "????" : this.x.k());
/*      */     
/* 2566 */     m.a("All players", new aad(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2572 */     m.a("Chunk stats", new aae(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 2579 */       this.x.a(m);
/* 2580 */     } catch (Throwable throwable) {
/* 2581 */       m.a("Level Data Unobtainable", throwable);
/*      */     } 
/*      */     
/* 2584 */     return m;
/*      */   }
/*      */   
/*      */   public void f(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 2588 */     for (byte b = 0; b < this.u.size(); b++) {
/* 2589 */       aag aag = this.u.get(b);
/* 2590 */       aag.b(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*      */     } 
/*      */   }
/*      */   
/*      */   public ard U() {
/* 2595 */     return this.J;
/*      */   }
/*      */   
/*      */   public Calendar V() {
/* 2599 */     if (H() % 600L == 0L) {
/* 2600 */       this.K.setTimeInMillis(System.currentTimeMillis());
/*      */     }
/* 2602 */     return this.K;
/*      */   }
/*      */ 
/*      */   
/*      */   public void a(double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6, bs parambs) {}
/*      */ 
/*      */   
/*      */   public arj W() {
/* 2610 */     return this.D;
/*      */   }
/*      */   
/*      */   public void m(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 2614 */     for (byte b = 0; b < 4; b++) {
/* 2615 */       int i = paramInt1 + r.a[b];
/* 2616 */       int j = paramInt3 + r.b[b];
/* 2617 */       int k = a(i, paramInt2, j);
/* 2618 */       if (k != 0) {
/* 2619 */         apa apa = apa.r[k];
/*      */         
/* 2621 */         if (apa.cp.g(k)) {
/* 2622 */           apa.a(this, i, paramInt2, j, paramInt4);
/* 2623 */         } else if (apa.l(k)) {
/* 2624 */           i += r.a[b];
/* 2625 */           j += r.b[b];
/* 2626 */           k = a(i, paramInt2, j);
/* 2627 */           apa = apa.r[k];
/*      */           
/* 2629 */           if (apa.cp.g(k))
/* 2630 */             apa.a(this, i, paramInt2, j, paramInt4); 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public ku X() {
/* 2637 */     return this.L;
/*      */   }
/*      */   
/*      */   protected abstract abt j();
/*      */   
/*      */   public abstract mp a(int paramInt);
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aab.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */