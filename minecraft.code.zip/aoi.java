/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aoi
/*     */   extends aly
/*     */ {
/*  15 */   public static final double[] b = new double[] { -0.0625D, 0.0625D, 0.1875D, 0.3125D };
/*     */ 
/*     */ 
/*     */   
/*  19 */   private static final int[] c = new int[] { 1, 2, 3, 4 };
/*     */ 
/*     */ 
/*     */   
/*     */   protected aoi(int paramInt, boolean paramBoolean) {
/*  24 */     super(paramInt, paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  29 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  30 */     int j = (i & 0xC) >> 2;
/*  31 */     j = j + 1 << 2 & 0xC;
/*     */     
/*  33 */     paramaab.b(paramInt1, paramInt2, paramInt3, j | i & 0x3, 3);
/*  34 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int i_(int paramInt) {
/*  39 */     return c[(paramInt & 0xC) >> 2] * 2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected aly i() {
/*  44 */     return apa.bm;
/*     */   }
/*     */ 
/*     */   
/*     */   protected aly j() {
/*  49 */     return apa.bl;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  54 */     return wk.bc.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  59 */     return wk.bc.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  64 */     return 15;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean e(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  69 */     return (f(paramaak, paramInt1, paramInt2, paramInt3, paramInt4) > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean e(int paramInt) {
/*  74 */     return f(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  79 */     if (!this.a)
/*  80 */       return;  int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  81 */     int j = j(i);
/*     */     
/*  83 */     double d1 = (paramInt1 + 0.5F) + (paramRandom.nextFloat() - 0.5F) * 0.2D;
/*  84 */     double d2 = (paramInt2 + 0.4F) + (paramRandom.nextFloat() - 0.5F) * 0.2D;
/*  85 */     double d3 = (paramInt3 + 0.5F) + (paramRandom.nextFloat() - 0.5F) * 0.2D;
/*     */     
/*  87 */     double d4 = 0.0D;
/*  88 */     double d5 = 0.0D;
/*     */     
/*  90 */     if (paramRandom.nextInt(2) == 0) {
/*     */       
/*  92 */       switch (j) {
/*     */         case 0:
/*  94 */           d5 = -0.3125D;
/*     */           break;
/*     */         case 2:
/*  97 */           d5 = 0.3125D;
/*     */           break;
/*     */         case 3:
/* 100 */           d4 = -0.3125D;
/*     */           break;
/*     */         case 1:
/* 103 */           d4 = 0.3125D;
/*     */           break;
/*     */       } 
/*     */     
/*     */     } else {
/* 108 */       int k = (i & 0xC) >> 2;
/* 109 */       switch (j) {
/*     */         case 0:
/* 111 */           d5 = b[k];
/*     */           break;
/*     */         case 2:
/* 114 */           d5 = -b[k];
/*     */           break;
/*     */         case 3:
/* 117 */           d4 = b[k];
/*     */           break;
/*     */         case 1:
/* 120 */           d4 = -b[k];
/*     */           break;
/*     */       } 
/*     */     
/*     */     } 
/* 125 */     paramaab.a("reddust", d1 + d4, d2, d3 + d5, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 130 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 131 */     h_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */