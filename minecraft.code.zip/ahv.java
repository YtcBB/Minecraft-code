/*     */ import java.util.Random;
/*     */ 
/*     */ public class ahv
/*     */   extends aib
/*     */ {
/*   6 */   private int[] d = new int[512];
/*     */   public double a;
/*     */   public double b;
/*     */   public double c;
/*     */   
/*     */   public ahv() {
/*  12 */     this(new Random());
/*     */   }
/*     */   
/*     */   public ahv(Random paramRandom) {
/*  16 */     this.a = paramRandom.nextDouble() * 256.0D;
/*  17 */     this.b = paramRandom.nextDouble() * 256.0D;
/*  18 */     this.c = paramRandom.nextDouble() * 256.0D; byte b;
/*  19 */     for (b = 0; b < 'Ā'; b++) {
/*  20 */       this.d[b] = b;
/*     */     }
/*     */     
/*  23 */     for (b = 0; b < 'Ā'; b++) {
/*  24 */       int i = paramRandom.nextInt(256 - b) + b;
/*  25 */       int j = this.d[b];
/*  26 */       this.d[b] = this.d[i];
/*  27 */       this.d[i] = j;
/*     */       
/*  29 */       this.d[b + 256] = this.d[b];
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public final double b(double paramDouble1, double paramDouble2, double paramDouble3) {
/*  71 */     return paramDouble2 + paramDouble1 * (paramDouble3 - paramDouble2);
/*     */   }
/*     */   
/*     */   public final double a(int paramInt, double paramDouble1, double paramDouble2) {
/*  75 */     int i = paramInt & 0xF;
/*     */     
/*  77 */     double d1 = (1 - ((i & 0x8) >> 3)) * paramDouble1;
/*  78 */     double d2 = (i < 4) ? 0.0D : ((i == 12 || i == 14) ? paramDouble1 : paramDouble2);
/*     */     
/*  80 */     return (((i & 0x1) == 0) ? d1 : -d1) + (((i & 0x2) == 0) ? d2 : -d2);
/*     */   }
/*     */   
/*     */   public final double a(int paramInt, double paramDouble1, double paramDouble2, double paramDouble3) {
/*  84 */     int i = paramInt & 0xF;
/*     */     
/*  86 */     double d1 = (i < 8) ? paramDouble1 : paramDouble2;
/*  87 */     double d2 = (i < 4) ? paramDouble2 : ((i == 12 || i == 14) ? paramDouble1 : paramDouble3);
/*     */     
/*  89 */     return (((i & 0x1) == 0) ? d1 : -d1) + (((i & 0x2) == 0) ? d2 : -d2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(double[] paramArrayOfdouble, double paramDouble1, double paramDouble2, double paramDouble3, int paramInt1, int paramInt2, int paramInt3, double paramDouble4, double paramDouble5, double paramDouble6, double paramDouble7) {
/* 102 */     if (paramInt2 == 1) {
/* 103 */       int i3 = 0, i4 = 0, i5 = 0, i6 = 0;
/* 104 */       double d6 = 0.0D, d7 = 0.0D;
/* 105 */       byte b3 = 0;
/* 106 */       double d8 = 1.0D / paramDouble7;
/* 107 */       for (byte b4 = 0; b4 < paramInt1; b4++) {
/* 108 */         double d9 = paramDouble1 + b4 * paramDouble4 + this.a;
/* 109 */         int i7 = (int)d9;
/* 110 */         if (d9 < i7) i7--; 
/* 111 */         int i8 = i7 & 0xFF;
/* 112 */         d9 -= i7;
/* 113 */         double d10 = d9 * d9 * d9 * (d9 * (d9 * 6.0D - 15.0D) + 10.0D);
/*     */         
/* 115 */         for (byte b = 0; b < paramInt3; b++) {
/* 116 */           double d11 = paramDouble3 + b * paramDouble6 + this.c;
/* 117 */           int i9 = (int)d11;
/* 118 */           if (d11 < i9) i9--; 
/* 119 */           int i10 = i9 & 0xFF;
/* 120 */           d11 -= i9;
/* 121 */           double d12 = d11 * d11 * d11 * (d11 * (d11 * 6.0D - 15.0D) + 10.0D);
/*     */           
/* 123 */           i3 = this.d[i8] + 0;
/* 124 */           i4 = this.d[i3] + i10;
/* 125 */           i5 = this.d[i8 + 1] + 0;
/* 126 */           i6 = this.d[i5] + i10;
/* 127 */           d6 = b(d10, a(this.d[i4], d9, d11), a(this.d[i6], d9 - 1.0D, 0.0D, d11));
/* 128 */           d7 = b(d10, a(this.d[i4 + 1], d9, 0.0D, d11 - 1.0D), a(this.d[i6 + 1], d9 - 1.0D, 0.0D, d11 - 1.0D));
/*     */           
/* 130 */           double d13 = b(d12, d6, d7);
/*     */           
/* 132 */           paramArrayOfdouble[b3++] = paramArrayOfdouble[b3++] + d13 * d8;
/*     */         } 
/*     */       } 
/*     */       return;
/*     */     } 
/* 137 */     byte b1 = 0;
/* 138 */     double d1 = 1.0D / paramDouble7;
/* 139 */     int i = -1;
/* 140 */     int j = 0, k = 0, m = 0, n = 0, i1 = 0, i2 = 0;
/* 141 */     double d2 = 0.0D, d3 = 0.0D, d4 = 0.0D, d5 = 0.0D;
/*     */     
/* 143 */     for (byte b2 = 0; b2 < paramInt1; b2++) {
/* 144 */       double d6 = paramDouble1 + b2 * paramDouble4 + this.a;
/* 145 */       int i3 = (int)d6;
/* 146 */       if (d6 < i3) i3--; 
/* 147 */       int i4 = i3 & 0xFF;
/* 148 */       d6 -= i3;
/* 149 */       double d7 = d6 * d6 * d6 * (d6 * (d6 * 6.0D - 15.0D) + 10.0D);
/*     */       
/* 151 */       for (byte b = 0; b < paramInt3; b++) {
/* 152 */         double d8 = paramDouble3 + b * paramDouble6 + this.c;
/* 153 */         int i5 = (int)d8;
/* 154 */         if (d8 < i5) i5--; 
/* 155 */         int i6 = i5 & 0xFF;
/* 156 */         d8 -= i5;
/* 157 */         double d9 = d8 * d8 * d8 * (d8 * (d8 * 6.0D - 15.0D) + 10.0D);
/*     */         
/* 159 */         for (byte b3 = 0; b3 < paramInt2; b3++) {
/* 160 */           double d10 = paramDouble2 + b3 * paramDouble5 + this.b;
/* 161 */           int i7 = (int)d10;
/* 162 */           if (d10 < i7) i7--; 
/* 163 */           int i8 = i7 & 0xFF;
/* 164 */           d10 -= i7;
/* 165 */           double d11 = d10 * d10 * d10 * (d10 * (d10 * 6.0D - 15.0D) + 10.0D);
/*     */           
/* 167 */           if (b3 == 0 || i8 != i) {
/* 168 */             i = i8;
/* 169 */             j = this.d[i4] + i8;
/* 170 */             k = this.d[j] + i6;
/* 171 */             m = this.d[j + 1] + i6;
/* 172 */             n = this.d[i4 + 1] + i8;
/* 173 */             i1 = this.d[n] + i6;
/* 174 */             i2 = this.d[n + 1] + i6;
/* 175 */             d2 = b(d7, a(this.d[k], d6, d10, d8), a(this.d[i1], d6 - 1.0D, d10, d8));
/* 176 */             d3 = b(d7, a(this.d[m], d6, d10 - 1.0D, d8), a(this.d[i2], d6 - 1.0D, d10 - 1.0D, d8));
/* 177 */             d4 = b(d7, a(this.d[k + 1], d6, d10, d8 - 1.0D), a(this.d[i1 + 1], d6 - 1.0D, d10, d8 - 1.0D));
/* 178 */             d5 = b(d7, a(this.d[m + 1], d6, d10 - 1.0D, d8 - 1.0D), a(this.d[i2 + 1], d6 - 1.0D, d10 - 1.0D, d8 - 1.0D));
/*     */           } 
/*     */           
/* 181 */           double d12 = b(d11, d2, d3);
/* 182 */           double d13 = b(d11, d4, d5);
/* 183 */           double d14 = b(d9, d12, d13);
/*     */           
/* 185 */           paramArrayOfdouble[b1++] = paramArrayOfdouble[b1++] + d14 * d1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ahv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */