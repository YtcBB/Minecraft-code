/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ani
/*    */   extends apa
/*    */ {
/*    */   private lx a;
/*    */   
/*    */   protected ani(int paramInt) {
/* 18 */     super(paramInt, aif.A);
/* 19 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 24 */     if (paramInt1 == 1 || paramInt1 == 0) return this.a; 
/* 25 */     return this.cQ;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 30 */     return wk.bg.cp;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 35 */     return 3 + paramRandom.nextInt(5);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt, Random paramRandom) {
/* 40 */     int i = a(paramRandom) + paramRandom.nextInt(1 + paramInt);
/* 41 */     if (i > 9) {
/* 42 */       i = 9;
/*    */     }
/* 44 */     return i;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 49 */     this.cQ = paramly.a("melon_side");
/* 50 */     this.a = paramly.a("melon_top");
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ani.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */