/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aba
/*     */ {
/*     */   private ait d;
/*     */   private ait e;
/*  19 */   private aax f = new aax(this);
/*     */   
/*     */   private List g;
/*     */ 
/*     */   
/*     */   protected aba() {
/*  25 */     this.g = new ArrayList();
/*  26 */     this.g.add(aav.f);
/*  27 */     this.g.add(aav.c);
/*  28 */     this.g.add(aav.g);
/*  29 */     this.g.add(aav.u);
/*  30 */     this.g.add(aav.t);
/*  31 */     this.g.add(aav.w);
/*  32 */     this.g.add(aav.x);
/*     */   }
/*     */   
/*     */   public aba(long paramLong, aal paramaal) {
/*  36 */     this();
/*     */     
/*  38 */     ait[] arrayOfAit = ait.a(paramLong, paramaal);
/*  39 */     this.d = arrayOfAit[0];
/*  40 */     this.e = arrayOfAit[1];
/*     */   }
/*     */   
/*     */   public aba(aab paramaab) {
/*  44 */     this(paramaab.G(), paramaab.M().u());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List a() {
/*  53 */     return this.g;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aav a(int paramInt1, int paramInt2) {
/*  61 */     return this.f.b(paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] a(float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  74 */     air.a();
/*  75 */     if (paramArrayOffloat == null || paramArrayOffloat.length < paramInt3 * paramInt4) {
/*  76 */       paramArrayOffloat = new float[paramInt3 * paramInt4];
/*     */     }
/*     */     
/*  79 */     int[] arrayOfInt = this.e.a(paramInt1, paramInt2, paramInt3, paramInt4);
/*  80 */     for (byte b = 0; b < paramInt3 * paramInt4; b++) {
/*  81 */       float f = aav.a[arrayOfInt[b]].g() / 65536.0F;
/*  82 */       if (f > 1.0F) f = 1.0F; 
/*  83 */       paramArrayOffloat[b] = f;
/*     */     } 
/*     */     
/*  86 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float a(float paramFloat, int paramInt) {
/*  98 */     return paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] b(float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 107 */     air.a();
/* 108 */     if (paramArrayOffloat == null || paramArrayOffloat.length < paramInt3 * paramInt4) {
/* 109 */       paramArrayOffloat = new float[paramInt3 * paramInt4];
/*     */     }
/*     */     
/* 112 */     int[] arrayOfInt = this.e.a(paramInt1, paramInt2, paramInt3, paramInt4);
/* 113 */     for (byte b = 0; b < paramInt3 * paramInt4; b++) {
/* 114 */       float f = aav.a[arrayOfInt[b]].h() / 65536.0F;
/* 115 */       if (f > 1.0F) f = 1.0F; 
/* 116 */       paramArrayOffloat[b] = f;
/*     */     } 
/*     */     
/* 119 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aav[] a(aav[] paramArrayOfaav, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 128 */     air.a();
/* 129 */     if (paramArrayOfaav == null || paramArrayOfaav.length < paramInt3 * paramInt4) {
/* 130 */       paramArrayOfaav = new aav[paramInt3 * paramInt4];
/*     */     }
/*     */     
/* 133 */     int[] arrayOfInt = this.d.a(paramInt1, paramInt2, paramInt3, paramInt4);
/* 134 */     for (byte b = 0; b < paramInt3 * paramInt4; b++) {
/* 135 */       paramArrayOfaav[b] = aav.a[arrayOfInt[b]];
/*     */     }
/*     */     
/* 138 */     return paramArrayOfaav;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aav[] b(aav[] paramArrayOfaav, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 151 */     return a(paramArrayOfaav, paramInt1, paramInt2, paramInt3, paramInt4, true);
/*     */   }
/*     */   
/*     */   public aav[] a(aav[] paramArrayOfaav, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/* 155 */     air.a();
/* 156 */     if (paramArrayOfaav == null || paramArrayOfaav.length < paramInt3 * paramInt4) {
/* 157 */       paramArrayOfaav = new aav[paramInt3 * paramInt4];
/*     */     }
/*     */     
/* 160 */     if (paramBoolean && paramInt3 == 16 && paramInt4 == 16 && (paramInt1 & 0xF) == 0 && (paramInt2 & 0xF) == 0) {
/* 161 */       aav[] arrayOfAav = this.f.e(paramInt1, paramInt2);
/* 162 */       System.arraycopy(arrayOfAav, 0, paramArrayOfaav, 0, paramInt3 * paramInt4);
/* 163 */       return paramArrayOfaav;
/*     */     } 
/*     */     
/* 166 */     int[] arrayOfInt = this.e.a(paramInt1, paramInt2, paramInt3, paramInt4);
/* 167 */     for (byte b = 0; b < paramInt3 * paramInt4; b++) {
/* 168 */       paramArrayOfaav[b] = aav.a[arrayOfInt[b]];
/*     */     }
/*     */     
/* 171 */     return paramArrayOfaav;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2, int paramInt3, List paramList) {
/* 182 */     air.a();
/* 183 */     int i = paramInt1 - paramInt3 >> 2;
/* 184 */     int j = paramInt2 - paramInt3 >> 2;
/* 185 */     int k = paramInt1 + paramInt3 >> 2;
/* 186 */     int m = paramInt2 + paramInt3 >> 2;
/*     */     
/* 188 */     int n = k - i + 1;
/* 189 */     int i1 = m - j + 1;
/*     */     
/* 191 */     int[] arrayOfInt = this.d.a(i, j, n, i1);
/* 192 */     for (byte b = 0; b < n * i1; b++) {
/* 193 */       aav aav = aav.a[arrayOfInt[b]];
/* 194 */       if (!paramList.contains(aav)) return false;
/*     */     
/*     */     } 
/* 197 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aat a(int paramInt1, int paramInt2, int paramInt3, List paramList, Random paramRandom) {
/* 263 */     air.a();
/* 264 */     int i = paramInt1 - paramInt3 >> 2;
/* 265 */     int j = paramInt2 - paramInt3 >> 2;
/* 266 */     int k = paramInt1 + paramInt3 >> 2;
/* 267 */     int m = paramInt2 + paramInt3 >> 2;
/*     */     
/* 269 */     int n = k - i + 1;
/* 270 */     int i1 = m - j + 1;
/* 271 */     int[] arrayOfInt = this.d.a(i, j, n, i1);
/* 272 */     aat aat = null;
/* 273 */     byte b1 = 0;
/* 274 */     for (byte b2 = 0; b2 < n * i1; b2++) {
/* 275 */       int i2 = i + b2 % n << 2;
/* 276 */       int i3 = j + b2 / n << 2;
/* 277 */       aav aav = aav.a[arrayOfInt[b2]];
/* 278 */       if (paramList.contains(aav) && (
/* 279 */         aat == null || paramRandom.nextInt(b1 + 1) == 0)) {
/* 280 */         aat = new aat(i2, 0, i3);
/* 281 */         b1++;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 286 */     return aat;
/*     */   }
/*     */   
/*     */   public void b() {
/* 290 */     this.f.a();
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aba.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */