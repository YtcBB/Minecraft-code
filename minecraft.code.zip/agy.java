/*    */ import java.util.Iterator;
/*    */ import java.util.LinkedList;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class agy
/*    */ {
/*  9 */   protected LinkedList a = new LinkedList();
/*    */ 
/*    */   
/*    */   protected aek b;
/*    */ 
/*    */ 
/*    */   
/*    */   public aek a() {
/* 17 */     return this.b;
/*    */   }
/*    */   
/*    */   public LinkedList b() {
/* 21 */     return this.a;
/*    */   }
/*    */   
/*    */   public void a(aab paramaab, Random paramRandom, aek paramaek) {
/* 25 */     Iterator<agw> iterator = this.a.iterator();
/* 26 */     while (iterator.hasNext()) {
/* 27 */       agw agw = iterator.next();
/* 28 */       if (!agw.b().a(paramaek) || 
/* 29 */         agw.a(paramaab, paramRandom, paramaek))
/*    */         continue; 
/* 31 */       iterator.remove();
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected void c() {
/* 38 */     this.b = aek.a();
/*    */     
/* 40 */     for (agw agw : this.a) {
/* 41 */       this.b.b(agw.b());
/*    */     }
/*    */   }
/*    */   
/*    */   protected void a(aab paramaab, Random paramRandom, int paramInt) {
/* 46 */     int i = 63 - paramInt;
/*    */ 
/*    */     
/* 49 */     int j = this.b.c() + 1;
/*    */     
/* 51 */     if (j < i) {
/* 52 */       j += paramRandom.nextInt(i - j);
/*    */     }
/*    */ 
/*    */     
/* 56 */     int k = j - this.b.e;
/* 57 */     this.b.a(0, k, 0);
/* 58 */     for (agw agw : this.a) {
/* 59 */       agw.b().a(0, k, 0);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   protected void a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 65 */     int i = paramInt2 - paramInt1 + 1 - this.b.c();
/* 66 */     int j = 1;
/*    */     
/* 68 */     if (i > 1) {
/* 69 */       j = paramInt1 + paramRandom.nextInt(i);
/*    */     } else {
/* 71 */       j = paramInt1;
/*    */     } 
/*    */ 
/*    */     
/* 75 */     int k = j - this.b.b;
/* 76 */     this.b.a(0, k, 0);
/* 77 */     for (agw agw : this.a) {
/* 78 */       agw.b().a(0, k, 0);
/*    */     }
/*    */   }
/*    */   
/*    */   public boolean d() {
/* 83 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\agy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */