/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ abstract class aft
/*    */   extends agw
/*    */ {
/*    */   protected final int a;
/*    */   protected final int b;
/*    */   protected final int c;
/* 21 */   protected int d = -1;
/*    */   
/*    */   protected aft(Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 24 */     super(0);
/*    */     
/* 26 */     this.a = paramInt4;
/* 27 */     this.b = paramInt5;
/* 28 */     this.c = paramInt6;
/*    */     
/* 30 */     this.f = paramRandom.nextInt(4);
/*    */     
/* 32 */     switch (this.f) {
/*    */       case 0:
/*    */       case 2:
/* 35 */         this.e = new aek(paramInt1, paramInt2, paramInt3, paramInt1 + paramInt4 - 1, paramInt2 + paramInt5 - 1, paramInt3 + paramInt6 - 1);
/*    */         return;
/*    */     } 
/* 38 */     this.e = new aek(paramInt1, paramInt2, paramInt3, paramInt1 + paramInt6 - 1, paramInt2 + paramInt5 - 1, paramInt3 + paramInt4 - 1);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean a(aab paramaab, aek paramaek, int paramInt) {
/* 45 */     if (this.d >= 0) {
/* 46 */       return true;
/*    */     }
/*    */     
/* 49 */     int i = 0;
/* 50 */     byte b = 0;
/* 51 */     for (int j = this.e.c; j <= this.e.f; j++) {
/* 52 */       for (int k = this.e.a; k <= this.e.d; k++) {
/* 53 */         if (paramaek.b(k, 64, j)) {
/* 54 */           i += Math.max(paramaab.i(k, j), paramaab.t.i());
/* 55 */           b++;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 60 */     if (b == 0) {
/* 61 */       return false;
/*    */     }
/* 63 */     this.d = i / b;
/* 64 */     this.e.a(0, this.d - this.e.b + paramInt, 0);
/* 65 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aft.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */