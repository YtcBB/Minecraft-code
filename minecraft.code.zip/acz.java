/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class acz
/*     */   implements abt
/*     */ {
/*     */   private Random i;
/*     */   private ahw j;
/*     */   private ahw k;
/*     */   private ahw l;
/*     */   public ahw a;
/*     */   public ahw b;
/*     */   private aab m;
/*     */   private double[] n;
/*     */   private aav[] o;
/*     */   double[] c;
/*     */   double[] d;
/*     */   double[] e;
/*     */   double[] f;
/*     */   double[] g;
/*     */   int[][] h;
/*     */   
/*     */   public acz(aab paramaab, long paramLong) {
/* 263 */     this.h = new int[32][32]; this.m = paramaab; this.i = new Random(paramLong); this.j = new ahw(this.i, 16); this.k = new ahw(this.i, 16); this.l = new ahw(this.i, 8); this.a = new ahw(this.i, 10); this.b = new ahw(this.i, 16);
/*     */   }
/*     */   public void a(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, aav[] paramArrayOfaav) { byte b1 = 2; int i = b1 + 1; byte b2 = 33; int j = b1 + 1; this.n = a(this.n, paramInt1 * b1, 0, paramInt2 * b1, i, b2, j); for (byte b3 = 0; b3 < b1; b3++) {
/*     */       for (byte b = 0; b < b1; b++) {
/*     */         for (byte b4 = 0; b4 < 32; b4++) {
/*     */           double d1 = 0.25D; double d2 = this.n[((b3 + 0) * j + b + 0) * b2 + b4 + 0]; double d3 = this.n[((b3 + 0) * j + b + 1) * b2 + b4 + 0]; double d4 = this.n[((b3 + 1) * j + b + 0) * b2 + b4 + 0]; double d5 = this.n[((b3 + 1) * j + b + 1) * b2 + b4 + 0]; double d6 = (this.n[((b3 + 0) * j + b + 0) * b2 + b4 + 1] - d2) * d1; double d7 = (this.n[((b3 + 0) * j + b + 1) * b2 + b4 + 1] - d3) * d1; double d8 = (this.n[((b3 + 1) * j + b + 0) * b2 + b4 + 1] - d4) * d1; double d9 = (this.n[((b3 + 1) * j + b + 1) * b2 + b4 + 1] - d5) * d1; for (byte b5 = 0; b5 < 4; b5++) {
/*     */             double d10 = 0.125D; double d11 = d2; double d12 = d3; double d13 = (d4 - d2) * d10; double d14 = (d5 - d3) * d10; for (byte b6 = 0; b6 < 8; b6++) {
/*     */               int k = b6 + b3 * 8 << 11 | 0 + b * 8 << 7 | b4 * 4 + b5; char c = ''; double d15 = 0.125D; double d16 = d11; double d17 = (d12 - d11) * d15; for (byte b7 = 0; b7 < 8; b7++) {
/*     */                 int m = 0; if (d16 > 0.0D)
/*     */                   m = apa.bN.cz;  paramArrayOfbyte[k] = (byte)m; k += c; d16 += d17;
/*     */               }  d11 += d13; d12 += d14;
/*     */             }  d2 += d6;
/*     */             d3 += d7;
/*     */             d4 += d8;
/*     */             d5 += d9;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }  }
/*     */   public void b(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, aav[] paramArrayOfaav) { for (byte b = 0; b < 16; b++) {
/*     */       for (byte b1 = 0; b1 < 16; b1++) {
/*     */         boolean bool = true;
/*     */         byte b2 = -1;
/*     */         byte b3 = (byte)apa.bN.cz;
/*     */         byte b4 = (byte)apa.bN.cz;
/*     */         for (byte b5 = 127; b5 >= 0; b5--) {
/*     */           int i = (b1 * 16 + b) * 128 + b5;
/*     */           byte b6 = paramArrayOfbyte[i];
/*     */           if (b6 == 0) {
/*     */             b2 = -1;
/*     */           } else if (b6 == apa.x.cz) {
/*     */             if (b2 == -1) {
/*     */               if (bool) {
/*     */                 b3 = 0;
/*     */                 b4 = (byte)apa.bN.cz;
/*     */               } 
/*     */               b2 = bool;
/*     */               if (b5 >= 0) {
/*     */                 paramArrayOfbyte[i] = b3;
/*     */               } else {
/*     */                 paramArrayOfbyte[i] = b4;
/*     */               } 
/*     */             } else if (b2 > 0) {
/*     */               b2--;
/*     */               paramArrayOfbyte[i] = b4;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 312 */     }  } public abw c(int paramInt1, int paramInt2) { return d(paramInt1, paramInt2); } public void a(abt paramabt, int paramInt1, int paramInt2) { amt.c = true;
/* 313 */     int i = paramInt1 * 16;
/* 314 */     int j = paramInt2 * 16;
/*     */     
/* 316 */     aav aav1 = this.m.a(i + 16, j + 16);
/* 317 */     aav1.a(this.m, this.m.s, i, j);
/*     */     
/* 319 */     amt.c = false; }
/*     */   public abw d(int paramInt1, int paramInt2) { this.i.setSeed(paramInt1 * 341873128712L + paramInt2 * 132897987541L); byte[] arrayOfByte1 = new byte[32768]; this.o = this.m.u().b(this.o, paramInt1 * 16, paramInt2 * 16, 16, 16); a(paramInt1, paramInt2, arrayOfByte1, this.o); b(paramInt1, paramInt2, arrayOfByte1, this.o); abw abw = new abw(this.m, arrayOfByte1, paramInt1, paramInt2); byte[] arrayOfByte2 = abw.m(); for (byte b = 0; b < arrayOfByte2.length; b++) arrayOfByte2[b] = (byte)(this.o[b]).N;  abw.b(); return abw; }
/*     */   private double[] a(double[] paramArrayOfdouble, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { if (paramArrayOfdouble == null) paramArrayOfdouble = new double[paramInt4 * paramInt5 * paramInt6];  double d1 = 684.412D; double d2 = 684.412D; this.f = this.a.a(this.f, paramInt1, paramInt3, paramInt4, paramInt6, 1.121D, 1.121D, 0.5D); this.g = this.b.a(this.g, paramInt1, paramInt3, paramInt4, paramInt6, 200.0D, 200.0D, 0.5D); d1 *= 2.0D; this.c = this.l.a(this.c, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1 / 80.0D, d2 / 160.0D, d1 / 80.0D); this.d = this.j.a(this.d, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1, d2, d1); this.e = this.k.a(this.e, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1, d2, d1); byte b1 = 0; byte b2 = 0; for (byte b3 = 0; b3 < paramInt4; b3++) { for (byte b = 0; b < paramInt6; b++) { double d3 = (this.f[b2] + 256.0D) / 512.0D; if (d3 > 1.0D) d3 = 1.0D;  double d4 = this.g[b2] / 8000.0D; if (d4 < 0.0D) d4 = -d4 * 0.3D;  d4 = d4 * 3.0D - 2.0D; float f1 = (b3 + paramInt1 - 0) / 1.0F; float f2 = (b + paramInt3 - 0) / 1.0F; float f3 = 100.0F - kx.c(f1 * f1 + f2 * f2) * 8.0F; if (f3 > 80.0F) f3 = 80.0F;  if (f3 < -100.0F) f3 = -100.0F;  if (d4 > 1.0D) d4 = 1.0D;  d4 /= 8.0D; d4 = 0.0D; if (d3 < 0.0D) d3 = 0.0D;  d3 += 0.5D; d4 = d4 * paramInt5 / 16.0D; b2++; double d5 = paramInt5 / 2.0D; for (byte b4 = 0; b4 < paramInt5; b4++) { double d6 = 0.0D; double d7 = (b4 - d5) * 8.0D / d3; if (d7 < 0.0D) d7 *= -1.0D;  double d8 = this.d[b1] / 512.0D; double d9 = this.e[b1] / 512.0D; double d10 = (this.c[b1] / 10.0D + 1.0D) / 2.0D; if (d10 < 0.0D) { d6 = d8; } else if (d10 > 1.0D) { d6 = d9; } else { d6 = d8 + (d9 - d8) * d10; }  d6 -= 8.0D; d6 += f3; byte b5 = 2; if (b4 > paramInt5 / 2 - b5) { double d = ((b4 - paramInt5 / 2 - b5) / 64.0F); if (d < 0.0D) d = 0.0D;  if (d > 1.0D)
/*     */               d = 1.0D;  d6 = d6 * (1.0D - d) + -3000.0D * d; }  b5 = 8; if (b4 < b5) { double d = ((b5 - b4) / (b5 - 1.0F)); d6 = d6 * (1.0D - d) + -30.0D * d; }  paramArrayOfdouble[b1] = d6; b1++; }  }  }  return paramArrayOfdouble; }
/* 323 */   public boolean a(int paramInt1, int paramInt2) { return true; } public boolean a(boolean paramBoolean, lc paramlc) { return true; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void b() {}
/*     */   
/*     */   public boolean c() {
/* 330 */     return false;
/*     */   }
/*     */   
/*     */   public boolean d() {
/* 334 */     return true;
/*     */   }
/*     */   
/*     */   public String e() {
/* 338 */     return "RandomLevelSource";
/*     */   }
/*     */   
/*     */   public List a(nn paramnn, int paramInt1, int paramInt2, int paramInt3) {
/* 342 */     aav aav1 = this.m.a(paramInt1, paramInt3);
/* 343 */     if (aav1 == null) {
/* 344 */       return null;
/*     */     }
/* 346 */     return aav1.a(paramnn);
/*     */   }
/*     */   
/*     */   public aat a(aab paramaab, String paramString, int paramInt1, int paramInt2, int paramInt3) {
/* 350 */     return null;
/*     */   }
/*     */   
/*     */   public int f() {
/* 354 */     return 0;
/*     */   }
/*     */   
/*     */   public void e(int paramInt1, int paramInt2) {}
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */