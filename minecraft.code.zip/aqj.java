/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aqj
/*    */   extends aqp
/*    */ {
/* 11 */   private final zs a = new aqk(this);
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void a(bs parambs) {
/* 49 */     super.a(parambs);
/* 50 */     this.a.a(parambs);
/*    */   }
/*    */ 
/*    */   
/*    */   public void b(bs parambs) {
/* 55 */     super.b(parambs);
/* 56 */     this.a.b(parambs);
/*    */   }
/*    */ 
/*    */   
/*    */   public void h() {
/* 61 */     this.a.g();
/* 62 */     super.h();
/*    */   }
/*    */ 
/*    */   
/*    */   public ei m() {
/* 67 */     bs bs = new bs();
/* 68 */     b(bs);
/* 69 */     bs.o("SpawnPotentials");
/* 70 */     return new fn(this.l, this.m, this.n, 1, bs);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b(int paramInt1, int paramInt2) {
/* 75 */     if (this.a.b(paramInt1)) return true; 
/* 76 */     return super.b(paramInt1, paramInt2);
/*    */   }
/*    */   
/*    */   public zs a() {
/* 80 */     return this.a;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */