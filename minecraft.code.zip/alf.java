/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class alf
/*    */   extends apa
/*    */ {
/*    */   public alf(int paramInt) {
/* 12 */     super(paramInt, aif.d);
/* 13 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 18 */     if (paramInt1 == 1 || paramInt1 == 0) return apa.B.m(paramInt1); 
/* 19 */     return super.a(paramInt1, paramInt2);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 24 */     return 3;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 29 */     return wk.aM.cp;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */