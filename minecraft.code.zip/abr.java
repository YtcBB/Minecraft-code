/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class abr
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 13 */     for (byte b = 0; b < 10; b++) {
/* 14 */       int i = paramInt1 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 15 */       int j = paramInt2 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 16 */       int k = paramInt3 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 17 */       if (paramaab.c(i, j, k) && 
/* 18 */         apa.bD.c(paramaab, i, j, k)) {
/* 19 */         paramaab.f(i, j, k, apa.bD.cz, 0, 2);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 24 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */