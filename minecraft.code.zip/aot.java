/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aot
/*     */   extends apa
/*     */ {
/*  17 */   public static final String[] a = new String[] { "stone", "cobble", "brick" };
/*     */ 
/*     */ 
/*     */   
/*     */   public aot(int paramInt) {
/*  22 */     super(paramInt, aif.z);
/*     */     
/*  24 */     c(0.0F);
/*  25 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  30 */     if (paramInt2 == 1) {
/*  31 */       return apa.A.m(paramInt1);
/*     */     }
/*  33 */     if (paramInt2 == 2) {
/*  34 */       return apa.bq.m(paramInt1);
/*     */     }
/*  36 */     return apa.x.m(paramInt1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void g(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  46 */     if (!paramaab.I) {
/*  47 */       se se = new se(paramaab);
/*  48 */       se.b(paramInt1 + 0.5D, paramInt2, paramInt3 + 0.5D, 0.0F, 0.0F);
/*  49 */       paramaab.d(se);
/*     */       
/*  51 */       se.aU();
/*     */     } 
/*  53 */     super.g(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/*  58 */     return 0;
/*     */   }
/*     */   
/*     */   public static boolean d(int paramInt) {
/*  62 */     return (paramInt == apa.x.cz || paramInt == apa.A.cz || paramInt == apa.bq.cz);
/*     */   }
/*     */   
/*     */   public static int e(int paramInt) {
/*  66 */     if (paramInt == apa.A.cz) {
/*  67 */       return 1;
/*     */     }
/*  69 */     if (paramInt == apa.bq.cz) {
/*  70 */       return 2;
/*     */     }
/*  72 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected wm c_(int paramInt) {
/*  88 */     apa apa1 = apa.x;
/*  89 */     if (paramInt == 1) {
/*  90 */       apa1 = apa.A;
/*     */     }
/*  92 */     if (paramInt == 2) {
/*  93 */       apa1 = apa.bq;
/*     */     }
/*  95 */     return new wm(apa1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int h(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 100 */     return paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 105 */     for (byte b = 0; b < 3; b++)
/* 106 */       paramList.add(new wm(paramInt, 1, b)); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aot.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */