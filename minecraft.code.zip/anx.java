/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class anx
/*    */   extends ala
/*    */ {
/*    */   private any a;
/*    */   
/*    */   protected anx(int paramInt, String paramString, aif paramaif, any paramany) {
/* 19 */     super(paramInt, paramString, paramaif);
/* 20 */     this.a = paramany;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int d(int paramInt) {
/* 25 */     return (paramInt > 0) ? 1 : 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int c(int paramInt) {
/* 30 */     return (paramInt == 1) ? 15 : 0;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int e(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 35 */     List list = null;
/*    */     
/* 37 */     if (this.a == any.a) list = paramaab.b((mp)null, a(paramInt1, paramInt2, paramInt3)); 
/* 38 */     if (this.a == any.b) list = paramaab.a(ng.class, a(paramInt1, paramInt2, paramInt3)); 
/* 39 */     if (this.a == any.c) list = paramaab.a(sq.class, a(paramInt1, paramInt2, paramInt3));
/*    */     
/* 41 */     if (!list.isEmpty()) {
/* 42 */       for (mp mp : list) {
/* 43 */         if (!mp.at()) {
/* 44 */           return 15;
/*    */         }
/*    */       } 
/*    */     }
/*    */     
/* 49 */     return 0;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anx.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */