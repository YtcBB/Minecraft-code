/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adx
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 11 */     for (byte b = 0; b < 64; b++) {
/* 12 */       int i = paramInt1 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 13 */       int j = paramInt2 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 14 */       int k = paramInt3 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 15 */       if (paramaab.c(i, j, k) && paramaab.a(i, j - 1, k) == apa.y.cz && 
/* 16 */         apa.be.c(paramaab, i, j, k)) {
/* 17 */         paramaab.f(i, j, k, apa.be.cz, paramRandom.nextInt(4), 2);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 22 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adx.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */