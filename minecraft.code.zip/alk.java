/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class alk
/*     */   extends apa
/*     */ {
/*     */   private lx a;
/*     */   private lx b;
/*     */   private lx c;
/*     */   
/*     */   protected alk(int paramInt) {
/*  21 */     super(paramInt, aif.D);
/*  22 */     b(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  27 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*  28 */     float f1 = 0.0625F;
/*  29 */     float f2 = (1 + i * 2) / 16.0F;
/*  30 */     float f3 = 0.5F;
/*  31 */     a(f2, 0.0F, f1, 1.0F - f1, f3, 1.0F - f1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  36 */     float f1 = 0.0625F;
/*  37 */     float f2 = 0.5F;
/*  38 */     a(f1, 0.0F, f1, 1.0F - f1, f2, 1.0F - f1);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  43 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  44 */     float f1 = 0.0625F;
/*  45 */     float f2 = (1 + i * 2) / 16.0F;
/*  46 */     float f3 = 0.5F;
/*  47 */     return aqx.a().a((paramInt1 + f2), paramInt2, (paramInt3 + f1), ((paramInt1 + 1) - f1), (paramInt2 + f3 - f1), ((paramInt3 + 1) - f1));
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  52 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  53 */     float f1 = 0.0625F;
/*  54 */     float f2 = (1 + i * 2) / 16.0F;
/*  55 */     float f3 = 0.5F;
/*  56 */     return aqx.a().a((paramInt1 + f2), paramInt2, (paramInt3 + f1), ((paramInt1 + 1) - f1), (paramInt2 + f3), ((paramInt3 + 1) - f1));
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  61 */     if (paramInt1 == 1) return this.a; 
/*  62 */     if (paramInt1 == 0) return this.b; 
/*  63 */     if (paramInt2 > 0 && paramInt1 == 4) return this.c; 
/*  64 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  69 */     this.cQ = paramly.a("cake_side");
/*  70 */     this.c = paramly.a("cake_inner");
/*  71 */     this.a = paramly.a("cake_top");
/*  72 */     this.b = paramly.a("cake_bottom");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  82 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  87 */     b(paramaab, paramInt1, paramInt2, paramInt3, paramsq);
/*  88 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {
/*  93 */     b(paramaab, paramInt1, paramInt2, paramInt3, paramsq);
/*     */   }
/*     */   
/*     */   private void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {
/*  97 */     if (paramsq.i(false)) {
/*  98 */       paramsq.cn().a(2, 0.1F);
/*     */       
/* 100 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3) + 1;
/* 101 */       if (i >= 6) {
/* 102 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       } else {
/* 104 */         paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 111 */     if (!super.c(paramaab, paramInt1, paramInt2, paramInt3)) return false;
/*     */     
/* 113 */     return f(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 118 */     if (!f(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 119 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 125 */     return paramaab.g(paramInt1, paramInt2 - 1, paramInt3).a();
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 130 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 135 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 140 */     return wk.ba.cp;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */