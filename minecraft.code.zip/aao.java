/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aao
/*     */ {
/*     */   private final iz a;
/*     */   private final Random b;
/*  14 */   private final kv c = new kv();
/*  15 */   private final List d = new ArrayList();
/*     */   
/*     */   public aao(iz paramiz) {
/*  18 */     this.a = paramiz;
/*  19 */     this.b = new Random(paramiz.G());
/*     */   }
/*     */   
/*     */   public void a(mp parammp, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat) {
/*  23 */     if (this.a.t.h == 1) {
/*  24 */       int i = kx.c(parammp.u);
/*  25 */       int j = kx.c(parammp.v) - 1;
/*  26 */       int k = kx.c(parammp.w);
/*     */       
/*  28 */       byte b1 = 1;
/*  29 */       byte b2 = 0;
/*  30 */       for (byte b = -2; b <= 2; b++) {
/*  31 */         for (byte b3 = -2; b3 <= 2; b3++) {
/*  32 */           for (byte b4 = -1; b4 < 3; b4++) {
/*  33 */             int m = i + b3 * b1 + b * b2;
/*  34 */             int n = j + b4;
/*  35 */             int i1 = k + b3 * b2 - b * b1;
/*     */             
/*  37 */             boolean bool = (b4 < 0) ? true : false;
/*     */             
/*  39 */             this.a.c(m, n, i1, bool ? apa.at.cz : 0);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/*  44 */       parammp.b(i, j, k, parammp.A, 0.0F);
/*  45 */       parammp.x = parammp.y = parammp.z = 0.0D;
/*     */       
/*     */       return;
/*     */     } 
/*  49 */     if (b(parammp, paramDouble1, paramDouble2, paramDouble3, paramFloat)) {
/*     */       return;
/*     */     }
/*     */     
/*  53 */     a(parammp);
/*  54 */     b(parammp, paramDouble1, paramDouble2, paramDouble3, paramFloat);
/*     */   }
/*     */   
/*     */   public boolean b(mp parammp, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat) {
/*  58 */     char c = '';
/*  59 */     double d = -1.0D;
/*  60 */     int i = 0;
/*  61 */     int j = 0;
/*  62 */     int k = 0;
/*     */     
/*  64 */     int m = kx.c(parammp.u);
/*  65 */     int n = kx.c(parammp.w);
/*  66 */     long l = zu.a(m, n);
/*  67 */     boolean bool = true;
/*     */     
/*  69 */     if (this.c.b(l)) {
/*  70 */       aap aap = (aap)this.c.a(l);
/*     */       
/*  72 */       d = 0.0D;
/*  73 */       i = aap.a;
/*  74 */       j = aap.b;
/*  75 */       k = aap.c;
/*  76 */       aap.d = this.a.H();
/*  77 */       bool = false;
/*     */     } else {
/*  79 */       for (int i1 = m - c; i1 <= m + c; i1++) {
/*  80 */         double d1 = i1 + 0.5D - parammp.u;
/*  81 */         for (int i2 = n - c; i2 <= n + c; i2++) {
/*  82 */           double d2 = i2 + 0.5D - parammp.w;
/*  83 */           for (int i3 = this.a.R() - 1; i3 >= 0; i3--) {
/*  84 */             if (this.a.a(i1, i3, i2) == apa.bi.cz) {
/*  85 */               while (this.a.a(i1, i3 - 1, i2) == apa.bi.cz) {
/*  86 */                 i3--;
/*     */               }
/*     */               
/*  89 */               double d3 = i3 + 0.5D - parammp.v;
/*  90 */               double d4 = d1 * d1 + d3 * d3 + d2 * d2;
/*  91 */               if (d < 0.0D || d4 < d) {
/*  92 */                 d = d4;
/*  93 */                 i = i1;
/*  94 */                 j = i3;
/*  95 */                 k = i2;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 103 */     if (d >= 0.0D) {
/* 104 */       int i1 = i;
/* 105 */       int i2 = j;
/* 106 */       int i3 = k;
/*     */       
/* 108 */       if (bool) {
/* 109 */         this.c.a(l, new aap(this, i1, i2, i3, this.a.H()));
/* 110 */         this.d.add(Long.valueOf(l));
/*     */       } 
/*     */       
/* 113 */       double d1 = i1 + 0.5D;
/* 114 */       double d2 = i2 + 0.5D;
/* 115 */       double d3 = i3 + 0.5D;
/* 116 */       int i4 = -1;
/*     */       
/* 118 */       if (this.a.a(i1 - 1, i2, i3) == apa.bi.cz) i4 = 2; 
/* 119 */       if (this.a.a(i1 + 1, i2, i3) == apa.bi.cz) i4 = 0; 
/* 120 */       if (this.a.a(i1, i2, i3 - 1) == apa.bi.cz) i4 = 3; 
/* 121 */       if (this.a.a(i1, i2, i3 + 1) == apa.bi.cz) i4 = 1;
/*     */       
/* 123 */       int i5 = parammp.as();
/*     */       
/* 125 */       if (i4 > -1) {
/* 126 */         int i6 = r.h[i4];
/* 127 */         int i7 = r.a[i4];
/* 128 */         int i8 = r.b[i4];
/* 129 */         int i9 = r.a[i6];
/* 130 */         int i10 = r.b[i6];
/*     */         
/* 132 */         boolean bool1 = (!this.a.c(i1 + i7 + i9, i2, i3 + i8 + i10) || !this.a.c(i1 + i7 + i9, i2 + 1, i3 + i8 + i10)) ? true : false;
/* 133 */         boolean bool2 = (!this.a.c(i1 + i7, i2, i3 + i8) || !this.a.c(i1 + i7, i2 + 1, i3 + i8)) ? true : false;
/*     */         
/* 135 */         if (bool1 && bool2) {
/* 136 */           i4 = r.f[i4];
/* 137 */           i6 = r.f[i6];
/* 138 */           i7 = r.a[i4];
/* 139 */           i8 = r.b[i4];
/* 140 */           i9 = r.a[i6];
/* 141 */           i10 = r.b[i6];
/*     */           
/* 143 */           i1 -= i9;
/* 144 */           d1 -= i9;
/* 145 */           i3 -= i10;
/* 146 */           d3 -= i10;
/* 147 */           bool1 = (!this.a.c(i1 + i7 + i9, i2, i3 + i8 + i10) || !this.a.c(i1 + i7 + i9, i2 + 1, i3 + i8 + i10)) ? true : false;
/* 148 */           bool2 = (!this.a.c(i1 + i7, i2, i3 + i8) || !this.a.c(i1 + i7, i2 + 1, i3 + i8)) ? true : false;
/*     */         } 
/*     */         
/* 151 */         float f1 = 0.5F;
/* 152 */         float f2 = 0.5F;
/*     */         
/* 154 */         if (!bool1 && bool2) {
/* 155 */           f1 = 1.0F;
/* 156 */         } else if (bool1 && !bool2) {
/* 157 */           f1 = 0.0F;
/* 158 */         } else if (bool1 && bool2) {
/* 159 */           f2 = 0.0F;
/*     */         } 
/*     */ 
/*     */         
/* 163 */         d1 += (i9 * f1 + f2 * i7);
/* 164 */         d3 += (i10 * f1 + f2 * i8);
/*     */         
/* 166 */         float f3 = 0.0F;
/* 167 */         float f4 = 0.0F;
/* 168 */         float f5 = 0.0F;
/* 169 */         float f6 = 0.0F;
/*     */         
/* 171 */         if (i4 == i5) {
/* 172 */           f3 = 1.0F;
/* 173 */           f4 = 1.0F;
/* 174 */         } else if (i4 == r.f[i5]) {
/* 175 */           f3 = -1.0F;
/* 176 */           f4 = -1.0F;
/* 177 */         } else if (i4 == r.g[i5]) {
/* 178 */           f5 = 1.0F;
/* 179 */           f6 = -1.0F;
/*     */         } else {
/* 181 */           f5 = -1.0F;
/* 182 */           f6 = 1.0F;
/*     */         } 
/*     */         
/* 185 */         double d4 = parammp.x;
/* 186 */         double d5 = parammp.z;
/* 187 */         parammp.x = d4 * f3 + d5 * f6;
/* 188 */         parammp.z = d4 * f5 + d5 * f4;
/* 189 */         parammp.A = paramFloat - (i5 * 90) + (i4 * 90);
/*     */       } else {
/* 191 */         parammp.x = parammp.y = parammp.z = 0.0D;
/*     */       } 
/*     */       
/* 194 */       parammp.b(d1, d2, d3, parammp.A, parammp.B);
/* 195 */       return true;
/*     */     } 
/*     */     
/* 198 */     return false;
/*     */   }
/*     */   
/*     */   public boolean a(mp parammp) {
/* 202 */     byte b1 = 16;
/* 203 */     double d = -1.0D;
/*     */     
/* 205 */     int i = kx.c(parammp.u);
/* 206 */     int j = kx.c(parammp.v);
/* 207 */     int k = kx.c(parammp.w);
/*     */     
/* 209 */     int m = i;
/* 210 */     int n = j;
/* 211 */     int i1 = k;
/* 212 */     int i2 = 0;
/*     */     
/* 214 */     int i3 = this.b.nextInt(4);
/*     */     int i4;
/* 216 */     for (i4 = i - b1; i4 <= i + b1; i4++) {
/* 217 */       double d1 = i4 + 0.5D - parammp.u;
/* 218 */       for (int i10 = k - b1; i10 <= k + b1; i10++) {
/* 219 */         double d2 = i10 + 0.5D - parammp.w; int i11;
/* 220 */         label175: for (i11 = this.a.R() - 1; i11 >= 0; i11--) {
/* 221 */           if (this.a.c(i4, i11, i10)) {
/* 222 */             while (i11 > 0 && this.a.c(i4, i11 - 1, i10)) {
/* 223 */               i11--;
/*     */             }
/*     */             
/* 226 */             for (int i12 = i3; i12 < i3 + 4; i12++) {
/* 227 */               int i13 = i12 % 2;
/* 228 */               int i14 = 1 - i13;
/*     */               
/* 230 */               if (i12 % 4 >= 2) {
/* 231 */                 i13 = -i13;
/* 232 */                 i14 = -i14;
/*     */               } 
/*     */               
/* 235 */               for (byte b = 0; b < 3; b++) {
/* 236 */                 for (byte b3 = 0; b3 < 4; b3++) {
/* 237 */                   for (byte b4 = -1; b4 < 4; b4++) {
/* 238 */                     int i15 = i4 + (b3 - 1) * i13 + b * i14;
/* 239 */                     int i16 = i11 + b4;
/* 240 */                     int i17 = i10 + (b3 - 1) * i14 - b * i13;
/*     */                     
/* 242 */                     if (b4 < 0 && !this.a.g(i15, i16, i17).a())
/* 243 */                       continue label175;  if (b4 >= 0 && !this.a.c(i15, i16, i17))
/*     */                       continue label175; 
/*     */                   } 
/*     */                 } 
/*     */               } 
/* 248 */               double d3 = i11 + 0.5D - parammp.v;
/* 249 */               double d4 = d1 * d1 + d3 * d3 + d2 * d2;
/* 250 */               if (d < 0.0D || d4 < d) {
/* 251 */                 d = d4;
/* 252 */                 m = i4;
/* 253 */                 n = i11;
/* 254 */                 i1 = i10;
/* 255 */                 i2 = i12 % 4;
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 262 */     if (d < 0.0D) {
/* 263 */       for (i4 = i - b1; i4 <= i + b1; i4++) {
/* 264 */         double d1 = i4 + 0.5D - parammp.u;
/* 265 */         for (int i10 = k - b1; i10 <= k + b1; i10++) {
/* 266 */           double d2 = i10 + 0.5D - parammp.w; int i11;
/* 267 */           label172: for (i11 = this.a.R() - 1; i11 >= 0; i11--) {
/* 268 */             if (this.a.c(i4, i11, i10)) {
/* 269 */               while (i11 > 0 && this.a.c(i4, i11 - 1, i10)) {
/* 270 */                 i11--;
/*     */               }
/*     */               
/* 273 */               for (int i12 = i3; i12 < i3 + 2; i12++) {
/* 274 */                 int i13 = i12 % 2;
/* 275 */                 int i14 = 1 - i13;
/* 276 */                 for (byte b = 0; b < 4; b++) {
/* 277 */                   for (byte b3 = -1; b3 < 4; b3++) {
/* 278 */                     int i15 = i4 + (b - 1) * i13;
/* 279 */                     int i16 = i11 + b3;
/* 280 */                     int i17 = i10 + (b - 1) * i14;
/*     */                     
/* 282 */                     if (b3 < 0 && !this.a.g(i15, i16, i17).a())
/* 283 */                       continue label172;  if (b3 >= 0 && !this.a.c(i15, i16, i17))
/*     */                       continue label172; 
/*     */                   } 
/*     */                 } 
/* 287 */                 double d3 = i11 + 0.5D - parammp.v;
/* 288 */                 double d4 = d1 * d1 + d3 * d3 + d2 * d2;
/* 289 */                 if (d < 0.0D || d4 < d) {
/* 290 */                   d = d4;
/* 291 */                   m = i4;
/* 292 */                   n = i11;
/* 293 */                   i1 = i10;
/* 294 */                   i2 = i12 % 2;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 303 */     i4 = i2;
/*     */     
/* 305 */     int i5 = m;
/* 306 */     int i6 = n;
/* 307 */     int i7 = i1;
/*     */     
/* 309 */     int i8 = i4 % 2;
/* 310 */     int i9 = 1 - i8;
/*     */     
/* 312 */     if (i4 % 4 >= 2) {
/* 313 */       i8 = -i8;
/* 314 */       i9 = -i9;
/*     */     } 
/*     */     
/* 317 */     if (d < 0.0D) {
/* 318 */       if (n < 70) n = 70; 
/* 319 */       if (n > this.a.R() - 10) n = this.a.R() - 10; 
/* 320 */       i6 = n;
/*     */       
/* 322 */       for (byte b = -1; b <= 1; b++) {
/* 323 */         for (byte b3 = 1; b3 < 3; b3++) {
/* 324 */           for (byte b4 = -1; b4 < 3; b4++) {
/* 325 */             int i10 = i5 + (b3 - 1) * i8 + b * i9;
/* 326 */             int i11 = i6 + b4;
/* 327 */             int i12 = i7 + (b3 - 1) * i9 - b * i8;
/*     */             
/* 329 */             boolean bool = (b4 < 0) ? true : false;
/*     */             
/* 331 */             this.a.c(i10, i11, i12, bool ? apa.at.cz : 0);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 337 */     for (byte b2 = 0; b2 < 4; b2++) {
/* 338 */       byte b; for (b = 0; b < 4; b++) {
/* 339 */         for (byte b3 = -1; b3 < 4; b3++) {
/* 340 */           int i10 = i5 + (b - 1) * i8;
/* 341 */           int i11 = i6 + b3;
/* 342 */           int i12 = i7 + (b - 1) * i9;
/*     */           
/* 344 */           boolean bool = (b == 0 || b == 3 || b3 == -1 || b3 == 3) ? true : false;
/* 345 */           this.a.f(i10, i11, i12, bool ? apa.at.cz : apa.bi.cz, 0, 2);
/*     */         } 
/*     */       } 
/*     */       
/* 349 */       for (b = 0; b < 4; b++) {
/* 350 */         for (byte b3 = -1; b3 < 4; b3++) {
/* 351 */           int i10 = i5 + (b - 1) * i8;
/* 352 */           int i11 = i6 + b3;
/* 353 */           int i12 = i7 + (b - 1) * i9;
/*     */           
/* 355 */           this.a.f(i10, i11, i12, this.a.a(i10, i11, i12));
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 360 */     return true;
/*     */   }
/*     */   
/*     */   public void a(long paramLong) {
/* 364 */     if (paramLong % 100L == 0L) {
/* 365 */       Iterator<Long> iterator = this.d.iterator();
/* 366 */       long l = paramLong - 600L;
/*     */       
/* 368 */       while (iterator.hasNext()) {
/* 369 */         Long long_ = iterator.next();
/* 370 */         aap aap = (aap)this.c.a(long_.longValue());
/*     */         
/* 372 */         if (aap == null || aap.d < l) {
/* 373 */           iterator.remove();
/* 374 */           this.c.d(long_.longValue());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aao.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */