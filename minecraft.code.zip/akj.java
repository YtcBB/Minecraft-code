/*    */ 
/*    */ 
/*    */ 
/*    */ public class akj
/*    */   implements Comparable
/*    */ {
/*    */   private final String a;
/*    */   private final String b;
/*    */   private final long c;
/*    */   private final long d;
/*    */   private final boolean e;
/*    */   private final aaj f;
/*    */   private final boolean g;
/*    */   private final boolean h;
/*    */   
/*    */   public akj(String paramString1, String paramString2, long paramLong1, long paramLong2, aaj paramaaj, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 17 */     this.a = paramString1;
/* 18 */     this.b = paramString2;
/* 19 */     this.c = paramLong1;
/* 20 */     this.d = paramLong2;
/* 21 */     this.f = paramaaj;
/* 22 */     this.e = paramBoolean1;
/* 23 */     this.g = paramBoolean2;
/* 24 */     this.h = paramBoolean3;
/*    */   }
/*    */   
/*    */   public String a() {
/* 28 */     return this.a;
/*    */   }
/*    */   
/*    */   public String b() {
/* 32 */     return this.b;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean d() {
/* 40 */     return this.e;
/*    */   }
/*    */   
/*    */   public long e() {
/* 44 */     return this.c;
/*    */   }
/*    */   
/*    */   public int a(akj paramakj) {
/* 48 */     if (this.c < paramakj.c) {
/* 49 */       return 1;
/*    */     }
/* 51 */     if (this.c > paramakj.c) {
/* 52 */       return -1;
/*    */     }
/* 54 */     return this.a.compareTo(paramakj.a);
/*    */   }
/*    */   
/*    */   public aaj f() {
/* 58 */     return this.f;
/*    */   }
/*    */   
/*    */   public boolean g() {
/* 62 */     return this.g;
/*    */   }
/*    */   
/*    */   public boolean h() {
/* 66 */     return this.h;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\akj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */