/*    */ import java.util.List;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aj
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 13 */     return "gamerule";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 18 */     return 2;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 24 */     return paramab.a("commands.gamerule.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 28 */     if (paramArrayOfString.length == 2) {
/* 29 */       String str1 = paramArrayOfString[0];
/* 30 */       String str2 = paramArrayOfString[1];
/*    */       
/* 32 */       zy zy = d();
/*    */       
/* 34 */       if (zy.e(str1)) {
/* 35 */         zy.b(str1, str2);
/* 36 */         a(paramab, "commands.gamerule.success", new Object[0]);
/*    */       } else {
/* 38 */         a(paramab, "commands.gamerule.norule", new Object[] { str1 });
/*    */       } 
/*    */       return;
/*    */     } 
/* 42 */     if (paramArrayOfString.length == 1) {
/* 43 */       String str = paramArrayOfString[0];
/* 44 */       zy zy = d();
/*    */       
/* 46 */       if (zy.e(str)) {
/* 47 */         String str1 = zy.a(str);
/* 48 */         paramab.a(str + " = " + str1);
/*    */       } else {
/* 50 */         a(paramab, "commands.gamerule.norule", new Object[] { str });
/*    */       } 
/*    */       return;
/*    */     } 
/* 54 */     if (paramArrayOfString.length == 0) {
/* 55 */       zy zy = d();
/*    */       
/* 57 */       paramab.a(a((Object[])zy.b()));
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 62 */     throw new ax("commands.gamerule.usage", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public List a(ab paramab, String[] paramArrayOfString) {
/* 67 */     if (paramArrayOfString.length == 1)
/* 68 */       return a(paramArrayOfString, d().b()); 
/* 69 */     if (paramArrayOfString.length == 2) {
/* 70 */       return a(paramArrayOfString, new String[] { "true", "false" });
/*    */     }
/*    */     
/* 73 */     return null;
/*    */   }
/*    */   
/*    */   private zy d() {
/* 77 */     return MinecraftServer.D().a(0).N();
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */