/*    */ 
/*    */ 
/*    */ 
/*    */ public class abp
/*    */   extends aav
/*    */ {
/*    */   public abp(int paramInt) {
/*  8 */     super(paramInt);
/*    */     
/* 10 */     this.J.clear();
/* 11 */     this.K.clear();
/* 12 */     this.L.clear();
/* 13 */     this.M.clear();
/*    */     
/* 15 */     this.J.add(new aaw(rv.class, 10, 4, 4));
/* 16 */     this.A = (byte)apa.z.cz;
/* 17 */     this.B = (byte)apa.z.cz;
/*    */     
/* 19 */     this.I = new abq(this);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(float paramFloat) {
/* 24 */     return 0;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */