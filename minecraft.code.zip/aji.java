/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aji
/*    */ {
/*    */   private final ajh[] a;
/*    */   private int b;
/*    */   private int c;
/*    */   
/*    */   public aji(ajh[] paramArrayOfajh) {
/* 12 */     this.a = paramArrayOfajh;
/* 13 */     this.c = paramArrayOfajh.length;
/*    */   }
/*    */   
/*    */   public void a() {
/* 17 */     this.b++;
/*    */   }
/*    */   
/*    */   public boolean b() {
/* 21 */     return (this.b >= this.c);
/*    */   }
/*    */   
/*    */   public ajh c() {
/* 25 */     if (this.c > 0) {
/* 26 */       return this.a[this.c - 1];
/*    */     }
/* 28 */     return null;
/*    */   }
/*    */   
/*    */   public ajh a(int paramInt) {
/* 32 */     return this.a[paramInt];
/*    */   }
/*    */   
/*    */   public int d() {
/* 36 */     return this.c;
/*    */   }
/*    */   
/*    */   public void b(int paramInt) {
/* 40 */     this.c = paramInt;
/*    */   }
/*    */   
/*    */   public int e() {
/* 44 */     return this.b;
/*    */   }
/*    */   
/*    */   public void c(int paramInt) {
/* 48 */     this.b = paramInt;
/*    */   }
/*    */   
/*    */   public arc a(mp parammp, int paramInt) {
/* 52 */     double d1 = (this.a[paramInt]).a + (int)(parammp.O + 1.0F) * 0.5D;
/* 53 */     double d2 = (this.a[paramInt]).b;
/* 54 */     double d3 = (this.a[paramInt]).c + (int)(parammp.O + 1.0F) * 0.5D;
/* 55 */     return parammp.q.U().a(d1, d2, d3);
/*    */   }
/*    */   
/*    */   public arc a(mp parammp) {
/* 59 */     return a(parammp, this.b);
/*    */   }
/*    */   
/*    */   public boolean a(aji paramaji) {
/* 63 */     if (paramaji == null) return false; 
/* 64 */     if (paramaji.a.length != this.a.length) return false; 
/* 65 */     for (byte b = 0; b < this.a.length; b++) {
/* 66 */       if ((this.a[b]).a != (paramaji.a[b]).a || (this.a[b]).b != (paramaji.a[b]).b || (this.a[b]).c != (paramaji.a[b]).c)
/* 67 */         return false; 
/* 68 */     }  return true;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean b(arc paramarc) {
/* 78 */     ajh ajh1 = c();
/* 79 */     if (ajh1 == null) return false; 
/* 80 */     return (ajh1.a == (int)paramarc.c && ajh1.c == (int)paramarc.e);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aji.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */