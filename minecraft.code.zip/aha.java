/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class aha
/*     */   extends agy
/*     */ {
/*     */   private boolean c = false;
/*     */   
/*     */   public aha(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/*  75 */     ArrayList arrayList = ahb.a(paramRandom, paramInt3);
/*     */     
/*  77 */     ahm ahm = new ahm(paramaab.u(), 0, paramRandom, (paramInt1 << 4) + 2, (paramInt2 << 4) + 2, arrayList, paramInt3);
/*  78 */     this.a.add(ahm);
/*  79 */     ahm.a(ahm, this.a, paramRandom);
/*     */     
/*  81 */     ArrayList<agw> arrayList1 = ahm.j;
/*  82 */     ArrayList<agw> arrayList2 = ahm.i;
/*  83 */     while (!arrayList1.isEmpty() || !arrayList2.isEmpty()) {
/*     */ 
/*     */       
/*  86 */       if (arrayList1.isEmpty()) {
/*  87 */         int j = paramRandom.nextInt(arrayList2.size());
/*  88 */         agw agw1 = arrayList2.remove(j);
/*  89 */         agw1.a(ahm, this.a, paramRandom); continue;
/*     */       } 
/*  91 */       int i = paramRandom.nextInt(arrayList1.size());
/*  92 */       agw agw = arrayList1.remove(i);
/*  93 */       agw.a(ahm, this.a, paramRandom);
/*     */     } 
/*     */ 
/*     */     
/*  97 */     c();
/*     */     
/*  99 */     byte b = 0;
/* 100 */     for (agw agw : this.a) {
/* 101 */       if (!(agw instanceof ahq)) {
/* 102 */         b++;
/*     */       }
/*     */     } 
/* 105 */     this.c = (b > 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean d() {
/* 110 */     return this.c;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aha.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */