/*    */ 
/*    */ 
/*    */ 
/*    */ public class aau
/*    */   extends aav
/*    */ {
/*    */   public aau(int paramInt) {
/*  8 */     super(paramInt);
/*    */ 
/*    */     
/* 11 */     this.K.clear();
/* 12 */     this.A = (byte)apa.I.cz;
/* 13 */     this.B = (byte)apa.I.cz;
/*    */     
/* 15 */     this.I.z = -999;
/* 16 */     this.I.C = 0;
/* 17 */     this.I.E = 0;
/* 18 */     this.I.F = 0;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aau.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */