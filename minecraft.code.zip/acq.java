/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class acq
/*    */   extends acn
/*    */ {
/*    */   public void b() {
/* 14 */     this.d = new abd(aav.k, 0.5F, 0.0F);
/* 15 */     this.h = 1;
/* 16 */     this.f = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public abt c() {
/* 21 */     return new acz(this.a, this.a.G());
/*    */   }
/*    */ 
/*    */   
/*    */   public float a(long paramLong, float paramFloat) {
/* 26 */     return 0.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public float[] a(float paramFloat1, float paramFloat2) {
/* 31 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public arc b(float paramFloat1, float paramFloat2) {
/* 36 */     int i = 10518688;
/* 37 */     float f1 = kx.b(paramFloat1 * 3.1415927F * 2.0F) * 2.0F + 0.5F;
/* 38 */     if (f1 < 0.0F) f1 = 0.0F; 
/* 39 */     if (f1 > 1.0F) f1 = 1.0F;
/*    */     
/* 41 */     float f2 = (i >> 16 & 0xFF) / 255.0F;
/* 42 */     float f3 = (i >> 8 & 0xFF) / 255.0F;
/* 43 */     float f4 = (i & 0xFF) / 255.0F;
/* 44 */     f2 *= f1 * 0.0F + 0.15F;
/* 45 */     f3 *= f1 * 0.0F + 0.15F;
/* 46 */     f4 *= f1 * 0.0F + 0.15F;
/*    */     
/* 48 */     return this.a.U().a(f2, f3, f4);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean g() {
/* 53 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean e() {
/* 58 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean d() {
/* 63 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public float f() {
/* 68 */     return 8.0F;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(int paramInt1, int paramInt2) {
/* 73 */     int i = this.a.b(paramInt1, paramInt2);
/*    */     
/* 75 */     if (i == 0) return false;
/*    */     
/* 77 */     return (apa.r[i]).cO.c();
/*    */   }
/*    */ 
/*    */   
/*    */   public t h() {
/* 82 */     return new t(100, 50, 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int i() {
/* 87 */     return 50;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b(int paramInt1, int paramInt2) {
/* 92 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public String l() {
/* 97 */     return "The End";
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */