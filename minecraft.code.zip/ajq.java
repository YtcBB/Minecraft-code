/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.util.ArrayList;
/*     */ import java.util.Collection;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ajq
/*     */   extends aju
/*     */ {
/*     */   public ajq(File paramFile) {
/*  32 */     super(paramFile);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List b() {
/*  43 */     if (this.a == null || !this.a.exists() || !this.a.isDirectory()) {
/*  44 */       throw new akg("Unable to read or access folder where game worlds are saved!");
/*     */     }
/*     */     
/*  47 */     ArrayList<akj> arrayList = new ArrayList();
/*     */     
/*  49 */     File[] arrayOfFile = this.a.listFiles();
/*  50 */     for (File file : arrayOfFile) {
/*  51 */       if (file.isDirectory()) {
/*     */ 
/*     */ 
/*     */         
/*  55 */         String str = file.getName();
/*     */         
/*  57 */         ajv ajv = c(str);
/*  58 */         if (ajv != null && (ajv.l() == 19132 || ajv.l() == 19133)) {
/*  59 */           boolean bool = (ajv.l() != c()) ? true : false;
/*  60 */           String str1 = ajv.k();
/*  61 */           if (str1 == null || kx.a(str1)) {
/*  62 */             str1 = str;
/*     */           }
/*  64 */           long l = 0L;
/*  65 */           arrayList.add(new akj(str, str1, ajv.m(), l, ajv.r(), bool, ajv.t(), ajv.v()));
/*     */         } 
/*     */       } 
/*     */     } 
/*  69 */     return arrayList;
/*     */   }
/*     */   
/*     */   protected int c() {
/*  73 */     return 19133;
/*     */   }
/*     */ 
/*     */   
/*     */   public void d() {
/*  78 */     aci.a();
/*     */   }
/*     */ 
/*     */   
/*     */   public akf a(String paramString, boolean paramBoolean) {
/*  83 */     return new ajp(this.a, paramString, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean b(String paramString) {
/* 100 */     ajv ajv = c(paramString);
/* 101 */     if (ajv == null || ajv.l() == c()) {
/* 102 */       return false;
/*     */     }
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(String paramString, lc paramlc) {
/* 110 */     paramlc.a(0);
/*     */     
/* 112 */     ArrayList arrayList1 = new ArrayList();
/* 113 */     ArrayList arrayList2 = new ArrayList();
/* 114 */     ArrayList arrayList3 = new ArrayList();
/* 115 */     File file1 = new File(this.a, paramString);
/* 116 */     File file2 = new File(file1, "DIM-1");
/* 117 */     File file3 = new File(file1, "DIM1");
/*     */     
/* 119 */     MinecraftServer.D().al().a("Scanning folders...");
/*     */ 
/*     */     
/* 122 */     a(file1, arrayList1);
/*     */ 
/*     */     
/* 125 */     if (file2.exists()) {
/* 126 */       a(file2, arrayList2);
/*     */     }
/* 128 */     if (file3.exists()) {
/* 129 */       a(file3, arrayList3);
/*     */     }
/*     */     
/* 132 */     int i = arrayList1.size() + arrayList2.size() + arrayList3.size();
/* 133 */     MinecraftServer.D().al().a("Total conversion count is " + i);
/*     */     
/* 135 */     ajv ajv = c(paramString);
/*     */     
/* 137 */     aba aba = null;
/* 138 */     if (ajv.u() == aal.c) {
/* 139 */       aba = new abd(aav.c, 0.5F, 0.5F);
/*     */     } else {
/* 141 */       aba = new aba(ajv.b(), ajv.u());
/*     */     } 
/*     */ 
/*     */     
/* 145 */     a(new File(file1, "region"), arrayList1, aba, 0, i, paramlc);
/*     */     
/* 147 */     a(new File(file2, "region"), arrayList2, new abd(aav.j, 1.0F, 0.0F), arrayList1.size(), i, paramlc);
/*     */     
/* 149 */     a(new File(file3, "region"), arrayList3, new abd(aav.k, 0.5F, 0.0F), arrayList1.size() + arrayList2.size(), i, paramlc);
/*     */     
/* 151 */     ajv.e(19133);
/* 152 */     if (ajv.u() == aal.e) {
/* 153 */       ajv.a(aal.b);
/*     */     }
/*     */     
/* 156 */     g(paramString);
/*     */     
/* 158 */     akf akf = a(paramString, false);
/* 159 */     akf.a(ajv);
/*     */     
/* 161 */     return true;
/*     */   }
/*     */   
/*     */   private void g(String paramString) {
/* 165 */     File file1 = new File(this.a, paramString);
/* 166 */     if (!file1.exists()) {
/* 167 */       System.out.println("Warning: Unable to create level.dat_mcr backup");
/*     */       
/*     */       return;
/*     */     } 
/* 171 */     File file2 = new File(file1, "level.dat");
/* 172 */     if (!file2.exists()) {
/* 173 */       System.out.println("Warning: Unable to create level.dat_mcr backup");
/*     */       
/*     */       return;
/*     */     } 
/* 177 */     File file3 = new File(file1, "level.dat_mcr");
/* 178 */     if (!file2.renameTo(file3)) {
/* 179 */       System.out.println("Warning: Unable to create level.dat_mcr backup");
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   private void a(File paramFile, Iterable paramIterable, aba paramaba, int paramInt1, int paramInt2, lc paramlc) {
/* 185 */     for (File file : paramIterable) {
/* 186 */       a(paramFile, file, paramaba, paramInt1, paramInt2, paramlc);
/*     */       
/* 188 */       paramInt1++;
/* 189 */       int i = (int)Math.round(100.0D * paramInt1 / paramInt2);
/* 190 */       paramlc.a(i);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(File paramFile1, File paramFile2, aba paramaba, int paramInt1, int paramInt2, lc paramlc) {
/*     */     try {
/* 198 */       String str = paramFile2.getName();
/*     */       
/* 200 */       acg acg1 = new acg(paramFile2);
/* 201 */       acg acg2 = new acg(new File(paramFile1, str.substring(0, str.length() - ".mcr".length()) + ".mca"));
/*     */       
/* 203 */       for (byte b = 0; b < 32; b++) {
/* 204 */         int i; for (i = 0; i < 32; i++) {
/* 205 */           if (acg1.c(b, i) && !acg2.c(b, i)) {
/* 206 */             DataInputStream dataInputStream = acg1.a(b, i);
/* 207 */             if (dataInputStream == null) {
/* 208 */               MinecraftServer.D().al().b("Failed to fetch input stream");
/*     */             } else {
/*     */               
/* 211 */               bs bs1 = cc.a(dataInputStream);
/* 212 */               dataInputStream.close();
/*     */               
/* 214 */               bs bs2 = bs1.l("Level");
/* 215 */               acf acf = ace.a(bs2);
/*     */               
/* 217 */               bs bs3 = new bs();
/* 218 */               bs bs4 = new bs();
/* 219 */               bs3.a("Level", bs4);
/* 220 */               ace.a(acf, bs4, paramaba);
/*     */               
/* 222 */               DataOutputStream dataOutputStream = acg2.b(b, i);
/* 223 */               cc.a(bs3, dataOutputStream);
/* 224 */               dataOutputStream.close();
/*     */             } 
/*     */           } 
/* 227 */         }  i = (int)Math.round(100.0D * (paramInt1 * 1024) / (paramInt2 * 1024));
/* 228 */         int j = (int)Math.round(100.0D * ((b + 1) * 32 + paramInt1 * 1024) / (paramInt2 * 1024));
/* 229 */         if (j > i) {
/* 230 */           paramlc.a(j);
/*     */         }
/*     */       } 
/*     */       
/* 234 */       acg1.c();
/* 235 */       acg2.c();
/* 236 */     } catch (IOException iOException) {
/* 237 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void a(File paramFile, Collection<? super File> paramCollection) {
/* 243 */     File file = new File(paramFile, "region");
/* 244 */     File[] arrayOfFile = file.listFiles(new ajr(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 250 */     if (arrayOfFile != null)
/* 251 */       Collections.addAll(paramCollection, arrayOfFile); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */