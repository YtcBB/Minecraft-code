/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class anq
/*    */ {
/*    */   int a;
/*    */   int b;
/*    */   int c;
/*    */   long d;
/*    */   
/*    */   public anq(int paramInt1, int paramInt2, int paramInt3, long paramLong) {
/* 20 */     this.a = paramInt1;
/* 21 */     this.b = paramInt2;
/* 22 */     this.c = paramInt3;
/* 23 */     this.d = paramLong;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */