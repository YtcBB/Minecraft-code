/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aqg
/*     */   extends aqp
/*     */   implements md
/*     */ {
/*  18 */   private static final int[] d = new int[] { 0 };
/*  19 */   private static final int[] e = new int[] { 2, 1 };
/*  20 */   private static final int[] f = new int[] { 1 };
/*     */ 
/*     */ 
/*     */   
/*  24 */   private wm[] g = new wm[3];
/*  25 */   public int a = 0;
/*  26 */   public int b = 0;
/*  27 */   public int c = 0;
/*     */   private String h;
/*     */   
/*     */   public int j_() {
/*  31 */     return this.g.length;
/*     */   }
/*     */   
/*     */   public wm a(int paramInt) {
/*  35 */     return this.g[paramInt];
/*     */   }
/*     */   
/*     */   public wm a(int paramInt1, int paramInt2) {
/*  39 */     if (this.g[paramInt1] != null) {
/*  40 */       if ((this.g[paramInt1]).a <= paramInt2) {
/*  41 */         wm wm2 = this.g[paramInt1];
/*  42 */         this.g[paramInt1] = null;
/*  43 */         return wm2;
/*     */       } 
/*  45 */       wm wm1 = this.g[paramInt1].a(paramInt2);
/*  46 */       if ((this.g[paramInt1]).a == 0) this.g[paramInt1] = null; 
/*  47 */       return wm1;
/*     */     } 
/*     */     
/*  50 */     return null;
/*     */   }
/*     */   
/*     */   public wm b(int paramInt) {
/*  54 */     if (this.g[paramInt] != null) {
/*  55 */       wm wm1 = this.g[paramInt];
/*  56 */       this.g[paramInt] = null;
/*  57 */       return wm1;
/*     */     } 
/*  59 */     return null;
/*     */   }
/*     */   
/*     */   public void a(int paramInt, wm paramwm) {
/*  63 */     this.g[paramInt] = paramwm;
/*  64 */     if (paramwm != null && paramwm.a > d()) paramwm.a = d(); 
/*     */   }
/*     */   
/*     */   public String b() {
/*  68 */     return c() ? this.h : "container.furnace";
/*     */   }
/*     */   
/*     */   public boolean c() {
/*  72 */     return (this.h != null && this.h.length() > 0);
/*     */   }
/*     */   
/*     */   public void a(String paramString) {
/*  76 */     this.h = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(bs parambs) {
/*  82 */     super.a(parambs);
/*  83 */     ca ca = parambs.m("Items");
/*  84 */     this.g = new wm[j_()];
/*  85 */     for (byte b = 0; b < ca.c(); b++) {
/*  86 */       bs bs1 = (bs)ca.b(b);
/*  87 */       byte b1 = bs1.c("Slot");
/*  88 */       if (b1 >= 0 && b1 < this.g.length) this.g[b1] = wm.a(bs1);
/*     */     
/*     */     } 
/*  91 */     this.a = parambs.d("BurnTime");
/*  92 */     this.c = parambs.d("CookTime");
/*  93 */     this.b = a(this.g[1]);
/*  94 */     if (parambs.b("CustomName")) this.h = parambs.i("CustomName");
/*     */   
/*     */   }
/*     */   
/*     */   public void b(bs parambs) {
/*  99 */     super.b(parambs);
/* 100 */     parambs.a("BurnTime", (short)this.a);
/* 101 */     parambs.a("CookTime", (short)this.c);
/* 102 */     ca ca = new ca();
/*     */     
/* 104 */     for (byte b = 0; b < this.g.length; b++) {
/* 105 */       if (this.g[b] != null) {
/* 106 */         bs bs1 = new bs();
/* 107 */         bs1.a("Slot", (byte)b);
/* 108 */         this.g[b].b(bs1);
/* 109 */         ca.a(bs1);
/*     */       } 
/*     */     } 
/* 112 */     parambs.a("Items", ca);
/* 113 */     if (c()) parambs.a("CustomName", this.h); 
/*     */   }
/*     */   
/*     */   public int d() {
/* 117 */     return 64;
/*     */   }
/*     */   
/*     */   public int d(int paramInt) {
/* 121 */     return this.c * paramInt / 200;
/*     */   }
/*     */   
/*     */   public int e(int paramInt) {
/* 125 */     if (this.b == 0) this.b = 200; 
/* 126 */     return this.a * paramInt / this.b;
/*     */   }
/*     */   
/*     */   public boolean j() {
/* 130 */     return (this.a > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void h() {
/* 135 */     boolean bool1 = (this.a > 0) ? true : false;
/* 136 */     boolean bool2 = false;
/* 137 */     if (this.a > 0) {
/* 138 */       this.a--;
/*     */     }
/*     */     
/* 141 */     if (!this.k.I) {
/* 142 */       if (this.a == 0 && u()) {
/* 143 */         this.b = this.a = a(this.g[1]);
/* 144 */         if (this.a > 0) {
/* 145 */           bool2 = true;
/* 146 */           if (this.g[1] != null) {
/* 147 */             (this.g[1]).a--;
/* 148 */             if ((this.g[1]).a == 0) {
/* 149 */               wk wk = this.g[1].b().s();
/* 150 */               this.g[1] = (wk != null) ? new wm(wk) : null;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 156 */       if (j() && u()) {
/* 157 */         this.c++;
/* 158 */         if (this.c == 200) {
/* 159 */           this.c = 0;
/* 160 */           l();
/* 161 */           bool2 = true;
/*     */         } 
/*     */       } else {
/* 164 */         this.c = 0;
/*     */       } 
/*     */       
/* 167 */       if (bool1 != ((this.a > 0) ? true : false)) {
/* 168 */         bool2 = true;
/* 169 */         amn.a((this.a > 0), this.k, this.l, this.m, this.n);
/*     */       } 
/*     */     } 
/*     */     
/* 173 */     if (bool2) k_(); 
/*     */   }
/*     */   
/*     */   private boolean u() {
/* 177 */     if (this.g[0] == null) return false; 
/* 178 */     wm wm1 = yg.a().b((this.g[0].b()).cp);
/* 179 */     if (wm1 == null) return false; 
/* 180 */     if (this.g[2] == null) return true; 
/* 181 */     if (!this.g[2].a(wm1)) return false; 
/* 182 */     if ((this.g[2]).a < d() && (this.g[2]).a < this.g[2].e()) return true; 
/* 183 */     if ((this.g[2]).a < wm1.e()) return true; 
/* 184 */     return false;
/*     */   }
/*     */   
/*     */   public void l() {
/* 188 */     if (!u())
/*     */       return; 
/* 190 */     wm wm1 = yg.a().b((this.g[0].b()).cp);
/* 191 */     if (this.g[2] == null) { this.g[2] = wm1.m(); }
/* 192 */     else if ((this.g[2]).c == wm1.c) { (this.g[2]).a++; }
/*     */     
/* 194 */     (this.g[0]).a--;
/* 195 */     if ((this.g[0]).a <= 0) this.g[0] = null; 
/*     */   }
/*     */   
/*     */   public static int a(wm paramwm) {
/* 199 */     if (paramwm == null) return 0; 
/* 200 */     int i = (paramwm.b()).cp;
/* 201 */     wk wk = paramwm.b();
/*     */     
/* 203 */     if (i < 256 && apa.r[i] != null) {
/* 204 */       apa apa = apa.r[i];
/*     */       
/* 206 */       if (apa == apa.bS) {
/* 207 */         return 150;
/*     */       }
/*     */       
/* 210 */       if (apa.cO == aif.d) {
/* 211 */         return 300;
/*     */       }
/*     */     } 
/*     */     
/* 215 */     if (wk instanceof vr && ((vr)wk).g().equals("WOOD"))
/* 216 */       return 200; 
/* 217 */     if (wk instanceof xr && ((xr)wk).h().equals("WOOD"))
/* 218 */       return 200; 
/* 219 */     if (wk instanceof wj && ((wj)wk).g().equals("WOOD")) {
/* 220 */       return 200;
/*     */     }
/*     */     
/* 223 */     if (i == wk.E.cp) {
/* 224 */       return 100;
/*     */     }
/*     */     
/* 227 */     if (i == wk.n.cp) return 1600;
/*     */     
/* 229 */     if (i == wk.az.cp) return 20000;
/*     */     
/* 231 */     if (i == apa.C.cz) return 100;
/*     */     
/* 233 */     if (i == wk.bp.cp) return 2400;
/*     */     
/* 235 */     return 0;
/*     */   }
/*     */   
/*     */   public static boolean b(wm paramwm) {
/* 239 */     return (a(paramwm) > 0);
/*     */   }
/*     */   
/*     */   public boolean a(sq paramsq) {
/* 243 */     if (this.k.r(this.l, this.m, this.n) != this) return false; 
/* 244 */     if (paramsq.e(this.l + 0.5D, this.m + 0.5D, this.n + 0.5D) > 64.0D) return false; 
/* 245 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void f() {}
/*     */ 
/*     */   
/*     */   public void g() {}
/*     */   
/*     */   public boolean b(int paramInt, wm paramwm) {
/* 255 */     if (paramInt == 2) return false; 
/* 256 */     if (paramInt == 1) return b(paramwm); 
/* 257 */     return true;
/*     */   }
/*     */   
/*     */   public int[] c(int paramInt) {
/* 261 */     if (paramInt == 0)
/* 262 */       return e; 
/* 263 */     if (paramInt == 1) {
/* 264 */       return d;
/*     */     }
/* 266 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt1, wm paramwm, int paramInt2) {
/* 271 */     return b(paramInt1, paramwm);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(int paramInt1, wm paramwm, int paramInt2) {
/* 276 */     if (paramInt2 == 0 && paramInt1 == 1 && 
/* 277 */       paramwm.c != wk.ax.cp) return false;
/*     */ 
/*     */     
/* 280 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */