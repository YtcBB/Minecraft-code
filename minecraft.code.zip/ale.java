/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ale
/*     */   extends alz
/*     */ {
/*  22 */   public static final int[][] a = new int[][] { { 0, 1 }, { -1, 0 }, { 0, -1 }, { 1, 0 } };
/*     */ 
/*     */ 
/*     */   
/*     */   private lx[] b;
/*     */ 
/*     */ 
/*     */   
/*     */   private lx[] c;
/*     */ 
/*     */ 
/*     */   
/*     */   private lx[] d;
/*     */ 
/*     */ 
/*     */   
/*     */   public ale(int paramInt) {
/*  39 */     super(paramInt, aif.n);
/*     */     
/*  41 */     q();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  46 */     if (paramaab.I) return true;
/*     */     
/*  48 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  50 */     if (!e_(i)) {
/*     */       
/*  52 */       int j = j(i);
/*  53 */       paramInt1 += a[j][0];
/*  54 */       paramInt3 += a[j][1];
/*  55 */       if (paramaab.a(paramInt1, paramInt2, paramInt3) != this.cz) {
/*  56 */         return true;
/*     */       }
/*  58 */       i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/*  61 */     if (!paramaab.t.e() || paramaab.a(paramInt1, paramInt3) == aav.j) {
/*  62 */       double d1 = paramInt1 + 0.5D;
/*  63 */       double d2 = paramInt2 + 0.5D;
/*  64 */       double d3 = paramInt3 + 0.5D;
/*  65 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*  66 */       int j = j(i);
/*  67 */       paramInt1 += a[j][0];
/*  68 */       paramInt3 += a[j][1];
/*  69 */       if (paramaab.a(paramInt1, paramInt2, paramInt3) == this.cz) {
/*  70 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*  71 */         d1 = (d1 + paramInt1 + 0.5D) / 2.0D;
/*  72 */         d2 = (d2 + paramInt2 + 0.5D) / 2.0D;
/*  73 */         d3 = (d3 + paramInt3 + 0.5D) / 2.0D;
/*     */       } 
/*  75 */       paramaab.a((mp)null, (paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), 5.0F, true, true);
/*  76 */       return true;
/*     */     } 
/*     */     
/*  79 */     if (c(i)) {
/*  80 */       sq sq1 = null;
/*  81 */       for (sq sq2 : paramaab.h) {
/*  82 */         if (sq2.bz()) {
/*  83 */           t t = sq2.cb;
/*  84 */           if (t.a == paramInt1 && t.b == paramInt2 && t.c == paramInt3) {
/*  85 */             sq1 = sq2;
/*     */           }
/*     */         } 
/*     */       } 
/*     */       
/*  90 */       if (sq1 == null) {
/*  91 */         a(paramaab, paramInt1, paramInt2, paramInt3, false);
/*     */       } else {
/*  93 */         paramsq.b("tile.bed.occupied");
/*  94 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/*  98 */     sr sr = paramsq.a(paramInt1, paramInt2, paramInt3);
/*  99 */     if (sr == sr.a) {
/* 100 */       a(paramaab, paramInt1, paramInt2, paramInt3, true);
/* 101 */       return true;
/*     */     } 
/*     */     
/* 104 */     if (sr == sr.c) {
/* 105 */       paramsq.b("tile.bed.noSleep");
/* 106 */     } else if (sr == sr.f) {
/* 107 */       paramsq.b("tile.bed.notSafe");
/*     */     } 
/* 109 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/* 114 */     if (paramInt1 == 0) {
/* 115 */       return apa.B.m(paramInt1);
/*     */     }
/*     */     
/* 118 */     int i = j(paramInt2);
/* 119 */     int j = r.i[i][paramInt1];
/* 120 */     boolean bool = e_(paramInt2) ? true : false;
/*     */     
/* 122 */     if ((bool == true && j == 2) || (!bool && j == 3)) {
/* 123 */       return this.b[bool];
/*     */     }
/* 125 */     if (j == 5 || j == 4) {
/* 126 */       return this.c[bool];
/*     */     }
/* 128 */     return this.d[bool];
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 133 */     this.d = new lx[] { paramly.a("bed_feet_top"), paramly.a("bed_head_top") };
/* 134 */     this.b = new lx[] { paramly.a("bed_feet_end"), paramly.a("bed_head_end") };
/* 135 */     this.c = new lx[] { paramly.a("bed_feet_side"), paramly.a("bed_head_side") };
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 140 */     return 14;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/* 145 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/* 150 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 155 */     q();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 160 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 161 */     int j = j(i);
/*     */     
/* 163 */     if (e_(i)) {
/* 164 */       if (paramaab.a(paramInt1 - a[j][0], paramInt2, paramInt3 - a[j][1]) != this.cz) {
/* 165 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       }
/*     */     }
/* 168 */     else if (paramaab.a(paramInt1 + a[j][0], paramInt2, paramInt3 + a[j][1]) != this.cz) {
/* 169 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/* 170 */       if (!paramaab.I) {
/* 171 */         c(paramaab, paramInt1, paramInt2, paramInt3, i, 0);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 179 */     if (e_(paramInt1)) {
/* 180 */       return 0;
/*     */     }
/* 182 */     return wk.bb.cp;
/*     */   }
/*     */   
/*     */   private void q() {
/* 186 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.5625F, 1.0F);
/*     */   }
/*     */   
/*     */   public static boolean e_(int paramInt) {
/* 190 */     return ((paramInt & 0x8) != 0);
/*     */   }
/*     */   
/*     */   public static boolean c(int paramInt) {
/* 194 */     return ((paramInt & 0x4) != 0);
/*     */   }
/*     */   
/*     */   public static void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/* 198 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 199 */     if (paramBoolean) {
/* 200 */       i |= 0x4;
/*     */     } else {
/* 202 */       i &= 0xFFFFFFFB;
/*     */     } 
/* 204 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 4);
/*     */   }
/*     */   
/*     */   public static t b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 208 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 209 */     int j = alz.j(i);
/*     */ 
/*     */     
/* 212 */     for (byte b = 0; b <= 1; b++) {
/* 213 */       int k = paramInt1 - a[j][0] * b - 1;
/* 214 */       int m = paramInt3 - a[j][1] * b - 1;
/* 215 */       int n = k + 2;
/* 216 */       int i1 = m + 2;
/*     */       
/* 218 */       for (int i2 = k; i2 <= n; i2++) {
/* 219 */         for (int i3 = m; i3 <= i1; i3++) {
/* 220 */           if (paramaab.w(i2, paramInt2 - 1, i3) && paramaab.c(i2, paramInt2, i3) && paramaab.c(i2, paramInt2 + 1, i3)) {
/* 221 */             if (paramInt4 > 0) {
/* 222 */               paramInt4--;
/*     */             } else {
/*     */               
/* 225 */               return new t(i2, paramInt2, i3);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/* 231 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 236 */     if (!e_(paramInt4)) {
/* 237 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int h() {
/* 243 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 248 */     return wk.bb.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, sq paramsq) {
/* 253 */     if (paramsq.ce.d && 
/* 254 */       e_(paramInt4)) {
/* 255 */       int i = j(paramInt4);
/* 256 */       paramInt1 -= a[i][0];
/* 257 */       paramInt3 -= a[i][1];
/* 258 */       if (paramaab.a(paramInt1, paramInt2, paramInt3) == this.cz)
/* 259 */         paramaab.i(paramInt1, paramInt2, paramInt3); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ale.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */