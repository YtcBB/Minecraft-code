/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public enum aaj
/*    */ {
/*  9 */   a(-1, ""), b(0, "survival"), c(1, "creative"), d(2, "adventure");
/*    */   
/*    */   String f;
/*    */   int e;
/*    */   
/*    */   aaj(int paramInt1, String paramString1) {
/* 15 */     this.e = paramInt1;
/* 16 */     this.f = paramString1;
/*    */   }
/*    */   
/*    */   public int a() {
/* 20 */     return this.e;
/*    */   }
/*    */   
/*    */   public String b() {
/* 24 */     return this.f;
/*    */   }
/*    */   
/*    */   public void a(sn paramsn) {
/* 28 */     if (this == c) {
/* 29 */       paramsn.c = true;
/* 30 */       paramsn.d = true;
/* 31 */       paramsn.a = true;
/*    */     } else {
/* 33 */       paramsn.c = false;
/* 34 */       paramsn.d = false;
/* 35 */       paramsn.a = false;
/* 36 */       paramsn.b = false;
/*    */     } 
/* 38 */     paramsn.e = !c();
/*    */   }
/*    */   
/*    */   public boolean c() {
/* 42 */     return (this == d);
/*    */   }
/*    */   
/*    */   public boolean d() {
/* 46 */     return (this == c);
/*    */   }
/*    */   
/*    */   public boolean e() {
/* 50 */     return (this == b || this == d);
/*    */   }
/*    */   
/*    */   public static aaj a(int paramInt) {
/* 54 */     for (aaj aaj1 : values()) {
/* 55 */       if (aaj1.e == paramInt) {
/* 56 */         return aaj1;
/*    */       }
/*    */     } 
/* 59 */     return b;
/*    */   }
/*    */   
/*    */   public static aaj a(String paramString) {
/* 63 */     for (aaj aaj1 : values()) {
/* 64 */       if (aaj1.f.equals(paramString)) {
/* 65 */         return aaj1;
/*    */       }
/*    */     } 
/* 68 */     return b;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aaj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */