/*    */ 
/*    */ 
/*    */ public class ail
/*    */   extends ait
/*    */ {
/*    */   public ail(long paramLong, ait paramait) {
/*  7 */     super(paramLong);
/*  8 */     this.a = paramait;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 13 */     int i = paramInt1 - 1;
/* 14 */     int j = paramInt2 - 1;
/* 15 */     int k = paramInt3 + 2;
/* 16 */     int m = paramInt4 + 2;
/* 17 */     int[] arrayOfInt1 = this.a.a(i, j, k, m);
/*    */     
/* 19 */     int[] arrayOfInt2 = air.a(paramInt3 * paramInt4);
/* 20 */     for (byte b = 0; b < paramInt4; b++) {
/* 21 */       for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 22 */         int n = arrayOfInt1[b1 + 1 + (b + 1) * k];
/* 23 */         a((b1 + paramInt1), (b + paramInt2));
/* 24 */         if (n == 0) {
/* 25 */           arrayOfInt2[b1 + b * paramInt3] = 0;
/*    */         } else {
/* 27 */           int i1 = a(5);
/* 28 */           if (i1 == 0) { i1 = aav.n.N; }
/* 29 */           else { i1 = 1; }
/* 30 */            arrayOfInt2[b1 + b * paramInt3] = i1;
/*    */         } 
/*    */       } 
/*    */     } 
/* 34 */     return arrayOfInt2;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ail.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */