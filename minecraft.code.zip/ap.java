/*    */ import java.util.List;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ap
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 12 */     return "time";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 17 */     return 2;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 23 */     return paramab.a("commands.time.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 27 */     if (paramArrayOfString.length > 1) {
/* 28 */       if (paramArrayOfString[0].equals("set")) {
/*    */         int i;
/*    */         
/* 31 */         if (paramArrayOfString[1].equals("day")) {
/* 32 */           i = 0;
/* 33 */         } else if (paramArrayOfString[1].equals("night")) {
/* 34 */           i = 12500;
/*    */         } else {
/* 36 */           i = a(paramab, paramArrayOfString[1], 0);
/*    */         } 
/*    */         
/* 39 */         a(paramab, i);
/* 40 */         a(paramab, "commands.time.set", new Object[] { Integer.valueOf(i) }); return;
/*    */       } 
/* 42 */       if (paramArrayOfString[0].equals("add")) {
/* 43 */         int i = a(paramab, paramArrayOfString[1], 0);
/* 44 */         b(paramab, i);
/*    */         
/* 46 */         a(paramab, "commands.time.added", new Object[] { Integer.valueOf(i) });
/*    */         
/*    */         return;
/*    */       } 
/*    */     } 
/* 51 */     throw new ax("commands.time.usage", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public List a(ab paramab, String[] paramArrayOfString) {
/* 56 */     if (paramArrayOfString.length == 1)
/* 57 */       return a(paramArrayOfString, new String[] { "set", "add" }); 
/* 58 */     if (paramArrayOfString.length == 2 && paramArrayOfString[0].equals("set")) {
/* 59 */       return a(paramArrayOfString, new String[] { "day", "night" });
/*    */     }
/*    */     
/* 62 */     return null;
/*    */   }
/*    */   
/*    */   protected void a(ab paramab, int paramInt) {
/* 66 */     for (byte b = 0; b < (MinecraftServer.D()).b.length; b++) {
/* 67 */       (MinecraftServer.D()).b[b].b(paramInt);
/*    */     }
/*    */   }
/*    */   
/*    */   protected void b(ab paramab, int paramInt) {
/* 72 */     for (byte b = 0; b < (MinecraftServer.D()).b.length; b++) {
/* 73 */       iz iz = (MinecraftServer.D()).b[b];
/* 74 */       iz.b(iz.I() + paramInt);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ap.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */