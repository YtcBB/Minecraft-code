package com.jcraft.jogg;

public class Packet {
  public byte[] packet_base;
  
  public int packet;
  
  public int bytes;
  
  public int b_o_s;
  
  public int e_o_s;
  
  public long granulepos;
  
  public long packetno;
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jogg\Packet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */