package com.jcraft.jorbis;

class PsyLook {
  int n;
  
  PsyInfo vi;
  
  float[][][] tonecurves;
  
  float[][] peakatt;
  
  float[][][] noisecurves;
  
  float[] ath;
  
  int[] octave;
  
  void init(PsyInfo paramPsyInfo, int paramInt1, int paramInt2) {}
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\PsyLook.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */