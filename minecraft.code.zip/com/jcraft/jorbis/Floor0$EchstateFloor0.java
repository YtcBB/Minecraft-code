package com.jcraft.jorbis;

class Floor0$EchstateFloor0 {
  int[] codewords;
  
  float[] curve;
  
  long frameno;
  
  long codes;
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\Floor0$EchstateFloor0.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */