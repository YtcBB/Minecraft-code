/*     */ package com.jcraft.jorbis;
/*     */ 
/*     */ import com.jcraft.jogg.Buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class Floor0
/*     */   extends FuncFloor
/*     */ {
/*     */   void pack(Object paramObject, Buffer paramBuffer) {
/*  34 */     Floor0$InfoFloor0 floor0$InfoFloor0 = (Floor0$InfoFloor0)paramObject;
/*  35 */     paramBuffer.write(floor0$InfoFloor0.order, 8);
/*  36 */     paramBuffer.write(floor0$InfoFloor0.rate, 16);
/*  37 */     paramBuffer.write(floor0$InfoFloor0.barkmap, 16);
/*  38 */     paramBuffer.write(floor0$InfoFloor0.ampbits, 6);
/*  39 */     paramBuffer.write(floor0$InfoFloor0.ampdB, 8);
/*  40 */     paramBuffer.write(floor0$InfoFloor0.numbooks - 1, 4);
/*  41 */     for (byte b = 0; b < floor0$InfoFloor0.numbooks; b++)
/*  42 */       paramBuffer.write(floor0$InfoFloor0.books[b], 8); 
/*     */   }
/*     */   
/*     */   Object unpack(Info paramInfo, Buffer paramBuffer) {
/*  46 */     Floor0$InfoFloor0 floor0$InfoFloor0 = new Floor0$InfoFloor0(this);
/*  47 */     floor0$InfoFloor0.order = paramBuffer.read(8);
/*  48 */     floor0$InfoFloor0.rate = paramBuffer.read(16);
/*  49 */     floor0$InfoFloor0.barkmap = paramBuffer.read(16);
/*  50 */     floor0$InfoFloor0.ampbits = paramBuffer.read(6);
/*  51 */     floor0$InfoFloor0.ampdB = paramBuffer.read(8);
/*  52 */     floor0$InfoFloor0.numbooks = paramBuffer.read(4) + 1;
/*     */     
/*  54 */     if (floor0$InfoFloor0.order < 1 || floor0$InfoFloor0.rate < 1 || floor0$InfoFloor0.barkmap < 1 || floor0$InfoFloor0.numbooks < 1) {
/*  55 */       return null;
/*     */     }
/*     */     
/*  58 */     for (byte b = 0; b < floor0$InfoFloor0.numbooks; b++) {
/*  59 */       floor0$InfoFloor0.books[b] = paramBuffer.read(8);
/*  60 */       if (floor0$InfoFloor0.books[b] < 0 || floor0$InfoFloor0.books[b] >= paramInfo.books) {
/*  61 */         return null;
/*     */       }
/*     */     } 
/*  64 */     return floor0$InfoFloor0;
/*     */   }
/*     */ 
/*     */   
/*     */   Object look(DspState paramDspState, InfoMode paramInfoMode, Object paramObject) {
/*  69 */     Info info = paramDspState.vi;
/*  70 */     Floor0$InfoFloor0 floor0$InfoFloor0 = (Floor0$InfoFloor0)paramObject;
/*  71 */     Floor0$LookFloor0 floor0$LookFloor0 = new Floor0$LookFloor0(this);
/*  72 */     floor0$LookFloor0.m = floor0$InfoFloor0.order;
/*  73 */     floor0$LookFloor0.n = info.blocksizes[paramInfoMode.blockflag] / 2;
/*  74 */     floor0$LookFloor0.ln = floor0$InfoFloor0.barkmap;
/*  75 */     floor0$LookFloor0.vi = floor0$InfoFloor0;
/*  76 */     floor0$LookFloor0.lpclook.init(floor0$LookFloor0.ln, floor0$LookFloor0.m);
/*     */ 
/*     */     
/*  79 */     float f = floor0$LookFloor0.ln / toBARK((float)(floor0$InfoFloor0.rate / 2.0D));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  87 */     floor0$LookFloor0.linearmap = new int[floor0$LookFloor0.n];
/*  88 */     for (byte b = 0; b < floor0$LookFloor0.n; b++) {
/*  89 */       int i = (int)Math.floor((toBARK((float)(floor0$InfoFloor0.rate / 2.0D / floor0$LookFloor0.n * b)) * f));
/*  90 */       if (i >= floor0$LookFloor0.ln)
/*  91 */         i = floor0$LookFloor0.ln; 
/*  92 */       floor0$LookFloor0.linearmap[b] = i;
/*     */     } 
/*  94 */     return floor0$LookFloor0;
/*     */   }
/*     */   
/*     */   static float toBARK(float paramFloat) {
/*  98 */     return (float)(13.1D * Math.atan(7.4E-4D * paramFloat) + 2.24D * Math.atan((paramFloat * paramFloat) * 1.85E-8D) + 1.0E-4D * paramFloat);
/*     */   }
/*     */   
/*     */   Object state(Object paramObject) {
/* 102 */     Floor0$EchstateFloor0 floor0$EchstateFloor0 = new Floor0$EchstateFloor0(this);
/* 103 */     Floor0$InfoFloor0 floor0$InfoFloor0 = (Floor0$InfoFloor0)paramObject;
/*     */ 
/*     */     
/* 106 */     floor0$EchstateFloor0.codewords = new int[floor0$InfoFloor0.order];
/* 107 */     floor0$EchstateFloor0.curve = new float[floor0$InfoFloor0.barkmap];
/* 108 */     floor0$EchstateFloor0.frameno = -1L;
/* 109 */     return floor0$EchstateFloor0;
/*     */   }
/*     */ 
/*     */   
/*     */   void free_info(Object paramObject) {}
/*     */ 
/*     */   
/*     */   void free_look(Object paramObject) {}
/*     */ 
/*     */   
/*     */   void free_state(Object paramObject) {}
/*     */   
/*     */   int forward(Block paramBlock, Object paramObject1, float[] paramArrayOffloat1, float[] paramArrayOffloat2, Object paramObject2) {
/* 122 */     return 0;
/*     */   }
/*     */   
/* 125 */   float[] lsp = null;
/*     */ 
/*     */   
/*     */   int inverse(Block paramBlock, Object paramObject, float[] paramArrayOffloat) {
/* 129 */     Floor0$LookFloor0 floor0$LookFloor0 = (Floor0$LookFloor0)paramObject;
/* 130 */     Floor0$InfoFloor0 floor0$InfoFloor0 = floor0$LookFloor0.vi;
/* 131 */     int i = paramBlock.opb.read(floor0$InfoFloor0.ampbits);
/* 132 */     if (i > 0) {
/* 133 */       int j = (1 << floor0$InfoFloor0.ampbits) - 1;
/* 134 */       float f = i / j * floor0$InfoFloor0.ampdB;
/* 135 */       int k = paramBlock.opb.read(Util.ilog(floor0$InfoFloor0.numbooks));
/*     */       
/* 137 */       if (k != -1 && k < floor0$InfoFloor0.numbooks)
/*     */       {
/* 139 */         synchronized (this) {
/* 140 */           if (this.lsp == null || this.lsp.length < floor0$LookFloor0.m) {
/* 141 */             this.lsp = new float[floor0$LookFloor0.m];
/*     */           } else {
/*     */             
/* 144 */             for (byte b = 0; b < floor0$LookFloor0.m; b++) {
/* 145 */               this.lsp[b] = 0.0F;
/*     */             }
/*     */           } 
/* 148 */           CodeBook codeBook = paramBlock.vd.fullbooks[floor0$InfoFloor0.books[k]];
/* 149 */           float f1 = 0.0F;
/*     */           int m;
/* 151 */           for (m = 0; m < floor0$LookFloor0.m; m++) {
/* 152 */             paramArrayOffloat[m] = 0.0F;
/*     */           }
/* 154 */           for (m = 0; m < floor0$LookFloor0.m; m += codeBook.dim) {
/* 155 */             if (codeBook.decodevs(this.lsp, m, paramBlock.opb, 1, -1) == -1) {
/* 156 */               for (byte b = 0; b < floor0$LookFloor0.n; b++)
/* 157 */                 paramArrayOffloat[b] = 0.0F; 
/* 158 */               return 0;
/*     */             } 
/*     */           } 
/* 161 */           for (m = 0; m < floor0$LookFloor0.m; ) {
/* 162 */             for (byte b = 0; b < codeBook.dim; b++, m++)
/* 163 */               this.lsp[m] = this.lsp[m] + f1; 
/* 164 */             f1 = this.lsp[m - 1];
/*     */           } 
/*     */           
/* 167 */           Lsp.lsp_to_curve(paramArrayOffloat, floor0$LookFloor0.linearmap, floor0$LookFloor0.n, floor0$LookFloor0.ln, this.lsp, floor0$LookFloor0.m, f, floor0$InfoFloor0.ampdB);
/*     */ 
/*     */           
/* 170 */           return 1;
/*     */         } 
/*     */       }
/*     */     } 
/* 174 */     return 0;
/*     */   }
/*     */   
/*     */   Object inverse1(Block paramBlock, Object paramObject1, Object paramObject2) {
/* 178 */     Floor0$LookFloor0 floor0$LookFloor0 = (Floor0$LookFloor0)paramObject1;
/* 179 */     Floor0$InfoFloor0 floor0$InfoFloor0 = floor0$LookFloor0.vi;
/* 180 */     float[] arrayOfFloat = null;
/* 181 */     if (paramObject2 instanceof float[]) {
/* 182 */       arrayOfFloat = (float[])paramObject2;
/*     */     }
/*     */     
/* 185 */     int i = paramBlock.opb.read(floor0$InfoFloor0.ampbits);
/* 186 */     if (i > 0) {
/* 187 */       int j = (1 << floor0$InfoFloor0.ampbits) - 1;
/* 188 */       float f = i / j * floor0$InfoFloor0.ampdB;
/* 189 */       int k = paramBlock.opb.read(Util.ilog(floor0$InfoFloor0.numbooks));
/*     */       
/* 191 */       if (k != -1 && k < floor0$InfoFloor0.numbooks) {
/* 192 */         CodeBook codeBook = paramBlock.vd.fullbooks[floor0$InfoFloor0.books[k]];
/* 193 */         float f1 = 0.0F;
/*     */         
/* 195 */         if (arrayOfFloat == null || arrayOfFloat.length < floor0$LookFloor0.m + 1) {
/* 196 */           arrayOfFloat = new float[floor0$LookFloor0.m + 1];
/*     */         } else {
/*     */           
/* 199 */           for (byte b = 0; b < arrayOfFloat.length; b++)
/* 200 */             arrayOfFloat[b] = 0.0F; 
/*     */         } 
/*     */         int m;
/* 203 */         for (m = 0; m < floor0$LookFloor0.m; m += codeBook.dim) {
/* 204 */           if (codeBook.decodev_set(arrayOfFloat, m, paramBlock.opb, codeBook.dim) == -1) {
/* 205 */             return null;
/*     */           }
/*     */         } 
/*     */         
/* 209 */         for (m = 0; m < floor0$LookFloor0.m; ) {
/* 210 */           for (byte b = 0; b < codeBook.dim; b++, m++)
/* 211 */             arrayOfFloat[m] = arrayOfFloat[m] + f1; 
/* 212 */           f1 = arrayOfFloat[m - 1];
/*     */         } 
/* 214 */         arrayOfFloat[floor0$LookFloor0.m] = f;
/* 215 */         return arrayOfFloat;
/*     */       } 
/*     */     } 
/* 218 */     return null;
/*     */   }
/*     */   
/*     */   int inverse2(Block paramBlock, Object paramObject1, Object paramObject2, float[] paramArrayOffloat) {
/* 222 */     Floor0$LookFloor0 floor0$LookFloor0 = (Floor0$LookFloor0)paramObject1;
/* 223 */     Floor0$InfoFloor0 floor0$InfoFloor0 = floor0$LookFloor0.vi;
/*     */     
/* 225 */     if (paramObject2 != null) {
/* 226 */       float[] arrayOfFloat = (float[])paramObject2;
/* 227 */       float f = arrayOfFloat[floor0$LookFloor0.m];
/*     */       
/* 229 */       Lsp.lsp_to_curve(paramArrayOffloat, floor0$LookFloor0.linearmap, floor0$LookFloor0.n, floor0$LookFloor0.ln, arrayOfFloat, floor0$LookFloor0.m, f, floor0$InfoFloor0.ampdB);
/*     */       
/* 231 */       return 1;
/*     */     } 
/* 233 */     for (byte b = 0; b < floor0$LookFloor0.n; b++) {
/* 234 */       paramArrayOffloat[b] = 0.0F;
/*     */     }
/* 236 */     return 0;
/*     */   }
/*     */   
/*     */   static float fromdB(float paramFloat) {
/* 240 */     return (float)Math.exp(paramFloat * 0.11512925D);
/*     */   }
/*     */   
/*     */   static void lsp_to_lpc(float[] paramArrayOffloat1, float[] paramArrayOffloat2, int paramInt) {
/* 244 */     int i = paramInt / 2;
/* 245 */     float[] arrayOfFloat1 = new float[i];
/* 246 */     float[] arrayOfFloat2 = new float[i];
/*     */     
/* 248 */     float[] arrayOfFloat3 = new float[i + 1];
/* 249 */     float[] arrayOfFloat4 = new float[i + 1];
/*     */     
/* 251 */     float[] arrayOfFloat5 = new float[i];
/* 252 */     float[] arrayOfFloat6 = new float[i];
/*     */     
/*     */     byte b1;
/*     */     
/* 256 */     for (b1 = 0; b1 < i; b1++) {
/* 257 */       arrayOfFloat1[b1] = (float)(-2.0D * Math.cos(paramArrayOffloat1[b1 * 2]));
/* 258 */       arrayOfFloat2[b1] = (float)(-2.0D * Math.cos(paramArrayOffloat1[b1 * 2 + 1]));
/*     */     } 
/*     */     
/*     */     byte b2;
/* 262 */     for (b2 = 0; b2 < i; b2++) {
/* 263 */       arrayOfFloat3[b2] = 0.0F;
/* 264 */       arrayOfFloat4[b2] = 1.0F;
/* 265 */       arrayOfFloat5[b2] = 0.0F;
/* 266 */       arrayOfFloat6[b2] = 1.0F;
/*     */     } 
/* 268 */     arrayOfFloat4[b2] = 1.0F;
/* 269 */     arrayOfFloat3[b2] = 1.0F;
/*     */ 
/*     */     
/* 272 */     for (b1 = 1; b1 < paramInt + 1; b1++) {
/* 273 */       float f2 = 0.0F, f1 = f2;
/* 274 */       for (b2 = 0; b2 < i; b2++) {
/* 275 */         float f = arrayOfFloat1[b2] * arrayOfFloat4[b2] + arrayOfFloat3[b2];
/* 276 */         arrayOfFloat3[b2] = arrayOfFloat4[b2];
/* 277 */         arrayOfFloat4[b2] = f1;
/* 278 */         f1 += f;
/*     */         
/* 280 */         f = arrayOfFloat2[b2] * arrayOfFloat6[b2] + arrayOfFloat5[b2];
/* 281 */         arrayOfFloat5[b2] = arrayOfFloat6[b2];
/* 282 */         arrayOfFloat6[b2] = f2;
/* 283 */         f2 += f;
/*     */       } 
/* 285 */       paramArrayOffloat2[b1 - 1] = (f1 + arrayOfFloat4[b2] + f2 - arrayOfFloat3[b2]) / 2.0F;
/* 286 */       arrayOfFloat4[b2] = f1;
/* 287 */       arrayOfFloat3[b2] = f2;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   static void lpc_to_curve(float[] paramArrayOffloat1, float[] paramArrayOffloat2, float paramFloat, Floor0$LookFloor0 paramFloor0$LookFloor0, String paramString, int paramInt) {
/* 294 */     float[] arrayOfFloat = new float[Math.max(paramFloor0$LookFloor0.ln * 2, paramFloor0$LookFloor0.m * 2 + 2)];
/*     */     
/* 296 */     if (paramFloat == 0.0F) {
/* 297 */       for (byte b1 = 0; b1 < paramFloor0$LookFloor0.n; b1++)
/* 298 */         paramArrayOffloat1[b1] = 0.0F; 
/*     */       return;
/*     */     } 
/* 301 */     paramFloor0$LookFloor0.lpclook.lpc_to_curve(arrayOfFloat, paramArrayOffloat2, paramFloat);
/*     */     
/* 303 */     for (byte b = 0; b < paramFloor0$LookFloor0.n; b++)
/* 304 */       paramArrayOffloat1[b] = arrayOfFloat[paramFloor0$LookFloor0.linearmap[b]]; 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\Floor0.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */