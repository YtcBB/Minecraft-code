package com.jcraft.jorbis;

class Mapping0$LookMapping0 {
  InfoMode mode;
  
  Mapping0$InfoMapping0 map;
  
  Object[] time_look;
  
  Object[] floor_look;
  
  Object[] floor_state;
  
  Object[] residue_look;
  
  PsyLook[] psy_look;
  
  FuncTime[] time_func;
  
  FuncFloor[] floor_func;
  
  FuncResidue[] residue_func;
  
  int ch;
  
  float[][] decay;
  
  int lastframe;
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\Mapping0$LookMapping0.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */