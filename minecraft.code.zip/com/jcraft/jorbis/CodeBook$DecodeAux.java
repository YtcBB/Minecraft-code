package com.jcraft.jorbis;

class CodeBook$DecodeAux {
  int[] tab;
  
  int[] tabl;
  
  int tabn;
  
  int[] ptr0;
  
  int[] ptr1;
  
  int aux;
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\CodeBook$DecodeAux.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */