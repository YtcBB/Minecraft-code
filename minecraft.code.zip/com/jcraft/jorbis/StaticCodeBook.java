/*     */ package com.jcraft.jorbis;
/*     */ 
/*     */ import com.jcraft.jogg.Buffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class StaticCodeBook
/*     */ {
/*     */   int dim;
/*     */   int entries;
/*     */   int[] lengthlist;
/*     */   int maptype;
/*     */   int q_min;
/*     */   int q_delta;
/*     */   int q_quant;
/*     */   int q_sequencep;
/*     */   int[] quantlist;
/*     */   static final int VQ_FEXP = 10;
/*     */   static final int VQ_FMAN = 21;
/*     */   static final int VQ_FEXP_BIAS = 768;
/*     */   
/*     */   int pack(Buffer paramBuffer) {
/*     */     int i;
/*  62 */     boolean bool = false;
/*     */     
/*  64 */     paramBuffer.write(5653314, 24);
/*  65 */     paramBuffer.write(this.dim, 16);
/*  66 */     paramBuffer.write(this.entries, 24);
/*     */ 
/*     */     
/*     */     byte b;
/*     */     
/*  71 */     for (b = 1; b < this.entries && 
/*  72 */       this.lengthlist[b] >= this.lengthlist[b - 1]; b++);
/*     */ 
/*     */     
/*  75 */     if (b == this.entries) {
/*  76 */       bool = true;
/*     */     }
/*  78 */     if (bool) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  83 */       byte b1 = 0;
/*  84 */       paramBuffer.write(1, 1);
/*  85 */       paramBuffer.write(this.lengthlist[0] - 1, 5);
/*     */       
/*  87 */       for (b = 1; b < this.entries; b++) {
/*  88 */         int j = this.lengthlist[b];
/*  89 */         int k = this.lengthlist[b - 1];
/*  90 */         if (j > k) {
/*  91 */           for (int m = k; m < j; m++) {
/*  92 */             paramBuffer.write(b - b1, Util.ilog(this.entries - b1));
/*  93 */             b1 = b;
/*     */           } 
/*     */         }
/*     */       } 
/*  97 */       paramBuffer.write(b - b1, Util.ilog(this.entries - b1));
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 102 */       paramBuffer.write(0, 1);
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 107 */       for (b = 0; b < this.entries && 
/* 108 */         this.lengthlist[b] != 0; b++);
/*     */ 
/*     */ 
/*     */       
/* 112 */       if (b == this.entries) {
/* 113 */         paramBuffer.write(0, 1);
/* 114 */         for (b = 0; b < this.entries; b++) {
/* 115 */           paramBuffer.write(this.lengthlist[b] - 1, 5);
/*     */         }
/*     */       } else {
/*     */         
/* 119 */         paramBuffer.write(1, 1);
/* 120 */         for (b = 0; b < this.entries; b++) {
/* 121 */           if (this.lengthlist[b] == 0) {
/* 122 */             paramBuffer.write(0, 1);
/*     */           } else {
/*     */             
/* 125 */             paramBuffer.write(1, 1);
/* 126 */             paramBuffer.write(this.lengthlist[b] - 1, 5);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 134 */     paramBuffer.write(this.maptype, 4);
/* 135 */     switch (this.maptype) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 0:
/* 178 */         return 0;
/*     */       case 1:
/*     */       case 2:
/*     */         if (this.quantlist == null)
/*     */           return -1;  paramBuffer.write(this.q_min, 32); paramBuffer.write(this.q_delta, 32); paramBuffer.write(this.q_quant - 1, 4); paramBuffer.write(this.q_sequencep, 1); i = 0; switch (this.maptype) { case 1:
/*     */             i = maptype1_quantvals(); break;
/*     */           case 2:
/*     */             i = this.entries * this.dim; break; }
/*     */          for (b = 0; b < i; b++)
/*     */           paramBuffer.write(Math.abs(this.quantlist[b]), this.q_quant); 
/* 188 */     }  return -1; } int unpack(Buffer paramBuffer) { byte b; int i; if (paramBuffer.read(24) != 5653314) {
/*     */       
/* 190 */       clear();
/* 191 */       return -1;
/*     */     } 
/*     */ 
/*     */     
/* 195 */     this.dim = paramBuffer.read(16);
/* 196 */     this.entries = paramBuffer.read(24);
/* 197 */     if (this.entries == -1) {
/*     */       
/* 199 */       clear();
/* 200 */       return -1;
/*     */     } 
/*     */ 
/*     */     
/* 204 */     switch (paramBuffer.read(1)) {
/*     */       
/*     */       case 0:
/* 207 */         this.lengthlist = new int[this.entries];
/*     */ 
/*     */         
/* 210 */         if (paramBuffer.read(1) != 0) {
/*     */ 
/*     */           
/* 213 */           for (byte b1 = 0; b1 < this.entries; b1++) {
/* 214 */             if (paramBuffer.read(1) != 0) {
/* 215 */               int j = paramBuffer.read(5);
/* 216 */               if (j == -1) {
/*     */                 
/* 218 */                 clear();
/* 219 */                 return -1;
/*     */               } 
/* 221 */               this.lengthlist[b1] = j + 1;
/*     */             } else {
/*     */               
/* 224 */               this.lengthlist[b1] = 0;
/*     */             } 
/*     */           } 
/*     */           
/*     */           break;
/*     */         } 
/* 230 */         for (b = 0; b < this.entries; b++) {
/* 231 */           int j = paramBuffer.read(5);
/* 232 */           if (j == -1) {
/*     */             
/* 234 */             clear();
/* 235 */             return -1;
/*     */           } 
/* 237 */           this.lengthlist[b] = j + 1;
/*     */         } 
/*     */         break;
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/* 244 */         i = paramBuffer.read(5) + 1;
/* 245 */         this.lengthlist = new int[this.entries];
/*     */         
/* 247 */         for (b = 0; b < this.entries; ) {
/* 248 */           int j = paramBuffer.read(Util.ilog(this.entries - b));
/* 249 */           if (j == -1) {
/*     */             
/* 251 */             clear();
/* 252 */             return -1;
/*     */           } 
/* 254 */           for (byte b1 = 0; b1 < j; b1++, b++) {
/* 255 */             this.lengthlist[b] = i;
/*     */           }
/* 257 */           i++;
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 263 */         return -1;
/*     */     } 
/*     */ 
/*     */     
/* 267 */     switch (this.maptype = paramBuffer.read(4)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*     */       case 0:
/* 309 */         return 0;
/*     */       case 1:
/*     */       case 2:
/*     */         this.q_min = paramBuffer.read(32); this.q_delta = paramBuffer.read(32); this.q_quant = paramBuffer.read(4) + 1; this.q_sequencep = paramBuffer.read(1); i = 0; switch (this.maptype) { case 1:
/*     */             i = maptype1_quantvals(); break;
/*     */           case 2:
/*     */             i = this.entries * this.dim; break; }
/*     */          this.quantlist = new int[i]; for (b = 0; b < i; b++)
/*     */           this.quantlist[b] = paramBuffer.read(this.q_quant);  if (this.quantlist[i - 1] == -1) {
/*     */           clear(); return -1;
/*     */         } 
/* 320 */     }  clear(); return -1; } private int maptype1_quantvals() { int i = (int)Math.floor(Math.pow(this.entries, 1.0D / this.dim));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*     */     while (true) {
/* 328 */       int j = 1;
/* 329 */       int k = 1;
/* 330 */       for (byte b = 0; b < this.dim; b++) {
/* 331 */         j *= i;
/* 332 */         k *= i + 1;
/*     */       } 
/* 334 */       if (j <= this.entries && k > this.entries) {
/* 335 */         return i;
/*     */       }
/*     */       
/* 338 */       if (j > this.entries) {
/* 339 */         i--;
/*     */         continue;
/*     */       } 
/* 342 */       i++;
/*     */     }  }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void clear() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float[] unquantize() {
/* 358 */     if (this.maptype == 1 || this.maptype == 2) {
/*     */       int i; byte b;
/* 360 */       float f1 = float32_unpack(this.q_min);
/* 361 */       float f2 = float32_unpack(this.q_delta);
/* 362 */       float[] arrayOfFloat = new float[this.entries * this.dim];
/*     */ 
/*     */ 
/*     */       
/* 366 */       switch (this.maptype) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*     */         case 1:
/* 374 */           i = maptype1_quantvals();
/* 375 */           for (b = 0; b < this.entries; b++) {
/* 376 */             float f = 0.0F;
/* 377 */             int j = 1;
/* 378 */             for (byte b1 = 0; b1 < this.dim; b1++) {
/* 379 */               int k = b / j % i;
/* 380 */               float f3 = this.quantlist[k];
/* 381 */               f3 = Math.abs(f3) * f2 + f1 + f;
/* 382 */               if (this.q_sequencep != 0)
/* 383 */                 f = f3; 
/* 384 */               arrayOfFloat[b * this.dim + b1] = f3;
/* 385 */               j *= i;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */         case 2:
/* 390 */           for (b = 0; b < this.entries; b++) {
/* 391 */             float f = 0.0F;
/* 392 */             for (byte b1 = 0; b1 < this.dim; b1++) {
/* 393 */               float f3 = this.quantlist[b * this.dim + b1];
/*     */               
/* 395 */               f3 = Math.abs(f3) * f2 + f1 + f;
/* 396 */               if (this.q_sequencep != 0)
/* 397 */                 f = f3; 
/* 398 */               arrayOfFloat[b * this.dim + b1] = f3;
/*     */             } 
/*     */           } 
/*     */           break;
/*     */       } 
/*     */       
/* 404 */       return arrayOfFloat;
/*     */     } 
/* 406 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   static long float32_pack(float paramFloat) {
/* 419 */     int i = 0;
/*     */ 
/*     */     
/* 422 */     if (paramFloat < 0.0F) {
/* 423 */       i = Integer.MIN_VALUE;
/* 424 */       paramFloat = -paramFloat;
/*     */     } 
/* 426 */     int j = (int)Math.floor(Math.log(paramFloat) / Math.log(2.0D));
/* 427 */     int k = (int)Math.rint(Math.pow(paramFloat, (20 - j)));
/* 428 */     j = j + 768 << 21;
/* 429 */     return (i | j | k);
/*     */   }
/*     */   
/*     */   static float float32_unpack(int paramInt) {
/* 433 */     float f1 = (paramInt & 0x1FFFFF);
/* 434 */     float f2 = ((paramInt & 0x7FE00000) >>> 21);
/* 435 */     if ((paramInt & Integer.MIN_VALUE) != 0)
/* 436 */       f1 = -f1; 
/* 437 */     return ldexp(f1, (int)f2 - 20 - 768);
/*     */   }
/*     */   
/*     */   static float ldexp(float paramFloat, int paramInt) {
/* 441 */     return (float)(paramFloat * Math.pow(2.0D, paramInt));
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\StaticCodeBook.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */