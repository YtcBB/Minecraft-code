/*      */ package com.jcraft.jorbis;
/*      */ 
/*      */ import com.jcraft.jogg.Packet;
/*      */ import com.jcraft.jogg.Page;
/*      */ import com.jcraft.jogg.StreamState;
/*      */ import com.jcraft.jogg.SyncState;
/*      */ import java.io.IOException;
/*      */ import java.io.InputStream;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class VorbisFile
/*      */ {
/*      */   static final int CHUNKSIZE = 8500;
/*      */   static final int SEEK_SET = 0;
/*      */   static final int SEEK_CUR = 1;
/*      */   static final int SEEK_END = 2;
/*      */   static final int OV_FALSE = -1;
/*      */   static final int OV_EOF = -2;
/*      */   static final int OV_HOLE = -3;
/*      */   static final int OV_EREAD = -128;
/*      */   static final int OV_EFAULT = -129;
/*      */   static final int OV_EIMPL = -130;
/*      */   static final int OV_EINVAL = -131;
/*      */   static final int OV_ENOTVORBIS = -132;
/*      */   static final int OV_EBADHEADER = -133;
/*      */   static final int OV_EVERSION = -134;
/*      */   static final int OV_ENOTAUDIO = -135;
/*      */   static final int OV_EBADPACKET = -136;
/*      */   static final int OV_EBADLINK = -137;
/*      */   static final int OV_ENOSEEK = -138;
/*      */   InputStream datasource;
/*      */   boolean seekable = false;
/*      */   long offset;
/*      */   long end;
/*   62 */   SyncState oy = new SyncState();
/*      */   
/*      */   int links;
/*      */   
/*      */   long[] offsets;
/*      */   
/*      */   long[] dataoffsets;
/*      */   
/*      */   int[] serialnos;
/*      */   
/*      */   long[] pcmlengths;
/*      */   
/*      */   Info[] vi;
/*      */   Comment[] vc;
/*      */   long pcm_offset;
/*      */   boolean decode_ready = false;
/*      */   int current_serialno;
/*      */   int current_link;
/*      */   float bittrack;
/*      */   float samptrack;
/*   82 */   StreamState os = new StreamState();
/*      */   
/*   84 */   DspState vd = new DspState();
/*      */   
/*   86 */   Block vb = new Block(this.vd);
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public VorbisFile(String paramString) {
/*   92 */     VorbisFile$SeekableInputStream vorbisFile$SeekableInputStream = null;
/*      */     try {
/*   94 */       vorbisFile$SeekableInputStream = new VorbisFile$SeekableInputStream(this, paramString);
/*   95 */       int i = open(vorbisFile$SeekableInputStream, null, 0);
/*   96 */       if (i == -1) {
/*   97 */         throw new JOrbisException("VorbisFile: open return -1");
/*      */       }
/*      */     }
/*  100 */     catch (Exception exception) {
/*  101 */       throw new JOrbisException("VorbisFile: " + exception.toString());
/*      */     } finally {
/*      */       
/*  104 */       if (vorbisFile$SeekableInputStream != null) {
/*      */         try {
/*  106 */           vorbisFile$SeekableInputStream.close();
/*      */         }
/*  108 */         catch (IOException iOException) {
/*  109 */           iOException.printStackTrace();
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public VorbisFile(InputStream paramInputStream, byte[] paramArrayOfbyte, int paramInt) {
/*  118 */     int i = open(paramInputStream, paramArrayOfbyte, paramInt);
/*  119 */     if (i == -1);
/*      */   }
/*      */ 
/*      */   
/*      */   private int get_data() {
/*  124 */     int i = this.oy.buffer(8500);
/*  125 */     byte[] arrayOfByte = this.oy.data;
/*  126 */     int j = 0;
/*      */     try {
/*  128 */       j = this.datasource.read(arrayOfByte, i, 8500);
/*      */     }
/*  130 */     catch (Exception exception) {
/*  131 */       return -128;
/*      */     } 
/*  133 */     this.oy.wrote(j);
/*  134 */     if (j == -1) {
/*  135 */       j = 0;
/*      */     }
/*  137 */     return j;
/*      */   }
/*      */   
/*      */   private void seek_helper(long paramLong) {
/*  141 */     fseek(this.datasource, paramLong, 0);
/*  142 */     this.offset = paramLong;
/*  143 */     this.oy.reset();
/*      */   }
/*      */   private int get_next_page(Page paramPage, long paramLong) {
/*      */     int i;
/*  147 */     if (paramLong > 0L) {
/*  148 */       paramLong += this.offset;
/*      */     }
/*      */     while (true) {
/*  151 */       if (paramLong > 0L && this.offset >= paramLong)
/*  152 */         return -1; 
/*  153 */       i = this.oy.pageseek(paramPage);
/*  154 */       if (i < 0) {
/*  155 */         this.offset -= i;
/*      */         continue;
/*      */       } 
/*  158 */       if (i == 0) {
/*  159 */         if (paramLong == 0L)
/*  160 */           return -1; 
/*  161 */         int k = get_data();
/*  162 */         if (k == 0)
/*  163 */           return -2; 
/*  164 */         if (k < 0)
/*  165 */           return -128;  continue;
/*      */       }  break;
/*      */     } 
/*  168 */     int j = (int)this.offset;
/*  169 */     this.offset += i;
/*  170 */     return j;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int get_prev_page(Page paramPage) {
/*  177 */     long l = this.offset;
/*      */     
/*  179 */     int j = -1;
/*  180 */     while (j == -1) {
/*  181 */       l -= 8500L;
/*  182 */       if (l < 0L)
/*  183 */         l = 0L; 
/*  184 */       seek_helper(l);
/*  185 */       while (this.offset < l + 8500L) {
/*  186 */         int k = get_next_page(paramPage, l + 8500L - this.offset);
/*  187 */         if (k == -128) {
/*  188 */           return -128;
/*      */         }
/*  190 */         if (k < 0) {
/*  191 */           if (j == -1) {
/*  192 */             throw new JOrbisException();
/*      */           }
/*      */           break;
/*      */         } 
/*  196 */         j = k;
/*      */       } 
/*      */     } 
/*      */     
/*  200 */     seek_helper(j);
/*  201 */     int i = get_next_page(paramPage, 8500L);
/*  202 */     if (i < 0) {
/*  203 */       return -129;
/*      */     }
/*  205 */     return j;
/*      */   }
/*      */ 
/*      */   
/*      */   int bisect_forward_serialno(long paramLong1, long paramLong2, long paramLong3, int paramInt1, int paramInt2) {
/*  210 */     long l1 = paramLong3;
/*  211 */     long l2 = paramLong3;
/*  212 */     Page page = new Page();
/*      */ 
/*      */     
/*  215 */     while (paramLong2 < l1) {
/*      */       long l;
/*  217 */       if (l1 - paramLong2 < 8500L) {
/*  218 */         l = paramLong2;
/*      */       } else {
/*      */         
/*  221 */         l = (paramLong2 + l1) / 2L;
/*      */       } 
/*      */       
/*  224 */       seek_helper(l);
/*  225 */       int j = get_next_page(page, -1L);
/*  226 */       if (j == -128)
/*  227 */         return -128; 
/*  228 */       if (j < 0 || page.serialno() != paramInt1) {
/*  229 */         l1 = l;
/*  230 */         if (j >= 0)
/*  231 */           l2 = j; 
/*      */         continue;
/*      */       } 
/*  234 */       paramLong2 = (j + page.header_len + page.body_len);
/*      */     } 
/*      */     
/*  237 */     seek_helper(l2);
/*  238 */     int i = get_next_page(page, -1L);
/*  239 */     if (i == -128) {
/*  240 */       return -128;
/*      */     }
/*  242 */     if (paramLong2 >= paramLong3 || i == -1) {
/*  243 */       this.links = paramInt2 + 1;
/*  244 */       this.offsets = new long[paramInt2 + 2];
/*  245 */       this.offsets[paramInt2 + 1] = paramLong2;
/*      */     } else {
/*      */       
/*  248 */       i = bisect_forward_serialno(l2, this.offset, paramLong3, page.serialno(), paramInt2 + 1);
/*  249 */       if (i == -128)
/*  250 */         return -128; 
/*      */     } 
/*  252 */     this.offsets[paramInt2] = paramLong1;
/*  253 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int fetch_headers(Info paramInfo, Comment paramComment, int[] paramArrayOfint, Page paramPage) {
/*  259 */     Page page = new Page();
/*  260 */     Packet packet = new Packet();
/*      */ 
/*      */     
/*  263 */     if (paramPage == null) {
/*  264 */       int i = get_next_page(page, 8500L);
/*  265 */       if (i == -128)
/*  266 */         return -128; 
/*  267 */       if (i < 0)
/*  268 */         return -132; 
/*  269 */       paramPage = page;
/*      */     } 
/*      */     
/*  272 */     if (paramArrayOfint != null) {
/*  273 */       paramArrayOfint[0] = paramPage.serialno();
/*      */     }
/*  275 */     this.os.init(paramPage.serialno());
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  280 */     paramInfo.init();
/*  281 */     paramComment.init();
/*      */     
/*  283 */     byte b = 0;
/*  284 */     while (b < 3) {
/*  285 */       this.os.pagein(paramPage);
/*  286 */       while (b < 3) {
/*  287 */         int i = this.os.packetout(packet);
/*  288 */         if (i == 0)
/*      */           break; 
/*  290 */         if (i == -1) {
/*  291 */           paramInfo.clear();
/*  292 */           paramComment.clear();
/*  293 */           this.os.clear();
/*  294 */           return -1;
/*      */         } 
/*  296 */         if (paramInfo.synthesis_headerin(paramComment, packet) != 0) {
/*  297 */           paramInfo.clear();
/*  298 */           paramComment.clear();
/*  299 */           this.os.clear();
/*  300 */           return -1;
/*      */         } 
/*  302 */         b++;
/*      */       } 
/*  304 */       if (b < 3 && 
/*  305 */         get_next_page(paramPage, 1L) < 0) {
/*  306 */         paramInfo.clear();
/*  307 */         paramComment.clear();
/*  308 */         this.os.clear();
/*  309 */         return -1;
/*      */       } 
/*      */     } 
/*  312 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   void prefetch_all_headers(Info paramInfo, Comment paramComment, int paramInt) {
/*  321 */     Page page = new Page();
/*      */ 
/*      */     
/*  324 */     this.vi = new Info[this.links];
/*  325 */     this.vc = new Comment[this.links];
/*  326 */     this.dataoffsets = new long[this.links];
/*  327 */     this.pcmlengths = new long[this.links];
/*  328 */     this.serialnos = new int[this.links];
/*      */     
/*  330 */     for (byte b = 0; b < this.links; b++) {
/*  331 */       if (paramInfo != null && paramComment != null && b == 0) {
/*      */ 
/*      */         
/*  334 */         this.vi[b] = paramInfo;
/*  335 */         this.vc[b] = paramComment;
/*  336 */         this.dataoffsets[b] = paramInt;
/*      */       }
/*      */       else {
/*      */         
/*  340 */         seek_helper(this.offsets[b]);
/*  341 */         this.vi[b] = new Info();
/*  342 */         this.vc[b] = new Comment();
/*  343 */         if (fetch_headers(this.vi[b], this.vc[b], null, null) == -1) {
/*  344 */           this.dataoffsets[b] = -1L;
/*      */         } else {
/*      */           
/*  347 */           this.dataoffsets[b] = this.offset;
/*  348 */           this.os.clear();
/*      */         } 
/*      */       } 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  355 */       long l = this.offsets[b + 1];
/*  356 */       seek_helper(l);
/*      */       
/*      */       while (true) {
/*  359 */         int i = get_prev_page(page);
/*  360 */         if (i == -1) {
/*      */           
/*  362 */           this.vi[b].clear();
/*  363 */           this.vc[b].clear();
/*      */           break;
/*      */         } 
/*  366 */         if (page.granulepos() != -1L) {
/*  367 */           this.serialnos[b] = page.serialno();
/*  368 */           this.pcmlengths[b] = page.granulepos();
/*      */           break;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */   
/*      */   private int make_decode_ready() {
/*  377 */     if (this.decode_ready)
/*  378 */       System.exit(1); 
/*  379 */     this.vd.synthesis_init(this.vi[0]);
/*  380 */     this.vb.init(this.vd);
/*  381 */     this.decode_ready = true;
/*  382 */     return 0;
/*      */   }
/*      */   
/*      */   int open_seekable() {
/*  386 */     Info info = new Info();
/*  387 */     Comment comment = new Comment();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  392 */     Page page = new Page();
/*      */     
/*  394 */     int[] arrayOfInt = new int[1];
/*  395 */     int j = fetch_headers(info, comment, arrayOfInt, null);
/*  396 */     int i = arrayOfInt[0];
/*  397 */     int k = (int)this.offset;
/*  398 */     this.os.clear();
/*  399 */     if (j == -1)
/*  400 */       return -1; 
/*  401 */     if (j < 0) {
/*  402 */       return j;
/*      */     }
/*  404 */     this.seekable = true;
/*  405 */     fseek(this.datasource, 0L, 2);
/*  406 */     this.offset = ftell(this.datasource);
/*  407 */     long l = this.offset;
/*      */ 
/*      */     
/*  410 */     l = get_prev_page(page);
/*      */     
/*  412 */     if (page.serialno() != i) {
/*      */ 
/*      */       
/*  415 */       if (bisect_forward_serialno(0L, 0L, l + 1L, i, 0) < 0) {
/*  416 */         clear();
/*  417 */         return -128;
/*      */       
/*      */       }
/*      */     
/*      */     }
/*  422 */     else if (bisect_forward_serialno(0L, l, l + 1L, i, 0) < 0) {
/*  423 */       clear();
/*  424 */       return -128;
/*      */     } 
/*      */     
/*  427 */     prefetch_all_headers(info, comment, k);
/*  428 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   int open_nonseekable() {
/*  433 */     this.links = 1;
/*  434 */     this.vi = new Info[this.links];
/*  435 */     this.vi[0] = new Info();
/*  436 */     this.vc = new Comment[this.links];
/*  437 */     this.vc[0] = new Comment();
/*      */ 
/*      */     
/*  440 */     int[] arrayOfInt = new int[1];
/*  441 */     if (fetch_headers(this.vi[0], this.vc[0], arrayOfInt, null) == -1)
/*  442 */       return -1; 
/*  443 */     this.current_serialno = arrayOfInt[0];
/*  444 */     make_decode_ready();
/*  445 */     return 0;
/*      */   }
/*      */ 
/*      */   
/*      */   void decode_clear() {
/*  450 */     this.os.clear();
/*  451 */     this.vd.clear();
/*  452 */     this.vb.clear();
/*  453 */     this.decode_ready = false;
/*  454 */     this.bittrack = 0.0F;
/*  455 */     this.samptrack = 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int process_packet(int paramInt) {
/*  469 */     Page page = new Page();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  476 */       if (this.decode_ready) {
/*  477 */         Packet packet = new Packet();
/*  478 */         int i = this.os.packetout(packet);
/*      */ 
/*      */ 
/*      */ 
/*      */         
/*  483 */         if (i > 0) {
/*      */           
/*  485 */           long l = packet.granulepos;
/*  486 */           if (this.vb.synthesis(packet) == 0) {
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */             
/*  495 */             int j = this.vd.synthesis_pcmout((float[][][])null, null);
/*  496 */             this.vd.synthesis_blockin(this.vb);
/*  497 */             this.samptrack += (this.vd.synthesis_pcmout((float[][][])null, null) - j);
/*  498 */             this.bittrack += (packet.bytes * 8);
/*      */ 
/*      */ 
/*      */             
/*  502 */             if (l != -1L && packet.e_o_s == 0) {
/*  503 */               j = this.seekable ? this.current_link : 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*  517 */               int k = this.vd.synthesis_pcmout((float[][][])null, null);
/*  518 */               l -= k;
/*  519 */               for (byte b = 0; b < j; b++) {
/*  520 */                 l += this.pcmlengths[b];
/*      */               }
/*  522 */               this.pcm_offset = l;
/*      */             } 
/*  524 */             return 1;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/*  529 */       if (paramInt == 0)
/*  530 */         return 0; 
/*  531 */       if (get_next_page(page, -1L) < 0) {
/*  532 */         return 0;
/*      */       }
/*      */ 
/*      */       
/*  536 */       this.bittrack += (page.header_len * 8);
/*      */ 
/*      */       
/*  539 */       if (this.decode_ready && 
/*  540 */         this.current_serialno != page.serialno()) {
/*  541 */         decode_clear();
/*      */       }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */       
/*  556 */       if (!this.decode_ready) {
/*      */         
/*  558 */         if (this.seekable) {
/*  559 */           this.current_serialno = page.serialno();
/*      */ 
/*      */           
/*      */           byte b;
/*      */           
/*  564 */           for (b = 0; b < this.links && 
/*  565 */             this.serialnos[b] != this.current_serialno; b++);
/*      */ 
/*      */           
/*  568 */           if (b == this.links) {
/*  569 */             return -1;
/*      */           }
/*  571 */           this.current_link = b;
/*      */           
/*  573 */           this.os.init(this.current_serialno);
/*  574 */           this.os.reset();
/*      */         
/*      */         }
/*      */         else {
/*      */ 
/*      */           
/*  580 */           int[] arrayOfInt = new int[1];
/*  581 */           int i = fetch_headers(this.vi[0], this.vc[0], arrayOfInt, page);
/*  582 */           this.current_serialno = arrayOfInt[0];
/*  583 */           if (i != 0)
/*  584 */             return i; 
/*  585 */           this.current_link++;
/*  586 */           boolean bool = false;
/*      */         } 
/*  588 */         make_decode_ready();
/*      */       } 
/*  590 */       this.os.pagein(page);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int clear() {
/*  597 */     this.vb.clear();
/*  598 */     this.vd.clear();
/*  599 */     this.os.clear();
/*      */     
/*  601 */     if (this.vi != null && this.links != 0) {
/*  602 */       for (byte b = 0; b < this.links; b++) {
/*  603 */         this.vi[b].clear();
/*  604 */         this.vc[b].clear();
/*      */       } 
/*  606 */       this.vi = null;
/*  607 */       this.vc = null;
/*      */     } 
/*  609 */     if (this.dataoffsets != null)
/*  610 */       this.dataoffsets = null; 
/*  611 */     if (this.pcmlengths != null)
/*  612 */       this.pcmlengths = null; 
/*  613 */     if (this.serialnos != null)
/*  614 */       this.serialnos = null; 
/*  615 */     if (this.offsets != null)
/*  616 */       this.offsets = null; 
/*  617 */     this.oy.clear();
/*      */     
/*  619 */     return 0;
/*      */   }
/*      */   
/*      */   static int fseek(InputStream paramInputStream, long paramLong, int paramInt) {
/*  623 */     if (paramInputStream instanceof VorbisFile$SeekableInputStream) {
/*  624 */       VorbisFile$SeekableInputStream vorbisFile$SeekableInputStream = (VorbisFile$SeekableInputStream)paramInputStream;
/*      */       try {
/*  626 */         if (paramInt == 0) {
/*  627 */           vorbisFile$SeekableInputStream.seek(paramLong);
/*      */         }
/*  629 */         else if (paramInt == 2) {
/*  630 */           vorbisFile$SeekableInputStream.seek(vorbisFile$SeekableInputStream.getLength() - paramLong);
/*      */         
/*      */         }
/*      */       
/*      */       }
/*  635 */       catch (Exception exception) {}
/*      */       
/*  637 */       return 0;
/*      */     } 
/*      */     try {
/*  640 */       if (paramInt == 0) {
/*  641 */         paramInputStream.reset();
/*      */       }
/*  643 */       paramInputStream.skip(paramLong);
/*      */     }
/*  645 */     catch (Exception exception) {
/*  646 */       return -1;
/*      */     } 
/*  648 */     return 0;
/*      */   }
/*      */   
/*      */   static long ftell(InputStream paramInputStream) {
/*      */     try {
/*  653 */       if (paramInputStream instanceof VorbisFile$SeekableInputStream) {
/*  654 */         VorbisFile$SeekableInputStream vorbisFile$SeekableInputStream = (VorbisFile$SeekableInputStream)paramInputStream;
/*  655 */         return vorbisFile$SeekableInputStream.tell();
/*      */       }
/*      */     
/*  658 */     } catch (Exception exception) {}
/*      */     
/*  660 */     return 0L;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int open(InputStream paramInputStream, byte[] paramArrayOfbyte, int paramInt) {
/*  671 */     return open_callbacks(paramInputStream, paramArrayOfbyte, paramInt);
/*      */   }
/*      */ 
/*      */   
/*      */   int open_callbacks(InputStream paramInputStream, byte[] paramArrayOfbyte, int paramInt) {
/*      */     int i;
/*  677 */     this.datasource = paramInputStream;
/*      */     
/*  679 */     this.oy.init();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  685 */     if (paramArrayOfbyte != null) {
/*  686 */       int j = this.oy.buffer(paramInt);
/*  687 */       System.arraycopy(paramArrayOfbyte, 0, this.oy.data, j, paramInt);
/*  688 */       this.oy.wrote(paramInt);
/*      */     } 
/*      */     
/*  691 */     if (paramInputStream instanceof VorbisFile$SeekableInputStream) {
/*  692 */       i = open_seekable();
/*      */     } else {
/*      */       
/*  695 */       i = open_nonseekable();
/*      */     } 
/*  697 */     if (i != 0) {
/*  698 */       this.datasource = null;
/*  699 */       clear();
/*      */     } 
/*  701 */     return i;
/*      */   }
/*      */ 
/*      */   
/*      */   public int streams() {
/*  706 */     return this.links;
/*      */   }
/*      */ 
/*      */   
/*      */   public boolean seekable() {
/*  711 */     return this.seekable;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int bitrate(int paramInt) {
/*  724 */     if (paramInt >= this.links)
/*  725 */       return -1; 
/*  726 */     if (!this.seekable && paramInt != 0)
/*  727 */       return bitrate(0); 
/*  728 */     if (paramInt < 0) {
/*  729 */       long l = 0L;
/*  730 */       for (byte b = 0; b < this.links; b++) {
/*  731 */         l += (this.offsets[b + 1] - this.dataoffsets[b]) * 8L;
/*      */       }
/*  733 */       return (int)Math.rint(((float)l / time_total(-1)));
/*      */     } 
/*      */     
/*  736 */     if (this.seekable)
/*      */     {
/*  738 */       return (int)Math.rint(((float)((this.offsets[paramInt + 1] - this.dataoffsets[paramInt]) * 8L) / time_total(paramInt)));
/*      */     }
/*      */ 
/*      */     
/*  742 */     if ((this.vi[paramInt]).bitrate_nominal > 0) {
/*  743 */       return (this.vi[paramInt]).bitrate_nominal;
/*      */     }
/*      */     
/*  746 */     if ((this.vi[paramInt]).bitrate_upper > 0) {
/*  747 */       if ((this.vi[paramInt]).bitrate_lower > 0) {
/*  748 */         return ((this.vi[paramInt]).bitrate_upper + (this.vi[paramInt]).bitrate_lower) / 2;
/*      */       }
/*      */       
/*  751 */       return (this.vi[paramInt]).bitrate_upper;
/*      */     } 
/*      */     
/*  754 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int bitrate_instant() {
/*  763 */     boolean bool = this.seekable ? this.current_link : false;
/*  764 */     if (this.samptrack == 0.0F)
/*  765 */       return -1; 
/*  766 */     int i = (int)((this.bittrack / this.samptrack * (this.vi[bool]).rate) + 0.5D);
/*  767 */     this.bittrack = 0.0F;
/*  768 */     this.samptrack = 0.0F;
/*  769 */     return i;
/*      */   }
/*      */   
/*      */   public int serialnumber(int paramInt) {
/*  773 */     if (paramInt >= this.links)
/*  774 */       return -1; 
/*  775 */     if (!this.seekable && paramInt >= 0)
/*  776 */       return serialnumber(-1); 
/*  777 */     if (paramInt < 0) {
/*  778 */       return this.current_serialno;
/*      */     }
/*      */     
/*  781 */     return this.serialnos[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long raw_total(int paramInt) {
/*  790 */     if (!this.seekable || paramInt >= this.links)
/*  791 */       return -1L; 
/*  792 */     if (paramInt < 0) {
/*  793 */       long l = 0L;
/*  794 */       for (byte b = 0; b < this.links; b++) {
/*  795 */         l += raw_total(b);
/*      */       }
/*  797 */       return l;
/*      */     } 
/*      */     
/*  800 */     return this.offsets[paramInt + 1] - this.offsets[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long pcm_total(int paramInt) {
/*  808 */     if (!this.seekable || paramInt >= this.links)
/*  809 */       return -1L; 
/*  810 */     if (paramInt < 0) {
/*  811 */       long l = 0L;
/*  812 */       for (byte b = 0; b < this.links; b++) {
/*  813 */         l += pcm_total(b);
/*      */       }
/*  815 */       return l;
/*      */     } 
/*      */     
/*  818 */     return this.pcmlengths[paramInt];
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float time_total(int paramInt) {
/*  826 */     if (!this.seekable || paramInt >= this.links)
/*  827 */       return -1.0F; 
/*  828 */     if (paramInt < 0) {
/*  829 */       float f = 0.0F;
/*  830 */       for (byte b = 0; b < this.links; b++) {
/*  831 */         f += time_total(b);
/*      */       }
/*  833 */       return f;
/*      */     } 
/*      */     
/*  836 */     return (float)this.pcmlengths[paramInt] / (this.vi[paramInt]).rate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int raw_seek(int paramInt) {
/*  849 */     if (!this.seekable)
/*  850 */       return -1; 
/*  851 */     if (paramInt < 0 || paramInt > this.offsets[this.links]) {
/*      */       
/*  853 */       this.pcm_offset = -1L;
/*  854 */       decode_clear();
/*  855 */       return -1;
/*      */     } 
/*      */ 
/*      */     
/*  859 */     this.pcm_offset = -1L;
/*  860 */     decode_clear();
/*      */ 
/*      */     
/*  863 */     seek_helper(paramInt);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  871 */     switch (process_packet(1)) {
/*      */ 
/*      */       
/*      */       case 0:
/*  875 */         this.pcm_offset = pcm_total(-1);
/*  876 */         return 0;
/*      */ 
/*      */       
/*      */       case -1:
/*  880 */         this.pcm_offset = -1L;
/*  881 */         decode_clear();
/*  882 */         return -1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     while (true) {
/*  888 */       switch (process_packet(0)) {
/*      */ 
/*      */ 
/*      */         
/*      */         case 0:
/*  893 */           return 0;
/*      */         case -1:
/*      */           break;
/*      */       } 
/*  897 */     }  this.pcm_offset = -1L;
/*  898 */     decode_clear();
/*  899 */     return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int pcm_seek(long paramLong) {
/*  917 */     int i = -1;
/*  918 */     long l1 = pcm_total(-1);
/*      */     
/*  920 */     if (!this.seekable)
/*  921 */       return -1; 
/*  922 */     if (paramLong < 0L || paramLong > l1) {
/*      */       
/*  924 */       this.pcm_offset = -1L;
/*  925 */       decode_clear();
/*  926 */       return -1;
/*      */     } 
/*      */ 
/*      */     
/*  930 */     for (i = this.links - 1; i >= 0; i--) {
/*  931 */       l1 -= this.pcmlengths[i];
/*  932 */       if (paramLong >= l1) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  942 */     long l2 = paramLong - l1;
/*  943 */     long l3 = this.offsets[i + 1];
/*  944 */     long l4 = this.offsets[i];
/*  945 */     int j = (int)l4;
/*      */     
/*  947 */     Page page = new Page();
/*  948 */     while (l4 < l3) {
/*      */       long l5;
/*      */ 
/*      */       
/*  952 */       if (l3 - l4 < 8500L) {
/*  953 */         l5 = l4;
/*      */       } else {
/*      */         
/*  956 */         l5 = (l3 + l4) / 2L;
/*      */       } 
/*      */       
/*  959 */       seek_helper(l5);
/*  960 */       int k = get_next_page(page, l3 - l5);
/*      */       
/*  962 */       if (k == -1) {
/*  963 */         l3 = l5;
/*      */         continue;
/*      */       } 
/*  966 */       long l6 = page.granulepos();
/*  967 */       if (l6 < l2) {
/*  968 */         j = k;
/*  969 */         l4 = this.offset;
/*      */         continue;
/*      */       } 
/*  972 */       l3 = l5;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  977 */     if (raw_seek(j) != 0) {
/*      */       
/*  979 */       this.pcm_offset = -1L;
/*  980 */       decode_clear();
/*  981 */       return -1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  986 */     if (this.pcm_offset >= paramLong) {
/*      */       
/*  988 */       this.pcm_offset = -1L;
/*  989 */       decode_clear();
/*  990 */       return -1;
/*      */     } 
/*  992 */     if (paramLong > pcm_total(-1)) {
/*      */       
/*  994 */       this.pcm_offset = -1L;
/*  995 */       decode_clear();
/*  996 */       return -1;
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1001 */     while (this.pcm_offset < paramLong) {
/* 1002 */       int k = (int)(paramLong - this.pcm_offset);
/* 1003 */       float[][][] arrayOfFloat = new float[1][][];
/* 1004 */       int[] arrayOfInt = new int[(getInfo(-1)).channels];
/* 1005 */       int m = this.vd.synthesis_pcmout(arrayOfFloat, arrayOfInt);
/*      */       
/* 1007 */       if (m > k)
/* 1008 */         m = k; 
/* 1009 */       this.vd.synthesis_read(m);
/* 1010 */       this.pcm_offset += m;
/*      */       
/* 1012 */       if (m < k && 
/* 1013 */         process_packet(1) == 0) {
/* 1014 */         this.pcm_offset = pcm_total(-1);
/*      */       }
/*      */     } 
/* 1017 */     return 0;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int time_seek(float paramFloat) {
/* 1031 */     int i = -1;
/* 1032 */     long l1 = pcm_total(-1);
/* 1033 */     float f = time_total(-1);
/*      */     
/* 1035 */     if (!this.seekable)
/* 1036 */       return -1; 
/* 1037 */     if (paramFloat < 0.0F || paramFloat > f) {
/*      */       
/* 1039 */       this.pcm_offset = -1L;
/* 1040 */       decode_clear();
/* 1041 */       return -1;
/*      */     } 
/*      */ 
/*      */     
/* 1045 */     for (i = this.links - 1; i >= 0; i--) {
/* 1046 */       l1 -= this.pcmlengths[i];
/* 1047 */       f -= time_total(i);
/* 1048 */       if (paramFloat >= f) {
/*      */         break;
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/* 1054 */     long l2 = (long)((float)l1 + (paramFloat - f) * (this.vi[i]).rate);
/* 1055 */     return pcm_seek(l2);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public long raw_tell() {
/* 1068 */     return this.offset;
/*      */   }
/*      */ 
/*      */   
/*      */   public long pcm_tell() {
/* 1073 */     return this.pcm_offset;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float time_tell() {
/* 1080 */     int i = -1;
/* 1081 */     long l = 0L;
/* 1082 */     float f = 0.0F;
/*      */     
/* 1084 */     if (this.seekable) {
/* 1085 */       l = pcm_total(-1);
/* 1086 */       f = time_total(-1);
/*      */ 
/*      */       
/* 1089 */       for (i = this.links - 1; i >= 0; i--) {
/* 1090 */         l -= this.pcmlengths[i];
/* 1091 */         f -= time_total(i);
/* 1092 */         if (this.pcm_offset >= l) {
/*      */           break;
/*      */         }
/*      */       } 
/*      */     } 
/* 1097 */     return f + (float)(this.pcm_offset - l) / (this.vi[i]).rate;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Info getInfo(int paramInt) {
/* 1109 */     if (this.seekable) {
/* 1110 */       if (paramInt < 0) {
/* 1111 */         if (this.decode_ready) {
/* 1112 */           return this.vi[this.current_link];
/*      */         }
/*      */         
/* 1115 */         return null;
/*      */       } 
/*      */ 
/*      */       
/* 1119 */       if (paramInt >= this.links) {
/* 1120 */         return null;
/*      */       }
/*      */       
/* 1123 */       return this.vi[paramInt];
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1128 */     if (this.decode_ready) {
/* 1129 */       return this.vi[0];
/*      */     }
/*      */     
/* 1132 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public Comment getComment(int paramInt) {
/* 1138 */     if (this.seekable) {
/* 1139 */       if (paramInt < 0) {
/* 1140 */         if (this.decode_ready) {
/* 1141 */           return this.vc[this.current_link];
/*      */         }
/*      */         
/* 1144 */         return null;
/*      */       } 
/*      */ 
/*      */       
/* 1148 */       if (paramInt >= this.links) {
/* 1149 */         return null;
/*      */       }
/*      */       
/* 1152 */       return this.vc[paramInt];
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/* 1157 */     if (this.decode_ready) {
/* 1158 */       return this.vc[0];
/*      */     }
/*      */     
/* 1161 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   int host_is_big_endian() {
/* 1167 */     return 1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   int read(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int[] paramArrayOfint) {
/* 1208 */     int i = host_is_big_endian();
/* 1209 */     byte b = 0;
/*      */     
/*      */     while (true)
/* 1212 */     { if (this.decode_ready) {
/*      */         
/* 1214 */         float[][][] arrayOfFloat1 = new float[1][][];
/* 1215 */         int[] arrayOfInt = new int[(getInfo(-1)).channels];
/* 1216 */         int j = this.vd.synthesis_pcmout(arrayOfFloat1, arrayOfInt);
/* 1217 */         float[][] arrayOfFloat = arrayOfFloat1[0];
/* 1218 */         if (j != 0) {
/*      */           
/* 1220 */           int k = (getInfo(-1)).channels;
/* 1221 */           int m = paramInt3 * k;
/* 1222 */           if (j > paramInt1 / m) {
/* 1223 */             j = paramInt1 / m;
/*      */           }
/*      */ 
/*      */ 
/*      */           
/* 1228 */           if (paramInt3 == 1) {
/* 1229 */             byte b1 = (paramInt4 != 0) ? 0 : 128;
/* 1230 */             for (byte b2 = 0; b2 < j; b2++) {
/* 1231 */               for (byte b3 = 0; b3 < k; b3++) {
/* 1232 */                 int n = (int)(arrayOfFloat[b3][arrayOfInt[b3] + b2] * 128.0D + 0.5D);
/* 1233 */                 if (n > 127) {
/* 1234 */                   n = 127;
/* 1235 */                 } else if (n < -128) {
/* 1236 */                   n = -128;
/* 1237 */                 }  paramArrayOfbyte[b++] = (byte)(n + b1);
/*      */               } 
/*      */             } 
/*      */           } else {
/*      */             
/* 1242 */             byte b1 = (paramInt4 != 0) ? 0 : 32768;
/*      */             
/* 1244 */             if (i == paramInt2) {
/* 1245 */               if (paramInt4 != 0) {
/* 1246 */                 for (byte b2 = 0; b2 < k; b2++) {
/* 1247 */                   int n = arrayOfInt[b2];
/* 1248 */                   int i1 = b2;
/* 1249 */                   for (byte b3 = 0; b3 < j; b3++) {
/* 1250 */                     int i2 = (int)(arrayOfFloat[b2][n + b3] * 32768.0D + 0.5D);
/* 1251 */                     if (i2 > 32767) {
/* 1252 */                       i2 = 32767;
/* 1253 */                     } else if (i2 < -32768) {
/* 1254 */                       i2 = -32768;
/* 1255 */                     }  paramArrayOfbyte[i1] = (byte)(i2 >>> 8);
/* 1256 */                     paramArrayOfbyte[i1 + 1] = (byte)i2;
/* 1257 */                     i1 += k * 2;
/*      */                   } 
/*      */                 } 
/*      */               } else {
/*      */                 
/* 1262 */                 for (byte b2 = 0; b2 < k; b2++) {
/* 1263 */                   float[] arrayOfFloat2 = arrayOfFloat[b2];
/* 1264 */                   int n = b2;
/* 1265 */                   for (byte b3 = 0; b3 < j; b3++) {
/* 1266 */                     int i1 = (int)(arrayOfFloat2[b3] * 32768.0D + 0.5D);
/* 1267 */                     if (i1 > 32767) {
/* 1268 */                       i1 = 32767;
/* 1269 */                     } else if (i1 < -32768) {
/* 1270 */                       i1 = -32768;
/* 1271 */                     }  paramArrayOfbyte[n] = (byte)(i1 + b1 >>> 8);
/* 1272 */                     paramArrayOfbyte[n + 1] = (byte)(i1 + b1);
/* 1273 */                     n += k * 2;
/*      */                   }
/*      */                 
/*      */                 } 
/*      */               } 
/* 1278 */             } else if (paramInt2 != 0) {
/* 1279 */               for (byte b2 = 0; b2 < j; b2++) {
/* 1280 */                 for (byte b3 = 0; b3 < k; b3++) {
/* 1281 */                   int n = (int)(arrayOfFloat[b3][b2] * 32768.0D + 0.5D);
/* 1282 */                   if (n > 32767) {
/* 1283 */                     n = 32767;
/* 1284 */                   } else if (n < -32768) {
/* 1285 */                     n = -32768;
/* 1286 */                   }  n += b1;
/* 1287 */                   paramArrayOfbyte[b++] = (byte)(n >>> 8);
/* 1288 */                   paramArrayOfbyte[b++] = (byte)n;
/*      */                 }
/*      */               
/*      */               } 
/*      */             } else {
/*      */               
/* 1294 */               for (byte b2 = 0; b2 < j; b2++) {
/* 1295 */                 for (byte b3 = 0; b3 < k; b3++) {
/* 1296 */                   int n = (int)(arrayOfFloat[b3][b2] * 32768.0D + 0.5D);
/* 1297 */                   if (n > 32767) {
/* 1298 */                     n = 32767;
/* 1299 */                   } else if (n < -32768) {
/* 1300 */                     n = -32768;
/* 1301 */                   }  n += b1;
/* 1302 */                   paramArrayOfbyte[b++] = (byte)n;
/* 1303 */                   paramArrayOfbyte[b++] = (byte)(n >>> 8);
/*      */                 } 
/*      */               } 
/*      */             } 
/*      */           } 
/*      */ 
/*      */           
/* 1310 */           this.vd.synthesis_read(j);
/* 1311 */           this.pcm_offset += j;
/* 1312 */           if (paramArrayOfint != null)
/* 1313 */             paramArrayOfint[0] = this.current_link; 
/* 1314 */           return j * m;
/*      */         } 
/*      */       } 
/*      */ 
/*      */       
/* 1319 */       switch (process_packet(1))
/*      */       { case 0:
/* 1321 */           return 0;
/*      */         case -1:
/* 1323 */           break; }  }  return -1;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Info[] getInfo() {
/* 1331 */     return this.vi;
/*      */   }
/*      */   
/*      */   public Comment[] getComment() {
/* 1335 */     return this.vc;
/*      */   }
/*      */   
/*      */   public void close() {
/* 1339 */     this.datasource.close();
/*      */   }
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\VorbisFile.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */