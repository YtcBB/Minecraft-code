package com.jcraft.jorbis;

class Floor1$Lsfit_acc {
  long x0;
  
  long x1;
  
  long xa;
  
  long ya;
  
  long x2a;
  
  long y2a;
  
  long xya;
  
  long n;
  
  long an;
  
  long un;
  
  long edgey0;
  
  long edgey1;
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\Floor1$Lsfit_acc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */