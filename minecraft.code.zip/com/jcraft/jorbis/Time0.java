/*    */ package com.jcraft.jorbis;
/*    */ 
/*    */ import com.jcraft.jogg.Buffer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class Time0
/*    */   extends FuncTime
/*    */ {
/*    */   void pack(Object paramObject, Buffer paramBuffer) {}
/*    */   
/*    */   Object unpack(Info paramInfo, Buffer paramBuffer) {
/* 36 */     return "";
/*    */   }
/*    */   
/*    */   Object look(DspState paramDspState, InfoMode paramInfoMode, Object paramObject) {
/* 40 */     return "";
/*    */   }
/*    */ 
/*    */   
/*    */   void free_info(Object paramObject) {}
/*    */ 
/*    */   
/*    */   void free_look(Object paramObject) {}
/*    */   
/*    */   int inverse(Block paramBlock, Object paramObject, float[] paramArrayOffloat1, float[] paramArrayOffloat2) {
/* 50 */     return 0;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\Time0.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */