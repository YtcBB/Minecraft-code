/*    */ package com.jcraft.jorbis;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ChainingExample
/*    */ {
/*    */   public static void main(String[] paramArrayOfString) {
/* 31 */     VorbisFile vorbisFile = null;
/*    */     
/*    */     try {
/* 34 */       if (paramArrayOfString.length > 0) {
/* 35 */         vorbisFile = new VorbisFile(paramArrayOfString[0]);
/*    */       } else {
/*    */         
/* 38 */         vorbisFile = new VorbisFile(System.in, null, -1);
/*    */       }
/*    */     
/* 41 */     } catch (Exception exception) {
/* 42 */       System.err.println(exception);
/*    */       
/*    */       return;
/*    */     } 
/* 46 */     if (vorbisFile.seekable()) {
/* 47 */       System.out.println("Input bitstream contained " + vorbisFile.streams() + " logical bitstream section(s).");
/*    */       
/* 49 */       System.out.println("Total bitstream playing time: " + vorbisFile.time_total(-1) + " seconds\n");
/*    */     }
/*    */     else {
/*    */       
/* 53 */       System.out.println("Standard input was not seekable.");
/* 54 */       System.out.println("First logical bitstream information:\n");
/*    */     } 
/*    */     
/* 57 */     for (byte b = 0; b < vorbisFile.streams(); b++) {
/* 58 */       Info info = vorbisFile.getInfo(b);
/* 59 */       System.out.println("\tlogical bitstream section " + (b + 1) + " information:");
/* 60 */       System.out.println("\t\t" + info.rate + "Hz " + info.channels + " channels bitrate " + (vorbisFile.bitrate(b) / 1000) + "kbps serial number=" + vorbisFile.serialnumber(b));
/*    */       
/* 62 */       System.out.print("\t\tcompressed length: " + vorbisFile.raw_total(b) + " bytes ");
/* 63 */       System.out.println(" play time: " + vorbisFile.time_total(b) + "s");
/* 64 */       Comment comment = vorbisFile.getComment(b);
/* 65 */       System.out.println(comment);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\ChainingExample.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */