package com.jcraft.jorbis;

class Residue0$LookResidue0 {
  Residue0$InfoResidue0 info;
  
  int map;
  
  int parts;
  
  int stages;
  
  CodeBook[] fullbooks;
  
  CodeBook phrasebook;
  
  int[][] partbooks;
  
  int partvals;
  
  int[][] decodemap;
  
  int postbits;
  
  int phrasebits;
  
  int frames;
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\Residue0$LookResidue0.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */