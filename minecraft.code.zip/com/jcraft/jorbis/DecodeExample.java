/*     */ package com.jcraft.jorbis;
/*     */ 
/*     */ import com.jcraft.jogg.Packet;
/*     */ import com.jcraft.jogg.Page;
/*     */ import com.jcraft.jogg.StreamState;
/*     */ import com.jcraft.jogg.SyncState;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.InputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class DecodeExample
/*     */ {
/*  36 */   static int convsize = 8192;
/*  37 */   static byte[] convbuffer = new byte[convsize];
/*     */   
/*     */   public static void main(String[] paramArrayOfString) {
/*  40 */     InputStream inputStream = System.in;
/*  41 */     if (paramArrayOfString.length > 0) {
/*     */       try {
/*  43 */         inputStream = new FileInputStream(paramArrayOfString[0]);
/*     */       }
/*  45 */       catch (Exception exception) {
/*  46 */         System.err.println(exception);
/*     */       } 
/*     */     }
/*     */     
/*  50 */     SyncState syncState = new SyncState();
/*  51 */     StreamState streamState = new StreamState();
/*  52 */     Page page = new Page();
/*  53 */     Packet packet = new Packet();
/*     */     
/*  55 */     Info info = new Info();
/*  56 */     Comment comment = new Comment();
/*  57 */     DspState dspState = new DspState();
/*  58 */     Block block = new Block(dspState);
/*     */ 
/*     */     
/*  61 */     int i = 0;
/*     */ 
/*     */ 
/*     */     
/*  65 */     syncState.init();
/*     */     
/*     */     while (true) {
/*  68 */       boolean bool = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  76 */       int j = syncState.buffer(4096);
/*  77 */       byte[] arrayOfByte = syncState.data;
/*     */       try {
/*  79 */         i = inputStream.read(arrayOfByte, j, 4096);
/*     */       }
/*  81 */       catch (Exception exception) {
/*  82 */         System.err.println(exception);
/*  83 */         System.exit(-1);
/*     */       } 
/*  85 */       syncState.wrote(i);
/*     */ 
/*     */       
/*  88 */       if (syncState.pageout(page) != 1) {
/*     */         
/*  90 */         if (i < 4096) {
/*     */           break;
/*     */         }
/*     */         
/*  94 */         System.err.println("Input does not appear to be an Ogg bitstream.");
/*  95 */         System.exit(1);
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 100 */       streamState.init(page.serialno());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 110 */       info.init();
/* 111 */       comment.init();
/* 112 */       if (streamState.pagein(page) < 0) {
/*     */         
/* 114 */         System.err.println("Error reading first page of Ogg bitstream data.");
/* 115 */         System.exit(1);
/*     */       } 
/*     */       
/* 118 */       if (streamState.packetout(packet) != 1) {
/*     */         
/* 120 */         System.err.println("Error reading initial header packet.");
/* 121 */         System.exit(1);
/*     */       } 
/*     */       
/* 124 */       if (info.synthesis_headerin(comment, packet) < 0) {
/*     */         
/* 126 */         System.err.println("This Ogg bitstream does not contain Vorbis audio data.");
/*     */         
/* 128 */         System.exit(1);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 141 */       byte b1 = 0;
/* 142 */       while (b1 < 2) {
/* 143 */         while (b1 < 2) {
/*     */           
/* 145 */           int k = syncState.pageout(page);
/* 146 */           if (k == 0) {
/*     */             break;
/*     */           }
/*     */ 
/*     */           
/* 151 */           if (k == 1) {
/* 152 */             streamState.pagein(page);
/*     */ 
/*     */             
/* 155 */             while (b1 < 2) {
/* 156 */               k = streamState.packetout(packet);
/* 157 */               if (k == 0)
/*     */                 break; 
/* 159 */               if (k == -1) {
/*     */ 
/*     */                 
/* 162 */                 System.err.println("Corrupt secondary header.  Exiting.");
/* 163 */                 System.exit(1);
/*     */               } 
/* 165 */               info.synthesis_headerin(comment, packet);
/* 166 */               b1++;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 171 */         j = syncState.buffer(4096);
/* 172 */         arrayOfByte = syncState.data;
/*     */         try {
/* 174 */           i = inputStream.read(arrayOfByte, j, 4096);
/*     */         }
/* 176 */         catch (Exception exception) {
/* 177 */           System.err.println(exception);
/* 178 */           System.exit(1);
/*     */         } 
/* 180 */         if (i == 0 && b1 < 2) {
/* 181 */           System.err.println("End of file before finding all Vorbis headers!");
/* 182 */           System.exit(1);
/*     */         } 
/* 184 */         syncState.wrote(i);
/*     */       } 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 190 */       byte[][] arrayOfByte1 = comment.user_comments;
/* 191 */       for (byte b2 = 0; b2 < arrayOfByte1.length && 
/* 192 */         arrayOfByte1[b2] != null; b2++)
/*     */       {
/* 194 */         System.err.println(new String(arrayOfByte1[b2], 0, (arrayOfByte1[b2]).length - 1));
/*     */       }
/* 196 */       System.err.println("\nBitstream is " + info.channels + " channel, " + info.rate + "Hz");
/*     */       
/* 198 */       System.err.println("Encoded by: " + new String(comment.vendor, 0, comment.vendor.length - 1) + "\n");
/*     */ 
/*     */ 
/*     */       
/* 202 */       convsize = 4096 / info.channels;
/*     */ 
/*     */ 
/*     */       
/* 206 */       dspState.synthesis_init(info);
/* 207 */       block.init(dspState);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 213 */       float[][][] arrayOfFloat = new float[1][][];
/* 214 */       int[] arrayOfInt = new int[info.channels];
/*     */       
/* 216 */       while (!bool) {
/* 217 */         while (!bool) {
/*     */           
/* 219 */           int k = syncState.pageout(page);
/* 220 */           if (k == 0)
/*     */             break; 
/* 222 */           if (k == -1) {
/* 223 */             System.err.println("Corrupt or missing data in bitstream; continuing...");
/*     */             
/*     */             continue;
/*     */           } 
/* 227 */           streamState.pagein(page);
/*     */           
/*     */           while (true) {
/* 230 */             k = streamState.packetout(packet);
/*     */             
/* 232 */             if (k == 0)
/*     */               break; 
/* 234 */             if (k == -1) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/* 240 */             if (block.synthesis(packet) == 0) {
/* 241 */               dspState.synthesis_blockin(block);
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*     */             int m;
/*     */ 
/*     */             
/* 249 */             while ((m = dspState.synthesis_pcmout(arrayOfFloat, arrayOfInt)) > 0) {
/* 250 */               float[][] arrayOfFloat1 = arrayOfFloat[0];
/* 251 */               int n = (m < convsize) ? m : convsize;
/*     */ 
/*     */ 
/*     */               
/* 255 */               for (b1 = 0; b1 < info.channels; b1++) {
/* 256 */                 int i1 = b1 * 2;
/*     */                 
/* 258 */                 int i2 = arrayOfInt[b1];
/* 259 */                 for (byte b = 0; b < n; b++) {
/* 260 */                   int i3 = (int)(arrayOfFloat1[b1][i2 + b] * 32767.0D);
/*     */ 
/*     */ 
/*     */                   
/* 264 */                   if (i3 > 32767) {
/* 265 */                     i3 = 32767;
/*     */                   }
/* 267 */                   if (i3 < -32768) {
/* 268 */                     i3 = -32768;
/*     */                   }
/* 270 */                   if (i3 < 0)
/* 271 */                     i3 |= 0x8000; 
/* 272 */                   convbuffer[i1] = (byte)i3;
/* 273 */                   convbuffer[i1 + 1] = (byte)(i3 >>> 8);
/* 274 */                   i1 += 2 * info.channels;
/*     */                 } 
/*     */               } 
/*     */               
/* 278 */               System.out.write(convbuffer, 0, 2 * info.channels * n);
/*     */ 
/*     */ 
/*     */ 
/*     */               
/* 283 */               dspState.synthesis_read(n);
/*     */             } 
/*     */           } 
/*     */           
/* 287 */           if (page.eos() != 0) {
/* 288 */             bool = true;
/*     */           }
/*     */         } 
/* 291 */         if (!bool) {
/* 292 */           j = syncState.buffer(4096);
/* 293 */           arrayOfByte = syncState.data;
/*     */           try {
/* 295 */             i = inputStream.read(arrayOfByte, j, 4096);
/*     */           }
/* 297 */           catch (Exception exception) {
/* 298 */             System.err.println(exception);
/* 299 */             System.exit(1);
/*     */           } 
/* 301 */           syncState.wrote(i);
/* 302 */           if (i == 0) {
/* 303 */             bool = true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 310 */       streamState.clear();
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 315 */       block.clear();
/* 316 */       dspState.clear();
/* 317 */       info.clear();
/*     */     } 
/*     */ 
/*     */     
/* 321 */     syncState.clear();
/* 322 */     System.err.println("Done.");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\com\jcraft\jorbis\DecodeExample.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */