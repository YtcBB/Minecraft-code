/*    */ import java.io.DataInputStream;
/*    */ import java.io.DataOutputStream;
/*    */ import java.io.File;
/*    */ import java.io.IOException;
/*    */ import java.util.HashMap;
/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aci
/*    */ {
/* 39 */   private static final Map a = new HashMap<Object, Object>();
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static synchronized acg a(File paramFile, int paramInt1, int paramInt2) {
/* 45 */     File file1 = new File(paramFile, "region");
/* 46 */     File file2 = new File(file1, "r." + (paramInt1 >> 5) + "." + (paramInt2 >> 5) + ".mca");
/*    */     
/* 48 */     acg acg1 = (acg)a.get(file2);
/* 49 */     if (acg1 != null) {
/* 50 */       return acg1;
/*    */     }
/*    */     
/* 53 */     if (!file1.exists()) {
/* 54 */       file1.mkdirs();
/*    */     }
/*    */     
/* 57 */     if (a.size() >= 256) {
/* 58 */       a();
/*    */     }
/*    */     
/* 61 */     acg acg2 = new acg(file2);
/* 62 */     a.put(file2, acg2);
/* 63 */     return acg2;
/*    */   }
/*    */   
/*    */   public static synchronized void a() {
/* 67 */     for (acg acg : a.values()) {
/*    */       try {
/* 69 */         if (acg != null) {
/* 70 */           acg.c();
/*    */         }
/* 72 */       } catch (IOException iOException) {
/* 73 */         iOException.printStackTrace();
/*    */       } 
/*    */     } 
/* 76 */     a.clear();
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public static DataInputStream c(File paramFile, int paramInt1, int paramInt2) {
/* 85 */     acg acg = a(paramFile, paramInt1, paramInt2);
/* 86 */     return acg.a(paramInt1 & 0x1F, paramInt2 & 0x1F);
/*    */   }
/*    */   
/*    */   public static DataOutputStream d(File paramFile, int paramInt1, int paramInt2) {
/* 90 */     acg acg = a(paramFile, paramInt1, paramInt2);
/* 91 */     return acg.b(paramInt1 & 0x1F, paramInt2 & 0x1F);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aci.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */