/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class alm
/*     */   extends apa
/*     */ {
/*     */   private lx a;
/*     */   private lx b;
/*     */   private lx c;
/*     */   
/*     */   public alm(int paramInt) {
/*  26 */     super(paramInt, aif.f);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  31 */     if (paramInt1 == 1) {
/*  32 */       return this.b;
/*     */     }
/*  34 */     if (paramInt1 == 0) {
/*  35 */       return this.c;
/*     */     }
/*  37 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  42 */     this.a = paramly.a("cauldron_inner");
/*  43 */     this.b = paramly.a("cauldron_top");
/*  44 */     this.c = paramly.a("cauldron_bottom");
/*  45 */     this.cQ = paramly.a("cauldron_side");
/*     */   }
/*     */   
/*     */   public static lx b(String paramString) {
/*  49 */     if (paramString == "cauldron_inner") return apa.bK.a; 
/*  50 */     if (paramString == "cauldron_bottom") return apa.bK.c; 
/*  51 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/*  56 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.3125F, 1.0F);
/*  57 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  58 */     float f = 0.125F;
/*  59 */     a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
/*  60 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  61 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
/*  62 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  63 */     a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  64 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  65 */     a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
/*  66 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     
/*  68 */     g();
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  73 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  78 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  83 */     return 24;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  88 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  93 */     if (paramaab.I) {
/*  94 */       return true;
/*     */     }
/*     */     
/*  97 */     wm wm = paramsq.bK.h();
/*  98 */     if (wm == null) {
/*  99 */       return true;
/*     */     }
/*     */     
/* 102 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/* 104 */     if (wm.c == wk.ay.cp) {
/* 105 */       if (i < 3) {
/* 106 */         if (!paramsq.ce.d) {
/* 107 */           paramsq.bK.a(paramsq.bK.c, new wm(wk.ax));
/*     */         }
/*     */         
/* 110 */         paramaab.b(paramInt1, paramInt2, paramInt3, 3, 2);
/*     */       } 
/* 112 */       return true;
/* 113 */     }  if (wm.c == wk.bu.cp) {
/* 114 */       if (i > 0) {
/* 115 */         wm wm1 = new wm(wk.bt, 1, 0);
/* 116 */         if (!paramsq.bK.a(wm1)) {
/* 117 */           paramaab.d(new rh(paramaab, paramInt1 + 0.5D, paramInt2 + 1.5D, paramInt3 + 0.5D, wm1));
/* 118 */         } else if (paramsq instanceof jc) {
/* 119 */           ((jc)paramsq).a(paramsq.bL);
/*     */         } 
/*     */         
/* 122 */         wm.a--;
/* 123 */         if (wm.a <= 0) {
/* 124 */           paramsq.bK.a(paramsq.bK.c, (wm)null);
/*     */         }
/* 126 */         paramaab.b(paramInt1, paramInt2, paramInt3, i - 1, 2);
/*     */       } 
/* 128 */     } else if (i > 0 && wm.b() instanceof uo && ((uo)wm.b()).d() == uq.a) {
/* 129 */       uo uo = (uo)wm.b();
/* 130 */       uo.c(wm);
/* 131 */       paramaab.b(paramInt1, paramInt2, paramInt3, i - 1, 2);
/* 132 */       return true;
/*     */     } 
/*     */     
/* 135 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void g(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 140 */     if (paramaab.s.nextInt(20) != 1)
/*     */       return; 
/* 142 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/* 144 */     if (i < 3) {
/* 145 */       paramaab.b(paramInt1, paramInt2, paramInt3, i + 1, 2);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 151 */     return wk.bA.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 156 */     return wk.bA.cp;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */