/*     */ import java.util.ArrayList;
/*     */ 
/*     */ public enum a {
/*     */   private static final Map w;
/*     */   private static final Map x;
/*     */   private static final Pattern y;
/*   7 */   a('0'),
/*   8 */   b('1'),
/*   9 */   c('2'),
/*  10 */   d('3'),
/*  11 */   e('4'),
/*  12 */   f('5'),
/*  13 */   g('6'),
/*  14 */   h('7'),
/*  15 */   i('8'),
/*  16 */   j('9'),
/*  17 */   k('a'),
/*  18 */   l('b'),
/*  19 */   m('c'),
/*  20 */   n('d'),
/*  21 */   o('e'),
/*  22 */   p('f'),
/*  23 */   q('k', true),
/*  24 */   r('l', true),
/*  25 */   s('m', true),
/*  26 */   t('n', true),
/*  27 */   u('o', true),
/*  28 */   v('r'); private final char z; private final boolean A; private final String B;
/*     */   
/*     */   static {
/*  31 */     w = new HashMap<Object, Object>();
/*  32 */     x = new HashMap<Object, Object>();
/*  33 */     y = Pattern.compile("(?i)" + String.valueOf('§') + "[0-9A-FK-OR]");
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  51 */     for (a a1 : values()) {
/*  52 */       w.put(Character.valueOf(a1.a()), a1);
/*  53 */       x.put(a1.d(), a1);
/*     */     }  } a(char paramChar, boolean paramBoolean) { this.z = paramChar;
/*     */     this.A = paramBoolean;
/*     */     this.B = "§" + paramChar; }
/*     */   public char a() {
/*  58 */     return this.z;
/*     */   }
/*     */   
/*     */   public boolean b() {
/*  62 */     return this.A;
/*     */   }
/*     */   
/*     */   public boolean c() {
/*  66 */     return (!this.A && this != v);
/*     */   }
/*     */   
/*     */   public String d() {
/*  70 */     return name().toLowerCase();
/*     */   }
/*     */ 
/*     */   
/*     */   public String toString() {
/*  75 */     return this.B;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static a b(String paramString) {
/*  87 */     if (paramString == null) return null; 
/*  88 */     return (a)x.get(paramString.toLowerCase());
/*     */   }
/*     */   
/*     */   public static Collection a(boolean paramBoolean1, boolean paramBoolean2) {
/*  92 */     ArrayList<String> arrayList = new ArrayList();
/*     */     
/*  94 */     for (a a1 : values()) {
/*  95 */       if ((!a1.c() || paramBoolean1) && (
/*  96 */         !a1.b() || paramBoolean2)) {
/*  97 */         arrayList.add(a1.d());
/*     */       }
/*     */     } 
/* 100 */     return arrayList;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\a.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */