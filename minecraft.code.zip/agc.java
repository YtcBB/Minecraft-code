/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class agc
/*     */   extends agq
/*     */ {
/*     */   private final int a;
/*     */   
/*     */   public agc(int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 321 */     super(paramInt1);
/*     */     
/* 323 */     this.f = paramInt2;
/* 324 */     this.e = paramaek;
/* 325 */     this.a = (paramInt2 == 2 || paramInt2 == 0) ? paramaek.d() : paramaek.b();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static aek a(List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 332 */     aek aek = aek.a(paramInt1, paramInt2, paramInt3, -1, -1, 0, 5, 5, 4, paramInt4);
/*     */     
/* 334 */     agw agw = agw.a(paramList, aek);
/* 335 */     if (agw == null)
/*     */     {
/*     */       
/* 338 */       return null;
/*     */     }
/*     */     
/* 341 */     if ((agw.b()).b == aek.b)
/*     */     {
/* 343 */       for (byte b = 3; b >= 1; b--) {
/* 344 */         aek = aek.a(paramInt1, paramInt2, paramInt3, -1, -1, 0, 5, 5, b - 1, paramInt4);
/* 345 */         if (!agw.b().a(aek))
/*     */         {
/*     */ 
/*     */           
/* 349 */           return aek.a(paramInt1, paramInt2, paramInt3, -1, -1, 0, 5, 5, b, paramInt4);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 354 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 359 */     if (a(paramaab, paramaek)) {
/* 360 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 364 */     for (byte b = 0; b < this.a; b++) {
/*     */       
/* 366 */       a(paramaab, apa.bq.cz, 0, 0, 0, b, paramaek);
/* 367 */       a(paramaab, apa.bq.cz, 0, 1, 0, b, paramaek);
/* 368 */       a(paramaab, apa.bq.cz, 0, 2, 0, b, paramaek);
/* 369 */       a(paramaab, apa.bq.cz, 0, 3, 0, b, paramaek);
/* 370 */       a(paramaab, apa.bq.cz, 0, 4, 0, b, paramaek);
/*     */       
/* 372 */       for (byte b1 = 1; b1 <= 3; b1++) {
/* 373 */         a(paramaab, apa.bq.cz, 0, 0, b1, b, paramaek);
/* 374 */         a(paramaab, 0, 0, 1, b1, b, paramaek);
/* 375 */         a(paramaab, 0, 0, 2, b1, b, paramaek);
/* 376 */         a(paramaab, 0, 0, 3, b1, b, paramaek);
/* 377 */         a(paramaab, apa.bq.cz, 0, 4, b1, b, paramaek);
/*     */       } 
/*     */       
/* 380 */       a(paramaab, apa.bq.cz, 0, 0, 4, b, paramaek);
/* 381 */       a(paramaab, apa.bq.cz, 0, 1, 4, b, paramaek);
/* 382 */       a(paramaab, apa.bq.cz, 0, 2, 4, b, paramaek);
/* 383 */       a(paramaab, apa.bq.cz, 0, 3, 4, b, paramaek);
/* 384 */       a(paramaab, apa.bq.cz, 0, 4, 4, b, paramaek);
/*     */     } 
/*     */     
/* 387 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\agc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */