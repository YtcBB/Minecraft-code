/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ano
/*     */   extends alh
/*     */ {
/*  12 */   private static final String[] a = new String[] { "netherStalk_0", "netherStalk_1", "netherStalk_2" };
/*     */ 
/*     */   
/*     */   private lx[] b;
/*     */ 
/*     */   
/*     */   protected ano(int paramInt) {
/*  19 */     super(paramInt);
/*     */     
/*  21 */     b(true);
/*  22 */     float f = 0.5F;
/*  23 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.25F, 0.5F + f);
/*  24 */     a((ve)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean f_(int paramInt) {
/*  29 */     return (paramInt == apa.bg.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  34 */     return f_(paramaab.a(paramInt1, paramInt2 - 1, paramInt3));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  40 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  41 */     if (i < 3)
/*     */     {
/*     */ 
/*     */       
/*  45 */       if (paramRandom.nextInt(10) == 0) {
/*  46 */         i++;
/*  47 */         paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/*  52 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  63 */     if (paramInt2 >= 3) {
/*  64 */       return this.b[2];
/*     */     }
/*  66 */     if (paramInt2 > 0) {
/*  67 */       return this.b[1];
/*     */     }
/*  69 */     return this.b[0];
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  74 */     return 6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/*  83 */     if (paramaab.I) {
/*     */       return;
/*     */     }
/*  86 */     int i = 1;
/*  87 */     if (paramInt4 >= 3) {
/*  88 */       i = 2 + paramaab.s.nextInt(3);
/*  89 */       if (paramInt5 > 0) {
/*  90 */         i += paramaab.s.nextInt(paramInt5 + 1);
/*     */       }
/*     */     } 
/*  93 */     for (byte b = 0; b < i; b++) {
/*  94 */       b(paramaab, paramInt1, paramInt2, paramInt3, new wm(wk.bs));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 100 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 105 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 110 */     return wk.bs.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 115 */     this.b = new lx[a.length];
/*     */     
/* 117 */     for (byte b = 0; b < this.b.length; b++)
/* 118 */       this.b[b] = paramly.a(a[b]); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ano.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */