/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ana
/*     */   extends api
/*     */ {
/*  14 */   public static final String[] a = new String[] { "oak", "spruce", "birch", "jungle" };
/*     */ 
/*     */ 
/*     */   
/*  18 */   public static final String[][] b = new String[][] { { "leaves", "leaves_spruce", "leaves", "leaves_jungle" }, { "leaves_opaque", "leaves_spruce_opaque", "leaves_opaque", "leaves_jungle_opaque" } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int e;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  38 */   private lx[][] cR = new lx[2][]; int[] c;
/*     */   
/*     */   protected ana(int paramInt) {
/*  41 */     super(paramInt, aif.j, false);
/*  42 */     b(true);
/*  43 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public int o() {
/*  48 */     double d1 = 0.5D;
/*  49 */     double d2 = 1.0D;
/*     */     
/*  51 */     return zx.a(d1, d2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(int paramInt) {
/*  56 */     if ((paramInt & 0x3) == 1) {
/*  57 */       return zx.a();
/*     */     }
/*  59 */     if ((paramInt & 0x3) == 2) {
/*  60 */       return zx.b();
/*     */     }
/*     */     
/*  63 */     return zx.c();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  69 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  71 */     if ((i & 0x3) == 1) {
/*  72 */       return zx.a();
/*     */     }
/*  74 */     if ((i & 0x3) == 2) {
/*  75 */       return zx.b();
/*     */     }
/*     */     
/*  78 */     int j = 0;
/*  79 */     int k = 0;
/*  80 */     int m = 0;
/*     */     
/*  82 */     for (byte b = -1; b <= 1; b++) {
/*  83 */       for (byte b1 = -1; b1 <= 1; b1++) {
/*  84 */         int n = paramaak.a(paramInt1 + b1, paramInt3 + b).l();
/*     */         
/*  86 */         j += (n & 0xFF0000) >> 16;
/*  87 */         k += (n & 0xFF00) >> 8;
/*  88 */         m += n & 0xFF;
/*     */       } 
/*     */     } 
/*     */     
/*  92 */     return (j / 9 & 0xFF) << 16 | (k / 9 & 0xFF) << 8 | m / 9 & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  97 */     byte b = 1;
/*  98 */     int i = b + 1;
/*     */     
/* 100 */     if (paramaab.e(paramInt1 - i, paramInt2 - i, paramInt3 - i, paramInt1 + i, paramInt2 + i, paramInt3 + i)) {
/* 101 */       for (byte b1 = -b; b1 <= b; b1++) {
/* 102 */         for (byte b2 = -b; b2 <= b; b2++) {
/* 103 */           for (byte b3 = -b; b3 <= b; b3++) {
/* 104 */             int j = paramaab.a(paramInt1 + b1, paramInt2 + b2, paramInt3 + b3);
/* 105 */             if (j == apa.O.cz) {
/* 106 */               int k = paramaab.h(paramInt1 + b1, paramInt2 + b2, paramInt3 + b3);
/* 107 */               paramaab.b(paramInt1 + b1, paramInt2 + b2, paramInt3 + b3, k | 0x8, 4);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 117 */     if (paramaab.I)
/*     */       return; 
/* 119 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 120 */     if ((i & 0x8) != 0 && (i & 0x4) == 0) {
/* 121 */       byte b1 = 4;
/* 122 */       int j = b1 + 1;
/*     */       
/* 124 */       byte b2 = 32;
/* 125 */       int k = b2 * b2;
/* 126 */       int m = b2 / 2;
/* 127 */       if (this.c == null) {
/* 128 */         this.c = new int[b2 * b2 * b2];
/*     */       }
/*     */       
/* 131 */       if (paramaab.e(paramInt1 - j, paramInt2 - j, paramInt3 - j, paramInt1 + j, paramInt2 + j, paramInt3 + j)) {
/* 132 */         byte b; for (b = -b1; b <= b1; b++) {
/* 133 */           for (byte b3 = -b1; b3 <= b1; b3++) {
/* 134 */             for (byte b4 = -b1; b4 <= b1; b4++) {
/* 135 */               int i1 = paramaab.a(paramInt1 + b, paramInt2 + b3, paramInt3 + b4);
/* 136 */               if (i1 == apa.N.cz)
/* 137 */               { this.c[(b + m) * k + (b3 + m) * b2 + b4 + m] = 0; }
/* 138 */               else if (i1 == apa.O.cz)
/* 139 */               { this.c[(b + m) * k + (b3 + m) * b2 + b4 + m] = -2; }
/*     */               else
/* 141 */               { this.c[(b + m) * k + (b3 + m) * b2 + b4 + m] = -1; } 
/*     */             } 
/*     */           } 
/* 144 */         }  for (b = 1; b <= 4; b++) {
/* 145 */           for (byte b3 = -b1; b3 <= b1; b3++) {
/* 146 */             for (byte b4 = -b1; b4 <= b1; b4++) {
/* 147 */               for (byte b5 = -b1; b5 <= b1; b5++) {
/* 148 */                 if (this.c[(b3 + m) * k + (b4 + m) * b2 + b5 + m] == b - 1) {
/* 149 */                   if (this.c[(b3 + m - 1) * k + (b4 + m) * b2 + b5 + m] == -2) {
/* 150 */                     this.c[(b3 + m - 1) * k + (b4 + m) * b2 + b5 + m] = b;
/*     */                   }
/* 152 */                   if (this.c[(b3 + m + 1) * k + (b4 + m) * b2 + b5 + m] == -2) {
/* 153 */                     this.c[(b3 + m + 1) * k + (b4 + m) * b2 + b5 + m] = b;
/*     */                   }
/* 155 */                   if (this.c[(b3 + m) * k + (b4 + m - 1) * b2 + b5 + m] == -2) {
/* 156 */                     this.c[(b3 + m) * k + (b4 + m - 1) * b2 + b5 + m] = b;
/*     */                   }
/* 158 */                   if (this.c[(b3 + m) * k + (b4 + m + 1) * b2 + b5 + m] == -2) {
/* 159 */                     this.c[(b3 + m) * k + (b4 + m + 1) * b2 + b5 + m] = b;
/*     */                   }
/* 161 */                   if (this.c[(b3 + m) * k + (b4 + m) * b2 + b5 + m - 1] == -2) {
/* 162 */                     this.c[(b3 + m) * k + (b4 + m) * b2 + b5 + m - 1] = b;
/*     */                   }
/* 164 */                   if (this.c[(b3 + m) * k + (b4 + m) * b2 + b5 + m + 1] == -2)
/* 165 */                     this.c[(b3 + m) * k + (b4 + m) * b2 + b5 + m + 1] = b; 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 172 */       int n = this.c[m * k + m * b2 + m];
/* 173 */       if (n >= 0) {
/* 174 */         paramaab.b(paramInt1, paramInt2, paramInt3, i & 0xFFFFFFF7, 4);
/*     */       } else {
/* 176 */         k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 183 */     if (paramaab.F(paramInt1, paramInt2 + 1, paramInt3) && !paramaab.w(paramInt1, paramInt2 - 1, paramInt3) && paramRandom.nextInt(15) == 1) {
/* 184 */       double d1 = (paramInt1 + paramRandom.nextFloat());
/* 185 */       double d2 = paramInt2 - 0.05D;
/* 186 */       double d3 = (paramInt3 + paramRandom.nextFloat());
/*     */       
/* 188 */       paramaab.a("dripWater", d1, d2, d3, 0.0D, 0.0D, 0.0D);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 193 */     c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 194 */     paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 199 */     return (paramRandom.nextInt(20) == 0) ? 1 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 204 */     return apa.C.cz;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 209 */     if (!paramaab.I) {
/* 210 */       int i = 20;
/* 211 */       if ((paramInt4 & 0x3) == 3) {
/* 212 */         i = 40;
/*     */       }
/* 214 */       if (paramInt5 > 0) {
/* 215 */         i -= 2 << paramInt5;
/* 216 */         if (i < 10) {
/* 217 */           i = 10;
/*     */         }
/*     */       } 
/* 220 */       if (paramaab.s.nextInt(i) == 0) {
/* 221 */         int j = a(paramInt4, paramaab.s, paramInt5);
/* 222 */         b(paramaab, paramInt1, paramInt2, paramInt3, new wm(j, 1, a(paramInt4)));
/*     */       } 
/*     */       
/* 225 */       i = 200;
/* 226 */       if (paramInt5 > 0) {
/* 227 */         i -= 10 << paramInt5;
/* 228 */         if (i < 40) {
/* 229 */           i = 40;
/*     */         }
/*     */       } 
/* 232 */       if ((paramInt4 & 0x3) == 0 && paramaab.s.nextInt(i) == 0) {
/* 233 */         b(paramaab, paramInt1, paramInt2, paramInt3, new wm(wk.k, 1, 0));
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 240 */     if (!paramaab.I && paramsq.cd() != null && (paramsq.cd()).c == wk.bf.cp) {
/* 241 */       paramsq.a(kf.C[this.cz], 1);
/*     */ 
/*     */       
/* 244 */       b(paramaab, paramInt1, paramInt2, paramInt3, new wm(apa.O.cz, 1, paramInt4 & 0x3));
/*     */     } else {
/* 246 */       super.a(paramaab, paramsq, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/* 252 */     return paramInt & 0x3;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/* 257 */     return !this.d;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/* 262 */     if ((paramInt2 & 0x3) == 1) {
/* 263 */       return this.cR[this.e][1];
/*     */     }
/* 265 */     if ((paramInt2 & 0x3) == 3) {
/* 266 */       return this.cR[this.e][3];
/*     */     }
/* 268 */     return this.cR[this.e][0];
/*     */   }
/*     */   
/*     */   public void a(boolean paramBoolean) {
/* 272 */     this.d = paramBoolean;
/* 273 */     this.e = paramBoolean ? 0 : 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 278 */     paramList.add(new wm(paramInt, 1, 0));
/* 279 */     paramList.add(new wm(paramInt, 1, 1));
/* 280 */     paramList.add(new wm(paramInt, 1, 2));
/* 281 */     paramList.add(new wm(paramInt, 1, 3));
/*     */   }
/*     */ 
/*     */   
/*     */   protected wm c_(int paramInt) {
/* 286 */     return new wm(this.cz, 1, paramInt & 0x3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 291 */     for (byte b = 0; b < b.length; b++) {
/* 292 */       this.cR[b] = new lx[(b[b]).length];
/*     */       
/* 294 */       for (byte b1 = 0; b1 < (b[b]).length; b1++)
/* 295 */         this.cR[b][b1] = paramly.a(b[b][b1]); 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ana.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */