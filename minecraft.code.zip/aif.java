/*     */ 
/*     */ public class aif
/*     */ {
/*   4 */   public static final aif a = new aid(aih.b);
/*   5 */   public static final aif b = new aif(aih.c);
/*   6 */   public static final aif c = new aif(aih.l);
/*   7 */   public static final aif d = (new aif(aih.o)).g();
/*   8 */   public static final aif e = (new aif(aih.m)).f();
/*   9 */   public static final aif f = (new aif(aih.h)).f();
/*  10 */   public static final aif g = (new aif(aih.h)).f().o();
/*  11 */   public static final aif h = (new aie(aih.n)).n();
/*  12 */   public static final aif i = (new aie(aih.f)).n();
/*  13 */   public static final aif j = (new aif(aih.i)).g().r().n();
/*  14 */   public static final aif k = (new aic(aih.i)).n();
/*  15 */   public static final aif l = (new aic(aih.i)).g().n().i();
/*  16 */   public static final aif m = new aif(aih.e);
/*  17 */   public static final aif n = (new aif(aih.e)).g();
/*  18 */   public static final aif o = (new aid(aih.b)).n();
/*  19 */   public static final aif p = new aif(aih.d);
/*  20 */   public static final aif q = (new aic(aih.b)).n();
/*  21 */   public static final aif r = (new aif(aih.b)).r().p();
/*  22 */   public static final aif s = (new aif(aih.b)).p();
/*  23 */   public static final aif t = (new aif(aih.f)).g().r();
/*  24 */   public static final aif u = (new aif(aih.i)).n();
/*  25 */   public static final aif v = (new aif(aih.g)).r().p();
/*  26 */   public static final aif w = (new aic(aih.j)).i().r().f().n();
/*  27 */   public static final aif x = (new aif(aih.j)).f();
/*  28 */   public static final aif y = (new aif(aih.i)).r().n();
/*  29 */   public static final aif z = new aif(aih.k);
/*  30 */   public static final aif A = (new aif(aih.i)).n();
/*  31 */   public static final aif B = (new aif(aih.i)).n();
/*  32 */   public static final aif C = (new aii(aih.b)).o();
/*  33 */   public static final aif D = (new aif(aih.b)).n();
/*  34 */   public static final aif E = (new aig(aih.e)).f().n();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  40 */   public static final aif F = (new aif(aih.m)).o();
/*     */   
/*     */   private boolean H;
/*     */   
/*     */   private boolean I;
/*     */   
/*     */   private boolean J;
/*     */   
/*     */   public final aih G;
/*     */   private boolean K = true;
/*     */   private int L;
/*     */   private boolean M;
/*     */   
/*     */   public aif(aih paramaih) {
/*  54 */     this.G = paramaih;
/*     */   }
/*     */   
/*     */   public boolean d() {
/*  58 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a() {
/*  66 */     return true;
/*     */   }
/*     */   
/*     */   public boolean b() {
/*  70 */     return true;
/*     */   }
/*     */   
/*     */   public boolean c() {
/*  74 */     return true;
/*     */   }
/*     */   
/*     */   private aif r() {
/*  78 */     this.J = true;
/*  79 */     return this;
/*     */   }
/*     */   
/*     */   protected aif f() {
/*  83 */     this.K = false;
/*  84 */     return this;
/*     */   }
/*     */   
/*     */   protected aif g() {
/*  88 */     this.H = true;
/*  89 */     return this;
/*     */   }
/*     */   
/*     */   public boolean h() {
/*  93 */     return this.H;
/*     */   }
/*     */   
/*     */   public aif i() {
/*  97 */     this.I = true;
/*  98 */     return this;
/*     */   }
/*     */   
/*     */   public boolean j() {
/* 102 */     return this.I;
/*     */   }
/*     */   
/*     */   public boolean k() {
/* 106 */     if (this.J) return false; 
/* 107 */     return c();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean l() {
/* 113 */     return this.K;
/*     */   }
/*     */   
/*     */   public int m() {
/* 117 */     return this.L;
/*     */   }
/*     */   
/*     */   protected aif n() {
/* 121 */     this.L = 1;
/* 122 */     return this;
/*     */   }
/*     */   
/*     */   protected aif o() {
/* 126 */     this.L = 2;
/* 127 */     return this;
/*     */   }
/*     */   
/*     */   protected aif p() {
/* 131 */     this.M = true;
/* 132 */     return this;
/*     */   }
/*     */   
/*     */   public boolean q() {
/* 136 */     return this.M;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aif.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */