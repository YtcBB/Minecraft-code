/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class als
/*     */   extends aly
/*     */   implements amh
/*     */ {
/*     */   public als(int paramInt, boolean paramBoolean) {
/*  22 */     super(paramInt, paramBoolean);
/*  23 */     this.cF = true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  28 */     return wk.bY.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  33 */     return wk.bY.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int i_(int paramInt) {
/*  38 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected aly i() {
/*  43 */     return apa.cq;
/*     */   }
/*     */ 
/*     */   
/*     */   protected aly j() {
/*  48 */     return apa.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  53 */     return 37;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  58 */     boolean bool = (this.a || (paramInt2 & 0x8) != 0) ? true : false;
/*     */     
/*  60 */     if (paramInt1 == 0) {
/*  61 */       if (bool) {
/*  62 */         return apa.aU.m(paramInt1);
/*     */       }
/*  64 */       return apa.aT.m(paramInt1);
/*     */     } 
/*  66 */     if (paramInt1 == 1) {
/*  67 */       if (bool) {
/*  68 */         return apa.cq.cQ;
/*     */       }
/*  70 */       return this.cQ;
/*     */     } 
/*     */     
/*  73 */     return apa.an.m(1);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean c(int paramInt) {
/*  78 */     return (this.a || (paramInt & 0x8) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int d(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  83 */     return a_(paramaak, paramInt1, paramInt2, paramInt3).a();
/*     */   }
/*     */   
/*     */   private int m(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  87 */     if (!d(paramInt4)) {
/*  88 */       return e(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     }
/*  90 */     return Math.max(e(paramaab, paramInt1, paramInt2, paramInt3, paramInt4) - f(paramaab, paramInt1, paramInt2, paramInt3, paramInt4), 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean d(int paramInt) {
/*  95 */     return ((paramInt & 0x4) == 4);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 100 */     int i = e(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/* 101 */     if (i >= 15) return true; 
/* 102 */     if (i == 0) return false;
/*     */     
/* 104 */     int j = f(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/* 105 */     if (j == 0) return true;
/*     */     
/* 107 */     return (i >= j);
/*     */   }
/*     */ 
/*     */   
/*     */   protected int e(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 112 */     int i = super.e(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     
/* 114 */     int j = j(paramInt4);
/* 115 */     int k = paramInt1 + r.a[j];
/* 116 */     int m = paramInt3 + r.b[j];
/* 117 */     int n = paramaab.a(k, paramInt2, m);
/*     */     
/* 119 */     if (n > 0) {
/* 120 */       if (apa.r[n].q_()) {
/* 121 */         i = apa.r[n].b_(paramaab, k, paramInt2, m, r.f[j]);
/* 122 */       } else if (i < 15 && apa.l(n)) {
/* 123 */         k += r.a[j];
/* 124 */         m += r.b[j];
/* 125 */         n = paramaab.a(k, paramInt2, m);
/*     */         
/* 127 */         if (n > 0 && apa.r[n].q_()) {
/* 128 */           i = apa.r[n].b_(paramaab, k, paramInt2, m, r.f[j]);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 133 */     return i;
/*     */   }
/*     */   
/*     */   public aqa a_(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 137 */     return (aqa)paramaak.r(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 142 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 143 */     int j = this.a | (((i & 0x8) != 0) ? 1 : 0);
/* 144 */     boolean bool = !d(i) ? true : false;
/* 145 */     int k = bool ? 4 : 0;
/* 146 */     k |= (j != 0) ? 8 : 0;
/*     */     
/* 148 */     paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "random.click", 0.3F, bool ? 0.55F : 0.5F);
/*     */     
/* 150 */     paramaab.b(paramInt1, paramInt2, paramInt3, k | i & 0x3, 2);
/* 151 */     c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.s);
/* 152 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void f(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 157 */     if (!paramaab.a(paramInt1, paramInt2, paramInt3, this.cz)) {
/* 158 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 159 */       int j = m(paramaab, paramInt1, paramInt2, paramInt3, i);
/* 160 */       int k = a_(paramaab, paramInt1, paramInt2, paramInt3).a();
/*     */       
/* 162 */       if (j != k || c(i) != d(paramaab, paramInt1, paramInt2, paramInt3, i))
/*     */       {
/* 164 */         if (h(paramaab, paramInt1, paramInt2, paramInt3, i)) {
/* 165 */           paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, i_(0), -1);
/*     */         } else {
/*     */           
/* 168 */           paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, i_(0), 0);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private void c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 175 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 176 */     int j = m(paramaab, paramInt1, paramInt2, paramInt3, i);
/* 177 */     int k = a_(paramaab, paramInt1, paramInt2, paramInt3).a();
/* 178 */     a_(paramaab, paramInt1, paramInt2, paramInt3).a(j);
/*     */     
/* 180 */     if (k != j || !d(i)) {
/* 181 */       boolean bool = d(paramaab, paramInt1, paramInt2, paramInt3, i);
/* 182 */       boolean bool1 = (this.a || (i & 0x8) != 0) ? true : false;
/* 183 */       if (bool1 && !bool) {
/* 184 */         paramaab.b(paramInt1, paramInt2, paramInt3, i & 0xFFFFFFF7, 2);
/* 185 */       } else if (!bool1 && bool) {
/* 186 */         paramaab.b(paramInt1, paramInt2, paramInt3, i | 0x8, 2);
/*     */       } 
/* 188 */       h_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 194 */     if (this.a) {
/*     */       
/* 196 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 197 */       paramaab.f(paramInt1, paramInt2, paramInt3, (j()).cz, i | 0x8, 4);
/*     */     } 
/* 199 */     c(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 204 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/* 205 */     paramaab.a(paramInt1, paramInt2, paramInt3, b(paramaab));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 210 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 211 */     paramaab.s(paramInt1, paramInt2, paramInt3);
/*     */     
/* 213 */     h_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 218 */     super.b(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 219 */     aqp aqp = paramaab.r(paramInt1, paramInt2, paramInt3);
/* 220 */     if (aqp != null) {
/* 221 */       return aqp.b(paramInt4, paramInt5);
/*     */     }
/* 223 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 228 */     this.cQ = paramly.a(this.a ? "comparator_lit" : "comparator");
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/* 232 */     return new aqa();
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\als.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */