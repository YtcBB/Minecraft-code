/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aod
/*    */   extends aqp
/*    */ {
/*    */   private wm a;
/*    */   
/*    */   public void a(bs parambs) {
/* 21 */     super.a(parambs);
/*    */     
/* 23 */     if (parambs.b("RecordItem")) {
/* 24 */       a(wm.a(parambs.l("RecordItem")));
/* 25 */     } else if (parambs.e("Record") > 0) {
/* 26 */       a(new wm(parambs.e("Record"), 1, 0));
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void b(bs parambs) {
/* 32 */     super.b(parambs);
/*    */     
/* 34 */     if (a() != null) {
/* 35 */       parambs.a("RecordItem", a().b(new bs()));
/*    */       
/* 37 */       parambs.a("Record", (a()).c);
/*    */     } 
/*    */   }
/*    */   
/*    */   public wm a() {
/* 42 */     return this.a;
/*    */   }
/*    */   
/*    */   public void a(wm paramwm) {
/* 46 */     this.a = paramwm;
/* 47 */     k_();
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aod.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */