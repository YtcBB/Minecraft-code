/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class abh
/*    */   extends aav
/*    */ {
/*    */   public abh(int paramInt) {
/* 13 */     super(paramInt);
/* 14 */     this.I.z = 50;
/* 15 */     this.I.B = 25;
/* 16 */     this.I.A = 4;
/*    */     
/* 18 */     this.J.add(new aaw(qm.class, 2, 1, 1));
/*    */ 
/*    */     
/* 21 */     this.K.add(new aaw(qi.class, 10, 4, 4));
/*    */   }
/*    */ 
/*    */   
/*    */   public adj a(Random paramRandom) {
/* 26 */     if (paramRandom.nextInt(10) == 0) {
/* 27 */       return this.P;
/*    */     }
/* 29 */     if (paramRandom.nextInt(2) == 0) {
/* 30 */       return new adl(3, 0);
/*    */     }
/* 32 */     if (paramRandom.nextInt(3) == 0) {
/* 33 */       return new adt(false, 10 + paramRandom.nextInt(20), 3, 3);
/*    */     }
/* 35 */     return new aef(false, 4 + paramRandom.nextInt(7), 3, 3, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public adj b(Random paramRandom) {
/* 40 */     if (paramRandom.nextInt(4) == 0) {
/* 41 */       return new aee(apa.ab.cz, 2);
/*    */     }
/* 43 */     return new aee(apa.ab.cz, 1);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 48 */     super.a(paramaab, paramRandom, paramInt1, paramInt2);
/*    */     
/* 50 */     aeg aeg = new aeg();
/*    */     
/* 52 */     for (byte b = 0; b < 50; b++) {
/* 53 */       int i = paramInt1 + paramRandom.nextInt(16) + 8;
/* 54 */       byte b1 = 64;
/* 55 */       int j = paramInt2 + paramRandom.nextInt(16) + 8;
/* 56 */       aeg.a(paramaab, paramRandom, i, b1, j);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */