/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aqc
/*     */   extends aqp
/*     */   implements lt
/*     */ {
/*  12 */   private wm[] b = new wm[9];
/*  13 */   private Random c = new Random();
/*     */   protected String a;
/*     */   
/*     */   public int j_() {
/*  17 */     return 9;
/*     */   }
/*     */   
/*     */   public wm a(int paramInt) {
/*  21 */     return this.b[paramInt];
/*     */   }
/*     */   
/*     */   public wm a(int paramInt1, int paramInt2) {
/*  25 */     if (this.b[paramInt1] != null) {
/*  26 */       if ((this.b[paramInt1]).a <= paramInt2) {
/*  27 */         wm wm2 = this.b[paramInt1];
/*  28 */         this.b[paramInt1] = null;
/*  29 */         k_();
/*  30 */         return wm2;
/*     */       } 
/*  32 */       wm wm1 = this.b[paramInt1].a(paramInt2);
/*  33 */       if ((this.b[paramInt1]).a == 0) this.b[paramInt1] = null; 
/*  34 */       k_();
/*  35 */       return wm1;
/*     */     } 
/*     */     
/*  38 */     return null;
/*     */   }
/*     */   
/*     */   public wm b(int paramInt) {
/*  42 */     if (this.b[paramInt] != null) {
/*  43 */       wm wm1 = this.b[paramInt];
/*  44 */       this.b[paramInt] = null;
/*  45 */       return wm1;
/*     */     } 
/*  47 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int j() {
/*  67 */     byte b = -1;
/*  68 */     byte b1 = 1;
/*     */     
/*  70 */     for (byte b2 = 0; b2 < this.b.length; b2++) {
/*  71 */       if (this.b[b2] != null && this.c.nextInt(b1++) == 0) {
/*  72 */         b = b2;
/*     */       }
/*     */     } 
/*     */     
/*  76 */     return b;
/*     */   }
/*     */   
/*     */   public void a(int paramInt, wm paramwm) {
/*  80 */     this.b[paramInt] = paramwm;
/*  81 */     if (paramwm != null && paramwm.a > d()) paramwm.a = d(); 
/*  82 */     k_();
/*     */   }
/*     */   
/*     */   public int a(wm paramwm) {
/*  86 */     for (byte b = 0; b < this.b.length; b++) {
/*  87 */       if (this.b[b] == null || (this.b[b]).c == 0) {
/*  88 */         a(b, paramwm);
/*  89 */         return b;
/*     */       } 
/*     */     } 
/*     */     
/*  93 */     return -1;
/*     */   }
/*     */   
/*     */   public String b() {
/*  97 */     return c() ? this.a : "container.dispenser";
/*     */   }
/*     */   
/*     */   public void a(String paramString) {
/* 101 */     this.a = paramString;
/*     */   }
/*     */   
/*     */   public boolean c() {
/* 105 */     return (this.a != null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(bs parambs) {
/* 111 */     super.a(parambs);
/* 112 */     ca ca = parambs.m("Items");
/* 113 */     this.b = new wm[j_()];
/* 114 */     for (byte b = 0; b < ca.c(); b++) {
/* 115 */       bs bs1 = (bs)ca.b(b);
/* 116 */       int i = bs1.c("Slot") & 0xFF;
/* 117 */       if (i >= 0 && i < this.b.length) this.b[i] = wm.a(bs1); 
/*     */     } 
/* 119 */     if (parambs.b("CustomName")) this.a = parambs.i("CustomName");
/*     */   
/*     */   }
/*     */   
/*     */   public void b(bs parambs) {
/* 124 */     super.b(parambs);
/* 125 */     ca ca = new ca();
/*     */     
/* 127 */     for (byte b = 0; b < this.b.length; b++) {
/* 128 */       if (this.b[b] != null) {
/* 129 */         bs bs1 = new bs();
/* 130 */         bs1.a("Slot", (byte)b);
/* 131 */         this.b[b].b(bs1);
/* 132 */         ca.a(bs1);
/*     */       } 
/*     */     } 
/* 135 */     parambs.a("Items", ca);
/* 136 */     if (c()) parambs.a("CustomName", this.a); 
/*     */   }
/*     */   
/*     */   public int d() {
/* 140 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean a(sq paramsq) {
/* 144 */     if (this.k.r(this.l, this.m, this.n) != this) return false; 
/* 145 */     if (paramsq.e(this.l + 0.5D, this.m + 0.5D, this.n + 0.5D) > 64.0D) return false; 
/* 146 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void f() {}
/*     */ 
/*     */   
/*     */   public void g() {}
/*     */   
/*     */   public boolean b(int paramInt, wm paramwm) {
/* 156 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */