/*    */ 
/*    */ 
/*    */ public class aat
/*    */ {
/*    */   public final int a;
/*    */   public final int b;
/*    */   public final int c;
/*    */   
/*    */   public aat(int paramInt1, int paramInt2, int paramInt3) {
/* 10 */     this.a = paramInt1;
/* 11 */     this.b = paramInt2;
/* 12 */     this.c = paramInt3;
/*    */   }
/*    */   
/*    */   public aat(arc paramarc) {
/* 16 */     this(kx.c(paramarc.c), kx.c(paramarc.d), kx.c(paramarc.e));
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 20 */     if (paramObject instanceof aat) {
/*    */       
/* 22 */       aat aat1 = (aat)paramObject;
/* 23 */       return (aat1.a == this.a && aat1.b == this.b && aat1.c == this.c);
/*    */     } 
/*    */     
/* 26 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 30 */     return this.a * 8976890 + this.b * 981131 + this.c;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aat.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */