/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class acu
/*     */   implements abt
/*     */ {
/*     */   private Random i;
/*     */   private ahw j;
/*     */   private ahw k;
/*     */   private ahw l;
/*     */   private ahw m;
/*     */   private ahw n;
/*     */   public ahw a;
/*     */   public ahw b;
/*     */   private aab o;
/*     */   private double[] p;
/*     */   public aes c;
/*     */   private double[] q;
/*     */   private double[] r;
/*     */   private double[] s;
/*     */   private acw t;
/*     */   double[] d;
/*     */   double[] e;
/*     */   double[] f;
/*     */   double[] g;
/*     */   double[] h;
/*     */   
/*     */   public acu(aab paramaab, long paramLong) {
/*  52 */     this.c = new aes();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 120 */     this.q = new double[256];
/* 121 */     this.r = new double[256];
/* 122 */     this.s = new double[256];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     this.t = new acx(); this.o = paramaab; this.i = new Random(paramLong); this.j = new ahw(this.i, 16); this.k = new ahw(this.i, 16); this.l = new ahw(this.i, 8); this.m = new ahw(this.i, 4); this.n = new ahw(this.i, 4); this.a = new ahw(this.i, 10); this.b = new ahw(this.i, 16);
/*     */   } public void a(int paramInt1, int paramInt2, byte[] paramArrayOfbyte) { byte b1 = 4; byte b2 = 32; int i = b1 + 1; byte b3 = 17; int j = b1 + 1; this.p = a(this.p, paramInt1 * b1, 0, paramInt2 * b1, i, b3, j); for (byte b4 = 0; b4 < b1; b4++) { for (byte b = 0; b < b1; b++) { for (byte b5 = 0; b5 < 16; b5++) { double d1 = 0.125D; double d2 = this.p[((b4 + 0) * j + b + 0) * b3 + b5 + 0]; double d3 = this.p[((b4 + 0) * j + b + 1) * b3 + b5 + 0]; double d4 = this.p[((b4 + 1) * j + b + 0) * b3 + b5 + 0]; double d5 = this.p[((b4 + 1) * j + b + 1) * b3 + b5 + 0]; double d6 = (this.p[((b4 + 0) * j + b + 0) * b3 + b5 + 1] - d2) * d1; double d7 = (this.p[((b4 + 0) * j + b + 1) * b3 + b5 + 1] - d3) * d1; double d8 = (this.p[((b4 + 1) * j + b + 0) * b3 + b5 + 1] - d4) * d1; double d9 = (this.p[((b4 + 1) * j + b + 1) * b3 + b5 + 1] - d5) * d1; for (byte b6 = 0; b6 < 8; b6++) { double d10 = 0.25D; double d11 = d2; double d12 = d3; double d13 = (d4 - d2) * d10; double d14 = (d5 - d3) * d10; for (byte b7 = 0; b7 < 4; b7++) { int k = b7 + b4 * 4 << 11 | 0 + b * 4 << 7 | b5 * 8 + b6; char c = ''; double d15 = 0.25D; double d16 = d11; double d17 = (d12 - d11) * d15; for (byte b8 = 0; b8 < 4; b8++) { int m = 0; if (b5 * 8 + b6 < b2)
/*     */                   m = apa.H.cz;  if (d16 > 0.0D)
/* 186 */                   m = apa.bf.cz;  paramArrayOfbyte[k] = (byte)m; k += c; d16 += d17; }  d11 += d13; d12 += d14; }  d2 += d6; d3 += d7; d4 += d8; d5 += d9; }  }  }  }  } public abw c(int paramInt1, int paramInt2) { return d(paramInt1, paramInt2); }
/*     */   public void b(int paramInt1, int paramInt2, byte[] paramArrayOfbyte) { byte b1 = 64; double d = 0.03125D; this.q = this.m.a(this.q, paramInt1 * 16, paramInt2 * 16, 0, 16, 16, 1, d, d, 1.0D); this.r = this.m.a(this.r, paramInt1 * 16, 109, paramInt2 * 16, 16, 1, 16, d, 1.0D, d); this.s = this.n.a(this.s, paramInt1 * 16, paramInt2 * 16, 0, 16, 16, 1, d * 2.0D, d * 2.0D, d * 2.0D); for (byte b2 = 0; b2 < 16; b2++) { for (byte b = 0; b < 16; b++) { boolean bool1 = (this.q[b2 + b * 16] + this.i.nextDouble() * 0.2D > 0.0D) ? true : false; boolean bool2 = (this.r[b2 + b * 16] + this.i.nextDouble() * 0.2D > 0.0D) ? true : false; int i = (int)(this.s[b2 + b * 16] / 3.0D + 3.0D + this.i.nextDouble() * 0.25D); int j = -1; byte b3 = (byte)apa.bf.cz; byte b4 = (byte)apa.bf.cz; for (byte b5 = 127; b5 >= 0; b5--) { int k = (b * 16 + b2) * 128 + b5; if (b5 >= 127 - this.i.nextInt(5) || b5 <= 0 + this.i.nextInt(5)) { paramArrayOfbyte[k] = (byte)apa.D.cz; } else { byte b6 = paramArrayOfbyte[k]; if (b6 == 0) { j = -1; } else if (b6 == apa.bf.cz) { if (j == -1) { if (i <= 0) { b3 = 0; b4 = (byte)apa.bf.cz; } else if (b5 >= b1 - 4 && b5 <= b1 + 1) { b3 = (byte)apa.bf.cz; b4 = (byte)apa.bf.cz; if (bool2) b3 = (byte)apa.J.cz;  if (bool2) b4 = (byte)apa.bf.cz;  if (bool1)
/*     */                     b3 = (byte)apa.bg.cz;  if (bool1)
/*     */                     b4 = (byte)apa.bg.cz;  }  if (b5 < b1 && b3 == 0)
/* 190 */                   b3 = (byte)apa.H.cz;  j = i; if (b5 >= b1 - 1) { paramArrayOfbyte[k] = b3; } else { paramArrayOfbyte[k] = b4; }  } else if (j > 0) { j--; paramArrayOfbyte[k] = b4; }  }  }  }  }  }  } public abw d(int paramInt1, int paramInt2) { this.i.setSeed(paramInt1 * 341873128712L + paramInt2 * 132897987541L);
/*     */     
/* 192 */     byte[] arrayOfByte1 = new byte[32768];
/*     */     
/* 194 */     a(paramInt1, paramInt2, arrayOfByte1);
/* 195 */     b(paramInt1, paramInt2, arrayOfByte1);
/*     */     
/* 197 */     this.t.a(this, this.o, paramInt1, paramInt2, arrayOfByte1);
/* 198 */     this.c.a(this, this.o, paramInt1, paramInt2, arrayOfByte1);
/*     */     
/* 200 */     abw abw = new abw(this.o, arrayOfByte1, paramInt1, paramInt2);
/* 201 */     aav[] arrayOfAav = this.o.u().b((aav[])null, paramInt1 * 16, paramInt2 * 16, 16, 16);
/* 202 */     byte[] arrayOfByte2 = abw.m();
/*     */     
/* 204 */     for (byte b = 0; b < arrayOfByte2.length; b++) {
/* 205 */       arrayOfByte2[b] = (byte)(arrayOfAav[b]).N;
/*     */     }
/*     */     
/* 208 */     abw.n();
/*     */     
/* 210 */     return abw; }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private double[] a(double[] paramArrayOfdouble, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 216 */     if (paramArrayOfdouble == null) {
/* 217 */       paramArrayOfdouble = new double[paramInt4 * paramInt5 * paramInt6];
/*     */     }
/*     */     
/* 220 */     double d1 = 684.412D;
/* 221 */     double d2 = 2053.236D;
/*     */     
/* 223 */     this.g = this.a.a(this.g, paramInt1, paramInt2, paramInt3, paramInt4, 1, paramInt6, 1.0D, 0.0D, 1.0D);
/* 224 */     this.h = this.b.a(this.h, paramInt1, paramInt2, paramInt3, paramInt4, 1, paramInt6, 100.0D, 0.0D, 100.0D);
/*     */     
/* 226 */     this.d = this.l.a(this.d, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1 / 80.0D, d2 / 60.0D, d1 / 80.0D);
/* 227 */     this.e = this.j.a(this.e, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1, d2, d1);
/* 228 */     this.f = this.k.a(this.f, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1, d2, d1);
/*     */     
/* 230 */     byte b1 = 0;
/* 231 */     byte b2 = 0;
/* 232 */     double[] arrayOfDouble = new double[paramInt5]; byte b3;
/* 233 */     for (b3 = 0; b3 < paramInt5; b3++) {
/* 234 */       arrayOfDouble[b3] = Math.cos(b3 * Math.PI * 6.0D / paramInt5) * 2.0D;
/*     */       
/* 236 */       double d = b3;
/* 237 */       if (b3 > paramInt5 / 2) {
/* 238 */         d = (paramInt5 - 1 - b3);
/*     */       }
/* 240 */       if (d < 4.0D) {
/* 241 */         d = 4.0D - d;
/* 242 */         arrayOfDouble[b3] = arrayOfDouble[b3] - d * d * d * 10.0D;
/*     */       } 
/*     */     } 
/*     */     
/* 246 */     for (b3 = 0; b3 < paramInt4; b3++) {
/*     */       
/* 248 */       for (byte b = 0; b < paramInt6; b++) {
/*     */         
/* 250 */         double d3 = (this.g[b2] + 256.0D) / 512.0D;
/* 251 */         if (d3 > 1.0D) d3 = 1.0D;
/*     */         
/* 253 */         double d4 = 0.0D;
/*     */         
/* 255 */         double d5 = this.h[b2] / 8000.0D;
/* 256 */         if (d5 < 0.0D) d5 = -d5; 
/* 257 */         d5 = d5 * 3.0D - 3.0D;
/*     */         
/* 259 */         if (d5 < 0.0D) {
/* 260 */           d5 /= 2.0D;
/* 261 */           if (d5 < -1.0D) d5 = -1.0D; 
/* 262 */           d5 /= 1.4D;
/* 263 */           d5 /= 2.0D;
/* 264 */           d3 = 0.0D;
/*     */         } else {
/* 266 */           if (d5 > 1.0D) d5 = 1.0D; 
/* 267 */           d5 /= 6.0D;
/*     */         } 
/* 269 */         d3 += 0.5D;
/* 270 */         d5 = d5 * paramInt5 / 16.0D;
/* 271 */         b2++;
/*     */         
/* 273 */         for (byte b4 = 0; b4 < paramInt5; b4++) {
/* 274 */           double d6 = 0.0D;
/*     */           
/* 276 */           double d7 = arrayOfDouble[b4];
/*     */           
/* 278 */           double d8 = this.e[b1] / 512.0D;
/* 279 */           double d9 = this.f[b1] / 512.0D;
/*     */           
/* 281 */           double d10 = (this.d[b1] / 10.0D + 1.0D) / 2.0D;
/* 282 */           if (d10 < 0.0D) { d6 = d8; }
/* 283 */           else if (d10 > 1.0D) { d6 = d9; }
/* 284 */           else { d6 = d8 + (d9 - d8) * d10; }
/* 285 */            d6 -= d7;
/*     */           
/* 287 */           if (b4 > paramInt5 - 4) {
/* 288 */             double d = ((b4 - paramInt5 - 4) / 3.0F);
/* 289 */             d6 = d6 * (1.0D - d) + -10.0D * d;
/*     */           } 
/*     */           
/* 292 */           if (b4 < d4) {
/* 293 */             double d = (d4 - b4) / 4.0D;
/* 294 */             if (d < 0.0D) d = 0.0D; 
/* 295 */             if (d > 1.0D) d = 1.0D; 
/* 296 */             d6 = d6 * (1.0D - d) + -10.0D * d;
/*     */           } 
/*     */           
/* 299 */           paramArrayOfdouble[b1] = d6;
/* 300 */           b1++;
/*     */         } 
/*     */       } 
/*     */     } 
/* 304 */     return paramArrayOfdouble;
/*     */   }
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2) {
/* 308 */     return true;
/*     */   }
/*     */   
/*     */   public void a(abt paramabt, int paramInt1, int paramInt2) {
/* 312 */     amt.c = true;
/* 313 */     int i = paramInt1 * 16;
/* 314 */     int j = paramInt2 * 16;
/*     */     
/* 316 */     this.c.a(this.o, this.i, paramInt1, paramInt2);
/*     */     int k;
/* 318 */     for (k = 0; k < 8; k++) {
/* 319 */       int n = i + this.i.nextInt(16) + 8;
/* 320 */       int i1 = this.i.nextInt(120) + 4;
/* 321 */       int i2 = j + this.i.nextInt(16) + 8;
/* 322 */       (new ado(apa.G.cz, false)).a(this.o, this.i, n, i1, i2);
/*     */     } 
/*     */     
/* 325 */     k = this.i.nextInt(this.i.nextInt(10) + 1) + 1;
/*     */     int m;
/* 327 */     for (m = 0; m < k; m++) {
/* 328 */       int n = i + this.i.nextInt(16) + 8;
/* 329 */       int i1 = this.i.nextInt(120) + 4;
/* 330 */       int i2 = j + this.i.nextInt(16) + 8;
/* 331 */       (new adm()).a(this.o, this.i, n, i1, i2);
/*     */     } 
/*     */     
/* 334 */     k = this.i.nextInt(this.i.nextInt(10) + 1);
/* 335 */     for (m = 0; m < k; m++) {
/* 336 */       int n = i + this.i.nextInt(16) + 8;
/* 337 */       int i1 = this.i.nextInt(120) + 4;
/* 338 */       int i2 = j + this.i.nextInt(16) + 8;
/* 339 */       (new ads()).a(this.o, this.i, n, i1, i2);
/*     */     } 
/*     */     
/* 342 */     for (m = 0; m < 10; m++) {
/* 343 */       int n = i + this.i.nextInt(16) + 8;
/* 344 */       int i1 = this.i.nextInt(128);
/* 345 */       int i2 = j + this.i.nextInt(16) + 8;
/* 346 */       (new adn()).a(this.o, this.i, n, i1, i2);
/*     */     } 
/*     */     
/* 349 */     if (this.i.nextInt(1) == 0) {
/* 350 */       m = i + this.i.nextInt(16) + 8;
/* 351 */       int n = this.i.nextInt(128);
/* 352 */       int i1 = j + this.i.nextInt(16) + 8;
/* 353 */       (new adk(apa.aj.cz)).a(this.o, this.i, m, n, i1);
/*     */     } 
/*     */     
/* 356 */     if (this.i.nextInt(1) == 0) {
/* 357 */       m = i + this.i.nextInt(16) + 8;
/* 358 */       int n = this.i.nextInt(128);
/* 359 */       int i1 = j + this.i.nextInt(16) + 8;
/* 360 */       (new adk(apa.ak.cz)).a(this.o, this.i, m, n, i1);
/*     */     } 
/*     */     
/* 363 */     adv adv = new adv(apa.ct.cz, 13, apa.bf.cz); byte b;
/* 364 */     for (b = 0; b < 16; b++) {
/* 365 */       int n = i + this.i.nextInt(16);
/* 366 */       int i1 = this.i.nextInt(108) + 10;
/* 367 */       int i2 = j + this.i.nextInt(16);
/* 368 */       adv.a(this.o, this.i, n, i1, i2);
/*     */     } 
/*     */     
/* 371 */     for (b = 0; b < 16; b++) {
/* 372 */       int n = i + this.i.nextInt(16);
/* 373 */       int i1 = this.i.nextInt(108) + 10;
/* 374 */       int i2 = j + this.i.nextInt(16);
/* 375 */       (new ado(apa.G.cz, true)).a(this.o, this.i, n, i1, i2);
/*     */     } 
/*     */ 
/*     */     
/* 379 */     amt.c = false;
/*     */   }
/*     */   
/*     */   public boolean a(boolean paramBoolean, lc paramlc) {
/* 383 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void b() {}
/*     */ 
/*     */   
/*     */   public boolean c() {
/* 391 */     return false;
/*     */   }
/*     */   
/*     */   public boolean d() {
/* 395 */     return true;
/*     */   }
/*     */   
/*     */   public String e() {
/* 399 */     return "HellRandomLevelSource";
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public List a(nn paramnn, int paramInt1, int paramInt2, int paramInt3) {
/* 405 */     if (paramnn == nn.a && this.c.a(paramInt1, paramInt2, paramInt3)) {
/* 406 */       return this.c.a();
/*     */     }
/*     */     
/* 409 */     aav aav = this.o.a(paramInt1, paramInt3);
/* 410 */     if (aav == null) {
/* 411 */       return null;
/*     */     }
/* 413 */     return aav.a(paramnn);
/*     */   }
/*     */   
/*     */   public aat a(aab paramaab, String paramString, int paramInt1, int paramInt2, int paramInt3) {
/* 417 */     return null;
/*     */   }
/*     */   
/*     */   public int f() {
/* 421 */     return 0;
/*     */   }
/*     */   
/*     */   public void e(int paramInt1, int paramInt2) {
/* 425 */     this.c.a(this, this.o, paramInt1, paramInt2, null);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */