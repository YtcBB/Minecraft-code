/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class ahp
/*     */   extends agw
/*     */ {
/*     */   private int a;
/*     */   protected ahm k;
/*     */   
/*     */   protected ahp(ahm paramahm, int paramInt) {
/* 210 */     super(paramInt);
/* 211 */     this.k = paramahm;
/*     */   }
/*     */   
/*     */   protected agw a(ahm paramahm, List paramList, Random paramRandom, int paramInt1, int paramInt2) {
/* 215 */     switch (this.f) {
/*     */       case 2:
/* 217 */         return ahb.a(paramahm, paramList, paramRandom, this.e.a - 1, this.e.b + paramInt1, this.e.c + paramInt2, 1, c());
/*     */       case 0:
/* 219 */         return ahb.a(paramahm, paramList, paramRandom, this.e.a - 1, this.e.b + paramInt1, this.e.c + paramInt2, 1, c());
/*     */       case 1:
/* 221 */         return ahb.a(paramahm, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.c - 1, 2, c());
/*     */       case 3:
/* 223 */         return ahb.a(paramahm, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.c - 1, 2, c());
/*     */     } 
/* 225 */     return null;
/*     */   }
/*     */   
/*     */   protected agw b(ahm paramahm, List paramList, Random paramRandom, int paramInt1, int paramInt2) {
/* 229 */     switch (this.f) {
/*     */       case 2:
/* 231 */         return ahb.a(paramahm, paramList, paramRandom, this.e.d + 1, this.e.b + paramInt1, this.e.c + paramInt2, 3, c());
/*     */       case 0:
/* 233 */         return ahb.a(paramahm, paramList, paramRandom, this.e.d + 1, this.e.b + paramInt1, this.e.c + paramInt2, 3, c());
/*     */       case 1:
/* 235 */         return ahb.a(paramahm, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.f + 1, 0, c());
/*     */       case 3:
/* 237 */         return ahb.a(paramahm, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.f + 1, 0, c());
/*     */     } 
/* 239 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int b(aab paramaab, aek paramaek) {
/* 244 */     int i = 0;
/* 245 */     byte b = 0;
/* 246 */     for (int j = this.e.c; j <= this.e.f; j++) {
/* 247 */       for (int k = this.e.a; k <= this.e.d; k++) {
/* 248 */         if (paramaek.b(k, 64, j)) {
/* 249 */           i += Math.max(paramaab.i(k, j), paramaab.t.i());
/* 250 */           b++;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 255 */     if (b == 0) {
/* 256 */       return -1;
/*     */     }
/* 258 */     return i / b;
/*     */   }
/*     */   
/*     */   protected static boolean a(aek paramaek) {
/* 262 */     return (paramaek != null && paramaek.b > 10);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 277 */     if (this.a >= paramInt4) {
/*     */       return;
/*     */     }
/*     */     
/* 281 */     for (int i = this.a; i < paramInt4; ) {
/* 282 */       int j = a(paramInt1 + i, paramInt3);
/* 283 */       int k = a(paramInt2);
/* 284 */       int m = b(paramInt1 + i, paramInt3);
/*     */       
/* 286 */       if (paramaek.b(j, k, m)) {
/* 287 */         this.a++;
/*     */         
/* 289 */         sm sm = new sm(paramaab, b(i));
/* 290 */         sm.b(j + 0.5D, k, m + 0.5D, 0.0F, 0.0F);
/* 291 */         paramaab.d(sm);
/*     */         i++;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected int b(int paramInt) {
/* 300 */     return 0;
/*     */   }
/*     */   
/*     */   protected int d(int paramInt1, int paramInt2) {
/* 304 */     if (this.k.b) {
/* 305 */       if (paramInt1 == apa.N.cz)
/* 306 */         return apa.U.cz; 
/* 307 */       if (paramInt1 == apa.A.cz)
/* 308 */         return apa.U.cz; 
/* 309 */       if (paramInt1 == apa.B.cz)
/* 310 */         return apa.U.cz; 
/* 311 */       if (paramInt1 == apa.ax.cz)
/* 312 */         return apa.bU.cz; 
/* 313 */       if (paramInt1 == apa.aL.cz)
/* 314 */         return apa.bU.cz; 
/* 315 */       if (paramInt1 == apa.J.cz) {
/* 316 */         return apa.U.cz;
/*     */       }
/*     */     } 
/* 319 */     return paramInt1;
/*     */   }
/*     */   
/*     */   protected int e(int paramInt1, int paramInt2) {
/* 323 */     if (this.k.b) {
/* 324 */       if (paramInt1 == apa.N.cz)
/* 325 */         return 0; 
/* 326 */       if (paramInt1 == apa.A.cz)
/* 327 */         return 0; 
/* 328 */       if (paramInt1 == apa.B.cz) {
/* 329 */         return 2;
/*     */       }
/*     */     } 
/* 332 */     return paramInt2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, aek paramaek) {
/* 337 */     int i = d(paramInt1, paramInt2);
/* 338 */     int j = e(paramInt1, paramInt2);
/* 339 */     super.a(paramaab, i, j, paramInt3, paramInt4, paramInt5, paramaek);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
/* 344 */     int i = d(paramInt7, 0);
/* 345 */     int j = e(paramInt7, 0);
/* 346 */     int k = d(paramInt8, 0);
/* 347 */     int m = e(paramInt8, 0);
/* 348 */     a(paramaab, paramaek, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, i, j, k, m, paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   protected void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, aek paramaek) {
/* 353 */     int i = d(paramInt1, paramInt2);
/* 354 */     int j = e(paramInt1, paramInt2);
/* 355 */     super.b(paramaab, i, j, paramInt3, paramInt4, paramInt5, paramaek);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ahp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */