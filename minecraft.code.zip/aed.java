/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aed
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 13 */     int i = paramRandom.nextInt(4) + 5;
/* 14 */     while (paramaab.g(paramInt1, paramInt2 - 1, paramInt3) == aif.h) {
/* 15 */       paramInt2--;
/*    */     }
/* 17 */     boolean bool = true;
/* 18 */     if (paramInt2 < 1 || paramInt2 + i + 1 > 128) return false; 
/*    */     int j;
/* 20 */     for (j = paramInt2; j <= paramInt2 + 1 + i; j++) {
/* 21 */       byte b = 1;
/* 22 */       if (j == paramInt2) b = 0; 
/* 23 */       if (j >= paramInt2 + 1 + i - 2) b = 3; 
/* 24 */       for (int m = paramInt1 - b; m <= paramInt1 + b && bool; m++) {
/* 25 */         for (int n = paramInt3 - b; n <= paramInt3 + b && bool; n++) {
/* 26 */           if (j >= 0 && j < 128) {
/* 27 */             int i1 = paramaab.a(m, j, n);
/* 28 */             if (i1 != 0 && i1 != apa.O.cz) {
/* 29 */               if (i1 == apa.F.cz || i1 == apa.E.cz) {
/* 30 */                 if (j > paramInt2) bool = false; 
/*    */               } else {
/* 32 */                 bool = false;
/*    */               } 
/*    */             }
/*    */           } else {
/* 36 */             bool = false;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 42 */     if (!bool) return false;
/*    */     
/* 44 */     j = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/* 45 */     if ((j != apa.y.cz && j != apa.z.cz) || paramInt2 >= 128 - i - 1) {
/* 46 */       return false;
/*    */     }
/* 48 */     a(paramaab, paramInt1, paramInt2 - 1, paramInt3, apa.z.cz);
/*    */     int k;
/* 50 */     for (k = paramInt2 - 3 + i; k <= paramInt2 + i; k++) {
/* 51 */       int m = k - paramInt2 + i;
/* 52 */       int n = 2 - m / 2;
/* 53 */       for (int i1 = paramInt1 - n; i1 <= paramInt1 + n; i1++) {
/* 54 */         int i2 = i1 - paramInt1;
/* 55 */         for (int i3 = paramInt3 - n; i3 <= paramInt3 + n; i3++) {
/* 56 */           int i4 = i3 - paramInt3;
/* 57 */           if ((Math.abs(i2) != n || Math.abs(i4) != n || (paramRandom.nextInt(2) != 0 && m != 0)) && 
/* 58 */             !apa.s[paramaab.a(i1, k, i3)]) a(paramaab, i1, k, i3, apa.O.cz);
/*    */         
/*    */         } 
/*    */       } 
/*    */     } 
/* 63 */     for (k = 0; k < i; k++) {
/* 64 */       int m = paramaab.a(paramInt1, paramInt2 + k, paramInt3);
/* 65 */       if (m == 0 || m == apa.O.cz || m == apa.E.cz || m == apa.F.cz) {
/* 66 */         a(paramaab, paramInt1, paramInt2 + k, paramInt3, apa.N.cz);
/*    */       }
/*    */     } 
/* 69 */     for (k = paramInt2 - 3 + i; k <= paramInt2 + i; k++) {
/* 70 */       int m = k - paramInt2 + i;
/* 71 */       int n = 2 - m / 2;
/* 72 */       for (int i1 = paramInt1 - n; i1 <= paramInt1 + n; i1++) {
/* 73 */         for (int i2 = paramInt3 - n; i2 <= paramInt3 + n; i2++) {
/* 74 */           if (paramaab.a(i1, k, i2) == apa.O.cz) {
/* 75 */             if (paramRandom.nextInt(4) == 0 && paramaab.a(i1 - 1, k, i2) == 0) {
/* 76 */               b(paramaab, i1 - 1, k, i2, 8);
/*    */             }
/* 78 */             if (paramRandom.nextInt(4) == 0 && paramaab.a(i1 + 1, k, i2) == 0) {
/* 79 */               b(paramaab, i1 + 1, k, i2, 2);
/*    */             }
/* 81 */             if (paramRandom.nextInt(4) == 0 && paramaab.a(i1, k, i2 - 1) == 0) {
/* 82 */               b(paramaab, i1, k, i2 - 1, 1);
/*    */             }
/* 84 */             if (paramRandom.nextInt(4) == 0 && paramaab.a(i1, k, i2 + 1) == 0) {
/* 85 */               b(paramaab, i1, k, i2 + 1, 4);
/*    */             }
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 91 */     return true;
/*    */   }
/*    */   
/*    */   private void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 95 */     a(paramaab, paramInt1, paramInt2, paramInt3, apa.by.cz, paramInt4);
/* 96 */     byte b = 4;
/* 97 */     while (paramaab.a(paramInt1, --paramInt2, paramInt3) == 0 && b > 0) {
/* 98 */       a(paramaab, paramInt1, paramInt2, paramInt3, apa.by.cz, paramInt4);
/* 99 */       b--;
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aed.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */