/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ant
/*     */   extends ams
/*     */ {
/*     */   public ant(int paramInt) {
/*  13 */     super(paramInt, "portal", aif.C, false);
/*  14 */     b(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  19 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*     */     
/*  21 */     if (paramaab.t.d() && paramRandom.nextInt(2000) < paramaab.r) {
/*     */       
/*  23 */       int i = paramInt2;
/*  24 */       while (!paramaab.w(paramInt1, i, paramInt3) && i > 0) {
/*  25 */         i--;
/*     */       }
/*  27 */       if (i > 0 && !paramaab.u(paramInt1, i + 1, paramInt3)) {
/*     */         
/*  29 */         mp mp = ws.a(paramaab, 57, paramInt1 + 0.5D, i + 1.1D, paramInt3 + 0.5D);
/*  30 */         if (mp != null) {
/*  31 */           mp.ao = mp.aa();
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  39 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  44 */     if (paramaak.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz || paramaak.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz) {
/*  45 */       float f1 = 0.5F;
/*  46 */       float f2 = 0.125F;
/*  47 */       a(0.5F - f1, 0.0F, 0.5F - f2, 0.5F + f1, 1.0F, 0.5F + f2);
/*     */     } else {
/*  49 */       float f1 = 0.125F;
/*  50 */       float f2 = 0.5F;
/*  51 */       a(0.5F - f1, 0.0F, 0.5F - f2, 0.5F + f1, 1.0F, 0.5F + f2);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  57 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  62 */     return false;
/*     */   }
/*     */   
/*     */   public boolean n_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  66 */     byte b1 = 0;
/*  67 */     byte b2 = 0;
/*  68 */     if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == apa.at.cz || paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == apa.at.cz) b1 = 1; 
/*  69 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == apa.at.cz || paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == apa.at.cz) b2 = 1;
/*     */     
/*  71 */     if (b1 == b2) return false;
/*     */     
/*  73 */     if (paramaab.a(paramInt1 - b1, paramInt2, paramInt3 - b2) == 0) {
/*  74 */       paramInt1 -= b1;
/*  75 */       paramInt3 -= b2;
/*     */     } 
/*     */     byte b;
/*  78 */     for (b = -1; b <= 2; b++) {
/*  79 */       for (byte b3 = -1; b3 <= 3; b3++) {
/*  80 */         boolean bool = (b == -1 || b == 2 || b3 == -1 || b3 == 3) ? true : false;
/*  81 */         if ((b != -1 && b != 2) || (b3 != -1 && b3 != 3)) {
/*     */           
/*  83 */           int i = paramaab.a(paramInt1 + b1 * b, paramInt2 + b3, paramInt3 + b2 * b);
/*     */           
/*  85 */           if (bool)
/*  86 */           { if (i != apa.at.cz) return false;
/*     */              }
/*  88 */           else if (i != 0 && i != apa.av.cz) { return false; }
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*  93 */     for (b = 0; b < 2; b++) {
/*  94 */       for (byte b3 = 0; b3 < 3; b3++) {
/*  95 */         paramaab.f(paramInt1 + b1 * b, paramInt2 + b3, paramInt3 + b2 * b, apa.bi.cz, 0, 2);
/*     */       }
/*     */     } 
/*     */     
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 104 */     byte b1 = 0;
/* 105 */     byte b2 = 1;
/* 106 */     if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz || paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz) {
/* 107 */       b1 = 1;
/* 108 */       b2 = 0;
/*     */     } 
/*     */     
/* 111 */     int i = paramInt2;
/* 112 */     while (paramaab.a(paramInt1, i - 1, paramInt3) == this.cz) {
/* 113 */       i--;
/*     */     }
/* 115 */     if (paramaab.a(paramInt1, i - 1, paramInt3) != apa.at.cz) {
/* 116 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       
/*     */       return;
/*     */     } 
/* 120 */     byte b3 = 1;
/* 121 */     while (b3 < 4 && paramaab.a(paramInt1, i + b3, paramInt3) == this.cz) {
/* 122 */       b3++;
/*     */     }
/* 124 */     if (b3 != 3 || paramaab.a(paramInt1, i + b3, paramInt3) != apa.at.cz) {
/* 125 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       
/*     */       return;
/*     */     } 
/* 129 */     boolean bool1 = (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz || paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz) ? true : false;
/* 130 */     boolean bool2 = (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == this.cz || paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == this.cz) ? true : false;
/* 131 */     if (bool1 && bool2) {
/* 132 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       
/*     */       return;
/*     */     } 
/* 136 */     if ((paramaab.a(paramInt1 + b1, paramInt2, paramInt3 + b2) != apa.at.cz || paramaab.a(paramInt1 - b1, paramInt2, paramInt3 - b2) != this.cz) && (paramaab.a(paramInt1 - b1, paramInt2, paramInt3 - b2) != apa.at.cz || paramaab.a(paramInt1 + b1, paramInt2, paramInt3 + b2) != this.cz))
/*     */     {
/*     */ 
/*     */       
/* 140 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 146 */     if (paramaak.a(paramInt1, paramInt2, paramInt3) == this.cz) return false;
/*     */     
/* 148 */     boolean bool1 = (paramaak.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz && paramaak.a(paramInt1 - 2, paramInt2, paramInt3) != this.cz) ? true : false;
/* 149 */     boolean bool2 = (paramaak.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz && paramaak.a(paramInt1 + 2, paramInt2, paramInt3) != this.cz) ? true : false;
/*     */     
/* 151 */     boolean bool3 = (paramaak.a(paramInt1, paramInt2, paramInt3 - 1) == this.cz && paramaak.a(paramInt1, paramInt2, paramInt3 - 2) != this.cz) ? true : false;
/* 152 */     boolean bool4 = (paramaak.a(paramInt1, paramInt2, paramInt3 + 1) == this.cz && paramaak.a(paramInt1, paramInt2, paramInt3 + 2) != this.cz) ? true : false;
/*     */     
/* 154 */     boolean bool5 = (bool1 || bool2) ? true : false;
/* 155 */     boolean bool6 = (bool3 || bool4) ? true : false;
/*     */     
/* 157 */     if (bool5 && paramInt4 == 4) return true; 
/* 158 */     if (bool5 && paramInt4 == 5) return true; 
/* 159 */     if (bool6 && paramInt4 == 2) return true; 
/* 160 */     if (bool6 && paramInt4 == 3) return true;
/*     */     
/* 162 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 167 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int n() {
/* 172 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/* 177 */     if (parammp.o == null && parammp.n == null) parammp.Z();
/*     */   
/*     */   }
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 182 */     if (paramRandom.nextInt(100) == 0) {
/* 183 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "portal.portal", 0.5F, paramRandom.nextFloat() * 0.4F + 0.8F, false);
/*     */     }
/* 185 */     for (byte b = 0; b < 4; b++) {
/* 186 */       double d1 = (paramInt1 + paramRandom.nextFloat());
/* 187 */       double d2 = (paramInt2 + paramRandom.nextFloat());
/* 188 */       double d3 = (paramInt3 + paramRandom.nextFloat());
/* 189 */       double d4 = 0.0D;
/* 190 */       double d5 = 0.0D;
/* 191 */       double d6 = 0.0D;
/* 192 */       int i = paramRandom.nextInt(2) * 2 - 1;
/* 193 */       d4 = (paramRandom.nextFloat() - 0.5D) * 0.5D;
/* 194 */       d5 = (paramRandom.nextFloat() - 0.5D) * 0.5D;
/* 195 */       d6 = (paramRandom.nextFloat() - 0.5D) * 0.5D;
/* 196 */       if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz || paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz) {
/* 197 */         d3 = paramInt3 + 0.5D + 0.25D * i;
/* 198 */         d6 = (paramRandom.nextFloat() * 2.0F * i);
/*     */       } else {
/* 200 */         d1 = paramInt1 + 0.5D + 0.25D * i;
/* 201 */         d4 = (paramRandom.nextFloat() * 2.0F * i);
/*     */       } 
/*     */       
/* 204 */       paramaab.a("portal", d1, d2, d3, d4, d5, d6);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 210 */     return 0;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ant.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */