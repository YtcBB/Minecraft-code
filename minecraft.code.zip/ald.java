/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ald
/*    */   extends akz
/*    */ {
/*    */   private lx a;
/*    */   
/*    */   public ald(int paramInt) {
/* 19 */     super(paramInt, aif.r);
/* 20 */     c(3.0F);
/* 21 */     a(ve.f);
/*    */   }
/*    */   
/*    */   public aqp b(aab paramaab) {
/* 25 */     return new apw();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 30 */     if (paramaab.I) return true;
/*    */     
/* 32 */     apw apw = (apw)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 33 */     if (apw != null) paramsq.a(apw);
/*    */     
/* 35 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 40 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b() {
/* 45 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int d() {
/* 54 */     return 34;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 59 */     super.a(paramly);
/* 60 */     this.a = paramly.a("beacon");
/*    */   }
/*    */   
/*    */   public lx i() {
/* 64 */     return this.a;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 69 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramng, paramwm);
/* 70 */     if (paramwm.t())
/* 71 */       ((apw)paramaab.r(paramInt1, paramInt2, paramInt3)).a(paramwm.s()); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ald.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */