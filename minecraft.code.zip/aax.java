/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aax
/*    */ {
/*    */   private final aba a;
/* 15 */   private long b = 0L;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 45 */   private kv c = new kv();
/* 46 */   private List d = new ArrayList();
/*    */   
/*    */   public aax(aba paramaba) {
/* 49 */     this.a = paramaba;
/*    */   }
/*    */   
/*    */   public aay a(int paramInt1, int paramInt2) {
/* 53 */     paramInt1 >>= 4;
/* 54 */     paramInt2 >>= 4;
/* 55 */     long l = paramInt1 & 0xFFFFFFFFL | (paramInt2 & 0xFFFFFFFFL) << 32L;
/* 56 */     aay aay = (aay)this.c.a(l);
/* 57 */     if (aay == null) {
/* 58 */       aay = new aay(this, paramInt1, paramInt2);
/* 59 */       this.c.a(l, aay);
/* 60 */       this.d.add(aay);
/*    */     } 
/* 62 */     aay.f = System.currentTimeMillis();
/* 63 */     return aay;
/*    */   }
/*    */   
/*    */   public aav b(int paramInt1, int paramInt2) {
/* 67 */     return a(paramInt1, paramInt2).a(paramInt1, paramInt2);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void a() {
/* 79 */     long l1 = System.currentTimeMillis();
/* 80 */     long l2 = l1 - this.b;
/* 81 */     if (l2 > 7500L || l2 < 0L) {
/* 82 */       this.b = l1;
/*    */       
/* 84 */       for (byte b = 0; b < this.d.size(); b++) {
/* 85 */         aay aay = this.d.get(b);
/* 86 */         long l = l1 - aay.f;
/* 87 */         if (l > 30000L || l < 0L) {
/* 88 */           this.d.remove(b--);
/* 89 */           long l3 = aay.d & 0xFFFFFFFFL | (aay.e & 0xFFFFFFFFL) << 32L;
/* 90 */           this.c.d(l3);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public aav[] e(int paramInt1, int paramInt2) {
/* 97 */     return (a(paramInt1, paramInt2)).c;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aax.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */