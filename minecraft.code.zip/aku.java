/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aku
/*     */ {
/*     */   private akf a;
/*  22 */   private Map b = new HashMap<Object, Object>();
/*  23 */   private List c = new ArrayList();
/*  24 */   private Map d = new HashMap<Object, Object>();
/*     */   
/*     */   public aku(akf paramakf) {
/*  27 */     this.a = paramakf;
/*  28 */     b();
/*     */   }
/*     */   
/*     */   public ajo a(Class<ajo> paramClass, String paramString) {
/*  32 */     ajo ajo = (ajo)this.b.get(paramString);
/*  33 */     if (ajo != null) return ajo;
/*     */     
/*  35 */     if (this.a != null) {
/*     */       try {
/*  37 */         File file = this.a.b(paramString);
/*  38 */         if (file != null && file.exists()) {
/*     */           try {
/*  40 */             ajo = paramClass.getConstructor(new Class[] { String.class }).newInstance(new Object[] { paramString });
/*  41 */           } catch (Exception exception) {
/*  42 */             throw new RuntimeException("Failed to instantiate " + paramClass.toString(), exception);
/*     */           } 
/*     */           
/*  45 */           FileInputStream fileInputStream = new FileInputStream(file);
/*  46 */           bs bs = cc.a(fileInputStream);
/*  47 */           fileInputStream.close();
/*     */           
/*  49 */           ajo.a(bs.l("data"));
/*     */         } 
/*  51 */       } catch (Exception exception) {
/*  52 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*  56 */     if (ajo != null) {
/*  57 */       this.b.put(paramString, ajo);
/*  58 */       this.c.add(ajo);
/*     */     } 
/*  60 */     return ajo;
/*     */   }
/*     */   
/*     */   public void a(String paramString, ajo paramajo) {
/*  64 */     if (paramajo == null) throw new RuntimeException("Can't set null data"); 
/*  65 */     if (this.b.containsKey(paramString)) {
/*  66 */       this.c.remove(this.b.remove(paramString));
/*     */     }
/*  68 */     this.b.put(paramString, paramajo);
/*  69 */     this.c.add(paramajo);
/*     */   }
/*     */   
/*     */   public void a() {
/*  73 */     for (byte b = 0; b < this.c.size(); b++) {
/*  74 */       ajo ajo = this.c.get(b);
/*  75 */       if (ajo.d()) {
/*  76 */         a(ajo);
/*  77 */         ajo.a(false);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private void a(ajo paramajo) {
/*  83 */     if (this.a == null)
/*     */       return;  try {
/*  85 */       File file = this.a.b(paramajo.h);
/*  86 */       if (file != null) {
/*  87 */         bs bs1 = new bs();
/*  88 */         paramajo.b(bs1);
/*     */         
/*  90 */         bs bs2 = new bs();
/*  91 */         bs2.a("data", bs1);
/*     */         
/*  93 */         FileOutputStream fileOutputStream = new FileOutputStream(file);
/*  94 */         cc.a(bs2, fileOutputStream);
/*  95 */         fileOutputStream.close();
/*     */       } 
/*  97 */     } catch (Exception exception) {
/*  98 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   private void b() {
/*     */     try {
/* 104 */       this.d.clear();
/* 105 */       if (this.a == null)
/* 106 */         return;  File file = this.a.b("idcounts");
/* 107 */       if (file != null && file.exists()) {
/* 108 */         DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
/* 109 */         bs bs = cc.a(dataInputStream);
/* 110 */         dataInputStream.close();
/*     */         
/* 112 */         for (cf cf : bs.c()) {
/* 113 */           if (cf instanceof cd) {
/* 114 */             cd cd = (cd)cf;
/* 115 */             String str = cd.e();
/* 116 */             short s = cd.a;
/* 117 */             this.d.put(str, Short.valueOf(s));
/*     */           } 
/*     */         } 
/*     */       } 
/* 121 */     } catch (Exception exception) {
/* 122 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public int a(String paramString) {
/* 127 */     Short short_ = (Short)this.d.get(paramString);
/* 128 */     if (short_ == null) {
/* 129 */       short_ = Short.valueOf((short)0);
/*     */     } else {
/* 131 */       Short short_1 = short_, short_2 = short_ = Short.valueOf((short)(short_.shortValue() + 1));
/*     */     } 
/*     */     
/* 134 */     this.d.put(paramString, short_);
/* 135 */     if (this.a == null) return short_.shortValue(); 
/*     */     try {
/* 137 */       File file = this.a.b("idcounts");
/* 138 */       if (file != null) {
/* 139 */         bs bs = new bs();
/*     */         
/* 141 */         for (String str : this.d.keySet()) {
/* 142 */           short s = ((Short)this.d.get(str)).shortValue();
/* 143 */           bs.a(str, s);
/*     */         } 
/*     */         
/* 146 */         DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(file));
/* 147 */         cc.a(bs, dataOutputStream);
/* 148 */         dataOutputStream.close();
/*     */       } 
/* 150 */     } catch (Exception exception) {
/* 151 */       exception.printStackTrace();
/*     */     } 
/* 153 */     return short_.shortValue();
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aku.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */