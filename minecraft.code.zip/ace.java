/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ace
/*     */ {
/*     */   public static acf a(bs parambs) {
/*  14 */     int i = parambs.e("xPos");
/*  15 */     int j = parambs.e("zPos");
/*     */     
/*  17 */     acf acf = new acf(i, j);
/*  18 */     acf.g = parambs.j("Blocks");
/*  19 */     acf.f = new aby(parambs.j("Data"), 7);
/*  20 */     acf.e = new aby(parambs.j("SkyLight"), 7);
/*  21 */     acf.d = new aby(parambs.j("BlockLight"), 7);
/*  22 */     acf.c = parambs.j("HeightMap");
/*  23 */     acf.b = parambs.n("TerrainPopulated");
/*  24 */     acf.h = parambs.m("Entities");
/*  25 */     acf.i = parambs.m("TileEntities");
/*  26 */     acf.j = parambs.m("TileTicks");
/*     */ 
/*     */     
/*     */     try {
/*  30 */       acf.a = parambs.f("LastUpdate");
/*  31 */     } catch (ClassCastException classCastException) {
/*  32 */       acf.a = parambs.e("LastUpdate");
/*     */     } 
/*     */     
/*  35 */     return acf;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void a(acf paramacf, bs parambs, aba paramaba) {
/*  40 */     parambs.a("xPos", paramacf.k);
/*  41 */     parambs.a("zPos", paramacf.l);
/*  42 */     parambs.a("LastUpdate", paramacf.a);
/*  43 */     int[] arrayOfInt = new int[paramacf.c.length];
/*  44 */     for (byte b1 = 0; b1 < paramacf.c.length; b1++) {
/*  45 */       arrayOfInt[b1] = paramacf.c[b1];
/*     */     }
/*  47 */     parambs.a("HeightMap", arrayOfInt);
/*  48 */     parambs.a("TerrainPopulated", paramacf.b);
/*     */     
/*  50 */     ca ca = new ca("Sections");
/*  51 */     for (byte b2 = 0; b2 < 8; b2++) {
/*     */ 
/*     */       
/*  54 */       boolean bool = true;
/*  55 */       for (byte b = 0; b < 16 && bool; b++) {
/*  56 */         for (byte b4 = 0; b4 < 16 && bool; b4++) {
/*  57 */           for (byte b5 = 0; b5 < 16; b5++) {
/*  58 */             int i = b << 11 | b5 << 7 | b4 + (b2 << 4);
/*  59 */             byte b6 = paramacf.g[i];
/*  60 */             if (b6 != 0) {
/*  61 */               bool = false;
/*     */               
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*  68 */       if (!bool) {
/*     */ 
/*     */ 
/*     */ 
/*     */         
/*  73 */         byte[] arrayOfByte1 = new byte[4096];
/*  74 */         abu abu1 = new abu(arrayOfByte1.length, 4);
/*  75 */         abu abu2 = new abu(arrayOfByte1.length, 4);
/*  76 */         abu abu3 = new abu(arrayOfByte1.length, 4);
/*     */         
/*  78 */         for (byte b4 = 0; b4 < 16; b4++) {
/*  79 */           for (byte b5 = 0; b5 < 16; b5++) {
/*  80 */             for (byte b6 = 0; b6 < 16; b6++) {
/*  81 */               int i = b4 << 11 | b6 << 7 | b5 + (b2 << 4);
/*  82 */               byte b7 = paramacf.g[i];
/*     */               
/*  84 */               arrayOfByte1[b5 << 8 | b6 << 4 | b4] = (byte)(b7 & 0xFF);
/*  85 */               abu1.a(b4, b5, b6, paramacf.f.a(b4, b5 + (b2 << 4), b6));
/*  86 */               abu2.a(b4, b5, b6, paramacf.e.a(b4, b5 + (b2 << 4), b6));
/*  87 */               abu3.a(b4, b5, b6, paramacf.d.a(b4, b5 + (b2 << 4), b6));
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/*  92 */         bs bs1 = new bs();
/*     */         
/*  94 */         bs1.a("Y", (byte)(b2 & 0xFF));
/*  95 */         bs1.a("Blocks", arrayOfByte1);
/*  96 */         bs1.a("Data", abu1.a);
/*  97 */         bs1.a("SkyLight", abu2.a);
/*  98 */         bs1.a("BlockLight", abu3.a);
/*     */         
/* 100 */         ca.a(bs1);
/*     */       } 
/* 102 */     }  parambs.a("Sections", ca);
/*     */ 
/*     */     
/* 105 */     byte[] arrayOfByte = new byte[256];
/* 106 */     for (byte b3 = 0; b3 < 16; b3++) {
/* 107 */       for (byte b = 0; b < 16; b++) {
/* 108 */         arrayOfByte[b << 4 | b3] = (byte)((paramaba.a(paramacf.k << 4 | b3, paramacf.l << 4 | b)).N & 0xFF);
/*     */       }
/*     */     } 
/* 111 */     parambs.a("Biomes", arrayOfByte);
/*     */     
/* 113 */     parambs.a("Entities", paramacf.h);
/*     */     
/* 115 */     parambs.a("TileEntities", paramacf.i);
/*     */     
/* 117 */     if (paramacf.j != null)
/* 118 */       parambs.a("TileTicks", paramacf.j); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ace.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */