/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class afi
/*    */ {
/*    */   public Class a;
/*    */   public final int b;
/*    */   public int c;
/*    */   public int d;
/*    */   public boolean e;
/*    */   
/*    */   public afi(Class paramClass, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 24 */     this.a = paramClass;
/* 25 */     this.b = paramInt1;
/* 26 */     this.d = paramInt2;
/* 27 */     this.e = paramBoolean;
/*    */   }
/*    */   
/*    */   public afi(Class paramClass, int paramInt1, int paramInt2) {
/* 31 */     this(paramClass, paramInt1, paramInt2, false);
/*    */   }
/*    */   
/*    */   public boolean a(int paramInt) {
/* 35 */     return (this.d == 0 || this.c < this.d);
/*    */   }
/*    */   
/*    */   public boolean a() {
/* 39 */     return (this.d == 0 || this.c < this.d);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */