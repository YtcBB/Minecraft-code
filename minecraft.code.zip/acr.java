/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class acr
/*     */   extends acw
/*     */ {
/*  10 */   private float[] d = new float[1024];
/*     */   
/*     */   protected void a(long paramLong, int paramInt1, int paramInt2, byte[] paramArrayOfbyte, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt3, int paramInt4, double paramDouble4) {
/*  13 */     Random random = new Random(paramLong);
/*     */     
/*  15 */     double d1 = (paramInt1 * 16 + 8);
/*  16 */     double d2 = (paramInt2 * 16 + 8);
/*     */     
/*  18 */     float f1 = 0.0F;
/*  19 */     float f2 = 0.0F;
/*     */     
/*  21 */     if (paramInt4 <= 0) {
/*  22 */       int i = this.a * 16 - 16;
/*  23 */       paramInt4 = i - random.nextInt(i / 4);
/*     */     } 
/*  25 */     boolean bool = false;
/*     */     
/*  27 */     if (paramInt3 == -1) {
/*  28 */       paramInt3 = paramInt4 / 2;
/*  29 */       bool = true;
/*     */     } 
/*     */     
/*  32 */     float f3 = 1.0F;
/*  33 */     for (byte b = 0; b < ''; b++) {
/*  34 */       if (b == 0 || random.nextInt(3) == 0) {
/*  35 */         f3 = 1.0F + random.nextFloat() * random.nextFloat() * 1.0F;
/*     */       }
/*  37 */       this.d[b] = f3 * f3;
/*     */     } 
/*     */     
/*  40 */     for (; paramInt3 < paramInt4; paramInt3++) {
/*  41 */       double d3 = 1.5D + (kx.a(paramInt3 * 3.1415927F / paramInt4) * paramFloat1 * 1.0F);
/*  42 */       double d4 = d3 * paramDouble4;
/*     */       
/*  44 */       d3 *= random.nextFloat() * 0.25D + 0.75D;
/*  45 */       d4 *= random.nextFloat() * 0.25D + 0.75D;
/*     */       
/*  47 */       float f4 = kx.b(paramFloat3);
/*  48 */       float f5 = kx.a(paramFloat3);
/*  49 */       paramDouble1 += (kx.b(paramFloat2) * f4);
/*  50 */       paramDouble2 += f5;
/*  51 */       paramDouble3 += (kx.a(paramFloat2) * f4);
/*     */       
/*  53 */       paramFloat3 *= 0.7F;
/*     */       
/*  55 */       paramFloat3 += f2 * 0.05F;
/*  56 */       paramFloat2 += f1 * 0.05F;
/*     */       
/*  58 */       f2 *= 0.8F;
/*  59 */       f1 *= 0.5F;
/*  60 */       f2 += (random.nextFloat() - random.nextFloat()) * random.nextFloat() * 2.0F;
/*  61 */       f1 += (random.nextFloat() - random.nextFloat()) * random.nextFloat() * 4.0F;
/*     */       
/*  63 */       if (bool || random.nextInt(4) != 0) {
/*     */ 
/*     */         
/*  66 */         double d5 = paramDouble1 - d1;
/*  67 */         double d6 = paramDouble3 - d2;
/*  68 */         double d7 = (paramInt4 - paramInt3);
/*  69 */         double d8 = (paramFloat1 + 2.0F + 16.0F);
/*  70 */         if (d5 * d5 + d6 * d6 - d7 * d7 > d8 * d8) {
/*     */           return;
/*     */         }
/*     */ 
/*     */         
/*  75 */         if (paramDouble1 >= d1 - 16.0D - d3 * 2.0D && paramDouble3 >= d2 - 16.0D - d3 * 2.0D && paramDouble1 <= d1 + 16.0D + d3 * 2.0D && paramDouble3 <= d2 + 16.0D + d3 * 2.0D) {
/*     */ 
/*     */           
/*  78 */           int i = kx.c(paramDouble1 - d3) - paramInt1 * 16 - 1;
/*  79 */           int j = kx.c(paramDouble1 + d3) - paramInt1 * 16 + 1;
/*     */           
/*  81 */           int k = kx.c(paramDouble2 - d4) - 1;
/*  82 */           int m = kx.c(paramDouble2 + d4) + 1;
/*     */           
/*  84 */           int n = kx.c(paramDouble3 - d3) - paramInt2 * 16 - 1;
/*  85 */           int i1 = kx.c(paramDouble3 + d3) - paramInt2 * 16 + 1;
/*     */           
/*  87 */           if (i < 0) i = 0; 
/*  88 */           if (j > 16) j = 16;
/*     */           
/*  90 */           if (k < 1) k = 1; 
/*  91 */           if (m > 120) m = 120;
/*     */           
/*  93 */           if (n < 0) n = 0; 
/*  94 */           if (i1 > 16) i1 = 16;
/*     */           
/*  96 */           boolean bool1 = false; int i2;
/*  97 */           for (i2 = i; !bool1 && i2 < j; i2++) {
/*  98 */             for (int i3 = n; !bool1 && i3 < i1; i3++) {
/*  99 */               for (int i4 = m + 1; !bool1 && i4 >= k - 1; i4--) {
/* 100 */                 int i5 = (i2 * 16 + i3) * 128 + i4;
/* 101 */                 if (i4 >= 0 && i4 < 128) {
/* 102 */                   if (paramArrayOfbyte[i5] == apa.E.cz || paramArrayOfbyte[i5] == apa.F.cz) {
/* 103 */                     bool1 = true;
/*     */                   }
/* 105 */                   if (i4 != k - 1 && i2 != i && i2 != j - 1 && i3 != n && i3 != i1 - 1)
/* 106 */                     i4 = k; 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/* 111 */           if (!bool1) {
/*     */             
/* 113 */             for (i2 = i; i2 < j; i2++) {
/* 114 */               double d = ((i2 + paramInt1 * 16) + 0.5D - paramDouble1) / d3;
/* 115 */               for (int i3 = n; i3 < i1; i3++) {
/* 116 */                 double d9 = ((i3 + paramInt2 * 16) + 0.5D - paramDouble3) / d3;
/* 117 */                 int i4 = (i2 * 16 + i3) * 128 + m;
/* 118 */                 boolean bool2 = false;
/* 119 */                 if (d * d + d9 * d9 < 1.0D) {
/* 120 */                   for (int i5 = m - 1; i5 >= k; i5--) {
/* 121 */                     double d10 = (i5 + 0.5D - paramDouble2) / d4;
/* 122 */                     if ((d * d + d9 * d9) * this.d[i5] + d10 * d10 / 6.0D < 1.0D) {
/* 123 */                       byte b1 = paramArrayOfbyte[i4];
/* 124 */                       if (b1 == apa.y.cz) bool2 = true; 
/* 125 */                       if (b1 == apa.x.cz || b1 == apa.z.cz || b1 == apa.y.cz)
/* 126 */                         if (i5 < 10) {
/* 127 */                           paramArrayOfbyte[i4] = (byte)apa.G.cz;
/*     */                         } else {
/* 129 */                           paramArrayOfbyte[i4] = 0;
/* 130 */                           if (bool2 && paramArrayOfbyte[i4 - 1] == apa.z.cz) {
/* 131 */                             paramArrayOfbyte[i4 - 1] = (this.c.a(i2 + paramInt1 * 16, i3 + paramInt2 * 16)).A;
/*     */                           }
/*     */                         }  
/*     */                     } 
/* 135 */                     i4--;
/*     */                   } 
/*     */                 }
/*     */               } 
/*     */             } 
/* 140 */             if (bool)
/*     */               break; 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }  } protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfbyte) {
/* 146 */     if (this.b.nextInt(50) != 0)
/* 147 */       return;  double d1 = (paramInt1 * 16 + this.b.nextInt(16));
/* 148 */     double d2 = (this.b.nextInt(this.b.nextInt(40) + 8) + 20);
/* 149 */     double d3 = (paramInt2 * 16 + this.b.nextInt(16));
/*     */     
/* 151 */     byte b1 = 1;
/*     */     
/* 153 */     for (byte b2 = 0; b2 < b1; b2++) {
/*     */       
/* 155 */       float f1 = this.b.nextFloat() * 3.1415927F * 2.0F;
/* 156 */       float f2 = (this.b.nextFloat() - 0.5F) * 2.0F / 8.0F;
/* 157 */       float f3 = (this.b.nextFloat() * 2.0F + this.b.nextFloat()) * 2.0F;
/*     */       
/* 159 */       a(this.b.nextLong(), paramInt3, paramInt4, paramArrayOfbyte, d1, d2, d3, f3, f1, f2, 0, 0, 3.0D);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */