/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ady
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 12 */     for (byte b = 0; b < 20; b++) {
/* 13 */       int i = paramInt1 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 14 */       int j = paramInt2;
/* 15 */       int k = paramInt3 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 16 */       if (paramaab.c(i, j, k) && (
/* 17 */         paramaab.g(i - 1, j - 1, k) == aif.h || paramaab.g(i + 1, j - 1, k) == aif.h || paramaab.g(i, j - 1, k - 1) == aif.h || paramaab.g(i, j - 1, k + 1) == aif.h)) {
/*    */ 
/*    */         
/* 20 */         int m = 2 + paramRandom.nextInt(paramRandom.nextInt(3) + 1);
/* 21 */         for (byte b1 = 0; b1 < m; b1++) {
/* 22 */           if (apa.bb.f(paramaab, i, j + b1, k)) {
/* 23 */             paramaab.f(i, j + b1, k, apa.bb.cz, 0, 2);
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 30 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ady.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */