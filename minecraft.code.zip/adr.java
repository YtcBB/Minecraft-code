/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class adr
/*     */   extends adj
/*     */ {
/*     */   private int a;
/*     */   
/*     */   public adr(int paramInt) {
/*  14 */     this.a = paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/*  19 */     paramInt1 -= 8;
/*  20 */     paramInt3 -= 8;
/*  21 */     while (paramInt2 > 5 && paramaab.c(paramInt1, paramInt2, paramInt3))
/*  22 */       paramInt2--; 
/*  23 */     if (paramInt2 <= 4) {
/*  24 */       return false;
/*     */     }
/*     */     
/*  27 */     paramInt2 -= 4;
/*     */     
/*  29 */     boolean[] arrayOfBoolean = new boolean[2048];
/*     */     
/*  31 */     int i = paramRandom.nextInt(4) + 4; byte b;
/*  32 */     for (b = 0; b < i; b++) {
/*  33 */       double d1 = paramRandom.nextDouble() * 6.0D + 3.0D;
/*  34 */       double d2 = paramRandom.nextDouble() * 4.0D + 2.0D;
/*  35 */       double d3 = paramRandom.nextDouble() * 6.0D + 3.0D;
/*     */       
/*  37 */       double d4 = paramRandom.nextDouble() * (16.0D - d1 - 2.0D) + 1.0D + d1 / 2.0D;
/*  38 */       double d5 = paramRandom.nextDouble() * (8.0D - d2 - 4.0D) + 2.0D + d2 / 2.0D;
/*  39 */       double d6 = paramRandom.nextDouble() * (16.0D - d3 - 2.0D) + 1.0D + d3 / 2.0D;
/*     */       
/*  41 */       for (byte b1 = 1; b1 < 15; b1++) {
/*  42 */         for (byte b2 = 1; b2 < 15; b2++) {
/*  43 */           for (byte b3 = 1; b3 < 7; b3++) {
/*  44 */             double d7 = (b1 - d4) / d1 / 2.0D;
/*  45 */             double d8 = (b3 - d5) / d2 / 2.0D;
/*  46 */             double d9 = (b2 - d6) / d3 / 2.0D;
/*  47 */             double d10 = d7 * d7 + d8 * d8 + d9 * d9;
/*  48 */             if (d10 < 1.0D) arrayOfBoolean[(b1 * 16 + b2) * 8 + b3] = true;
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  54 */     for (b = 0; b < 16; b++) {
/*  55 */       for (byte b1 = 0; b1 < 16; b1++) {
/*  56 */         for (byte b2 = 0; b2 < 8; b2++) {
/*  57 */           boolean bool = (!arrayOfBoolean[(b * 16 + b1) * 8 + b2] && ((b < 15 && arrayOfBoolean[((b + 1) * 16 + b1) * 8 + b2]) || (b > 0 && arrayOfBoolean[((b - 1) * 16 + b1) * 8 + b2]) || (b1 < 15 && arrayOfBoolean[(b * 16 + b1 + 1) * 8 + b2]) || (b1 > 0 && arrayOfBoolean[(b * 16 + b1 - 1) * 8 + b2]) || (b2 < 7 && arrayOfBoolean[(b * 16 + b1) * 8 + b2 + 1]) || (b2 > 0 && arrayOfBoolean[(b * 16 + b1) * 8 + b2 - 1]))) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/*  64 */           if (bool) {
/*  65 */             aif aif = paramaab.g(paramInt1 + b, paramInt2 + b2, paramInt3 + b1);
/*  66 */             if (b2 >= 4 && aif.d()) return false; 
/*  67 */             if (b2 < 4 && !aif.a() && paramaab.a(paramInt1 + b, paramInt2 + b2, paramInt3 + b1) != this.a) return false;
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  74 */     for (b = 0; b < 16; b++) {
/*  75 */       for (byte b1 = 0; b1 < 16; b1++) {
/*  76 */         for (byte b2 = 0; b2 < 8; b2++) {
/*  77 */           if (arrayOfBoolean[(b * 16 + b1) * 8 + b2]) {
/*  78 */             paramaab.f(paramInt1 + b, paramInt2 + b2, paramInt3 + b1, (b2 >= 4) ? 0 : this.a, 0, 2);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  84 */     for (b = 0; b < 16; b++) {
/*  85 */       for (byte b1 = 0; b1 < 16; b1++) {
/*  86 */         for (byte b2 = 4; b2 < 8; b2++) {
/*  87 */           if (arrayOfBoolean[(b * 16 + b1) * 8 + b2] && 
/*  88 */             paramaab.a(paramInt1 + b, paramInt2 + b2 - 1, paramInt3 + b1) == apa.z.cz && paramaab.b(aam.a, paramInt1 + b, paramInt2 + b2, paramInt3 + b1) > 0) {
/*  89 */             aav aav = paramaab.a(paramInt1 + b, paramInt3 + b1);
/*  90 */             if (aav.A == apa.bC.cz) { paramaab.f(paramInt1 + b, paramInt2 + b2 - 1, paramInt3 + b1, apa.bC.cz, 0, 2); }
/*  91 */             else { paramaab.f(paramInt1 + b, paramInt2 + b2 - 1, paramInt3 + b1, apa.y.cz, 0, 2); }
/*     */           
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  98 */     if ((apa.r[this.a]).cO == aif.i) {
/*  99 */       for (b = 0; b < 16; b++) {
/* 100 */         for (byte b1 = 0; b1 < 16; b1++) {
/* 101 */           for (byte b2 = 0; b2 < 8; b2++) {
/* 102 */             boolean bool = (!arrayOfBoolean[(b * 16 + b1) * 8 + b2] && ((b < 15 && arrayOfBoolean[((b + 1) * 16 + b1) * 8 + b2]) || (b > 0 && arrayOfBoolean[((b - 1) * 16 + b1) * 8 + b2]) || (b1 < 15 && arrayOfBoolean[(b * 16 + b1 + 1) * 8 + b2]) || (b1 > 0 && arrayOfBoolean[(b * 16 + b1 - 1) * 8 + b2]) || (b2 < 7 && arrayOfBoolean[(b * 16 + b1) * 8 + b2 + 1]) || (b2 > 0 && arrayOfBoolean[(b * 16 + b1) * 8 + b2 - 1]))) ? true : false;
/*     */ 
/*     */ 
/*     */ 
/*     */             
/* 107 */             if (bool && (
/* 108 */               b2 < 4 || paramRandom.nextInt(2) != 0) && paramaab.g(paramInt1 + b, paramInt2 + b2, paramInt3 + b1).a()) {
/* 109 */               paramaab.f(paramInt1 + b, paramInt2 + b2, paramInt3 + b1, apa.x.cz, 0, 2);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 117 */     if ((apa.r[this.a]).cO == aif.h) {
/* 118 */       for (b = 0; b < 16; b++) {
/* 119 */         for (byte b1 = 0; b1 < 16; b1++) {
/* 120 */           byte b2 = 4;
/* 121 */           if (paramaab.x(paramInt1 + b, paramInt2 + b2, paramInt3 + b1)) paramaab.f(paramInt1 + b, paramInt2 + b2, paramInt3 + b1, apa.aX.cz, 0, 2);
/*     */         
/*     */         } 
/*     */       } 
/*     */     }
/* 126 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */