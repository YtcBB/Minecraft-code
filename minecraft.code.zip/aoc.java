/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aoc
/*     */   extends akz
/*     */ {
/*     */   private lx a;
/*     */   
/*     */   protected aoc(int paramInt) {
/*  54 */     super(paramInt, aif.d);
/*  55 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  60 */     if (paramInt1 == 1) {
/*  61 */       return this.a;
/*     */     }
/*  63 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  68 */     if (paramaab.h(paramInt1, paramInt2, paramInt3) == 0) return false; 
/*  69 */     o_(paramaab, paramInt1, paramInt2, paramInt3);
/*  70 */     return true;
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, wm paramwm) {
/*  74 */     if (paramaab.I)
/*     */       return; 
/*  76 */     aod aod = (aod)paramaab.r(paramInt1, paramInt2, paramInt3);
/*  77 */     if (aod == null)
/*     */       return; 
/*  79 */     aod.a(paramwm.m());
/*     */     
/*  81 */     paramaab.b(paramInt1, paramInt2, paramInt3, 1, 2);
/*     */   }
/*     */   
/*     */   public void o_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  85 */     if (paramaab.I)
/*     */       return; 
/*  87 */     aod aod = (aod)paramaab.r(paramInt1, paramInt2, paramInt3);
/*  88 */     if (aod == null)
/*     */       return; 
/*  90 */     wm wm1 = aod.a();
/*  91 */     if (wm1 == null)
/*     */       return; 
/*  93 */     paramaab.e(1005, paramInt1, paramInt2, paramInt3, 0);
/*  94 */     paramaab.a((String)null, paramInt1, paramInt2, paramInt3);
/*  95 */     aod.a((wm)null);
/*  96 */     paramaab.b(paramInt1, paramInt2, paramInt3, 0, 2);
/*     */     
/*  98 */     float f = 0.7F;
/*  99 */     double d1 = (paramaab.s.nextFloat() * f) + (1.0F - f) * 0.5D;
/* 100 */     double d2 = (paramaab.s.nextFloat() * f) + (1.0F - f) * 0.2D + 0.6D;
/* 101 */     double d3 = (paramaab.s.nextFloat() * f) + (1.0F - f) * 0.5D;
/*     */     
/* 103 */     wm wm2 = wm1.m();
/*     */     
/* 105 */     rh rh = new rh(paramaab, paramInt1 + d1, paramInt2 + d2, paramInt3 + d3, wm2);
/* 106 */     rh.b = 10;
/* 107 */     paramaab.d(rh);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 112 */     o_(paramaab, paramInt1, paramInt2, paramInt3);
/* 113 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 118 */     if (paramaab.I)
/* 119 */       return;  super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, 0);
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/* 123 */     return new aod();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 128 */     this.cQ = paramly.a("musicBlock");
/* 129 */     this.a = paramly.a("jukebox_top");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean q_() {
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 139 */     wm wm = ((aod)paramaab.r(paramInt1, paramInt2, paramInt3)).a();
/* 140 */     return (wm == null) ? 0 : (wm.c + 1 - wk.cd.cp);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */