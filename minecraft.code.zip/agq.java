/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class agq
/*     */   extends agw
/*     */ {
/*     */   protected agq(int paramInt) {
/* 197 */     super(paramInt);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, Random paramRandom, aek paramaek, agr paramagr, int paramInt1, int paramInt2, int paramInt3) {
/* 206 */     switch (aga.a[paramagr.ordinal()]) {
/*     */       
/*     */       default:
/* 209 */         a(paramaab, paramaek, paramInt1, paramInt2, paramInt3, paramInt1 + 3 - 1, paramInt2 + 3 - 1, paramInt3, 0, 0, false);
/*     */         return;
/*     */       case 2:
/* 212 */         a(paramaab, apa.bq.cz, 0, paramInt1, paramInt2, paramInt3, paramaek);
/* 213 */         a(paramaab, apa.bq.cz, 0, paramInt1, paramInt2 + 1, paramInt3, paramaek);
/* 214 */         a(paramaab, apa.bq.cz, 0, paramInt1, paramInt2 + 2, paramInt3, paramaek);
/* 215 */         a(paramaab, apa.bq.cz, 0, paramInt1 + 1, paramInt2 + 2, paramInt3, paramaek);
/* 216 */         a(paramaab, apa.bq.cz, 0, paramInt1 + 2, paramInt2 + 2, paramInt3, paramaek);
/* 217 */         a(paramaab, apa.bq.cz, 0, paramInt1 + 2, paramInt2 + 1, paramInt3, paramaek);
/* 218 */         a(paramaab, apa.bq.cz, 0, paramInt1 + 2, paramInt2, paramInt3, paramaek);
/* 219 */         a(paramaab, apa.aI.cz, 0, paramInt1 + 1, paramInt2, paramInt3, paramaek);
/* 220 */         a(paramaab, apa.aI.cz, 8, paramInt1 + 1, paramInt2 + 1, paramInt3, paramaek);
/*     */         return;
/*     */       case 3:
/* 223 */         a(paramaab, 0, 0, paramInt1 + 1, paramInt2, paramInt3, paramaek);
/* 224 */         a(paramaab, 0, 0, paramInt1 + 1, paramInt2 + 1, paramInt3, paramaek);
/* 225 */         a(paramaab, apa.bt.cz, 0, paramInt1, paramInt2, paramInt3, paramaek);
/* 226 */         a(paramaab, apa.bt.cz, 0, paramInt1, paramInt2 + 1, paramInt3, paramaek);
/* 227 */         a(paramaab, apa.bt.cz, 0, paramInt1, paramInt2 + 2, paramInt3, paramaek);
/* 228 */         a(paramaab, apa.bt.cz, 0, paramInt1 + 1, paramInt2 + 2, paramInt3, paramaek);
/* 229 */         a(paramaab, apa.bt.cz, 0, paramInt1 + 2, paramInt2 + 2, paramInt3, paramaek);
/* 230 */         a(paramaab, apa.bt.cz, 0, paramInt1 + 2, paramInt2 + 1, paramInt3, paramaek);
/* 231 */         a(paramaab, apa.bt.cz, 0, paramInt1 + 2, paramInt2, paramInt3, paramaek); return;
/*     */       case 4:
/*     */         break;
/* 234 */     }  a(paramaab, apa.bq.cz, 0, paramInt1, paramInt2, paramInt3, paramaek);
/* 235 */     a(paramaab, apa.bq.cz, 0, paramInt1, paramInt2 + 1, paramInt3, paramaek);
/* 236 */     a(paramaab, apa.bq.cz, 0, paramInt1, paramInt2 + 2, paramInt3, paramaek);
/* 237 */     a(paramaab, apa.bq.cz, 0, paramInt1 + 1, paramInt2 + 2, paramInt3, paramaek);
/* 238 */     a(paramaab, apa.bq.cz, 0, paramInt1 + 2, paramInt2 + 2, paramInt3, paramaek);
/* 239 */     a(paramaab, apa.bq.cz, 0, paramInt1 + 2, paramInt2 + 1, paramInt3, paramaek);
/* 240 */     a(paramaab, apa.bq.cz, 0, paramInt1 + 2, paramInt2, paramInt3, paramaek);
/* 241 */     a(paramaab, apa.aP.cz, 0, paramInt1 + 1, paramInt2, paramInt3, paramaek);
/* 242 */     a(paramaab, apa.aP.cz, 8, paramInt1 + 1, paramInt2 + 1, paramInt3, paramaek);
/* 243 */     a(paramaab, apa.aV.cz, c(apa.aV.cz, 4), paramInt1 + 2, paramInt2 + 1, paramInt3 + 1, paramaek);
/* 244 */     a(paramaab, apa.aV.cz, c(apa.aV.cz, 3), paramInt1 + 2, paramInt2 + 1, paramInt3 - 1, paramaek);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected agr a(Random paramRandom) {
/* 250 */     int i = paramRandom.nextInt(5);
/* 251 */     switch (i)
/*     */     
/*     */     { 
/*     */       default:
/* 255 */         return agr.a;
/*     */       case 2:
/* 257 */         return agr.b;
/*     */       case 3:
/* 259 */         return agr.c;
/*     */       case 4:
/* 261 */         break; }  return agr.d;
/*     */   }
/*     */ 
/*     */   
/*     */   protected agw a(agn paramagn, List paramList, Random paramRandom, int paramInt1, int paramInt2) {
/* 266 */     switch (this.f) {
/*     */       case 2:
/* 268 */         return afx.a(paramagn, paramList, paramRandom, this.e.a + paramInt1, this.e.b + paramInt2, this.e.c - 1, this.f, c());
/*     */       case 0:
/* 270 */         return afx.a(paramagn, paramList, paramRandom, this.e.a + paramInt1, this.e.b + paramInt2, this.e.f + 1, this.f, c());
/*     */       case 1:
/* 272 */         return afx.a(paramagn, paramList, paramRandom, this.e.a - 1, this.e.b + paramInt2, this.e.c + paramInt1, this.f, c());
/*     */       case 3:
/* 274 */         return afx.a(paramagn, paramList, paramRandom, this.e.d + 1, this.e.b + paramInt2, this.e.c + paramInt1, this.f, c());
/*     */     } 
/* 276 */     return null;
/*     */   }
/*     */   
/*     */   protected agw b(agn paramagn, List paramList, Random paramRandom, int paramInt1, int paramInt2) {
/* 280 */     switch (this.f) {
/*     */       case 2:
/* 282 */         return afx.a(paramagn, paramList, paramRandom, this.e.a - 1, this.e.b + paramInt1, this.e.c + paramInt2, 1, c());
/*     */       case 0:
/* 284 */         return afx.a(paramagn, paramList, paramRandom, this.e.a - 1, this.e.b + paramInt1, this.e.c + paramInt2, 1, c());
/*     */       case 1:
/* 286 */         return afx.a(paramagn, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.c - 1, 2, c());
/*     */       case 3:
/* 288 */         return afx.a(paramagn, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.c - 1, 2, c());
/*     */     } 
/* 290 */     return null;
/*     */   }
/*     */   
/*     */   protected agw c(agn paramagn, List paramList, Random paramRandom, int paramInt1, int paramInt2) {
/* 294 */     switch (this.f) {
/*     */       case 2:
/* 296 */         return afx.a(paramagn, paramList, paramRandom, this.e.d + 1, this.e.b + paramInt1, this.e.c + paramInt2, 3, c());
/*     */       case 0:
/* 298 */         return afx.a(paramagn, paramList, paramRandom, this.e.d + 1, this.e.b + paramInt1, this.e.c + paramInt2, 3, c());
/*     */       case 1:
/* 300 */         return afx.a(paramagn, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.f + 1, 0, c());
/*     */       case 3:
/* 302 */         return afx.a(paramagn, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.f + 1, 0, c());
/*     */     } 
/* 304 */     return null;
/*     */   }
/*     */   
/*     */   protected static boolean a(aek paramaek) {
/* 308 */     return (paramaek != null && paramaek.b > 10);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\agq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */