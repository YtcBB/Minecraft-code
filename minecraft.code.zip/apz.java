/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class apz
/*    */   extends aqp
/*    */   implements ab
/*    */ {
/* 11 */   private int a = 0;
/* 12 */   private String b = "";
/* 13 */   private String c = "@";
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void b(String paramString) {
/* 19 */     this.b = paramString;
/* 20 */     k_();
/*    */   }
/*    */   
/*    */   public String c() {
/* 24 */     return this.b;
/*    */   }
/*    */   
/*    */   public int a(aab paramaab) {
/* 28 */     if (paramaab.I) {
/* 29 */       return 0;
/*    */     }
/*    */     
/* 32 */     MinecraftServer minecraftServer = MinecraftServer.D();
/* 33 */     if (minecraftServer != null && minecraftServer.Z()) {
/* 34 */       aa aa = minecraftServer.E();
/* 35 */       return aa.a(this, this.b);
/*    */     } 
/*    */     
/* 38 */     return 0;
/*    */   }
/*    */   
/*    */   public String c_() {
/* 42 */     return this.c;
/*    */   }
/*    */   
/*    */   public void c(String paramString) {
/* 46 */     this.c = paramString;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(String paramString) {}
/*    */   
/*    */   public boolean a(int paramInt, String paramString) {
/* 53 */     return (paramInt <= 2);
/*    */   }
/*    */   
/*    */   public String a(String paramString, Object... paramVarArgs) {
/* 57 */     return paramString;
/*    */   }
/*    */ 
/*    */   
/*    */   public void b(bs parambs) {
/* 62 */     super.b(parambs);
/* 63 */     parambs.a("Command", this.b);
/* 64 */     parambs.a("SuccessCount", this.a);
/* 65 */     parambs.a("CustomName", this.c);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(bs parambs) {
/* 70 */     super.a(parambs);
/* 71 */     this.b = parambs.i("Command");
/* 72 */     this.a = parambs.e("SuccessCount");
/* 73 */     if (parambs.b("CustomName")) this.c = parambs.i("CustomName"); 
/*    */   }
/*    */   
/*    */   public t b() {
/* 77 */     return new t(this.l, this.m, this.n);
/*    */   }
/*    */ 
/*    */   
/*    */   public ei m() {
/* 82 */     bs bs = new bs();
/* 83 */     b(bs);
/* 84 */     return new fn(this.l, this.m, this.n, 2, bs);
/*    */   }
/*    */   
/*    */   public int d() {
/* 88 */     return this.a;
/*    */   }
/*    */   
/*    */   public void a(int paramInt) {
/* 92 */     this.a = paramInt;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */