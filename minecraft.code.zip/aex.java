/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aex
/*     */   extends afh
/*     */ {
/*     */   public aex(int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 288 */     super(paramInt1);
/*     */     
/* 290 */     this.f = paramInt2;
/* 291 */     this.e = paramaek;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/* 298 */     a((afl)paramagw, paramList, paramRandom, 1, 3, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static aex a(List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 304 */     aek aek = aek.a(paramInt1, paramInt2, paramInt3, -1, -3, 0, 5, 10, 19, paramInt4);
/*     */     
/* 306 */     if (!a(aek) || agw.a(paramList, aek) != null) {
/* 307 */       return null;
/*     */     }
/*     */     
/* 310 */     return new aex(paramInt5, paramRandom, aek, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 317 */     a(paramaab, paramaek, 0, 3, 0, 4, 4, 18, apa.bE.cz, apa.bE.cz, false);
/*     */     
/* 319 */     a(paramaab, paramaek, 1, 5, 0, 3, 7, 18, 0, 0, false);
/*     */ 
/*     */     
/* 322 */     a(paramaab, paramaek, 0, 5, 0, 0, 5, 18, apa.bE.cz, apa.bE.cz, false);
/* 323 */     a(paramaab, paramaek, 4, 5, 0, 4, 5, 18, apa.bE.cz, apa.bE.cz, false);
/*     */ 
/*     */     
/* 326 */     a(paramaab, paramaek, 0, 2, 0, 4, 2, 5, apa.bE.cz, apa.bE.cz, false);
/* 327 */     a(paramaab, paramaek, 0, 2, 13, 4, 2, 18, apa.bE.cz, apa.bE.cz, false);
/* 328 */     a(paramaab, paramaek, 0, 0, 0, 4, 1, 3, apa.bE.cz, apa.bE.cz, false);
/* 329 */     a(paramaab, paramaek, 0, 0, 15, 4, 1, 18, apa.bE.cz, apa.bE.cz, false);
/*     */     
/* 331 */     for (byte b = 0; b <= 4; b++) {
/* 332 */       for (byte b1 = 0; b1 <= 2; b1++) {
/* 333 */         b(paramaab, apa.bE.cz, 0, b, -1, b1, paramaek);
/* 334 */         b(paramaab, apa.bE.cz, 0, b, -1, 18 - b1, paramaek);
/*     */       } 
/*     */     } 
/*     */     
/* 338 */     a(paramaab, paramaek, 0, 1, 1, 0, 4, 1, apa.bF.cz, apa.bF.cz, false);
/* 339 */     a(paramaab, paramaek, 0, 3, 4, 0, 4, 4, apa.bF.cz, apa.bF.cz, false);
/* 340 */     a(paramaab, paramaek, 0, 3, 14, 0, 4, 14, apa.bF.cz, apa.bF.cz, false);
/* 341 */     a(paramaab, paramaek, 0, 1, 17, 0, 4, 17, apa.bF.cz, apa.bF.cz, false);
/* 342 */     a(paramaab, paramaek, 4, 1, 1, 4, 4, 1, apa.bF.cz, apa.bF.cz, false);
/* 343 */     a(paramaab, paramaek, 4, 3, 4, 4, 4, 4, apa.bF.cz, apa.bF.cz, false);
/* 344 */     a(paramaab, paramaek, 4, 3, 14, 4, 4, 14, apa.bF.cz, apa.bF.cz, false);
/* 345 */     a(paramaab, paramaek, 4, 1, 17, 4, 4, 17, apa.bF.cz, apa.bF.cz, false);
/*     */     
/* 347 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aex.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */