/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class alu
/*     */   extends alh
/*     */ {
/*     */   private lx[] a;
/*     */   
/*     */   protected alu(int paramInt) {
/*  15 */     super(paramInt);
/*     */     
/*  17 */     b(true);
/*  18 */     float f = 0.5F;
/*  19 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.25F, 0.5F + f);
/*  20 */     a((ve)null);
/*     */     
/*  22 */     c(0.0F);
/*  23 */     a(i);
/*  24 */     D();
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean f_(int paramInt) {
/*  29 */     return (paramInt == apa.aE.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  34 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*  35 */     if (paramaab.n(paramInt1, paramInt2 + 1, paramInt3) >= 9) {
/*     */       
/*  37 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  38 */       if (i < 7) {
/*  39 */         float f = k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */         
/*  41 */         if (paramRandom.nextInt((int)(25.0F / f) + 1) == 0) {
/*  42 */           i++;
/*  43 */           paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void e_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  50 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3) + kx.a(paramaab.s, 2, 5);
/*  51 */     if (i > 7) i = 7; 
/*  52 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */   }
/*     */   
/*     */   private float k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  56 */     float f = 1.0F;
/*     */     
/*  58 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3 - 1);
/*  59 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3 + 1);
/*  60 */     int k = paramaab.a(paramInt1 - 1, paramInt2, paramInt3);
/*  61 */     int m = paramaab.a(paramInt1 + 1, paramInt2, paramInt3);
/*     */     
/*  63 */     int n = paramaab.a(paramInt1 - 1, paramInt2, paramInt3 - 1);
/*  64 */     int i1 = paramaab.a(paramInt1 + 1, paramInt2, paramInt3 - 1);
/*  65 */     int i2 = paramaab.a(paramInt1 + 1, paramInt2, paramInt3 + 1);
/*  66 */     int i3 = paramaab.a(paramInt1 - 1, paramInt2, paramInt3 + 1);
/*     */     
/*  68 */     boolean bool1 = (k == this.cz || m == this.cz) ? true : false;
/*  69 */     boolean bool2 = (i == this.cz || j == this.cz) ? true : false;
/*  70 */     boolean bool3 = (n == this.cz || i1 == this.cz || i2 == this.cz || i3 == this.cz) ? true : false;
/*     */     
/*  72 */     for (int i4 = paramInt1 - 1; i4 <= paramInt1 + 1; i4++) {
/*  73 */       for (int i5 = paramInt3 - 1; i5 <= paramInt3 + 1; i5++) {
/*  74 */         int i6 = paramaab.a(i4, paramInt2 - 1, i5);
/*     */         
/*  76 */         float f1 = 0.0F;
/*  77 */         if (i6 == apa.aE.cz) {
/*  78 */           f1 = 1.0F;
/*  79 */           if (paramaab.h(i4, paramInt2 - 1, i5) > 0) f1 = 3.0F;
/*     */         
/*     */         } 
/*  82 */         if (i4 != paramInt1 || i5 != paramInt3) f1 /= 4.0F;
/*     */         
/*  84 */         f += f1;
/*     */       } 
/*     */     } 
/*  87 */     if (bool3 || (bool1 && bool2)) f /= 2.0F;
/*     */     
/*  89 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  94 */     if (paramInt2 < 0 || paramInt2 > 7) paramInt2 = 7; 
/*  95 */     return this.a[paramInt2];
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 100 */     return 6;
/*     */   }
/*     */   
/*     */   protected int j() {
/* 104 */     return wk.T.cp;
/*     */   }
/*     */   
/*     */   protected int k() {
/* 108 */     return wk.U.cp;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 118 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, 0);
/*     */     
/* 120 */     if (paramaab.I) {
/*     */       return;
/*     */     }
/* 123 */     if (paramInt4 >= 7) {
/*     */       
/* 125 */       int i = 3 + paramInt5;
/* 126 */       for (byte b = 0; b < i; b++) {
/* 127 */         if (paramaab.s.nextInt(15) <= paramInt4) {
/* 128 */           b(paramaab, paramInt1, paramInt2, paramInt3, new wm(j(), 1, 0));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 135 */     if (paramInt1 == 7) {
/* 136 */       return k();
/*     */     }
/*     */     
/* 139 */     return j();
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 144 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 149 */     return j();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 154 */     this.a = new lx[8];
/*     */     
/* 156 */     for (byte b = 0; b < this.a.length; b++)
/* 157 */       this.a[b] = paramly.a("crops_" + b); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */