/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.LinkedHashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ajl
/*     */   extends ajo
/*     */ {
/*     */   public int a;
/*     */   public int b;
/*     */   public byte c;
/*     */   public byte d;
/* 113 */   public byte[] e = new byte[16384];
/* 114 */   public List f = new ArrayList();
/* 115 */   private Map i = new HashMap<Object, Object>();
/* 116 */   public Map g = new LinkedHashMap<Object, Object>();
/*     */   
/*     */   public ajl(String paramString) {
/* 119 */     super(paramString);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(bs parambs) {
/* 124 */     this.c = parambs.c("dimension");
/* 125 */     this.a = parambs.e("xCenter");
/* 126 */     this.b = parambs.e("zCenter");
/* 127 */     this.d = parambs.c("scale");
/* 128 */     if (this.d < 0) this.d = 0; 
/* 129 */     if (this.d > 4) this.d = 4;
/*     */     
/* 131 */     short s1 = parambs.d("width");
/* 132 */     short s2 = parambs.d("height");
/* 133 */     if (s1 == 128 && s2 == 128) {
/* 134 */       this.e = parambs.j("colors");
/*     */     } else {
/* 136 */       byte[] arrayOfByte = parambs.j("colors");
/* 137 */       this.e = new byte[16384];
/* 138 */       int i = (128 - s1) / 2;
/* 139 */       int j = (128 - s2) / 2;
/* 140 */       for (byte b = 0; b < s2; b++) {
/* 141 */         int k = b + j;
/* 142 */         if (k >= 0 || k < 128)
/* 143 */           for (byte b1 = 0; b1 < s1; b1++) {
/* 144 */             int m = b1 + i;
/* 145 */             if (m >= 0 || m < 128) {
/* 146 */               this.e[m + k * 128] = arrayOfByte[b1 + b * s1];
/*     */             }
/*     */           }  
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void b(bs parambs) {
/* 154 */     parambs.a("dimension", this.c);
/* 155 */     parambs.a("xCenter", this.a);
/* 156 */     parambs.a("zCenter", this.b);
/* 157 */     parambs.a("scale", this.d);
/* 158 */     parambs.a("width", (short)128);
/* 159 */     parambs.a("height", (short)128);
/* 160 */     parambs.a("colors", this.e);
/*     */   }
/*     */   
/*     */   public void a(sq paramsq, wm paramwm) {
/* 164 */     if (!this.i.containsKey(paramsq)) {
/* 165 */       ajm ajm = new ajm(this, paramsq);
/* 166 */       this.i.put(paramsq, ajm);
/* 167 */       this.f.add(ajm);
/*     */     } 
/*     */     
/* 170 */     if (!paramsq.bK.c(paramwm)) {
/* 171 */       this.g.remove(paramsq.c_());
/*     */     }
/*     */     
/* 174 */     for (byte b = 0; b < this.f.size(); b++) {
/* 175 */       ajm ajm = this.f.get(b);
/*     */       
/* 177 */       if (ajm.a.M || (!ajm.a.bK.c(paramwm) && !paramwm.z())) {
/* 178 */         this.i.remove(ajm.a);
/* 179 */         this.f.remove(ajm);
/* 180 */       } else if (!paramwm.z() && ajm.a.ar == this.c) {
/* 181 */         a(0, ajm.a.q, ajm.a.c_(), ajm.a.u, ajm.a.w, ajm.a.A);
/*     */       } 
/*     */     } 
/*     */     
/* 185 */     if (paramwm.z())
/* 186 */       a(1, paramsq.q, "frame-" + (paramwm.A()).k, (paramwm.A()).b, (paramwm.A()).d, ((paramwm.A()).a * 90)); 
/*     */   }
/*     */   
/*     */   private void a(int paramInt, aab paramaab, String paramString, double paramDouble1, double paramDouble2, double paramDouble3) {
/*     */     boolean bool;
/* 191 */     int i = 1 << this.d;
/* 192 */     float f1 = (float)(paramDouble1 - this.a) / i;
/* 193 */     float f2 = (float)(paramDouble2 - this.b) / i;
/* 194 */     byte b1 = (byte)(int)((f1 * 2.0F) + 0.5D);
/* 195 */     byte b2 = (byte)(int)((f2 * 2.0F) + 0.5D);
/*     */     
/* 197 */     byte b = 63;
/*     */     
/* 199 */     if (f1 >= -b && f2 >= -b && f1 <= b && f2 <= b) {
/* 200 */       paramDouble3 += (paramDouble3 < 0.0D) ? -8.0D : 8.0D;
/* 201 */       bool = (byte)(int)(paramDouble3 * 16.0D / 360.0D);
/*     */       
/* 203 */       if (this.c < 0) {
/* 204 */         int j = (int)(paramaab.M().g() / 10L);
/* 205 */         bool = (byte)(j * j * 34187121 + j * 121 >> 15 & 0xF);
/*     */       } 
/* 207 */     } else if (Math.abs(f1) < 320.0F && Math.abs(f2) < 320.0F) {
/* 208 */       paramInt = 6;
/* 209 */       bool = false;
/* 210 */       if (f1 <= -b) b1 = (byte)(int)((b * 2) + 2.5D); 
/* 211 */       if (f2 <= -b) b2 = (byte)(int)((b * 2) + 2.5D); 
/* 212 */       if (f1 >= b) b1 = (byte)(b * 2 + 1); 
/* 213 */       if (f2 >= b) b2 = (byte)(b * 2 + 1); 
/*     */     } else {
/* 215 */       this.g.remove(paramString);
/*     */       
/*     */       return;
/*     */     } 
/* 219 */     this.g.put(paramString, new ajn(this, (byte)paramInt, b1, b2, bool));
/*     */   }
/*     */   
/*     */   public byte[] a(wm paramwm, aab paramaab, sq paramsq) {
/* 223 */     ajm ajm = (ajm)this.i.get(paramsq);
/* 224 */     if (ajm == null) return null;
/*     */     
/* 226 */     return ajm.a(paramwm);
/*     */   }
/*     */   
/*     */   public void a(int paramInt1, int paramInt2, int paramInt3) {
/* 230 */     c();
/* 231 */     for (byte b = 0; b < this.f.size(); b++) {
/* 232 */       ajm ajm = this.f.get(b);
/* 233 */       if (ajm.b[paramInt1] < 0 || ajm.b[paramInt1] > paramInt2) ajm.b[paramInt1] = paramInt2; 
/* 234 */       if (ajm.c[paramInt1] < 0 || ajm.c[paramInt1] < paramInt3) ajm.c[paramInt1] = paramInt3; 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void a(byte[] paramArrayOfbyte) {
/* 239 */     if (paramArrayOfbyte[0] == 0) {
/* 240 */       int i = paramArrayOfbyte[1] & 0xFF;
/* 241 */       int j = paramArrayOfbyte[2] & 0xFF;
/* 242 */       for (byte b = 0; b < paramArrayOfbyte.length - 3; b++) {
/* 243 */         this.e[(b + j) * 128 + i] = paramArrayOfbyte[b + 3];
/*     */       }
/* 245 */       c();
/* 246 */     } else if (paramArrayOfbyte[0] == 1) {
/* 247 */       this.g.clear();
/* 248 */       for (byte b = 0; b < (paramArrayOfbyte.length - 1) / 3; b++) {
/* 249 */         byte b1 = (byte)(paramArrayOfbyte[b * 3 + 1] >> 4);
/* 250 */         byte b2 = paramArrayOfbyte[b * 3 + 2];
/* 251 */         byte b3 = paramArrayOfbyte[b * 3 + 3];
/* 252 */         byte b4 = (byte)(paramArrayOfbyte[b * 3 + 1] & 0xF);
/* 253 */         this.g.put("icon-" + b, new ajn(this, b1, b2, b3, b4));
/*     */       } 
/* 255 */     } else if (paramArrayOfbyte[0] == 2) {
/* 256 */       this.d = paramArrayOfbyte[1];
/*     */     } 
/*     */   }
/*     */   
/*     */   public ajm a(sq paramsq) {
/* 261 */     ajm ajm = (ajm)this.i.get(paramsq);
/*     */     
/* 263 */     if (ajm == null) {
/* 264 */       ajm = new ajm(this, paramsq);
/* 265 */       this.i.put(paramsq, ajm);
/* 266 */       this.f.add(ajm);
/*     */     } 
/*     */     
/* 269 */     return ajm;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */