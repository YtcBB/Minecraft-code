/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aks
/*    */   implements akf
/*    */ {
/*    */   public ajv d() {
/* 13 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void c() {}
/*    */   
/*    */   public acb a(acn paramacn) {
/* 20 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ajv paramajv, bs parambs) {}
/*    */ 
/*    */   
/*    */   public void a(ajv paramajv) {}
/*    */   
/*    */   public akt e() {
/* 30 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a() {}
/*    */   
/*    */   public File b(String paramString) {
/* 37 */     return null;
/*    */   }
/*    */   
/*    */   public String g() {
/* 41 */     return "none";
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aks.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */