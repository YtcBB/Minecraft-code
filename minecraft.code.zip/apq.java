/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class apq
/*    */   extends apa
/*    */ {
/*    */   public apq(int paramInt) {
/* 13 */     super(paramInt, aif.E);
/* 14 */     a(ve.c);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/* 19 */     parammp.al();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 24 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 29 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int d() {
/* 34 */     return 1;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean b() {
/* 43 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 49 */     return wk.L.cp;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean r_() {
/* 54 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */