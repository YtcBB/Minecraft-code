/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aon
/*    */   extends apa
/*    */ {
/* 16 */   public static final String[] a = new String[] { "default", "mossy", "cracked", "chiseled" };
/*    */ 
/*    */ 
/*    */   
/* 20 */   public static final String[] b = new String[] { "stonebricksmooth", "stonebricksmooth_mossy", "stonebricksmooth_cracked", "stonebricksmooth_carved" };
/*    */ 
/*    */   
/*    */   private lx[] c;
/*    */ 
/*    */   
/*    */   public aon(int paramInt) {
/* 27 */     super(paramInt, aif.e);
/* 28 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 33 */     if (paramInt2 < 0 || paramInt2 >= b.length) paramInt2 = 0; 
/* 34 */     return this.c[paramInt2];
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt) {
/* 39 */     return paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 44 */     for (byte b = 0; b < 4; b++) {
/* 45 */       paramList.add(new wm(paramInt, 1, b));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 51 */     this.c = new lx[b.length];
/*    */     
/* 53 */     for (byte b = 0; b < this.c.length; b++)
/* 54 */       this.c[b] = paramly.a(b[b]); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aon.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */