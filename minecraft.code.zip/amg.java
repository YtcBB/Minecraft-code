/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amg
/*     */   extends akz
/*     */ {
/*     */   protected amg(int paramInt) {
/*  28 */     super(paramInt, aif.e);
/*  29 */     a(ve.c);
/*     */     
/*  31 */     a(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  36 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  41 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  46 */     return 22;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  51 */     return apa.at.cz;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/*  56 */     return 8;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean r_() {
/*  61 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/*  67 */     byte b = 0;
/*  68 */     int i = kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3;
/*     */     
/*  70 */     if (i == 0) b = 2; 
/*  71 */     if (i == 1) b = 5; 
/*  72 */     if (i == 2) b = 3; 
/*  73 */     if (i == 3) b = 4;
/*     */     
/*  75 */     paramaab.b(paramInt1, paramInt2, paramInt3, b, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  80 */     uf uf = paramsq.cp();
/*  81 */     aqf aqf = (aqf)paramaab.r(paramInt1, paramInt2, paramInt3);
/*  82 */     if (uf == null || aqf == null) return true;
/*     */     
/*  84 */     if (paramaab.u(paramInt1, paramInt2 + 1, paramInt3)) return true;
/*     */     
/*  86 */     if (paramaab.I) {
/*  87 */       return true;
/*     */     }
/*     */     
/*  90 */     uf.a(aqf);
/*  91 */     paramsq.a(uf);
/*     */     
/*  93 */     return true;
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/*  97 */     return new aqf();
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 102 */     for (byte b = 0; b < 3; b++) {
/* 103 */       double d1 = (paramInt1 + paramRandom.nextFloat());
/* 104 */       double d2 = (paramInt2 + paramRandom.nextFloat());
/* 105 */       double d3 = (paramInt3 + paramRandom.nextFloat());
/* 106 */       double d4 = 0.0D;
/* 107 */       double d5 = 0.0D;
/* 108 */       double d6 = 0.0D;
/* 109 */       int i = paramRandom.nextInt(2) * 2 - 1;
/* 110 */       int j = paramRandom.nextInt(2) * 2 - 1;
/* 111 */       d4 = (paramRandom.nextFloat() - 0.5D) * 0.125D;
/* 112 */       d5 = (paramRandom.nextFloat() - 0.5D) * 0.125D;
/* 113 */       d6 = (paramRandom.nextFloat() - 0.5D) * 0.125D;
/* 114 */       d3 = paramInt3 + 0.5D + 0.25D * j;
/* 115 */       d6 = (paramRandom.nextFloat() * 1.0F * j);
/* 116 */       d1 = paramInt1 + 0.5D + 0.25D * i;
/* 117 */       d4 = (paramRandom.nextFloat() * 1.0F * i);
/*     */       
/* 119 */       paramaab.a("portal", d1, d2, d3, d4, d5, d6);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 127 */     this.cQ = paramly.a("obsidian");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */