/*    */ import java.util.Random;
/*    */ 
/*    */ public class aqe extends aqp {
/*    */   public int a;
/*    */   public float b;
/*    */   public float c;
/*    */   public float d;
/*    */   public float e;
/*    */   public float f;
/*    */   public float g;
/*    */   public float h;
/*    */   public float i;
/*    */   public float j;
/* 14 */   private static Random r = new Random();
/*    */   
/*    */   private String s;
/*    */   
/*    */   public void b(bs parambs) {
/* 19 */     super.b(parambs);
/* 20 */     if (b()) parambs.a("CustomName", this.s);
/*    */   
/*    */   }
/*    */   
/*    */   public void a(bs parambs) {
/* 25 */     super.a(parambs);
/* 26 */     if (parambs.b("CustomName")) this.s = parambs.i("CustomName");
/*    */   
/*    */   }
/*    */   
/*    */   public void h() {
/* 31 */     super.h();
/* 32 */     this.g = this.f;
/* 33 */     this.i = this.h;
/*    */     
/* 35 */     sq sq = this.k.a((this.l + 0.5F), (this.m + 0.5F), (this.n + 0.5F), 3.0D);
/* 36 */     if (sq != null) {
/* 37 */       double d1 = sq.u - (this.l + 0.5F);
/* 38 */       double d2 = sq.w - (this.n + 0.5F);
/*    */       
/* 40 */       this.j = (float)Math.atan2(d2, d1);
/*    */       
/* 42 */       this.f += 0.1F;
/*    */       
/* 44 */       if (this.f < 0.5F || r.nextInt(40) == 0) {
/* 45 */         float f = this.d;
/*    */         do {
/* 47 */           this.d += (r.nextInt(4) - r.nextInt(4));
/* 48 */         } while (f == this.d);
/*    */       } 
/*    */     } else {
/*    */       
/* 52 */       this.j += 0.02F;
/* 53 */       this.f -= 0.1F;
/*    */     } 
/*    */     
/* 56 */     while (this.h >= 3.1415927F)
/* 57 */       this.h -= 6.2831855F; 
/* 58 */     while (this.h < -3.1415927F)
/* 59 */       this.h += 6.2831855F; 
/* 60 */     while (this.j >= 3.1415927F)
/* 61 */       this.j -= 6.2831855F; 
/* 62 */     while (this.j < -3.1415927F)
/* 63 */       this.j += 6.2831855F; 
/* 64 */     float f1 = this.j - this.h;
/* 65 */     while (f1 >= 3.1415927F)
/* 66 */       f1 -= 6.2831855F; 
/* 67 */     while (f1 < -3.1415927F) {
/* 68 */       f1 += 6.2831855F;
/*    */     }
/* 70 */     this.h += f1 * 0.4F;
/*    */     
/* 72 */     if (this.f < 0.0F) this.f = 0.0F; 
/* 73 */     if (this.f > 1.0F) this.f = 1.0F;
/*    */     
/* 75 */     this.a++;
/* 76 */     this.c = this.b;
/*    */     
/* 78 */     float f2 = (this.d - this.b) * 0.4F;
/* 79 */     float f3 = 0.2F;
/* 80 */     if (f2 < -f3) f2 = -f3; 
/* 81 */     if (f2 > f3) f2 = f3; 
/* 82 */     this.e += (f2 - this.e) * 0.9F;
/*    */     
/* 84 */     this.b += this.e;
/*    */   }
/*    */   
/*    */   public String a() {
/* 88 */     return b() ? this.s : "container.enchant";
/*    */   }
/*    */   
/*    */   public boolean b() {
/* 92 */     return (this.s != null && this.s.length() > 0);
/*    */   }
/*    */   
/*    */   public void a(String paramString) {
/* 96 */     this.s = paramString;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqe.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */