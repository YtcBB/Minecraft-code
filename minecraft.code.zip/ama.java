/*   */ 
/*   */ 
/*   */ 
/*   */ public class ama
/*   */   extends apa
/*   */ {
/*   */   protected ama(int paramInt) {
/* 8 */     super(paramInt, aif.c);
/* 9 */     a(ve.b);
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ama.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */