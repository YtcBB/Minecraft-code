/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class abn
/*    */   extends aav
/*    */ {
/*    */   protected abn(int paramInt) {
/* 11 */     super(paramInt);
/* 12 */     this.I.z = 2;
/* 13 */     this.I.A = -999;
/* 14 */     this.I.C = 1;
/* 15 */     this.I.D = 8;
/* 16 */     this.I.E = 10;
/* 17 */     this.I.I = 1;
/* 18 */     this.I.y = 4;
/*    */     
/* 20 */     this.H = 14745518;
/*    */     
/* 22 */     this.J.add(new aaw(sg.class, 1, 1, 1));
/*    */   }
/*    */ 
/*    */   
/*    */   public adj a(Random paramRandom) {
/* 27 */     return this.R;
/*    */   }
/*    */ 
/*    */   
/*    */   public int k() {
/* 32 */     double d1 = j();
/* 33 */     double d2 = i();
/*    */     
/* 35 */     return ((aaa.a(d1, d2) & 0xFEFEFE) + 5115470) / 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public int l() {
/* 40 */     double d1 = j();
/* 41 */     double d2 = i();
/*    */     
/* 43 */     return ((zx.a(d1, d2) & 0xFEFEFE) + 5115470) / 2;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */