/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amz
/*     */   extends apa
/*     */ {
/*     */   protected amz(int paramInt) {
/*  12 */     super(paramInt, aif.q);
/*  13 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  18 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  19 */     return super.b(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  24 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  25 */     return super.c_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  30 */     c(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   public void c(int paramInt) {
/*  34 */     int i = paramInt;
/*  35 */     float f = 0.125F;
/*     */     
/*  37 */     if (i == 2) a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F); 
/*  38 */     if (i == 3) a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f); 
/*  39 */     if (i == 4) a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); 
/*  40 */     if (i == 5) a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
/*     */   
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  49 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  54 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  59 */     return 8;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  64 */     if (paramaab.u(paramInt1 - 1, paramInt2, paramInt3))
/*  65 */       return true; 
/*  66 */     if (paramaab.u(paramInt1 + 1, paramInt2, paramInt3))
/*  67 */       return true; 
/*  68 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 - 1))
/*  69 */       return true; 
/*  70 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) {
/*  71 */       return true;
/*     */     }
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  78 */     int i = paramInt5;
/*     */     
/*  80 */     if ((i == 0 || paramInt4 == 2) && paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) i = 2; 
/*  81 */     if ((i == 0 || paramInt4 == 3) && paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) i = 3; 
/*  82 */     if ((i == 0 || paramInt4 == 4) && paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) i = 4; 
/*  83 */     if ((i == 0 || paramInt4 == 5) && paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) i = 5;
/*     */     
/*  85 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  90 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  91 */     boolean bool = false;
/*     */     
/*  93 */     if (i == 2 && paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) bool = true; 
/*  94 */     if (i == 3 && paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) bool = true; 
/*  95 */     if (i == 4 && paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) bool = true; 
/*  96 */     if (i == 5 && paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) bool = true; 
/*  97 */     if (!bool) {
/*  98 */       c(paramaab, paramInt1, paramInt2, paramInt3, i, 0);
/*  99 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/* 102 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 107 */     return 1;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */