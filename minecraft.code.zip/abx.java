/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class abx
/*     */ {
/*     */   private int a;
/*     */   private int b;
/*     */   private int c;
/*     */   private byte[] d;
/*     */   private abu e;
/*     */   private abu f;
/*     */   private abu g;
/*     */   private abu h;
/*     */   
/*     */   public abx(int paramInt, boolean paramBoolean) {
/*  21 */     this.a = paramInt;
/*  22 */     this.d = new byte[4096];
/*  23 */     this.f = new abu(this.d.length, 4);
/*  24 */     this.g = new abu(this.d.length, 4);
/*  25 */     if (paramBoolean) {
/*  26 */       this.h = new abu(this.d.length, 4);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, int paramInt2, int paramInt3) {
/*  32 */     int i = this.d[paramInt2 << 8 | paramInt3 << 4 | paramInt1] & 0xFF;
/*  33 */     if (this.e != null) {
/*  34 */       return this.e.a(paramInt1, paramInt2, paramInt3) << 8 | i;
/*     */     }
/*  36 */     return i;
/*     */   }
/*     */   
/*     */   public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  40 */     int i = this.d[paramInt2 << 8 | paramInt3 << 4 | paramInt1] & 0xFF;
/*  41 */     if (this.e != null) {
/*  42 */       i = this.e.a(paramInt1, paramInt2, paramInt3) << 8 | i;
/*     */     }
/*  44 */     if (i == 0 && paramInt4 != 0) {
/*  45 */       this.b++;
/*     */       
/*  47 */       if (apa.r[paramInt4] != null && apa.r[paramInt4].s()) {
/*  48 */         this.c++;
/*     */       }
/*  50 */     } else if (i != 0 && paramInt4 == 0) {
/*  51 */       this.b--;
/*     */       
/*  53 */       if (apa.r[i] != null && apa.r[i].s()) {
/*  54 */         this.c--;
/*     */       }
/*     */     }
/*  57 */     else if (apa.r[i] != null && apa.r[i].s() && (apa.r[paramInt4] == null || !apa.r[paramInt4].s())) {
/*  58 */       this.c--;
/*  59 */     } else if ((apa.r[i] == null || !apa.r[i].s()) && apa.r[paramInt4] != null && apa.r[paramInt4].s()) {
/*  60 */       this.c++;
/*     */     } 
/*     */     
/*  63 */     this.d[paramInt2 << 8 | paramInt3 << 4 | paramInt1] = (byte)(paramInt4 & 0xFF);
/*  64 */     if (paramInt4 > 255) {
/*  65 */       if (this.e == null) {
/*  66 */         this.e = new abu(this.d.length, 4);
/*     */       }
/*  68 */       this.e.a(paramInt1, paramInt2, paramInt3, (paramInt4 & 0xF00) >> 8);
/*  69 */     } else if (this.e != null) {
/*  70 */       this.e.a(paramInt1, paramInt2, paramInt3, 0);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int b(int paramInt1, int paramInt2, int paramInt3) {
/*  75 */     return this.f.a(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public void b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  79 */     this.f.a(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public boolean a() {
/*  83 */     return (this.b == 0);
/*     */   }
/*     */   
/*     */   public boolean b() {
/*  87 */     return (this.c > 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int d() {
/*  95 */     return this.a;
/*     */   }
/*     */   
/*     */   public void c(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  99 */     this.h.a(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public int c(int paramInt1, int paramInt2, int paramInt3) {
/* 103 */     return this.h.a(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public void d(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 107 */     this.g.a(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public int d(int paramInt1, int paramInt2, int paramInt3) {
/* 111 */     return this.g.a(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public void e() {
/* 115 */     this.b = 0;
/* 116 */     this.c = 0;
/*     */     
/* 118 */     for (byte b = 0; b < 16; b++) {
/* 119 */       for (byte b1 = 0; b1 < 16; b1++) {
/* 120 */         for (byte b2 = 0; b2 < 16; b2++) {
/* 121 */           int i = a(b, b1, b2);
/* 122 */           if (i > 0) {
/* 123 */             if (apa.r[i] == null) {
/* 124 */               this.d[b1 << 8 | b2 << 4 | b] = 0;
/* 125 */               if (this.e != null) {
/* 126 */                 this.e.a(b, b1, b2, 0);
/*     */               }
/*     */             } else {
/* 129 */               this.b++;
/* 130 */               if (apa.r[i].s()) {
/* 131 */                 this.c++;
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public byte[] g() {
/* 145 */     return this.d;
/*     */   }
/*     */   
/*     */   public void h() {
/* 149 */     this.e = null;
/*     */   }
/*     */   
/*     */   public abu i() {
/* 153 */     return this.e;
/*     */   }
/*     */   
/*     */   public abu j() {
/* 157 */     return this.f;
/*     */   }
/*     */   
/*     */   public abu k() {
/* 161 */     return this.g;
/*     */   }
/*     */   
/*     */   public abu l() {
/* 165 */     return this.h;
/*     */   }
/*     */   
/*     */   public void a(byte[] paramArrayOfbyte) {
/* 169 */     this.d = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   public void a(abu paramabu) {
/* 173 */     this.e = paramabu;
/*     */   }
/*     */   
/*     */   public void b(abu paramabu) {
/* 177 */     this.f = paramabu;
/*     */   }
/*     */   
/*     */   public void c(abu paramabu) {
/* 181 */     this.g = paramabu;
/*     */   }
/*     */   
/*     */   public void d(abu paramabu) {
/* 185 */     this.h = paramabu;
/*     */   }
/*     */   
/*     */   public abu m() {
/* 189 */     this.e = new abu(this.d.length, 4);
/* 190 */     return this.e;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abx.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */