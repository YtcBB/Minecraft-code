/*    */ import java.util.List;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ak
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 17 */     return "give";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 22 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 27 */     return paramab.a("commands.give.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 31 */     if (paramArrayOfString.length >= 2) {
/* 32 */       jc jc = c(paramab, paramArrayOfString[0]);
/*    */       
/* 34 */       int i = a(paramab, paramArrayOfString[1], 1);
/* 35 */       int j = 1;
/* 36 */       int k = 0;
/*    */       
/* 38 */       if (wk.f[i] == null) {
/* 39 */         throw new at("commands.give.notFound", new Object[] { Integer.valueOf(i) });
/*    */       }
/*    */       
/* 42 */       if (paramArrayOfString.length >= 3) {
/* 43 */         j = a(paramab, paramArrayOfString[2], 1, 64);
/*    */       }
/*    */       
/* 46 */       if (paramArrayOfString.length >= 4) {
/* 47 */         k = a(paramab, paramArrayOfString[3]);
/*    */       }
/*    */       
/* 50 */       wm wm = new wm(i, j, k);
/* 51 */       rh rh = jc.c(wm);
/* 52 */       rh.b = 0;
/*    */       
/* 54 */       a(paramab, "commands.give.success", new Object[] { wk.f[i].k(wm), Integer.valueOf(i), Integer.valueOf(j), jc.am() });
/*    */       
/*    */       return;
/*    */     } 
/* 58 */     throw new ax("commands.give.usage", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public List a(ab paramab, String[] paramArrayOfString) {
/* 63 */     if (paramArrayOfString.length == 1) {
/* 64 */       return a(paramArrayOfString, d());
/*    */     }
/*    */     
/* 67 */     return null;
/*    */   }
/*    */   
/*    */   protected String[] d() {
/* 71 */     return MinecraftServer.D().A();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(String[] paramArrayOfString, int paramInt) {
/* 76 */     return (paramInt == 0);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ak.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */