/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adl
/*    */   extends adj
/*    */ {
/*    */   private int a;
/*    */   private int b;
/*    */   
/*    */   public adl(int paramInt1, int paramInt2) {
/* 13 */     this.b = paramInt1;
/* 14 */     this.a = paramInt2;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 19 */     int i = 0;
/* 20 */     while (((i = paramaab.a(paramInt1, paramInt2, paramInt3)) == 0 || i == apa.O.cz) && paramInt2 > 0) {
/* 21 */       paramInt2--;
/*    */     }
/* 23 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3);
/* 24 */     if (j == apa.z.cz || j == apa.y.cz) {
/* 25 */       paramInt2++;
/* 26 */       a(paramaab, paramInt1, paramInt2, paramInt3, apa.N.cz, this.b);
/*    */       
/* 28 */       for (int k = paramInt2; k <= paramInt2 + 2; k++) {
/* 29 */         int m = k - paramInt2;
/* 30 */         int n = 2 - m;
/* 31 */         for (int i1 = paramInt1 - n; i1 <= paramInt1 + n; i1++) {
/* 32 */           int i2 = i1 - paramInt1;
/* 33 */           for (int i3 = paramInt3 - n; i3 <= paramInt3 + n; i3++) {
/* 34 */             int i4 = i3 - paramInt3;
/* 35 */             if ((Math.abs(i2) != n || Math.abs(i4) != n || paramRandom.nextInt(2) != 0) && 
/* 36 */               !apa.s[paramaab.a(i1, k, i3)])
/* 37 */               a(paramaab, i1, k, i3, apa.O.cz, this.a); 
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/* 42 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */