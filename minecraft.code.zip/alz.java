/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class alz
/*    */   extends apa
/*    */ {
/*    */   protected alz(int paramInt, aif paramaif) {
/* 11 */     super(paramInt, paramaif);
/*    */   }
/*    */   
/*    */   public static int j(int paramInt) {
/* 15 */     return paramInt & 0x3;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */