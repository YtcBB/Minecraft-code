/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class afr
/*     */   extends aft
/*     */ {
/*     */   private boolean h;
/*     */   private boolean i;
/*     */   private boolean j;
/*     */   private boolean k;
/* 307 */   private static final lp[] l = new lp[] { new lp(wk.o.cp, 0, 1, 3, 3), new lp(wk.p.cp, 0, 1, 5, 10), new lp(wk.q.cp, 0, 2, 7, 15), new lp(wk.bI.cp, 0, 1, 3, 2), new lp(wk.aY.cp, 0, 4, 6, 20), new lp(wk.bn.cp, 0, 3, 7, 16) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 315 */   private static final lp[] m = new lp[] { new lp(wk.m.cp, 0, 2, 7, 30) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public afr(Random paramRandom, int paramInt1, int paramInt2) {
/* 322 */     super(paramRandom, paramInt1, 64, paramInt2, 12, 10, 15);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 328 */     if (!a(paramaab, paramaek, 0)) {
/* 329 */       return false;
/*     */     }
/*     */     
/* 332 */     int i = c(apa.aL.cz, 3);
/* 333 */     int j = c(apa.aL.cz, 2);
/* 334 */     int k = c(apa.aL.cz, 0);
/* 335 */     int m = c(apa.aL.cz, 1);
/*     */ 
/*     */     
/* 338 */     a(paramaab, paramaek, 0, -4, 0, this.a - 1, 0, this.c - 1, false, paramRandom, n);
/*     */ 
/*     */     
/* 341 */     a(paramaab, paramaek, 2, 1, 2, 9, 2, 2, false, paramRandom, n);
/* 342 */     a(paramaab, paramaek, 2, 1, 12, 9, 2, 12, false, paramRandom, n);
/* 343 */     a(paramaab, paramaek, 2, 1, 3, 2, 2, 11, false, paramRandom, n);
/* 344 */     a(paramaab, paramaek, 9, 1, 3, 9, 2, 11, false, paramRandom, n);
/*     */ 
/*     */     
/* 347 */     a(paramaab, paramaek, 1, 3, 1, 10, 6, 1, false, paramRandom, n);
/* 348 */     a(paramaab, paramaek, 1, 3, 13, 10, 6, 13, false, paramRandom, n);
/* 349 */     a(paramaab, paramaek, 1, 3, 2, 1, 6, 12, false, paramRandom, n);
/* 350 */     a(paramaab, paramaek, 10, 3, 2, 10, 6, 12, false, paramRandom, n);
/*     */ 
/*     */     
/* 353 */     a(paramaab, paramaek, 2, 3, 2, 9, 3, 12, false, paramRandom, n);
/* 354 */     a(paramaab, paramaek, 2, 6, 2, 9, 6, 12, false, paramRandom, n);
/* 355 */     a(paramaab, paramaek, 3, 7, 3, 8, 7, 11, false, paramRandom, n);
/* 356 */     a(paramaab, paramaek, 4, 8, 4, 7, 8, 10, false, paramRandom, n);
/*     */ 
/*     */     
/* 359 */     a(paramaab, paramaek, 3, 1, 3, 8, 2, 11);
/* 360 */     a(paramaab, paramaek, 4, 3, 6, 7, 3, 9);
/* 361 */     a(paramaab, paramaek, 2, 4, 2, 9, 5, 12);
/* 362 */     a(paramaab, paramaek, 4, 6, 5, 7, 6, 9);
/* 363 */     a(paramaab, paramaek, 5, 7, 6, 6, 7, 8);
/*     */ 
/*     */     
/* 366 */     a(paramaab, paramaek, 5, 1, 2, 6, 2, 2);
/* 367 */     a(paramaab, paramaek, 5, 2, 12, 6, 2, 12);
/* 368 */     a(paramaab, paramaek, 5, 5, 1, 6, 5, 1);
/* 369 */     a(paramaab, paramaek, 5, 5, 13, 6, 5, 13);
/* 370 */     a(paramaab, 0, 0, 1, 5, 5, paramaek);
/* 371 */     a(paramaab, 0, 0, 10, 5, 5, paramaek);
/* 372 */     a(paramaab, 0, 0, 1, 5, 9, paramaek);
/* 373 */     a(paramaab, 0, 0, 10, 5, 9, paramaek);
/*     */     
/*     */     byte b;
/* 376 */     for (b = 0; b <= 14; b += 14) {
/* 377 */       a(paramaab, paramaek, 2, 4, b, 2, 5, b, false, paramRandom, n);
/* 378 */       a(paramaab, paramaek, 4, 4, b, 4, 5, b, false, paramRandom, n);
/* 379 */       a(paramaab, paramaek, 7, 4, b, 7, 5, b, false, paramRandom, n);
/* 380 */       a(paramaab, paramaek, 9, 4, b, 9, 5, b, false, paramRandom, n);
/*     */     } 
/* 382 */     a(paramaab, paramaek, 5, 6, 0, 6, 6, 0, false, paramRandom, n);
/* 383 */     for (b = 0; b <= 11; b += 11) {
/* 384 */       for (byte b1 = 2; b1 <= 12; b1 += 2) {
/* 385 */         a(paramaab, paramaek, b, 4, b1, b, 5, b1, false, paramRandom, n);
/*     */       }
/* 387 */       a(paramaab, paramaek, b, 6, 5, b, 6, 5, false, paramRandom, n);
/* 388 */       a(paramaab, paramaek, b, 6, 9, b, 6, 9, false, paramRandom, n);
/*     */     } 
/* 390 */     a(paramaab, paramaek, 2, 7, 2, 2, 9, 2, false, paramRandom, n);
/* 391 */     a(paramaab, paramaek, 9, 7, 2, 9, 9, 2, false, paramRandom, n);
/* 392 */     a(paramaab, paramaek, 2, 7, 12, 2, 9, 12, false, paramRandom, n);
/* 393 */     a(paramaab, paramaek, 9, 7, 12, 9, 9, 12, false, paramRandom, n);
/* 394 */     a(paramaab, paramaek, 4, 9, 4, 4, 9, 4, false, paramRandom, n);
/* 395 */     a(paramaab, paramaek, 7, 9, 4, 7, 9, 4, false, paramRandom, n);
/* 396 */     a(paramaab, paramaek, 4, 9, 10, 4, 9, 10, false, paramRandom, n);
/* 397 */     a(paramaab, paramaek, 7, 9, 10, 7, 9, 10, false, paramRandom, n);
/* 398 */     a(paramaab, paramaek, 5, 9, 7, 6, 9, 7, false, paramRandom, n);
/* 399 */     a(paramaab, apa.aL.cz, i, 5, 9, 6, paramaek);
/* 400 */     a(paramaab, apa.aL.cz, i, 6, 9, 6, paramaek);
/* 401 */     a(paramaab, apa.aL.cz, j, 5, 9, 8, paramaek);
/* 402 */     a(paramaab, apa.aL.cz, j, 6, 9, 8, paramaek);
/*     */ 
/*     */     
/* 405 */     a(paramaab, apa.aL.cz, i, 4, 0, 0, paramaek);
/* 406 */     a(paramaab, apa.aL.cz, i, 5, 0, 0, paramaek);
/* 407 */     a(paramaab, apa.aL.cz, i, 6, 0, 0, paramaek);
/* 408 */     a(paramaab, apa.aL.cz, i, 7, 0, 0, paramaek);
/*     */ 
/*     */     
/* 411 */     a(paramaab, apa.aL.cz, i, 4, 1, 8, paramaek);
/* 412 */     a(paramaab, apa.aL.cz, i, 4, 2, 9, paramaek);
/* 413 */     a(paramaab, apa.aL.cz, i, 4, 3, 10, paramaek);
/* 414 */     a(paramaab, apa.aL.cz, i, 7, 1, 8, paramaek);
/* 415 */     a(paramaab, apa.aL.cz, i, 7, 2, 9, paramaek);
/* 416 */     a(paramaab, apa.aL.cz, i, 7, 3, 10, paramaek);
/* 417 */     a(paramaab, paramaek, 4, 1, 9, 4, 1, 9, false, paramRandom, n);
/* 418 */     a(paramaab, paramaek, 7, 1, 9, 7, 1, 9, false, paramRandom, n);
/* 419 */     a(paramaab, paramaek, 4, 1, 10, 7, 2, 10, false, paramRandom, n);
/*     */ 
/*     */     
/* 422 */     a(paramaab, paramaek, 5, 4, 5, 6, 4, 5, false, paramRandom, n);
/* 423 */     a(paramaab, apa.aL.cz, k, 4, 4, 5, paramaek);
/* 424 */     a(paramaab, apa.aL.cz, m, 7, 4, 5, paramaek);
/*     */ 
/*     */     
/* 427 */     for (b = 0; b < 4; b++) {
/* 428 */       a(paramaab, apa.aL.cz, j, 5, 0 - b, 6 + b, paramaek);
/* 429 */       a(paramaab, apa.aL.cz, j, 6, 0 - b, 6 + b, paramaek);
/* 430 */       a(paramaab, paramaek, 5, 0 - b, 7 + b, 6, 0 - b, 9 + b);
/*     */     } 
/*     */ 
/*     */     
/* 434 */     a(paramaab, paramaek, 1, -3, 12, 10, -1, 13);
/* 435 */     a(paramaab, paramaek, 1, -3, 1, 3, -1, 13);
/* 436 */     a(paramaab, paramaek, 1, -3, 1, 9, -1, 5);
/* 437 */     for (b = 1; b <= 13; b += 2) {
/* 438 */       a(paramaab, paramaek, 1, -3, b, 1, -2, b, false, paramRandom, n);
/*     */     }
/* 440 */     for (b = 2; b <= 12; b += 2) {
/* 441 */       a(paramaab, paramaek, 1, -1, b, 3, -1, b, false, paramRandom, n);
/*     */     }
/* 443 */     a(paramaab, paramaek, 2, -2, 1, 5, -2, 1, false, paramRandom, n);
/* 444 */     a(paramaab, paramaek, 7, -2, 1, 9, -2, 1, false, paramRandom, n);
/* 445 */     a(paramaab, paramaek, 6, -3, 1, 6, -3, 1, false, paramRandom, n);
/* 446 */     a(paramaab, paramaek, 6, -1, 1, 6, -1, 1, false, paramRandom, n);
/*     */ 
/*     */     
/* 449 */     a(paramaab, apa.bX.cz, c(apa.bX.cz, 3) | 0x4, 1, -3, 8, paramaek);
/* 450 */     a(paramaab, apa.bX.cz, c(apa.bX.cz, 1) | 0x4, 4, -3, 8, paramaek);
/* 451 */     a(paramaab, apa.bY.cz, 4, 2, -3, 8, paramaek);
/* 452 */     a(paramaab, apa.bY.cz, 4, 3, -3, 8, paramaek);
/* 453 */     a(paramaab, apa.az.cz, 0, 5, -3, 7, paramaek);
/* 454 */     a(paramaab, apa.az.cz, 0, 5, -3, 6, paramaek);
/* 455 */     a(paramaab, apa.az.cz, 0, 5, -3, 5, paramaek);
/* 456 */     a(paramaab, apa.az.cz, 0, 5, -3, 4, paramaek);
/* 457 */     a(paramaab, apa.az.cz, 0, 5, -3, 3, paramaek);
/* 458 */     a(paramaab, apa.az.cz, 0, 5, -3, 2, paramaek);
/* 459 */     a(paramaab, apa.az.cz, 0, 5, -3, 1, paramaek);
/* 460 */     a(paramaab, apa.az.cz, 0, 4, -3, 1, paramaek);
/* 461 */     a(paramaab, apa.as.cz, 0, 3, -3, 1, paramaek);
/* 462 */     if (!this.j) {
/* 463 */       this.j = a(paramaab, paramaek, paramRandom, 3, -2, 1, 2, m, 2);
/*     */     }
/* 465 */     a(paramaab, apa.by.cz, 15, 3, -2, 2, paramaek);
/*     */ 
/*     */     
/* 468 */     a(paramaab, apa.bX.cz, c(apa.bX.cz, 2) | 0x4, 7, -3, 1, paramaek);
/* 469 */     a(paramaab, apa.bX.cz, c(apa.bX.cz, 0) | 0x4, 7, -3, 5, paramaek);
/* 470 */     a(paramaab, apa.bY.cz, 4, 7, -3, 2, paramaek);
/* 471 */     a(paramaab, apa.bY.cz, 4, 7, -3, 3, paramaek);
/* 472 */     a(paramaab, apa.bY.cz, 4, 7, -3, 4, paramaek);
/* 473 */     a(paramaab, apa.az.cz, 0, 8, -3, 6, paramaek);
/* 474 */     a(paramaab, apa.az.cz, 0, 9, -3, 6, paramaek);
/* 475 */     a(paramaab, apa.az.cz, 0, 9, -3, 5, paramaek);
/* 476 */     a(paramaab, apa.as.cz, 0, 9, -3, 4, paramaek);
/* 477 */     a(paramaab, apa.az.cz, 0, 9, -2, 4, paramaek);
/* 478 */     if (!this.k) {
/* 479 */       this.k = a(paramaab, paramaek, paramRandom, 9, -2, 3, 4, m, 2);
/*     */     }
/* 481 */     a(paramaab, apa.by.cz, 15, 8, -1, 3, paramaek);
/* 482 */     a(paramaab, apa.by.cz, 15, 8, -2, 3, paramaek);
/* 483 */     if (!this.h) {
/* 484 */       this.h = a(paramaab, paramaek, paramRandom, 8, -3, 3, lp.a(l, new lp[] { wk.bX.b(paramRandom) }), 2 + paramRandom.nextInt(5));
/*     */     }
/* 486 */     a(paramaab, apa.as.cz, 0, 9, -3, 2, paramaek);
/* 487 */     a(paramaab, apa.as.cz, 0, 8, -3, 1, paramaek);
/* 488 */     a(paramaab, apa.as.cz, 0, 4, -3, 5, paramaek);
/* 489 */     a(paramaab, apa.as.cz, 0, 5, -2, 5, paramaek);
/* 490 */     a(paramaab, apa.as.cz, 0, 5, -1, 5, paramaek);
/* 491 */     a(paramaab, apa.as.cz, 0, 6, -3, 5, paramaek);
/* 492 */     a(paramaab, apa.as.cz, 0, 7, -2, 5, paramaek);
/* 493 */     a(paramaab, apa.as.cz, 0, 7, -1, 5, paramaek);
/* 494 */     a(paramaab, apa.as.cz, 0, 8, -3, 5, paramaek);
/* 495 */     a(paramaab, paramaek, 9, -1, 1, 9, -1, 5, false, paramRandom, n);
/*     */ 
/*     */     
/* 498 */     a(paramaab, paramaek, 8, -3, 8, 10, -1, 10);
/* 499 */     a(paramaab, apa.bq.cz, 3, 8, -2, 11, paramaek);
/* 500 */     a(paramaab, apa.bq.cz, 3, 9, -2, 11, paramaek);
/* 501 */     a(paramaab, apa.bq.cz, 3, 10, -2, 11, paramaek);
/* 502 */     a(paramaab, apa.aN.cz, anc.d(c(apa.aN.cz, 2)), 8, -2, 12, paramaek);
/* 503 */     a(paramaab, apa.aN.cz, anc.d(c(apa.aN.cz, 2)), 9, -2, 12, paramaek);
/* 504 */     a(paramaab, apa.aN.cz, anc.d(c(apa.aN.cz, 2)), 10, -2, 12, paramaek);
/* 505 */     a(paramaab, paramaek, 8, -3, 8, 8, -3, 10, false, paramRandom, n);
/* 506 */     a(paramaab, paramaek, 10, -3, 8, 10, -3, 10, false, paramRandom, n);
/* 507 */     a(paramaab, apa.as.cz, 0, 10, -2, 9, paramaek);
/* 508 */     a(paramaab, apa.az.cz, 0, 8, -2, 9, paramaek);
/* 509 */     a(paramaab, apa.az.cz, 0, 8, -2, 10, paramaek);
/* 510 */     a(paramaab, apa.az.cz, 0, 10, -1, 9, paramaek);
/* 511 */     a(paramaab, apa.Z.cz, 1, 9, -2, 8, paramaek);
/* 512 */     a(paramaab, apa.Z.cz, c(apa.Z.cz, 4), 10, -2, 8, paramaek);
/* 513 */     a(paramaab, apa.Z.cz, c(apa.Z.cz, 4), 10, -1, 8, paramaek);
/* 514 */     a(paramaab, apa.bl.cz, c(apa.bl.cz, 2), 10, -2, 10, paramaek);
/* 515 */     if (!this.i) {
/* 516 */       this.i = a(paramaab, paramaek, paramRandom, 9, -3, 10, lp.a(l, new lp[] { wk.bX.b(paramRandom) }), 2 + paramRandom.nextInt(5));
/*     */     }
/*     */ 
/*     */     
/* 520 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 535 */   private static afs n = new afs(null);
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */