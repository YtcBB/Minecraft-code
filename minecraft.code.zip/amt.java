/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class amt
/*    */   extends apa
/*    */ {
/*    */   public static boolean c = false;
/*    */   
/*    */   public amt(int paramInt) {
/* 14 */     super(paramInt, aif.p);
/* 15 */     a(ve.b);
/*    */   }
/*    */   
/*    */   public amt(int paramInt, aif paramaif) {
/* 19 */     super(paramInt, paramaif);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 24 */     paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 29 */     paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 34 */     if (!paramaab.I) {
/* 35 */       k(paramaab, paramInt1, paramInt2, paramInt3);
/*    */     }
/*    */   }
/*    */   
/*    */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 40 */     int i = paramInt1;
/* 41 */     int j = paramInt2;
/* 42 */     int k = paramInt3;
/* 43 */     if (a_(paramaab, i, j - 1, k) && j >= 0) {
/* 44 */       byte b = 32;
/* 45 */       if (c || !paramaab.e(paramInt1 - b, paramInt2 - b, paramInt3 - b, paramInt1 + b, paramInt2 + b, paramInt3 + b)) {
/* 46 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/* 47 */         while (a_(paramaab, paramInt1, paramInt2 - 1, paramInt3) && paramInt2 > 0)
/* 48 */           paramInt2--; 
/* 49 */         if (paramInt2 > 0) {
/* 50 */           paramaab.c(paramInt1, paramInt2, paramInt3, this.cz);
/*    */         }
/* 52 */       } else if (!paramaab.I) {
/* 53 */         rg rg = new rg(paramaab, (paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), this.cz, paramaab.h(paramInt1, paramInt2, paramInt3));
/* 54 */         a(rg);
/* 55 */         paramaab.d(rg);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected void a(rg paramrg) {}
/*    */ 
/*    */   
/*    */   public int a(aab paramaab) {
/* 65 */     return 2;
/*    */   }
/*    */   
/*    */   public static boolean a_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 69 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3);
/* 70 */     if (i == 0) return true; 
/* 71 */     if (i == apa.av.cz) return true; 
/* 72 */     aif aif = (apa.r[i]).cO;
/* 73 */     if (aif == aif.h) return true; 
/* 74 */     if (aif == aif.i) return true; 
/* 75 */     return false;
/*    */   }
/*    */   
/*    */   public void a_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */