/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class abi
/*    */   extends aav
/*    */ {
/*    */   public abi(int paramInt) {
/*  9 */     super(paramInt);
/*    */     
/* 11 */     this.I.z = -100;
/* 12 */     this.I.A = -100;
/* 13 */     this.I.B = -100;
/*    */     
/* 15 */     this.I.D = 1;
/* 16 */     this.I.J = 1;
/*    */     
/* 18 */     this.A = (byte)apa.bC.cz;
/*    */     
/* 20 */     this.J.clear();
/* 21 */     this.K.clear();
/* 22 */     this.L.clear();
/*    */     
/* 24 */     this.K.add(new aaw(ql.class, 8, 4, 8));
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */