/*    */ import java.util.ArrayList;
/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aes
/*    */   extends ags
/*    */ {
/* 11 */   private List e = new ArrayList();
/*    */ 
/*    */ 
/*    */   
/*    */   public aes() {
/* 16 */     this.e.add(new aaw(rs.class, 10, 2, 3));
/* 17 */     this.e.add(new aaw(sc.class, 5, 4, 4));
/* 18 */     this.e.add(new aaw(sf.class, 10, 4, 4));
/* 19 */     this.e.add(new aaw(sa.class, 3, 4, 4));
/*    */   }
/*    */   
/*    */   public List a() {
/* 23 */     return this.e;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected boolean a(int paramInt1, int paramInt2) {
/* 29 */     int i = paramInt1 >> 4;
/* 30 */     int j = paramInt2 >> 4;
/*    */     
/* 32 */     this.b.setSeed((i ^ j << 4) ^ this.c.G());
/* 33 */     this.b.nextInt();
/*    */     
/* 35 */     if (this.b.nextInt(3) != 0) {
/* 36 */       return false;
/*    */     }
/* 38 */     if (paramInt1 != (i << 4) + 4 + this.b.nextInt(8)) {
/* 39 */       return false;
/*    */     }
/* 41 */     if (paramInt2 != (j << 4) + 4 + this.b.nextInt(8)) {
/* 42 */       return false;
/*    */     }
/* 44 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   protected agy b(int paramInt1, int paramInt2) {
/* 49 */     return new aet(this.c, this.b, paramInt1, paramInt2);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aes.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */