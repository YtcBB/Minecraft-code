/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class alw
/*    */   extends alh
/*    */ {
/*    */   protected alw(int paramInt) {
/* 13 */     super(paramInt, aif.l);
/* 14 */     float f = 0.4F;
/* 15 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.8F, 0.5F + f);
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean f_(int paramInt) {
/* 20 */     return (paramInt == apa.I.cz);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 25 */     return -1;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 30 */     if (!paramaab.I && paramsq.cd() != null && (paramsq.cd()).c == wk.bf.cp) {
/* 31 */       paramsq.a(kf.C[this.cz], 1);
/*    */ 
/*    */       
/* 34 */       b(paramaab, paramInt1, paramInt2, paramInt3, new wm(apa.ac, 1, paramInt4));
/*    */     } else {
/* 36 */       super.a(paramaab, paramsq, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */