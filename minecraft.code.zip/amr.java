/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class amr
/*     */   extends apa
/*     */ {
/*     */   protected final boolean a;
/*     */   
/*     */   public amr(int paramInt, boolean paramBoolean, aif paramaif) {
/*  19 */     super(paramInt, paramaif);
/*  20 */     this.a = paramBoolean;
/*     */     
/*  22 */     if (paramBoolean) {
/*  23 */       s[paramInt] = true;
/*     */     } else {
/*  25 */       a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
/*     */     } 
/*  27 */     k(255);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  32 */     if (this.a) {
/*  33 */       a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     } else {
/*  35 */       boolean bool = ((paramaak.h(paramInt1, paramInt2, paramInt3) & 0x8) != 0) ? true : false;
/*  36 */       if (bool) {
/*  37 */         a(0.0F, 0.5F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */       } else {
/*  39 */         a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  46 */     if (this.a) {
/*  47 */       a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     } else {
/*  49 */       a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/*  55 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  56 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  61 */     return this.a;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  66 */     if (this.a) return paramInt5;
/*     */     
/*  68 */     if (paramInt4 == 0 || (paramInt4 != 1 && paramFloat2 > 0.5D)) {
/*  69 */       return paramInt5 | 0x8;
/*     */     }
/*  71 */     return paramInt5;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/*  76 */     if (this.a) {
/*  77 */       return 2;
/*     */     }
/*  79 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/*  84 */     return paramInt & 0x7;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  89 */     return this.a;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  94 */     if (this.a) return super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     
/*  96 */     if (paramInt4 != 1 && paramInt4 != 0 && !super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4)) {
/*  97 */       return false;
/*     */     }
/*     */     
/* 100 */     int i = paramInt1, j = paramInt2, k = paramInt3;
/* 101 */     i += s.b[s.a[paramInt4]];
/* 102 */     j += s.c[s.a[paramInt4]];
/* 103 */     k += s.d[s.a[paramInt4]];
/*     */     
/* 105 */     boolean bool = ((paramaak.h(i, j, k) & 0x8) != 0) ? true : false;
/* 106 */     if (bool) {
/* 107 */       if (paramInt4 == 0) return true; 
/* 108 */       if (paramInt4 == 1 && super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4)) return true; 
/* 109 */       return (!d(paramaak.a(paramInt1, paramInt2, paramInt3)) || (paramaak.h(paramInt1, paramInt2, paramInt3) & 0x8) == 0);
/*     */     } 
/* 111 */     if (paramInt4 == 1) return true; 
/* 112 */     if (paramInt4 == 0 && super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4)) return true; 
/* 113 */     return (!d(paramaak.a(paramInt1, paramInt2, paramInt3)) || (paramaak.h(paramInt1, paramInt2, paramInt3) & 0x8) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean d(int paramInt) {
/* 118 */     return (paramInt == apa.ao.cz || paramInt == apa.bS.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public abstract String c(int paramInt);
/*     */   
/*     */   public int h(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 125 */     return super.h(paramaab, paramInt1, paramInt2, paramInt3) & 0x7;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 130 */     if (d(this.cz)) {
/* 131 */       return this.cz;
/*     */     }
/* 133 */     if (this.cz == apa.an.cz) {
/* 134 */       return apa.ao.cz;
/*     */     }
/* 136 */     if (this.cz == apa.bR.cz) {
/* 137 */       return apa.bS.cz;
/*     */     }
/* 139 */     return apa.ao.cz;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */