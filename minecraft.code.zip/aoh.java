/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aoh
/*    */   extends apa
/*    */ {
/*    */   protected aoh(int paramInt) {
/* 12 */     super(paramInt, aif.k);
/* 13 */     float f = 0.375F;
/* 14 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 1.0F, 0.5F + f);
/* 15 */     b(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 20 */     if (paramaab.c(paramInt1, paramInt2 + 1, paramInt3)) {
/* 21 */       byte b = 1;
/* 22 */       while (paramaab.a(paramInt1, paramInt2 - b, paramInt3) == this.cz) {
/* 23 */         b++;
/*    */       }
/* 25 */       if (b < 3) {
/* 26 */         int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 27 */         if (i == 15) {
/* 28 */           paramaab.c(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/* 29 */           paramaab.b(paramInt1, paramInt2, paramInt3, 0, 4);
/*    */         } else {
/* 31 */           paramaab.b(paramInt1, paramInt2, paramInt3, i + 1, 4);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 39 */     int i = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/* 40 */     if (i == this.cz) return true; 
/* 41 */     if (i != apa.y.cz && i != apa.z.cz && i != apa.I.cz) return false; 
/* 42 */     if (paramaab.g(paramInt1 - 1, paramInt2 - 1, paramInt3) == aif.h) return true; 
/* 43 */     if (paramaab.g(paramInt1 + 1, paramInt2 - 1, paramInt3) == aif.h) return true; 
/* 44 */     if (paramaab.g(paramInt1, paramInt2 - 1, paramInt3 - 1) == aif.h) return true; 
/* 45 */     if (paramaab.g(paramInt1, paramInt2 - 1, paramInt3 + 1) == aif.h) return true; 
/* 46 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 51 */     p_(paramaab, paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */   
/*    */   protected final void p_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 55 */     if (!f(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 56 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 57 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 63 */     return c(paramaab, paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */ 
/*    */   
/*    */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 68 */     return null;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 73 */     return wk.aK.cp;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 82 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b() {
/* 87 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int d() {
/* 92 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 97 */     return wk.aK.cp;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */