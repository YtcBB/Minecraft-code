/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ams
/*    */   extends apa
/*    */ {
/*    */   private boolean a;
/*    */   private String b;
/*    */   
/*    */   protected ams(int paramInt, String paramString, aif paramaif, boolean paramBoolean) {
/* 12 */     super(paramInt, paramaif);
/* 13 */     this.a = paramBoolean;
/* 14 */     this.b = paramString;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 19 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 24 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/* 25 */     if (!this.a && i == this.cz) return false; 
/* 26 */     return super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 35 */     this.cQ = paramly.a(this.b);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ams.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */