/*    */ import java.util.Random;
/*    */ 
/*    */ public class anr
/*    */   extends aov
/*    */ {
/*    */   public anr(int paramInt) {
/*  7 */     super(paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 12 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 17 */     return apa.at.cz;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */