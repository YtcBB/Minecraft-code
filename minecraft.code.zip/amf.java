/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class amf
/*    */   extends akz
/*    */ {
/*    */   private lx a;
/*    */   private lx b;
/*    */   
/*    */   protected amf(int paramInt) {
/* 25 */     super(paramInt, aif.e);
/* 26 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.75F, 1.0F);
/* 27 */     k(0);
/* 28 */     a(ve.c);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b() {
/* 33 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 38 */     super.b(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*    */     
/* 40 */     for (int i = paramInt1 - 2; i <= paramInt1 + 2; i++) {
/* 41 */       for (int j = paramInt3 - 2; j <= paramInt3 + 2; j++) {
/* 42 */         if (i > paramInt1 - 2 && i < paramInt1 + 2 && j == paramInt3 - 1) {
/* 43 */           j = paramInt3 + 2;
/*    */         }
/* 45 */         if (paramRandom.nextInt(16) == 0) {
/* 46 */           for (int k = paramInt2; k <= paramInt2 + 1; k++) {
/* 47 */             if (paramaab.a(i, k, j) == apa.ar.cz) {
/* 48 */               if (!paramaab.c((i - paramInt1) / 2 + paramInt1, k, (j - paramInt3) / 2 + paramInt3))
/*    */                 break; 
/* 50 */               paramaab.a("enchantmenttable", paramInt1 + 0.5D, paramInt2 + 2.0D, paramInt3 + 0.5D, ((i - paramInt1) + paramRandom.nextFloat()) - 0.5D, ((k - paramInt2) - paramRandom.nextFloat() - 1.0F), ((j - paramInt3) + paramRandom.nextFloat()) - 0.5D);
/*    */             } 
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   public boolean c() {
/* 59 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 64 */     if (paramInt1 == 0) return this.b; 
/* 65 */     if (paramInt1 == 1) return this.a; 
/* 66 */     return this.cQ;
/*    */   }
/*    */   
/*    */   public aqp b(aab paramaab) {
/* 70 */     return new aqe();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 75 */     if (paramaab.I) {
/* 76 */       return true;
/*    */     }
/* 78 */     aqe aqe = (aqe)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 79 */     paramsq.a(paramInt1, paramInt2, paramInt3, aqe.b() ? aqe.a() : null);
/* 80 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 85 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramng, paramwm);
/* 86 */     if (paramwm.t()) {
/* 87 */       ((aqe)paramaab.r(paramInt1, paramInt2, paramInt3)).a(paramwm.s());
/*    */     }
/*    */   }
/*    */   
/*    */   public void a(ly paramly) {
/* 92 */     this.cQ = paramly.a("enchantment_side");
/* 93 */     this.a = paramly.a("enchantment_top");
/* 94 */     this.b = paramly.a("enchantment_bottom");
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */