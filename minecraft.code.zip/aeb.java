/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aeb
/*    */   extends adj
/*    */ {
/*    */   private int a;
/*    */   
/*    */   public aeb(int paramInt) {
/* 12 */     this.a = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 17 */     if (paramaab.a(paramInt1, paramInt2 + 1, paramInt3) != apa.x.cz) return false; 
/* 18 */     if (paramaab.a(paramInt1, paramInt2 - 1, paramInt3) != apa.x.cz) return false;
/*    */     
/* 20 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) != 0 && paramaab.a(paramInt1, paramInt2, paramInt3) != apa.x.cz) return false;
/*    */     
/* 22 */     byte b1 = 0;
/* 23 */     if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == apa.x.cz) b1++; 
/* 24 */     if (paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == apa.x.cz) b1++; 
/* 25 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == apa.x.cz) b1++; 
/* 26 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == apa.x.cz) b1++;
/*    */     
/* 28 */     byte b2 = 0;
/* 29 */     if (paramaab.c(paramInt1 - 1, paramInt2, paramInt3)) b2++; 
/* 30 */     if (paramaab.c(paramInt1 + 1, paramInt2, paramInt3)) b2++; 
/* 31 */     if (paramaab.c(paramInt1, paramInt2, paramInt3 - 1)) b2++; 
/* 32 */     if (paramaab.c(paramInt1, paramInt2, paramInt3 + 1)) b2++;
/*    */     
/* 34 */     if (b1 == 3 && b2 == 1) {
/* 35 */       paramaab.f(paramInt1, paramInt2, paramInt3, this.a, 0, 2);
/* 36 */       paramaab.d = true;
/* 37 */       apa.r[this.a].a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/* 38 */       paramaab.d = false;
/*    */     } 
/*    */     
/* 41 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aeb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */