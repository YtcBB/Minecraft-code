/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class akz
/*    */   extends apa
/*    */   implements amh
/*    */ {
/*    */   protected akz(int paramInt, aif paramaif) {
/*  9 */     super(paramInt, paramaif);
/* 10 */     this.cF = true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 15 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 21 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 22 */     paramaab.s(paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 27 */     super.b(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 28 */     aqp aqp = paramaab.r(paramInt1, paramInt2, paramInt3);
/* 29 */     if (aqp != null) {
/* 30 */       return aqp.b(paramInt4, paramInt5);
/*    */     }
/* 32 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\akz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */