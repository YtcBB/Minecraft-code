/*    */ import java.util.Arrays;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class al
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 13 */     return "help";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 18 */     return 0;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 24 */     return paramab.a("commands.help.usage", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public List b() {
/* 29 */     return Arrays.asList(new String[] { "?" });
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 33 */     List<z> list = d(paramab);
/* 34 */     byte b1 = 7;
/* 35 */     int i = (list.size() - 1) / b1;
/* 36 */     byte b2 = 0;
/*    */     
/*    */     try {
/* 39 */       b2 = (paramArrayOfString.length == 0) ? 0 : (a(paramab, paramArrayOfString[0], 1, i + 1) - 1);
/* 40 */     } catch (at at) {
/*    */       
/* 42 */       Map map = d();
/* 43 */       z z = (z)map.get(paramArrayOfString[0]);
/*    */       
/* 45 */       if (z != null)
/*    */       {
/* 47 */         throw new ax(z.a(paramab), new Object[0]);
/*    */       }
/* 49 */       throw new aw();
/*    */     } 
/*    */ 
/*    */ 
/*    */     
/* 54 */     int j = Math.min((b2 + 1) * b1, list.size());
/*    */     
/* 56 */     paramab.a(a.c + paramab.a("commands.help.header", new Object[] { Integer.valueOf(b2 + 1), Integer.valueOf(i + 1) }));
/*    */     
/* 58 */     for (int k = b2 * b1; k < j; k++) {
/* 59 */       z z = list.get(k);
/*    */       
/* 61 */       paramab.a(z.a(paramab));
/*    */     } 
/*    */     
/* 64 */     if (b2 == 0 && paramab instanceof sq) {
/* 65 */       paramab.a(a.k + paramab.a("commands.help.footer", new Object[0]));
/*    */     }
/*    */   }
/*    */   
/*    */   protected List d(ab paramab) {
/* 70 */     List<Comparable> list = MinecraftServer.D().E().a(paramab);
/* 71 */     Collections.sort(list);
/* 72 */     return list;
/*    */   }
/*    */   
/*    */   protected Map d() {
/* 76 */     return MinecraftServer.D().E().a();
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\al.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */