/*    */ import java.util.concurrent.Callable;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class agu
/*    */   implements Callable
/*    */ {
/*    */   agu(ags paramags, int paramInt1, int paramInt2) {}
/*    */   
/*    */   public String a() {
/* 50 */     return String.valueOf(zu.a(this.a, this.b));
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\agu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */