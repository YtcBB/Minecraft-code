/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ank
/*    */   extends akz
/*    */ {
/*    */   protected ank(int paramInt) {
/* 11 */     super(paramInt, aif.e);
/*    */   }
/*    */   
/*    */   public aqp b(aab paramaab) {
/* 15 */     return new aqj();
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 20 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 25 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 30 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, paramInt5);
/*    */ 
/*    */ 
/*    */     
/* 34 */     int i = 15 + paramaab.s.nextInt(15) + paramaab.s.nextInt(15);
/* 35 */     j(paramaab, paramInt1, paramInt2, paramInt3, i);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 41 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 50 */     return 0;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ank.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */