/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aaz
/*     */ {
/*     */   protected aab a;
/*     */   protected Random b;
/*     */   protected int c;
/*     */   protected int d;
/*     */   protected aav e;
/*     */   protected adj f;
/*     */   protected adj g;
/*     */   protected adj h;
/*     */   protected adj i;
/*     */   protected adj j;
/*     */   protected adj k;
/*     */   protected adj l;
/*     */   protected adj m;
/*     */   protected adj n;
/*     */   protected adj o;
/*     */   protected adj p;
/*     */   protected adj q;
/*     */   protected adj r;
/*     */   
/*     */   public aaz(aav paramaav) {
/*  33 */     this.f = new adg(4);
/*  34 */     this.g = new adz(7, apa.I.cz);
/*  35 */     this.h = new adz(6, apa.J.cz);
/*  36 */     this.i = new adv(apa.z.cz, 32);
/*  37 */     this.j = new adv(apa.J.cz, 32);
/*  38 */     this.k = new adv(apa.M.cz, 16);
/*  39 */     this.l = new adv(apa.L.cz, 8);
/*  40 */     this.m = new adv(apa.K.cz, 8);
/*  41 */     this.n = new adv(apa.aR.cz, 7);
/*  42 */     this.o = new adv(apa.aA.cz, 7);
/*  43 */     this.p = new adv(apa.R.cz, 6);
/*  44 */     this.q = new adk(apa.ah.cz);
/*  45 */     this.r = new adk(apa.ai.cz);
/*  46 */     this.s = new adk(apa.aj.cz);
/*  47 */     this.t = new adk(apa.ak.cz);
/*  48 */     this.u = new adq();
/*  49 */     this.v = new ady();
/*  50 */     this.w = new ade();
/*  51 */     this.x = new abr();
/*     */     
/*  53 */     this.y = 0;
/*  54 */     this.z = 0;
/*  55 */     this.A = 2;
/*  56 */     this.B = 1;
/*  57 */     this.C = 0;
/*  58 */     this.D = 0;
/*  59 */     this.E = 0;
/*  60 */     this.F = 0;
/*  61 */     this.G = 1;
/*  62 */     this.H = 3;
/*  63 */     this.I = 1;
/*  64 */     this.J = 0;
/*  65 */     this.K = true;
/*     */     this.e = paramaav;
/*     */   } protected adj s; protected adj t; protected adj u; protected adj v; protected adj w; protected adj x; protected int y; protected int z; protected int A; protected int B; protected int C; protected int D; protected int E; protected int F; protected int G; protected int H; protected int I; protected int J; public boolean K; protected void a() {
/*  68 */     b();
/*     */     int i;
/*  70 */     for (i = 0; i < this.H; i++) {
/*  71 */       int k = this.c + this.b.nextInt(16) + 8;
/*  72 */       int m = this.d + this.b.nextInt(16) + 8;
/*  73 */       this.g.a(this.a, this.b, k, this.a.i(k, m), m);
/*     */     } 
/*     */     
/*  76 */     for (i = 0; i < this.I; i++) {
/*  77 */       int k = this.c + this.b.nextInt(16) + 8;
/*  78 */       int m = this.d + this.b.nextInt(16) + 8;
/*  79 */       this.f.a(this.a, this.b, k, this.a.i(k, m), m);
/*     */     } 
/*     */     
/*  82 */     for (i = 0; i < this.G; i++) {
/*  83 */       int k = this.c + this.b.nextInt(16) + 8;
/*  84 */       int m = this.d + this.b.nextInt(16) + 8;
/*  85 */       this.g.a(this.a, this.b, k, this.a.i(k, m), m);
/*     */     } 
/*     */     
/*  88 */     i = this.z;
/*  89 */     if (this.b.nextInt(10) == 0) i++; 
/*     */     int j;
/*  91 */     for (j = 0; j < i; j++) {
/*  92 */       int k = this.c + this.b.nextInt(16) + 8;
/*  93 */       int m = this.d + this.b.nextInt(16) + 8;
/*  94 */       adj adj1 = this.e.a(this.b);
/*  95 */       adj1.a(1.0D, 1.0D, 1.0D);
/*  96 */       adj1.a(this.a, this.b, k, this.a.f(k, m), m);
/*     */     } 
/*     */     
/*  99 */     for (j = 0; j < this.J; j++) {
/* 100 */       int k = this.c + this.b.nextInt(16) + 8;
/* 101 */       int m = this.d + this.b.nextInt(16) + 8;
/* 102 */       this.u.a(this.a, this.b, k, this.a.f(k, m), m);
/*     */     } 
/*     */     
/* 105 */     for (j = 0; j < this.A; j++) {
/* 106 */       int k = this.c + this.b.nextInt(16) + 8;
/* 107 */       int m = this.b.nextInt(128);
/* 108 */       int n = this.d + this.b.nextInt(16) + 8;
/* 109 */       this.q.a(this.a, this.b, k, m, n);
/*     */       
/* 111 */       if (this.b.nextInt(4) == 0) {
/* 112 */         k = this.c + this.b.nextInt(16) + 8;
/* 113 */         m = this.b.nextInt(128);
/* 114 */         n = this.d + this.b.nextInt(16) + 8;
/* 115 */         this.r.a(this.a, this.b, k, m, n);
/*     */       } 
/*     */     } 
/*     */     
/* 119 */     for (j = 0; j < this.B; j++) {
/* 120 */       int k = this.c + this.b.nextInt(16) + 8;
/* 121 */       int m = this.b.nextInt(128);
/* 122 */       int n = this.d + this.b.nextInt(16) + 8;
/* 123 */       adj adj1 = this.e.b(this.b);
/* 124 */       adj1.a(this.a, this.b, k, m, n);
/*     */     } 
/*     */     
/* 127 */     for (j = 0; j < this.C; j++) {
/* 128 */       int k = this.c + this.b.nextInt(16) + 8;
/* 129 */       int m = this.b.nextInt(128);
/* 130 */       int n = this.d + this.b.nextInt(16) + 8;
/* 131 */       (new adh(apa.ac.cz)).a(this.a, this.b, k, m, n);
/*     */     } 
/*     */     
/* 134 */     for (j = 0; j < this.y; j++) {
/* 135 */       int k = this.c + this.b.nextInt(16) + 8;
/* 136 */       int m = this.d + this.b.nextInt(16) + 8;
/* 137 */       int n = this.b.nextInt(128);
/* 138 */       while (n > 0 && this.a.a(k, n - 1, m) == 0)
/* 139 */         n--; 
/* 140 */       this.x.a(this.a, this.b, k, n, m);
/*     */     } 
/*     */     
/* 143 */     for (j = 0; j < this.D; j++) {
/* 144 */       if (this.b.nextInt(4) == 0) {
/* 145 */         int k = this.c + this.b.nextInt(16) + 8;
/* 146 */         int m = this.d + this.b.nextInt(16) + 8;
/* 147 */         int n = this.a.f(k, m);
/* 148 */         this.s.a(this.a, this.b, k, n, m);
/*     */       } 
/*     */       
/* 151 */       if (this.b.nextInt(8) == 0) {
/* 152 */         int k = this.c + this.b.nextInt(16) + 8;
/* 153 */         int m = this.d + this.b.nextInt(16) + 8;
/* 154 */         int n = this.b.nextInt(128);
/* 155 */         this.t.a(this.a, this.b, k, n, m);
/*     */       } 
/*     */     } 
/*     */     
/* 159 */     if (this.b.nextInt(4) == 0) {
/* 160 */       j = this.c + this.b.nextInt(16) + 8;
/* 161 */       int k = this.b.nextInt(128);
/* 162 */       int m = this.d + this.b.nextInt(16) + 8;
/* 163 */       this.s.a(this.a, this.b, j, k, m);
/*     */     } 
/*     */     
/* 166 */     if (this.b.nextInt(8) == 0) {
/* 167 */       j = this.c + this.b.nextInt(16) + 8;
/* 168 */       int k = this.b.nextInt(128);
/* 169 */       int m = this.d + this.b.nextInt(16) + 8;
/* 170 */       this.t.a(this.a, this.b, j, k, m);
/*     */     } 
/*     */     
/* 173 */     for (j = 0; j < this.E; j++) {
/* 174 */       int k = this.c + this.b.nextInt(16) + 8;
/* 175 */       int m = this.d + this.b.nextInt(16) + 8;
/* 176 */       int n = this.b.nextInt(128);
/* 177 */       this.v.a(this.a, this.b, k, n, m);
/*     */     } 
/*     */     
/* 180 */     for (j = 0; j < 10; j++) {
/* 181 */       int k = this.c + this.b.nextInt(16) + 8;
/* 182 */       int m = this.b.nextInt(128);
/* 183 */       int n = this.d + this.b.nextInt(16) + 8;
/* 184 */       this.v.a(this.a, this.b, k, m, n);
/*     */     } 
/*     */     
/* 187 */     if (this.b.nextInt(32) == 0) {
/* 188 */       j = this.c + this.b.nextInt(16) + 8;
/* 189 */       int k = this.b.nextInt(128);
/* 190 */       int m = this.d + this.b.nextInt(16) + 8;
/* 191 */       (new adx()).a(this.a, this.b, j, k, m);
/*     */     } 
/*     */     
/* 194 */     for (j = 0; j < this.F; j++) {
/* 195 */       int k = this.c + this.b.nextInt(16) + 8;
/* 196 */       int m = this.b.nextInt(128);
/* 197 */       int n = this.d + this.b.nextInt(16) + 8;
/* 198 */       this.w.a(this.a, this.b, k, m, n);
/*     */     } 
/*     */     
/* 201 */     if (this.K) {
/* 202 */       for (j = 0; j < 50; j++) {
/* 203 */         int k = this.c + this.b.nextInt(16) + 8;
/* 204 */         int m = this.b.nextInt(this.b.nextInt(120) + 8);
/* 205 */         int n = this.d + this.b.nextInt(16) + 8;
/* 206 */         (new aeb(apa.E.cz)).a(this.a, this.b, k, m, n);
/*     */       } 
/*     */       
/* 209 */       for (j = 0; j < 20; j++) {
/* 210 */         int k = this.c + this.b.nextInt(16) + 8;
/* 211 */         int m = this.b.nextInt(this.b.nextInt(this.b.nextInt(112) + 8) + 8);
/* 212 */         int n = this.d + this.b.nextInt(16) + 8;
/* 213 */         (new aeb(apa.G.cz)).a(this.a, this.b, k, m, n);
/*     */       } 
/*     */     }  } public void a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) { if (this.a != null)
/*     */       throw new RuntimeException("Already decorating!!");  this.a = paramaab;
/*     */     this.b = paramRandom;
/*     */     this.c = paramInt1;
/*     */     this.d = paramInt2;
/*     */     a();
/*     */     this.a = null;
/*     */     this.b = null; }
/* 223 */   protected void a(int paramInt1, adj paramadj, int paramInt2, int paramInt3) { for (byte b = 0; b < paramInt1; b++) {
/* 224 */       int i = this.c + this.b.nextInt(16);
/* 225 */       int j = this.b.nextInt(paramInt3 - paramInt2) + paramInt2;
/* 226 */       int k = this.d + this.b.nextInt(16);
/* 227 */       paramadj.a(this.a, this.b, i, j, k);
/*     */     }  }
/*     */ 
/*     */   
/*     */   protected void b(int paramInt1, adj paramadj, int paramInt2, int paramInt3) {
/* 232 */     for (byte b = 0; b < paramInt1; b++) {
/* 233 */       int i = this.c + this.b.nextInt(16);
/* 234 */       int j = this.b.nextInt(paramInt3) + this.b.nextInt(paramInt3) + paramInt2 - paramInt3;
/* 235 */       int k = this.d + this.b.nextInt(16);
/* 236 */       paramadj.a(this.a, this.b, i, j, k);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void b() {
/* 241 */     a(20, this.i, 0, 128);
/* 242 */     a(10, this.j, 0, 128);
/* 243 */     a(20, this.k, 0, 128);
/* 244 */     a(20, this.l, 0, 64);
/* 245 */     a(2, this.m, 0, 32);
/* 246 */     a(8, this.n, 0, 16);
/* 247 */     a(1, this.o, 0, 16);
/* 248 */     b(1, this.p, 16, 16);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aaz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */