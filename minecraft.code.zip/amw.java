/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amw
/*     */   extends akz
/*     */ {
/*  26 */   private final Random a = new Random();
/*     */   
/*     */   private lx b;
/*     */   private lx c;
/*     */   private lx d;
/*     */   
/*     */   public amw(int paramInt) {
/*  33 */     super(paramInt, aif.f);
/*  34 */     a(ve.d);
/*  35 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  40 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/*  45 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.625F, 1.0F);
/*  46 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  47 */     float f = 0.125F;
/*  48 */     a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
/*  49 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  50 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f);
/*  51 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  52 */     a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  53 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  54 */     a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F);
/*  55 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     
/*  57 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  62 */     int i = s.a[paramInt4];
/*  63 */     if (i == 1) i = 0; 
/*  64 */     return i;
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/*  68 */     return new aqi();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/*  73 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramng, paramwm);
/*     */     
/*  75 */     if (paramwm.t()) {
/*  76 */       aqi aqi = d(paramaab, paramInt1, paramInt2, paramInt3);
/*  77 */       aqi.a(paramwm.s());
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  83 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/*  84 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  89 */     if (paramaab.I) {
/*  90 */       return true;
/*     */     }
/*  92 */     aqi aqi = d(paramaab, paramInt1, paramInt2, paramInt3);
/*  93 */     if (aqi != null) paramsq.a(aqi); 
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  99 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 103 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 104 */     int j = c(i);
/* 105 */     boolean bool1 = !paramaab.C(paramInt1, paramInt2, paramInt3);
/* 106 */     boolean bool2 = d(i);
/*     */     
/* 108 */     if (bool1 != bool2) {
/* 109 */       paramaab.b(paramInt1, paramInt2, paramInt3, j | (bool1 ? 0 : 8), 4);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 115 */     aqi aqi = (aqi)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 116 */     if (aqi != null) {
/* 117 */       for (byte b = 0; b < aqi.j_(); b++) {
/* 118 */         wm wm = aqi.a(b);
/* 119 */         if (wm != null) {
/* 120 */           float f1 = this.a.nextFloat() * 0.8F + 0.1F;
/* 121 */           float f2 = this.a.nextFloat() * 0.8F + 0.1F;
/* 122 */           float f3 = this.a.nextFloat() * 0.8F + 0.1F;
/*     */           
/* 124 */           while (wm.a > 0) {
/* 125 */             int i = this.a.nextInt(21) + 10;
/* 126 */             if (i > wm.a) i = wm.a; 
/* 127 */             wm.a -= i;
/*     */             
/* 129 */             rh rh = new rh(paramaab, (paramInt1 + f1), (paramInt2 + f2), (paramInt3 + f3), new wm(wm.c, i, wm.k()));
/*     */             
/* 131 */             if (wm.p()) {
/* 132 */               rh.d().d((bs)wm.q().b());
/*     */             }
/*     */             
/* 135 */             float f = 0.05F;
/* 136 */             rh.x = ((float)this.a.nextGaussian() * f);
/* 137 */             rh.y = ((float)this.a.nextGaussian() * f + 0.2F);
/* 138 */             rh.z = ((float)this.a.nextGaussian() * f);
/* 139 */             paramaab.d(rh);
/*     */           } 
/*     */         } 
/*     */       } 
/* 143 */       paramaab.m(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/*     */     
/* 146 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 151 */     return 38;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/* 156 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/* 161 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 166 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/* 171 */     if (paramInt1 == 1) {
/* 172 */       return this.c;
/*     */     }
/* 174 */     return this.b;
/*     */   }
/*     */   
/*     */   public static int c(int paramInt) {
/* 178 */     return paramInt & 0x7;
/*     */   }
/*     */   
/*     */   public static boolean d(int paramInt) {
/* 182 */     return ((paramInt & 0x8) != 8);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean q_() {
/* 187 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 192 */     return tj.b(d(paramaab, paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 197 */     this.b = paramly.a("hopper");
/* 198 */     this.c = paramly.a("hopper_top");
/* 199 */     this.d = paramly.a("hopper_inside");
/*     */   }
/*     */ 
/*     */   
/*     */   public static lx b(String paramString) {
/* 204 */     if (paramString == "hopper") return apa.cu.b; 
/* 205 */     if (paramString == "hopper_inside") return apa.cu.d; 
/* 206 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public String u_() {
/* 211 */     return "hopper";
/*     */   }
/*     */   
/*     */   public static aqi d(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 215 */     return (aqi)paramaak.r(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */