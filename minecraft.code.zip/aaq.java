/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aaq
/*     */   implements aak
/*     */ {
/*     */   private int a;
/*     */   private int b;
/*     */   private abw[][] c;
/*     */   private boolean d;
/*     */   private aab e;
/*     */   
/*     */   public aaq(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7) {
/*  20 */     this.e = paramaab;
/*     */     
/*  22 */     this.a = paramInt1 - paramInt7 >> 4;
/*  23 */     this.b = paramInt3 - paramInt7 >> 4;
/*  24 */     int i = paramInt4 + paramInt7 >> 4;
/*  25 */     int j = paramInt6 + paramInt7 >> 4;
/*     */     
/*  27 */     this.c = new abw[i - this.a + 1][j - this.b + 1];
/*     */     
/*  29 */     this.d = true; int k;
/*  30 */     for (k = this.a; k <= i; k++) {
/*  31 */       for (int m = this.b; m <= j; m++) {
/*  32 */         abw abw1 = paramaab.e(k, m);
/*  33 */         if (abw1 != null) {
/*  34 */           this.c[k - this.a][m - this.b] = abw1;
/*     */         }
/*     */       } 
/*     */     } 
/*  38 */     for (k = paramInt1 >> 4; k <= paramInt4 >> 4; k++) {
/*  39 */       for (int m = paramInt3 >> 4; m <= paramInt6 >> 4; m++) {
/*  40 */         abw abw1 = this.c[k - this.a][m - this.b];
/*  41 */         if (abw1 != null && 
/*  42 */           !abw1.c(paramInt2, paramInt5)) {
/*  43 */           this.d = false;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean S() {
/*  51 */     return this.d;
/*     */   }
/*     */   
/*     */   public int a(int paramInt1, int paramInt2, int paramInt3) {
/*  55 */     if (paramInt2 < 0) return 0; 
/*  56 */     if (paramInt2 >= 256) return 0;
/*     */     
/*  58 */     int i = (paramInt1 >> 4) - this.a;
/*  59 */     int j = (paramInt3 >> 4) - this.b;
/*     */     
/*  61 */     if (i < 0 || i >= this.c.length || j < 0 || j >= (this.c[i]).length) {
/*  62 */       return 0;
/*     */     }
/*     */     
/*  65 */     abw abw1 = this.c[i][j];
/*  66 */     if (abw1 == null) return 0;
/*     */     
/*  68 */     return abw1.a(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*     */   }
/*     */   
/*     */   public aqp r(int paramInt1, int paramInt2, int paramInt3) {
/*  72 */     int i = (paramInt1 >> 4) - this.a;
/*  73 */     int j = (paramInt3 >> 4) - this.b;
/*     */     
/*  75 */     return this.c[i][j].e(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*     */   }
/*     */   
/*     */   public float i(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  79 */     int i = b(paramInt1, paramInt2, paramInt3);
/*  80 */     if (i < paramInt4) i = paramInt4; 
/*  81 */     return this.e.t.g[i];
/*     */   }
/*     */   
/*     */   public int h(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  85 */     int i = a(aam.a, paramInt1, paramInt2, paramInt3);
/*  86 */     int j = a(aam.b, paramInt1, paramInt2, paramInt3);
/*  87 */     if (j < paramInt4) j = paramInt4; 
/*  88 */     return i << 20 | j << 4;
/*     */   }
/*     */   
/*     */   public float q(int paramInt1, int paramInt2, int paramInt3) {
/*  92 */     return this.e.t.g[b(paramInt1, paramInt2, paramInt3)];
/*     */   }
/*     */   
/*     */   public int b(int paramInt1, int paramInt2, int paramInt3) {
/*  96 */     return a(paramInt1, paramInt2, paramInt3, true);
/*     */   }
/*     */   
/*     */   public int a(int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/* 100 */     if (paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 > 30000000) {
/* 101 */       return 15;
/*     */     }
/*     */     
/* 104 */     if (paramBoolean) {
/* 105 */       int k = a(paramInt1, paramInt2, paramInt3);
/* 106 */       if (k == apa.ao.cz || k == apa.bS.cz || k == apa.aE.cz || k == apa.ax.cz || k == apa.aL.cz) {
/* 107 */         int m = a(paramInt1, paramInt2 + 1, paramInt3, false);
/* 108 */         int n = a(paramInt1 + 1, paramInt2, paramInt3, false);
/* 109 */         int i1 = a(paramInt1 - 1, paramInt2, paramInt3, false);
/* 110 */         int i2 = a(paramInt1, paramInt2, paramInt3 + 1, false);
/* 111 */         int i3 = a(paramInt1, paramInt2, paramInt3 - 1, false);
/* 112 */         if (n > m) m = n; 
/* 113 */         if (i1 > m) m = i1; 
/* 114 */         if (i2 > m) m = i2; 
/* 115 */         if (i3 > m) m = i3; 
/* 116 */         return m;
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     if (paramInt2 < 0) return 0; 
/* 121 */     if (paramInt2 >= 256) {
/* 122 */       int k = 15 - this.e.j;
/* 123 */       if (k < 0) k = 0; 
/* 124 */       return k;
/*     */     } 
/*     */     
/* 127 */     int i = (paramInt1 >> 4) - this.a;
/* 128 */     int j = (paramInt3 >> 4) - this.b;
/*     */     
/* 130 */     return this.c[i][j].c(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF, this.e.j);
/*     */   }
/*     */   
/*     */   public int h(int paramInt1, int paramInt2, int paramInt3) {
/* 134 */     if (paramInt2 < 0) return 0; 
/* 135 */     if (paramInt2 >= 256) return 0; 
/* 136 */     int i = (paramInt1 >> 4) - this.a;
/* 137 */     int j = (paramInt3 >> 4) - this.b;
/*     */     
/* 139 */     return this.c[i][j].c(paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*     */   }
/*     */   
/*     */   public aif g(int paramInt1, int paramInt2, int paramInt3) {
/* 143 */     int i = a(paramInt1, paramInt2, paramInt3);
/* 144 */     if (i == 0) return aif.a; 
/* 145 */     return (apa.r[i]).cO;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aav a(int paramInt1, int paramInt2) {
/* 153 */     return this.e.a(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public boolean t(int paramInt1, int paramInt2, int paramInt3) {
/* 157 */     apa apa = apa.r[a(paramInt1, paramInt2, paramInt3)];
/* 158 */     if (apa == null) return false; 
/* 159 */     return apa.c();
/*     */   }
/*     */   
/*     */   public boolean u(int paramInt1, int paramInt2, int paramInt3) {
/* 163 */     apa apa = apa.r[a(paramInt1, paramInt2, paramInt3)];
/* 164 */     if (apa == null) return false; 
/* 165 */     return (apa.cO.c() && apa.b());
/*     */   }
/*     */   
/*     */   public boolean w(int paramInt1, int paramInt2, int paramInt3) {
/* 169 */     apa apa = apa.r[a(paramInt1, paramInt2, paramInt3)];
/* 170 */     return this.e.a(apa, h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   public ard U() {
/* 174 */     return this.e.U();
/*     */   }
/*     */   
/*     */   public boolean c(int paramInt1, int paramInt2, int paramInt3) {
/* 178 */     apa apa = apa.r[a(paramInt1, paramInt2, paramInt3)];
/* 179 */     return (apa == null);
/*     */   }
/*     */   
/*     */   public int a(aam paramaam, int paramInt1, int paramInt2, int paramInt3) {
/* 183 */     if (paramInt2 < 0) paramInt2 = 0; 
/* 184 */     if (paramInt2 >= 256) paramInt2 = 255; 
/* 185 */     if (paramInt2 < 0 || paramInt2 >= 256 || paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 > 30000000) {
/* 186 */       return paramaam.c;
/*     */     }
/* 188 */     if (paramaam == aam.a && this.e.t.f) {
/* 189 */       return 0;
/*     */     }
/*     */     
/* 192 */     if (apa.w[a(paramInt1, paramInt2, paramInt3)]) {
/* 193 */       int k = b(paramaam, paramInt1, paramInt2 + 1, paramInt3);
/* 194 */       int m = b(paramaam, paramInt1 + 1, paramInt2, paramInt3);
/* 195 */       int n = b(paramaam, paramInt1 - 1, paramInt2, paramInt3);
/* 196 */       int i1 = b(paramaam, paramInt1, paramInt2, paramInt3 + 1);
/* 197 */       int i2 = b(paramaam, paramInt1, paramInt2, paramInt3 - 1);
/* 198 */       if (m > k) k = m; 
/* 199 */       if (n > k) k = n; 
/* 200 */       if (i1 > k) k = i1; 
/* 201 */       if (i2 > k) k = i2; 
/* 202 */       return k;
/*     */     } 
/*     */     
/* 205 */     int i = (paramInt1 >> 4) - this.a;
/* 206 */     int j = (paramInt3 >> 4) - this.b;
/*     */     
/* 208 */     return this.c[i][j].a(paramaam, paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*     */   }
/*     */   
/*     */   public int b(aam paramaam, int paramInt1, int paramInt2, int paramInt3) {
/* 212 */     if (paramInt2 < 0) paramInt2 = 0; 
/* 213 */     if (paramInt2 >= 256) paramInt2 = 255; 
/* 214 */     if (paramInt2 < 0 || paramInt2 >= 256 || paramInt1 < -30000000 || paramInt3 < -30000000 || paramInt1 >= 30000000 || paramInt3 > 30000000) {
/* 215 */       return paramaam.c;
/*     */     }
/* 217 */     int i = (paramInt1 >> 4) - this.a;
/* 218 */     int j = (paramInt3 >> 4) - this.b;
/*     */     
/* 220 */     return this.c[i][j].a(paramaam, paramInt1 & 0xF, paramInt2, paramInt3 & 0xF);
/*     */   }
/*     */   
/*     */   public int Q() {
/* 224 */     return 256;
/*     */   }
/*     */   
/*     */   public int j(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 228 */     int i = a(paramInt1, paramInt2, paramInt3);
/* 229 */     if (i == 0) return 0; 
/* 230 */     return apa.r[i].c(this, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aaq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */