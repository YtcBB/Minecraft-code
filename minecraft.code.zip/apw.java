/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apw
/*     */   extends aqp
/*     */   implements lt
/*     */ {
/*  21 */   public static final mk[][] a = new mk[][] { { mk.c, mk.e }, { mk.m, mk.j }, { mk.g }, { mk.l } };
/*     */ 
/*     */ 
/*     */   
/*     */   private long b;
/*     */ 
/*     */ 
/*     */   
/*     */   private float c;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean d;
/*     */ 
/*     */ 
/*     */   
/*  37 */   private int e = -1;
/*     */   
/*     */   private int f;
/*     */   
/*     */   private int g;
/*     */   
/*     */   private wm h;
/*     */   
/*     */   private String i;
/*     */   
/*     */   public void h() {
/*  48 */     if (this.k.H() % 80L == 0L) {
/*  49 */       v();
/*  50 */       u();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void u() {
/*  56 */     if (this.d && this.e > 0 && !this.k.I && this.f > 0) {
/*     */       
/*  58 */       double d = (this.e * 10 + 10);
/*  59 */       boolean bool = false;
/*  60 */       if (this.e >= 4 && this.f == this.g) {
/*  61 */         bool = true;
/*     */       }
/*     */       
/*  64 */       aqx aqx = aqx.a().a(this.l, this.m, this.n, (this.l + 1), (this.m + 1), (this.n + 1)).b(d, d, d);
/*  65 */       aqx.e = this.k.Q();
/*  66 */       List list = this.k.a(sq.class, aqx);
/*  67 */       for (sq sq : list) {
/*  68 */         sq.d(new ml(this.f, 180, bool, true));
/*     */       }
/*     */       
/*  71 */       if (this.e >= 4 && this.f != this.g && this.g > 0) {
/*  72 */         for (sq sq : list) {
/*  73 */           sq.d(new ml(this.g, 180, 0, true));
/*     */         }
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void v() {
/*  81 */     if (!this.k.l(this.l, this.m + 1, this.n)) {
/*  82 */       this.d = false;
/*  83 */       this.e = 0;
/*     */     } else {
/*  85 */       this.d = true;
/*     */       
/*  87 */       this.e = 0;
/*  88 */       for (byte b = 1; b <= 4; ) {
/*     */         
/*  90 */         int i = this.m - b;
/*  91 */         if (i < 0) {
/*     */           break;
/*     */         }
/*     */         
/*  95 */         boolean bool = true;
/*  96 */         for (int j = this.l - b; j <= this.l + b && bool; j++) {
/*  97 */           for (int k = this.n - b; k <= this.n + b; k++) {
/*  98 */             int m = this.k.a(j, i, k);
/*  99 */             if (m != apa.bZ.cz && m != apa.al.cz && m != apa.aB.cz && m != apa.am.cz) {
/* 100 */               bool = false;
/*     */               break;
/*     */             } 
/*     */           } 
/*     */         } 
/* 105 */         if (bool) {
/* 106 */           this.e = b;
/*     */           
/*     */           b++;
/*     */         } 
/*     */       } 
/* 111 */       if (this.e == 0) {
/* 112 */         this.d = false;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float v_() {
/* 121 */     if (!this.d) {
/* 122 */       return 0.0F;
/*     */     }
/*     */     
/* 125 */     int i = (int)(this.k.H() - this.b);
/* 126 */     this.b = this.k.H();
/* 127 */     if (i > 1) {
/* 128 */       this.c -= i / 40.0F;
/*     */       
/* 130 */       if (this.c < 0.0F) {
/* 131 */         this.c = 0.0F;
/*     */       }
/*     */     } 
/* 134 */     this.c += 0.025F;
/* 135 */     if (this.c > 1.0F) {
/* 136 */       this.c = 1.0F;
/*     */     }
/* 138 */     return this.c;
/*     */   }
/*     */   
/*     */   public int j() {
/* 142 */     return this.f;
/*     */   }
/*     */   
/*     */   public int k() {
/* 146 */     return this.g;
/*     */   }
/*     */   
/*     */   public int l() {
/* 150 */     return this.e;
/*     */   }
/*     */ 
/*     */   
/*     */   public void c(int paramInt) {
/* 155 */     this.e = paramInt;
/*     */   }
/*     */   
/*     */   public void d(int paramInt) {
/* 159 */     this.f = 0;
/*     */ 
/*     */     
/* 162 */     for (byte b = 0; b < this.e && b < 3; b++) {
/* 163 */       for (mk mk1 : a[b]) {
/* 164 */         if (mk1.H == paramInt) {
/* 165 */           this.f = paramInt;
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void e(int paramInt) {
/* 173 */     this.g = 0;
/*     */ 
/*     */     
/* 176 */     if (this.e >= 4) {
/* 177 */       for (byte b = 0; b < 4; b++) {
/* 178 */         for (mk mk1 : a[b]) {
/* 179 */           if (mk1.H == paramInt) {
/* 180 */             this.g = paramInt;
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ei m() {
/* 190 */     bs bs = new bs();
/* 191 */     b(bs);
/* 192 */     return new fn(this.l, this.m, this.n, 3, bs);
/*     */   }
/*     */ 
/*     */   
/*     */   public double n() {
/* 197 */     return 65536.0D;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(bs parambs) {
/* 202 */     super.a(parambs);
/*     */     
/* 204 */     this.f = parambs.e("Primary");
/* 205 */     this.g = parambs.e("Secondary");
/* 206 */     this.e = parambs.e("Levels");
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(bs parambs) {
/* 211 */     super.b(parambs);
/*     */     
/* 213 */     parambs.a("Primary", this.f);
/* 214 */     parambs.a("Secondary", this.g);
/*     */     
/* 216 */     parambs.a("Levels", this.e);
/*     */   }
/*     */   
/*     */   public int j_() {
/* 220 */     return 1;
/*     */   }
/*     */   
/*     */   public wm a(int paramInt) {
/* 224 */     if (paramInt == 0) {
/* 225 */       return this.h;
/*     */     }
/* 227 */     return null;
/*     */   }
/*     */   
/*     */   public wm a(int paramInt1, int paramInt2) {
/* 231 */     if (paramInt1 == 0 && this.h != null) {
/* 232 */       if (paramInt2 >= this.h.a) {
/* 233 */         wm wm1 = this.h;
/* 234 */         this.h = null;
/* 235 */         return wm1;
/*     */       } 
/* 237 */       this.h.a -= paramInt2;
/* 238 */       return new wm(this.h.c, paramInt2, this.h.k());
/*     */     } 
/*     */     
/* 241 */     return null;
/*     */   }
/*     */   
/*     */   public wm b(int paramInt) {
/* 245 */     if (paramInt == 0 && this.h != null) {
/* 246 */       wm wm1 = this.h;
/* 247 */       this.h = null;
/* 248 */       return wm1;
/*     */     } 
/* 250 */     return null;
/*     */   }
/*     */   
/*     */   public void a(int paramInt, wm paramwm) {
/* 254 */     if (paramInt == 0) {
/* 255 */       this.h = paramwm;
/*     */     }
/*     */   }
/*     */   
/*     */   public String b() {
/* 260 */     return c() ? this.i : "container.beacon";
/*     */   }
/*     */   
/*     */   public boolean c() {
/* 264 */     return (this.i != null && this.i.length() > 0);
/*     */   }
/*     */   
/*     */   public void a(String paramString) {
/* 268 */     this.i = paramString;
/*     */   }
/*     */   
/*     */   public int d() {
/* 272 */     return 1;
/*     */   }
/*     */   
/*     */   public boolean a(sq paramsq) {
/* 276 */     if (this.k.r(this.l, this.m, this.n) != this) return false; 
/* 277 */     if (paramsq.e(this.l + 0.5D, this.m + 0.5D, this.n + 0.5D) > 64.0D) return false; 
/* 278 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void f() {}
/*     */ 
/*     */   
/*     */   public void g() {}
/*     */   
/*     */   public boolean b(int paramInt, wm paramwm) {
/* 288 */     return (paramwm.c == wk.bI.cp || paramwm.c == wk.o.cp || paramwm.c == wk.q.cp || paramwm.c == wk.p.cp);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */