/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apj
/*     */   extends apa
/*     */ {
/*     */   protected apj(int paramInt, aif paramaif) {
/*  14 */     super(paramInt, paramaif);
/*     */     
/*  16 */     float f1 = 0.5F;
/*  17 */     float f2 = 1.0F;
/*     */     
/*  19 */     a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, f2, 0.5F + f1);
/*  20 */     a(ve.d);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  29 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  34 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  39 */     return !f(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  44 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  49 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  50 */     return super.c_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  55 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  56 */     return super.b(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  61 */     d(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  66 */     float f = 0.1875F;
/*  67 */     a(0.0F, 0.5F - f / 2.0F, 0.0F, 1.0F, 0.5F + f / 2.0F, 1.0F);
/*     */   }
/*     */   
/*     */   public void d(int paramInt) {
/*  71 */     float f = 0.1875F;
/*     */     
/*  73 */     if ((paramInt & 0x8) != 0) {
/*  74 */       a(0.0F, 1.0F - f, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     } else {
/*  76 */       a(0.0F, 0.0F, 0.0F, 1.0F, f, 1.0F);
/*     */     } 
/*     */     
/*  79 */     if (f(paramInt)) {
/*  80 */       if ((paramInt & 0x3) == 0) a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F); 
/*  81 */       if ((paramInt & 0x3) == 1) a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f); 
/*  82 */       if ((paramInt & 0x3) == 2) a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); 
/*  83 */       if ((paramInt & 0x3) == 3) a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {}
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  94 */     if (this.cO == aif.f) return true;
/*     */     
/*  96 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  97 */     paramaab.b(paramInt1, paramInt2, paramInt3, i ^ 0x4, 2);
/*     */     
/*  99 */     paramaab.a(paramsq, 1003, paramInt1, paramInt2, paramInt3, 0);
/* 100 */     return true;
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/* 104 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/* 106 */     boolean bool = ((i & 0x4) > 0);
/* 107 */     if (bool == paramBoolean)
/*     */       return; 
/* 109 */     paramaab.b(paramInt1, paramInt2, paramInt3, i ^ 0x4, 2);
/*     */     
/* 111 */     paramaab.a((sq)null, 1003, paramInt1, paramInt2, paramInt3, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 116 */     if (paramaab.I)
/*     */       return; 
/* 118 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 119 */     int j = paramInt1;
/* 120 */     int k = paramInt3;
/* 121 */     if ((i & 0x3) == 0) k++; 
/* 122 */     if ((i & 0x3) == 1) k--; 
/* 123 */     if ((i & 0x3) == 2) j++; 
/* 124 */     if ((i & 0x3) == 3) j--;
/*     */     
/* 126 */     if (!g(paramaab.a(j, paramInt2, k))) {
/* 127 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/* 128 */       c(paramaab, paramInt1, paramInt2, paramInt3, i, 0);
/*     */     } 
/*     */     
/* 131 */     boolean bool = paramaab.C(paramInt1, paramInt2, paramInt3);
/* 132 */     if (bool || (paramInt4 > 0 && apa.r[paramInt4].f())) {
/* 133 */       a(paramaab, paramInt1, paramInt2, paramInt3, bool);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public ara a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, arc paramarc1, arc paramarc2) {
/* 139 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/* 140 */     return super.a(paramaab, paramInt1, paramInt2, paramInt3, paramarc1, paramarc2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/* 153 */     int i = 0;
/* 154 */     if (paramInt4 == 2) i = 0; 
/* 155 */     if (paramInt4 == 3) i = 1; 
/* 156 */     if (paramInt4 == 4) i = 2; 
/* 157 */     if (paramInt4 == 5) i = 3; 
/* 158 */     if (paramInt4 != 1 && paramInt4 != 0 && paramFloat2 > 0.5F) i |= 0x8; 
/* 159 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 164 */     if (paramInt4 == 0) return false; 
/* 165 */     if (paramInt4 == 1) return false; 
/* 166 */     if (paramInt4 == 2) paramInt3++; 
/* 167 */     if (paramInt4 == 3) paramInt3--; 
/* 168 */     if (paramInt4 == 4) paramInt1++; 
/* 169 */     if (paramInt4 == 5) paramInt1--;
/*     */     
/* 171 */     return g(paramaab.a(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   public static boolean f(int paramInt) {
/* 175 */     return ((paramInt & 0x4) != 0);
/*     */   }
/*     */   
/*     */   private static boolean g(int paramInt) {
/* 179 */     if (paramInt <= 0) {
/* 180 */       return false;
/*     */     }
/* 182 */     apa apa1 = apa.r[paramInt];
/* 183 */     return ((apa1 != null && apa1.cO.k() && apa1.b()) || apa1 == apa.bh || apa1 instanceof amr || apa1 instanceof aoq);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */