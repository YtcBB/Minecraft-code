/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class app
/*    */   extends alh
/*    */ {
/*    */   protected app(int paramInt) {
/* 16 */     super(paramInt);
/* 17 */     float f1 = 0.5F;
/* 18 */     float f2 = 0.015625F;
/* 19 */     a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, f2, 0.5F + f1);
/* 20 */     a(ve.c);
/*    */   }
/*    */ 
/*    */   
/*    */   public int d() {
/* 25 */     return 23;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/* 30 */     if (parammp == null || !(parammp instanceof rf)) {
/* 31 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 37 */     return aqx.a().a(paramInt1 + this.cG, paramInt2 + this.cH, paramInt3 + this.cI, paramInt1 + this.cJ, paramInt2 + this.cK, paramInt3 + this.cL);
/*    */   }
/*    */ 
/*    */   
/*    */   public int o() {
/* 42 */     return 2129968;
/*    */   }
/*    */ 
/*    */   
/*    */   public int b(int paramInt) {
/* 47 */     return 2129968;
/*    */   }
/*    */ 
/*    */   
/*    */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 52 */     return 2129968;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean f_(int paramInt) {
/* 57 */     return (paramInt == apa.F.cz);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 62 */     if (paramInt2 < 0 || paramInt2 >= 256) return false; 
/* 63 */     return (paramaab.g(paramInt1, paramInt2 - 1, paramInt3) == aif.h && paramaab.h(paramInt1, paramInt2 - 1, paramInt3) == 0);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\app.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */