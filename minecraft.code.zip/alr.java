/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class alr
/*    */   extends akz
/*    */ {
/*    */   public alr(int paramInt) {
/* 17 */     super(paramInt, aif.f);
/*    */   }
/*    */   
/*    */   public aqp b(aab paramaab) {
/* 21 */     return new apz();
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 26 */     if (!paramaab.I) {
/*    */       
/* 28 */       boolean bool = paramaab.C(paramInt1, paramInt2, paramInt3);
/* 29 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 30 */       boolean bool1 = ((i & 0x1) != 0) ? true : false;
/*    */       
/* 32 */       if (bool && !bool1) {
/* 33 */         paramaab.b(paramInt1, paramInt2, paramInt3, i | 0x1, 4);
/* 34 */         paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/* 35 */       } else if (!bool && bool1) {
/* 36 */         paramaab.b(paramInt1, paramInt2, paramInt3, i & 0xFFFFFFFE, 4);
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 43 */     aqp aqp = paramaab.r(paramInt1, paramInt2, paramInt3);
/*    */     
/* 45 */     if (aqp != null && aqp instanceof apz) {
/* 46 */       apz apz = (apz)aqp;
/* 47 */       apz.a(apz.a(paramaab));
/* 48 */       paramaab.m(paramInt1, paramInt2, paramInt3, this.cz);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(aab paramaab) {
/* 54 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 59 */     apz apz = (apz)paramaab.r(paramInt1, paramInt2, paramInt3);
/*    */     
/* 61 */     if (apz != null) {
/* 62 */       paramsq.a(apz);
/*    */     }
/*    */     
/* 65 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean q_() {
/* 70 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 75 */     aqp aqp = paramaab.r(paramInt1, paramInt2, paramInt3);
/*    */     
/* 77 */     if (aqp != null && aqp instanceof apz) {
/* 78 */       return ((apz)aqp).d();
/*    */     }
/*    */     
/* 81 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 86 */     apz apz = (apz)paramaab.r(paramInt1, paramInt2, paramInt3);
/*    */     
/* 88 */     if (paramwm.t())
/* 89 */       apz.c(paramwm.s()); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */