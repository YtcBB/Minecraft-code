/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apg
/*     */   extends apa
/*     */ {
/*     */   protected apg(int paramInt) {
/*  20 */     super(paramInt, aif.w);
/*  21 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
/*  22 */     b(true);
/*  23 */     a(ve.c);
/*  24 */     d(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  29 */     this.cQ = paramly.a("snow");
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  34 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3) & 0x7;
/*  35 */     float f = 0.125F;
/*  36 */     return aqx.a().a(paramInt1 + this.cG, paramInt2 + this.cH, paramInt3 + this.cI, paramInt1 + this.cJ, (paramInt2 + i * f), paramInt3 + this.cL);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  60 */     d(0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  65 */     d(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   protected void d(int paramInt) {
/*  69 */     int i = paramInt & 0x7;
/*  70 */     float f = (2 * (1 + i)) / 16.0F;
/*  71 */     a(0.0F, 0.0F, 0.0F, 1.0F, f, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  76 */     int i = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/*  77 */     if (i == 0) return false; 
/*  78 */     if (i == this.cz && (paramaab.h(paramInt1, paramInt2 - 1, paramInt3) & 0x7) == 7) return true; 
/*  79 */     if (i != apa.O.cz && !apa.r[i].c()) return false; 
/*  80 */     return paramaab.g(paramInt1, paramInt2 - 1, paramInt3).c();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  85 */     m(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   private boolean m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  89 */     if (!c(paramaab, paramInt1, paramInt2, paramInt3)) {
/*  90 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/*  91 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*  92 */       return false;
/*     */     } 
/*  94 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  99 */     int i = wk.aE.cp;
/* 100 */     int j = paramInt4 & 0x7;
/* 101 */     b(paramaab, paramInt1, paramInt2, paramInt3, new wm(i, j + 1, 0));
/* 102 */     paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     
/* 104 */     paramsq.a(kf.C[this.cz], 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 109 */     return wk.aE.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 114 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 119 */     if (paramaab.b(aam.b, paramInt1, paramInt2, paramInt3) > 11) {
/* 120 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 121 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 127 */     if (paramInt4 == 1) return true; 
/* 128 */     return super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */