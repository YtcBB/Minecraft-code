/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class agg
/*    */ {
/*    */   public Class a;
/*    */   public final int b;
/*    */   public int c;
/*    */   public int d;
/*    */   
/*    */   public agg(Class paramClass, int paramInt1, int paramInt2) {
/* 31 */     this.a = paramClass;
/* 32 */     this.b = paramInt1;
/* 33 */     this.d = paramInt2;
/*    */   }
/*    */   
/*    */   public boolean a(int paramInt) {
/* 37 */     return (this.d == 0 || this.c < this.d);
/*    */   }
/*    */   
/*    */   public boolean a() {
/* 41 */     return (this.d == 0 || this.c < this.d);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\agg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */