/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ade
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 11 */     for (byte b = 0; b < 10; b++) {
/* 12 */       int i = paramInt1 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 13 */       int j = paramInt2 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 14 */       int k = paramInt3 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 15 */       if (paramaab.c(i, j, k)) {
/* 16 */         int m = 1 + paramRandom.nextInt(paramRandom.nextInt(3) + 1);
/* 17 */         for (byte b1 = 0; b1 < m; b1++) {
/* 18 */           if (apa.aZ.f(paramaab, i, j + b1, k)) {
/* 19 */             paramaab.f(i, j + b1, k, apa.aZ.cz, 0, 2);
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 25 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ade.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */