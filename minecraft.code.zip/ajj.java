/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ajj
/*     */ {
/*     */   private aak a;
/*  12 */   private ajg b = new ajg();
/*  13 */   private kr c = new kr();
/*     */   
/*  15 */   private ajh[] d = new ajh[32];
/*     */   
/*     */   private boolean e;
/*     */   private boolean f;
/*     */   private boolean g;
/*     */   private boolean h;
/*     */   
/*     */   public ajj(aak paramaak, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/*  23 */     this.a = paramaak;
/*  24 */     this.e = paramBoolean1;
/*  25 */     this.f = paramBoolean2;
/*  26 */     this.g = paramBoolean3;
/*  27 */     this.h = paramBoolean4;
/*     */   }
/*     */   
/*     */   public aji a(mp parammp1, mp parammp2, float paramFloat) {
/*  31 */     return a(parammp1, parammp2.u, parammp2.E.b, parammp2.w, paramFloat);
/*     */   }
/*     */   
/*     */   public aji a(mp parammp, int paramInt1, int paramInt2, int paramInt3, float paramFloat) {
/*  35 */     return a(parammp, (paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), paramFloat);
/*     */   }
/*     */   
/*     */   private aji a(mp parammp, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat) {
/*  39 */     this.b.a();
/*  40 */     this.c.c();
/*     */     
/*  42 */     boolean bool = this.g;
/*  43 */     int i = kx.c(parammp.E.b + 0.5D);
/*  44 */     if (this.h && parammp.G())
/*  45 */     { i = (int)parammp.E.b;
/*  46 */       int j = this.a.a(kx.c(parammp.u), i, kx.c(parammp.w));
/*  47 */       while (j == apa.E.cz || j == apa.F.cz) {
/*  48 */         i++;
/*  49 */         j = this.a.a(kx.c(parammp.u), i, kx.c(parammp.w));
/*     */       } 
/*  51 */       bool = this.g;
/*  52 */       this.g = false; }
/*  53 */     else { i = kx.c(parammp.E.b + 0.5D); }
/*     */     
/*  55 */     ajh ajh1 = a(kx.c(parammp.E.a), i, kx.c(parammp.E.c));
/*  56 */     ajh ajh2 = a(kx.c(paramDouble1 - (parammp.O / 2.0F)), kx.c(paramDouble2), kx.c(paramDouble3 - (parammp.O / 2.0F)));
/*     */     
/*  58 */     ajh ajh3 = new ajh(kx.d(parammp.O + 1.0F), kx.d(parammp.P + 1.0F), kx.d(parammp.O + 1.0F));
/*  59 */     aji aji = a(parammp, ajh1, ajh2, ajh3, paramFloat);
/*     */     
/*  61 */     this.g = bool;
/*  62 */     return aji;
/*     */   }
/*     */ 
/*     */   
/*     */   private aji a(mp parammp, ajh paramajh1, ajh paramajh2, ajh paramajh3, float paramFloat) {
/*  67 */     paramajh1.e = 0.0F;
/*  68 */     paramajh1.f = paramajh1.b(paramajh2);
/*  69 */     paramajh1.g = paramajh1.f;
/*     */     
/*  71 */     this.b.a();
/*  72 */     this.b.a(paramajh1);
/*     */     
/*  74 */     ajh ajh1 = paramajh1;
/*     */     
/*  76 */     while (!this.b.e()) {
/*  77 */       ajh ajh2 = this.b.c();
/*     */       
/*  79 */       if (ajh2.equals(paramajh2)) {
/*  80 */         return a(paramajh1, paramajh2);
/*     */       }
/*     */       
/*  83 */       if (ajh2.b(paramajh2) < ajh1.b(paramajh2)) {
/*  84 */         ajh1 = ajh2;
/*     */       }
/*  86 */       ajh2.i = true;
/*     */       
/*  88 */       int i = b(parammp, ajh2, paramajh3, paramajh2, paramFloat);
/*  89 */       for (byte b = 0; b < i; b++) {
/*  90 */         ajh ajh3 = this.d[b];
/*     */         
/*  92 */         float f = ajh2.e + ajh2.b(ajh3);
/*  93 */         if (!ajh3.a() || f < ajh3.e) {
/*  94 */           ajh3.h = ajh2;
/*  95 */           ajh3.e = f;
/*  96 */           ajh3.f = ajh3.b(paramajh2);
/*  97 */           if (ajh3.a()) {
/*  98 */             this.b.a(ajh3, ajh3.e + ajh3.f);
/*     */           } else {
/* 100 */             ajh3.g = ajh3.e + ajh3.f;
/* 101 */             this.b.a(ajh3);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     if (ajh1 == paramajh1) return null; 
/* 108 */     return a(paramajh1, ajh1);
/*     */   }
/*     */   
/*     */   private int b(mp parammp, ajh paramajh1, ajh paramajh2, ajh paramajh3, float paramFloat) {
/* 112 */     byte b = 0;
/*     */     
/* 114 */     boolean bool = false;
/* 115 */     if (a(parammp, paramajh1.a, paramajh1.b + 1, paramajh1.c, paramajh2) == 1) bool = true;
/*     */     
/* 117 */     ajh ajh1 = a(parammp, paramajh1.a, paramajh1.b, paramajh1.c + 1, paramajh2, bool);
/* 118 */     ajh ajh2 = a(parammp, paramajh1.a - 1, paramajh1.b, paramajh1.c, paramajh2, bool);
/* 119 */     ajh ajh3 = a(parammp, paramajh1.a + 1, paramajh1.b, paramajh1.c, paramajh2, bool);
/* 120 */     ajh ajh4 = a(parammp, paramajh1.a, paramajh1.b, paramajh1.c - 1, paramajh2, bool);
/*     */     
/* 122 */     if (ajh1 != null && !ajh1.i && ajh1.a(paramajh3) < paramFloat) this.d[b++] = ajh1; 
/* 123 */     if (ajh2 != null && !ajh2.i && ajh2.a(paramajh3) < paramFloat) this.d[b++] = ajh2; 
/* 124 */     if (ajh3 != null && !ajh3.i && ajh3.a(paramajh3) < paramFloat) this.d[b++] = ajh3; 
/* 125 */     if (ajh4 != null && !ajh4.i && ajh4.a(paramajh3) < paramFloat) this.d[b++] = ajh4;
/*     */     
/* 127 */     return b;
/*     */   }
/*     */   
/*     */   private ajh a(mp parammp, int paramInt1, int paramInt2, int paramInt3, ajh paramajh, int paramInt4) {
/* 131 */     ajh ajh1 = null;
/* 132 */     int i = a(parammp, paramInt1, paramInt2, paramInt3, paramajh);
/* 133 */     if (i == 2) return a(paramInt1, paramInt2, paramInt3); 
/* 134 */     if (i == 1) ajh1 = a(paramInt1, paramInt2, paramInt3); 
/* 135 */     if (ajh1 == null && paramInt4 > 0 && i != -3 && i != -4 && a(parammp, paramInt1, paramInt2 + paramInt4, paramInt3, paramajh) == 1) {
/* 136 */       ajh1 = a(paramInt1, paramInt2 + paramInt4, paramInt3);
/* 137 */       paramInt2 += paramInt4;
/*     */     } 
/*     */     
/* 140 */     if (ajh1 != null) {
/* 141 */       byte b = 0;
/* 142 */       int j = 0;
/*     */       
/* 144 */       while (paramInt2 > 0) {
/* 145 */         j = a(parammp, paramInt1, paramInt2 - 1, paramInt3, paramajh);
/* 146 */         if (this.g && j == -1) return null; 
/* 147 */         if (j != 1) {
/*     */           break;
/*     */         }
/* 150 */         if (b++ >= parammp.ar()) return null; 
/* 151 */         paramInt2--;
/* 152 */         if (paramInt2 > 0) ajh1 = a(paramInt1, paramInt2, paramInt3);
/*     */       
/*     */       } 
/* 155 */       if (j == -2) return null;
/*     */     
/*     */     } 
/* 158 */     return ajh1;
/*     */   }
/*     */   
/*     */   private final ajh a(int paramInt1, int paramInt2, int paramInt3) {
/* 162 */     int i = ajh.a(paramInt1, paramInt2, paramInt3);
/* 163 */     ajh ajh1 = (ajh)this.c.a(i);
/* 164 */     if (ajh1 == null) {
/* 165 */       ajh1 = new ajh(paramInt1, paramInt2, paramInt3);
/* 166 */       this.c.a(i, ajh1);
/*     */     } 
/* 168 */     return ajh1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(mp parammp, int paramInt1, int paramInt2, int paramInt3, ajh paramajh) {
/* 180 */     return a(parammp, paramInt1, paramInt2, paramInt3, paramajh, this.g, this.f, this.e);
/*     */   }
/*     */   
/*     */   public static int a(mp parammp, int paramInt1, int paramInt2, int paramInt3, ajh paramajh, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/* 184 */     boolean bool = false;
/* 185 */     for (int i = paramInt1; i < paramInt1 + paramajh.a; i++) {
/* 186 */       for (int j = paramInt2; j < paramInt2 + paramajh.b; j++) {
/* 187 */         for (int k = paramInt3; k < paramInt3 + paramajh.c; k++) {
/*     */           
/* 189 */           int m = parammp.q.a(i, j, k);
/* 190 */           if (m > 0) {
/* 191 */             if (m == apa.bo.cz) { bool = true; }
/* 192 */             else if (m == apa.E.cz || m == apa.F.cz)
/* 193 */             { if (paramBoolean1) return -1; 
/* 194 */               bool = true; }
/* 195 */             else if (!paramBoolean3 && m == apa.aI.cz)
/* 196 */             { return 0; }
/*     */             
/* 198 */             apa apa = apa.r[m];
/* 199 */             int n = apa.d();
/*     */             
/* 201 */             if (parammp.q.e(i, j, k) == 9)
/* 202 */             { int i1 = kx.c(parammp.u);
/* 203 */               int i2 = kx.c(parammp.v);
/* 204 */               int i3 = kx.c(parammp.w);
/* 205 */               if (parammp.q.e(i1, i2, i3) != 9 && parammp.q.e(i1, i2 - 1, i3) != 9)
/*     */               {
/*     */ 
/*     */                 
/* 209 */                 return -3;
/*     */               
/*     */               } }
/*     */             
/* 213 */             else if (!apa.b(parammp.q, i, j, k) && (
/* 214 */               !paramBoolean2 || m != apa.aI.cz))
/*     */             
/* 216 */             { if (n == 11 || m == apa.bz.cz || n == 32) return -3;
/*     */               
/* 218 */               if (m == apa.bo.cz) return -4; 
/* 219 */               aif aif = apa.cO;
/* 220 */               if (aif == aif.i)
/* 221 */               { if (!parammp.I())
/* 222 */                   return -2;  }
/*     */               else
/* 224 */               { return 0; }  } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 228 */     }  return bool ? 2 : 1;
/*     */   }
/*     */ 
/*     */   
/*     */   private aji a(ajh paramajh1, ajh paramajh2) {
/* 233 */     byte b = 1;
/* 234 */     ajh ajh1 = paramajh2;
/* 235 */     while (ajh1.h != null) {
/* 236 */       b++;
/* 237 */       ajh1 = ajh1.h;
/*     */     } 
/*     */     
/* 240 */     ajh[] arrayOfAjh = new ajh[b];
/* 241 */     ajh1 = paramajh2;
/* 242 */     arrayOfAjh[--b] = ajh1;
/* 243 */     while (ajh1.h != null) {
/* 244 */       ajh1 = ajh1.h;
/* 245 */       arrayOfAjh[--b] = ajh1;
/*     */     } 
/* 247 */     return new aji(arrayOfAjh);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */