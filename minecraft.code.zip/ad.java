/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ad
/*    */   extends ai
/*    */ {
/*    */   public String c() {
/* 11 */     return "defaultgamemode";
/*    */   }
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 16 */     return paramab.a("commands.defaultgamemode.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 20 */     if (paramArrayOfString.length > 0) {
/* 21 */       aaj aaj = e(paramab, paramArrayOfString[0]);
/* 22 */       a(aaj);
/*    */       
/* 24 */       String str = bo.a("gameMode." + aaj.b());
/* 25 */       a(paramab, "commands.defaultgamemode.success", new Object[] { str });
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 30 */     throw new ax("commands.defaultgamemode.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   protected void a(aaj paramaaj) {
/* 34 */     MinecraftServer.D().a(paramaaj);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ad.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */