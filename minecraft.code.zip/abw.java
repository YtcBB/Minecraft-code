/*     */ import java.util.ArrayList;
/*     */ import java.util.Arrays;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class abw
/*     */ {
/*     */   public static boolean a;
/*  22 */   private abx[] r = new abx[16];
/*  23 */   private byte[] s = new byte[256];
/*  24 */   public int[] b = new int[256];
/*  25 */   public boolean[] c = new boolean[256];
/*     */   public boolean d;
/*     */   public aab e;
/*     */   public int[] f;
/*     */   public final int g;
/*     */   public final int h;
/*     */   private boolean t = false;
/*  32 */   public Map i = new HashMap<Object, Object>();
/*     */   
/*     */   public List[] j;
/*     */   public boolean k = false;
/*     */   public boolean l = false;
/*     */   public boolean m = false;
/*  38 */   public long n = 0L;
/*     */   public boolean o = false;
/*  40 */   public int p = 0;
/*     */ 
/*     */   
/*  43 */   private int u = 4096;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean q;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public abw(aab paramaab, byte[] paramArrayOfbyte, int paramInt1, int paramInt2) {
/*  59 */     this(paramaab, paramInt1, paramInt2);
/*     */     
/*  61 */     int i = paramArrayOfbyte.length / 256;
/*  62 */     for (byte b = 0; b < 16; b++) {
/*  63 */       for (byte b1 = 0; b1 < 16; b1++) {
/*  64 */         for (byte b2 = 0; b2 < i; b2++) {
/*  65 */           byte b3 = paramArrayOfbyte[b << 11 | b1 << 7 | b2];
/*  66 */           if (b3 != 0) {
/*  67 */             int j = b2 >> 4;
/*  68 */             if (this.r[j] == null) {
/*  69 */               this.r[j] = new abx(j << 4, !paramaab.t.f);
/*     */             }
/*  71 */             this.r[j].a(b, b2 & 0xF, b1, b3);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2) {
/*  79 */     return (paramInt1 == this.g && paramInt2 == this.h);
/*     */   }
/*     */   
/*     */   public int b(int paramInt1, int paramInt2) {
/*  83 */     return this.f[paramInt2 << 4 | paramInt1];
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int h() {
/*  97 */     for (int i = this.r.length - 1; i >= 0; i--) {
/*  98 */       if (this.r[i] != null) {
/*  99 */         return this.r[i].d();
/*     */       }
/*     */     } 
/* 102 */     return 0;
/*     */   }
/*     */   
/*     */   public abx[] i() {
/* 106 */     return this.r;
/*     */   }
/*     */   
/*     */   public void a() {
/* 110 */     int i = h();
/*     */     
/* 112 */     for (byte b = 0; b < 16; b++) {
/* 113 */       for (byte b1 = 0; b1 < 16; b1++) {
/* 114 */         this.b[b + (b1 << 4)] = -999;
/*     */         
/* 116 */         for (int j = i + 16 - 1; j > 0; j--) {
/* 117 */           int k = a(b, j - 1, b1);
/* 118 */           if (apa.t[k] != 0) {
/* 119 */             this.f[b1 << 4 | b] = j;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 126 */     this.l = true;
/*     */   }
/*     */   
/*     */   public void b() {
/* 130 */     int i = h();
/* 131 */     this.p = Integer.MAX_VALUE;
/*     */     byte b;
/* 133 */     for (b = 0; b < 16; b++) {
/* 134 */       for (byte b1 = 0; b1 < 16; b1++) {
/* 135 */         this.b[b + (b1 << 4)] = -999;
/*     */         int j;
/* 137 */         for (j = i + 16 - 1; j > 0; j--) {
/* 138 */           if (b(b, j - 1, b1) != 0) {
/* 139 */             this.f[b1 << 4 | b] = j;
/* 140 */             if (j < this.p) this.p = j;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/* 145 */         if (!this.e.t.f) {
/* 146 */           j = 15;
/* 147 */           int k = i + 16 - 1;
/*     */           do {
/* 149 */             j -= b(b, k, b1);
/* 150 */             if (j <= 0)
/* 151 */               continue;  abx abx1 = this.r[k >> 4];
/* 152 */             if (abx1 == null)
/* 153 */               continue;  abx1.c(b, k & 0xF, b1, j);
/* 154 */             this.e.p((this.g << 4) + b, k, (this.h << 4) + b1);
/*     */ 
/*     */             
/* 157 */             --k;
/* 158 */           } while (k > 0 && j > 0);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 163 */     this.l = true;
/*     */     
/* 165 */     for (b = 0; b < 16; b++) {
/* 166 */       for (byte b1 = 0; b1 < 16; b1++) {
/* 167 */         e(b, b1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void e(int paramInt1, int paramInt2) {
/* 174 */     this.c[paramInt1 + paramInt2 * 16] = true;
/* 175 */     this.t = true;
/*     */   }
/*     */   
/* 178 */   public abw(aab paramaab, int paramInt1, int paramInt2) { this.q = false; this.j = new List[16]; this.e = paramaab; this.g = paramInt1; this.h = paramInt2; this.f = new int[256]; for (byte b = 0; b < this.j.length; b++)
/*     */       this.j[b] = new ArrayList(); 
/*     */     Arrays.fill(this.b, -999);
/* 181 */     Arrays.fill(this.s, (byte)-1); } private void q() { this.e.C.a("recheckGaps");
/* 182 */     if (this.e.b(this.g * 16 + 8, 0, this.h * 16 + 8, 16)) {
/* 183 */       for (byte b = 0; b < 16; b++) {
/* 184 */         for (byte b1 = 0; b1 < 16; b1++) {
/* 185 */           if (this.c[b + b1 * 16]) {
/* 186 */             this.c[b + b1 * 16] = false;
/* 187 */             int i = b(b, b1);
/* 188 */             int j = this.g * 16 + b;
/* 189 */             int k = this.h * 16 + b1;
/*     */             
/* 191 */             int m = this.e.g(j - 1, k);
/* 192 */             int n = this.e.g(j + 1, k);
/* 193 */             int i1 = this.e.g(j, k - 1);
/* 194 */             int i2 = this.e.g(j, k + 1);
/* 195 */             if (n < m) m = n; 
/* 196 */             if (i1 < m) m = i1; 
/* 197 */             if (i2 < m) m = i2; 
/* 198 */             g(j, k, m);
/* 199 */             g(j - 1, k, i);
/* 200 */             g(j + 1, k, i);
/* 201 */             g(j, k - 1, i);
/* 202 */             g(j, k + 1, i);
/*     */           } 
/*     */         } 
/*     */       } 
/* 206 */       this.t = false;
/*     */     } 
/* 208 */     this.e.C.b(); }
/*     */ 
/*     */   
/*     */   private void g(int paramInt1, int paramInt2, int paramInt3) {
/* 212 */     int i = this.e.f(paramInt1, paramInt2);
/*     */     
/* 214 */     if (i > paramInt3) {
/* 215 */       d(paramInt1, paramInt2, paramInt3, i + 1);
/* 216 */     } else if (i < paramInt3) {
/* 217 */       d(paramInt1, paramInt2, i, paramInt3 + 1);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void d(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 222 */     if (paramInt4 > paramInt3 && 
/* 223 */       this.e.b(paramInt1, 0, paramInt2, 16)) {
/* 224 */       for (int i = paramInt3; i < paramInt4; i++) {
/* 225 */         this.e.c(aam.a, paramInt1, i, paramInt2);
/*     */       }
/* 227 */       this.l = true;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void h(int paramInt1, int paramInt2, int paramInt3) {
/* 233 */     int i = this.f[paramInt3 << 4 | paramInt1] & 0xFF;
/* 234 */     int j = i;
/* 235 */     if (paramInt2 > i) j = paramInt2;
/*     */     
/* 237 */     while (j > 0 && b(paramInt1, j - 1, paramInt3) == 0)
/* 238 */       j--; 
/* 239 */     if (j == i)
/*     */       return; 
/* 241 */     this.e.e(paramInt1 + this.g * 16, paramInt3 + this.h * 16, j, i);
/* 242 */     this.f[paramInt3 << 4 | paramInt1] = j;
/*     */     
/* 244 */     int k = this.g * 16 + paramInt1;
/* 245 */     int m = this.h * 16 + paramInt3;
/* 246 */     if (!this.e.t.f) {
/* 247 */       if (j < i) {
/* 248 */         for (int i4 = j; i4 < i; i4++) {
/* 249 */           abx abx1 = this.r[i4 >> 4];
/* 250 */           if (abx1 != null) {
/* 251 */             abx1.c(paramInt1, i4 & 0xF, paramInt3, 15);
/* 252 */             this.e.p((this.g << 4) + paramInt1, i4, (this.h << 4) + paramInt3);
/*     */           } 
/*     */         } 
/*     */       } else {
/* 256 */         for (int i4 = i; i4 < j; i4++) {
/* 257 */           abx abx1 = this.r[i4 >> 4];
/* 258 */           if (abx1 != null) {
/* 259 */             abx1.c(paramInt1, i4 & 0xF, paramInt3, 0);
/* 260 */             this.e.p((this.g << 4) + paramInt1, i4, (this.h << 4) + paramInt3);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */       
/* 265 */       int i3 = 15;
/* 266 */       while (j > 0 && i3 > 0) {
/* 267 */         j--;
/* 268 */         int i4 = b(paramInt1, j, paramInt3);
/* 269 */         if (i4 == 0) i4 = 1; 
/* 270 */         i3 -= i4;
/* 271 */         if (i3 < 0) i3 = 0;
/*     */         
/* 273 */         abx abx1 = this.r[j >> 4];
/* 274 */         if (abx1 != null) {
/* 275 */           abx1.c(paramInt1, j & 0xF, paramInt3, i3);
/*     */         }
/*     */       } 
/*     */     } 
/* 279 */     int n = this.f[paramInt3 << 4 | paramInt1];
/* 280 */     int i1 = i;
/* 281 */     int i2 = n;
/* 282 */     if (i2 < i1) {
/* 283 */       int i3 = i1;
/* 284 */       i1 = i2;
/* 285 */       i2 = i3;
/*     */     } 
/* 287 */     if (n < this.p) this.p = n; 
/* 288 */     if (!this.e.t.f) {
/* 289 */       d(k - 1, m, i1, i2);
/* 290 */       d(k + 1, m, i1, i2);
/* 291 */       d(k, m - 1, i1, i2);
/* 292 */       d(k, m + 1, i1, i2);
/* 293 */       d(k, m, i1, i2);
/*     */     } 
/*     */     
/* 296 */     this.l = true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int b(int paramInt1, int paramInt2, int paramInt3) {
/* 309 */     return apa.t[a(paramInt1, paramInt2, paramInt3)];
/*     */   }
/*     */   
/*     */   public int a(int paramInt1, int paramInt2, int paramInt3) {
/* 313 */     if (paramInt2 >> 4 >= this.r.length) return 0; 
/* 314 */     abx abx1 = this.r[paramInt2 >> 4];
/* 315 */     if (abx1 != null) {
/* 316 */       return abx1.a(paramInt1, paramInt2 & 0xF, paramInt3);
/*     */     }
/* 318 */     return 0;
/*     */   }
/*     */   
/*     */   public int c(int paramInt1, int paramInt2, int paramInt3) {
/* 322 */     if (paramInt2 >> 4 >= this.r.length) return 0; 
/* 323 */     abx abx1 = this.r[paramInt2 >> 4];
/* 324 */     if (abx1 != null) {
/* 325 */       return abx1.b(paramInt1, paramInt2 & 0xF, paramInt3);
/*     */     }
/* 327 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 335 */     int i = paramInt3 << 4 | paramInt1;
/*     */     
/* 337 */     if (paramInt2 >= this.b[i] - 1) {
/* 338 */       this.b[i] = -999;
/*     */     }
/*     */     
/* 341 */     int j = this.f[i];
/*     */     
/* 343 */     int k = a(paramInt1, paramInt2, paramInt3);
/* 344 */     int m = c(paramInt1, paramInt2, paramInt3);
/* 345 */     if (k == paramInt4 && m == paramInt5) return false;
/*     */     
/* 347 */     abx abx1 = this.r[paramInt2 >> 4];
/* 348 */     boolean bool = false;
/* 349 */     if (abx1 == null) {
/* 350 */       if (paramInt4 == 0) {
/* 351 */         return false;
/*     */       }
/*     */       
/* 354 */       abx1 = this.r[paramInt2 >> 4] = new abx(paramInt2 >> 4 << 4, !this.e.t.f);
/* 355 */       bool = (paramInt2 >= j) ? true : false;
/*     */     } 
/*     */     
/* 358 */     int n = this.g * 16 + paramInt1;
/* 359 */     int i1 = this.h * 16 + paramInt3;
/* 360 */     if (k != 0 && !this.e.I) {
/* 361 */       apa.r[k].l(this.e, n, paramInt2, i1, m);
/*     */     }
/*     */     
/* 364 */     abx1.a(paramInt1, paramInt2 & 0xF, paramInt3, paramInt4);
/* 365 */     if (k != 0) {
/* 366 */       if (!this.e.I) {
/* 367 */         apa.r[k].a(this.e, n, paramInt2, i1, k, m);
/* 368 */       } else if (apa.r[k] instanceof amh && k != paramInt4) {
/* 369 */         this.e.s(n, paramInt2, i1);
/*     */       } 
/*     */     }
/*     */     
/* 373 */     if (abx1.a(paramInt1, paramInt2 & 0xF, paramInt3) != paramInt4) return false;
/*     */     
/* 375 */     abx1.b(paramInt1, paramInt2 & 0xF, paramInt3, paramInt5);
/*     */     
/* 377 */     if (bool) {
/* 378 */       b();
/*     */     } else {
/* 380 */       if (apa.t[paramInt4 & 0xFFF] > 0) {
/* 381 */         if (paramInt2 >= j) {
/* 382 */           h(paramInt1, paramInt2 + 1, paramInt3);
/*     */         }
/*     */       }
/* 385 */       else if (paramInt2 == j - 1) {
/* 386 */         h(paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */ 
/*     */       
/* 390 */       e(paramInt1, paramInt3);
/*     */     } 
/*     */     
/* 393 */     if (paramInt4 != 0) {
/* 394 */       if (!this.e.I) apa.r[paramInt4].a(this.e, n, paramInt2, i1); 
/* 395 */       if (apa.r[paramInt4] instanceof amh) {
/* 396 */         aqp aqp = e(paramInt1, paramInt2, paramInt3);
/* 397 */         if (aqp == null) {
/* 398 */           aqp = ((amh)apa.r[paramInt4]).b(this.e);
/* 399 */           this.e.a(n, paramInt2, i1, aqp);
/*     */         } 
/* 401 */         if (aqp != null) {
/* 402 */           aqp.i();
/*     */         }
/*     */       } 
/* 405 */     } else if (k > 0 && apa.r[k] instanceof amh) {
/* 406 */       aqp aqp = e(paramInt1, paramInt2, paramInt3);
/* 407 */       if (aqp != null) {
/* 408 */         aqp.i();
/*     */       }
/*     */     } 
/*     */     
/* 412 */     this.l = true;
/* 413 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 418 */     abx abx1 = this.r[paramInt2 >> 4];
/* 419 */     if (abx1 == null) {
/* 420 */       return false;
/*     */     }
/*     */     
/* 423 */     int i = abx1.b(paramInt1, paramInt2 & 0xF, paramInt3);
/* 424 */     if (i == paramInt4) {
/* 425 */       return false;
/*     */     }
/*     */     
/* 428 */     this.l = true;
/* 429 */     abx1.b(paramInt1, paramInt2 & 0xF, paramInt3, paramInt4);
/* 430 */     int j = abx1.a(paramInt1, paramInt2 & 0xF, paramInt3);
/* 431 */     if (j > 0 && apa.r[j] instanceof amh) {
/* 432 */       aqp aqp = e(paramInt1, paramInt2, paramInt3);
/* 433 */       if (aqp != null) {
/* 434 */         aqp.i();
/* 435 */         aqp.p = paramInt4;
/*     */       } 
/*     */     } 
/* 438 */     return true;
/*     */   }
/*     */   
/*     */   public int a(aam paramaam, int paramInt1, int paramInt2, int paramInt3) {
/* 442 */     abx abx1 = this.r[paramInt2 >> 4];
/* 443 */     if (abx1 == null) {
/* 444 */       if (d(paramInt1, paramInt2, paramInt3)) {
/* 445 */         return paramaam.c;
/*     */       }
/* 447 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 451 */     if (paramaam == aam.a) {
/* 452 */       if (this.e.t.f) {
/* 453 */         return 0;
/*     */       }
/* 455 */       return abx1.c(paramInt1, paramInt2 & 0xF, paramInt3);
/* 456 */     }  if (paramaam == aam.b) return abx1.d(paramInt1, paramInt2 & 0xF, paramInt3); 
/* 457 */     return paramaam.c;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aam paramaam, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 462 */     abx abx1 = this.r[paramInt2 >> 4];
/* 463 */     if (abx1 == null) {
/* 464 */       abx1 = this.r[paramInt2 >> 4] = new abx(paramInt2 >> 4 << 4, !this.e.t.f);
/* 465 */       b();
/*     */     } 
/*     */     
/* 468 */     this.l = true;
/* 469 */     if (paramaam == aam.a) {
/* 470 */       if (!this.e.t.f) {
/* 471 */         abx1.c(paramInt1, paramInt2 & 0xF, paramInt3, paramInt4);
/*     */       }
/*     */     }
/* 474 */     else if (paramaam == aam.b) {
/* 475 */       abx1.d(paramInt1, paramInt2 & 0xF, paramInt3, paramInt4);
/*     */     } 
/*     */   }
/*     */   
/*     */   public int c(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 480 */     abx abx1 = this.r[paramInt2 >> 4];
/* 481 */     if (abx1 == null) {
/* 482 */       if (!this.e.t.f && paramInt4 < aam.a.c) {
/* 483 */         return aam.a.c - paramInt4;
/*     */       }
/* 485 */       return 0;
/*     */     } 
/*     */     
/* 488 */     int i = this.e.t.f ? 0 : abx1.c(paramInt1, paramInt2 & 0xF, paramInt3);
/* 489 */     if (i) a = true; 
/* 490 */     i -= paramInt4;
/* 491 */     int j = abx1.d(paramInt1, paramInt2 & 0xF, paramInt3);
/* 492 */     if (j > i) i = j;
/*     */     
/* 494 */     return i;
/*     */   }
/*     */   
/*     */   public void a(mp parammp) {
/* 498 */     this.m = true;
/*     */     
/* 500 */     int i = kx.c(parammp.u / 16.0D);
/* 501 */     int j = kx.c(parammp.w / 16.0D);
/* 502 */     if (i != this.g || j != this.h) {
/* 503 */       this.e.X().c("Wrong location! " + parammp);
/* 504 */       Thread.dumpStack();
/*     */     } 
/* 506 */     int k = kx.c(parammp.v / 16.0D);
/* 507 */     if (k < 0) k = 0; 
/* 508 */     if (k >= this.j.length) k = this.j.length - 1; 
/* 509 */     parammp.ai = true;
/* 510 */     parammp.aj = this.g;
/* 511 */     parammp.ak = k;
/* 512 */     parammp.al = this.h;
/* 513 */     this.j[k].add(parammp);
/*     */   }
/*     */   
/*     */   public void b(mp parammp) {
/* 517 */     a(parammp, parammp.ak);
/*     */   }
/*     */   
/*     */   public void a(mp parammp, int paramInt) {
/* 521 */     if (paramInt < 0) paramInt = 0; 
/* 522 */     if (paramInt >= this.j.length) paramInt = this.j.length - 1; 
/* 523 */     this.j[paramInt].remove(parammp);
/*     */   }
/*     */   
/*     */   public boolean d(int paramInt1, int paramInt2, int paramInt3) {
/* 527 */     return (paramInt2 >= this.f[paramInt3 << 4 | paramInt1]);
/*     */   }
/*     */   
/*     */   public aqp e(int paramInt1, int paramInt2, int paramInt3) {
/* 531 */     aat aat = new aat(paramInt1, paramInt2, paramInt3);
/*     */     
/* 533 */     aqp aqp = (aqp)this.i.get(aat);
/* 534 */     if (aqp == null) {
/* 535 */       int i = a(paramInt1, paramInt2, paramInt3);
/* 536 */       if (i <= 0 || !apa.r[i].t()) return null; 
/* 537 */       if (aqp == null) {
/* 538 */         aqp = ((amh)apa.r[i]).b(this.e);
/* 539 */         this.e.a(this.g * 16 + paramInt1, paramInt2, this.h * 16 + paramInt3, aqp);
/*     */       } 
/* 541 */       aqp = (aqp)this.i.get(aat);
/*     */     } 
/*     */     
/* 544 */     if (aqp != null && aqp.r()) {
/* 545 */       this.i.remove(aat);
/* 546 */       return null;
/*     */     } 
/*     */     
/* 549 */     return aqp;
/*     */   }
/*     */   
/*     */   public void a(aqp paramaqp) {
/* 553 */     int i = paramaqp.l - this.g * 16;
/* 554 */     int j = paramaqp.m;
/* 555 */     int k = paramaqp.n - this.h * 16;
/* 556 */     a(i, j, k, paramaqp);
/* 557 */     if (this.d) {
/* 558 */       this.e.g.add(paramaqp);
/*     */     }
/*     */   }
/*     */   
/*     */   public void a(int paramInt1, int paramInt2, int paramInt3, aqp paramaqp) {
/* 563 */     aat aat = new aat(paramInt1, paramInt2, paramInt3);
/*     */     
/* 565 */     paramaqp.b(this.e);
/* 566 */     paramaqp.l = this.g * 16 + paramInt1;
/* 567 */     paramaqp.m = paramInt2;
/* 568 */     paramaqp.n = this.h * 16 + paramInt3;
/*     */     
/* 570 */     if (a(paramInt1, paramInt2, paramInt3) == 0 || !(apa.r[a(paramInt1, paramInt2, paramInt3)] instanceof amh)) {
/*     */       return;
/*     */     }
/* 573 */     if (this.i.containsKey(aat)) {
/* 574 */       ((aqp)this.i.get(aat)).w_();
/*     */     }
/*     */     
/* 577 */     paramaqp.s();
/* 578 */     this.i.put(aat, paramaqp);
/*     */   }
/*     */ 
/*     */   
/*     */   public void f(int paramInt1, int paramInt2, int paramInt3) {
/* 583 */     aat aat = new aat(paramInt1, paramInt2, paramInt3);
/*     */     
/* 585 */     if (this.d) {
/* 586 */       aqp aqp = (aqp)this.i.remove(aat);
/* 587 */       if (aqp != null) {
/* 588 */         aqp.w_();
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public void c() {
/* 594 */     this.d = true;
/* 595 */     this.e.a(this.i.values());
/* 596 */     for (byte b = 0; b < this.j.length; b++) {
/* 597 */       this.e.a(this.j[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void d() {
/* 602 */     this.d = false;
/* 603 */     for (aqp aqp : this.i.values()) {
/* 604 */       this.e.a(aqp);
/*     */     }
/* 606 */     for (byte b = 0; b < this.j.length; b++) {
/* 607 */       this.e.b(this.j[b]);
/*     */     }
/*     */   }
/*     */   
/*     */   public void e() {
/* 612 */     this.l = true;
/*     */   }
/*     */   
/*     */   public void a(mp parammp, aqx paramaqx, List<mp> paramList, my parammy) {
/* 616 */     int i = kx.c((paramaqx.b - 2.0D) / 16.0D);
/* 617 */     int j = kx.c((paramaqx.e + 2.0D) / 16.0D);
/*     */     
/* 619 */     if (i < 0) {
/* 620 */       i = 0;
/* 621 */       j = Math.max(i, j);
/*     */     } 
/*     */     
/* 624 */     if (j >= this.j.length) {
/* 625 */       j = this.j.length - 1;
/* 626 */       i = Math.min(i, j);
/*     */     } 
/*     */     
/* 629 */     for (int k = i; k <= j; k++) {
/* 630 */       List<mp> list = this.j[k];
/* 631 */       for (byte b = 0; b < list.size(); b++) {
/* 632 */         mp mp1 = list.get(b);
/* 633 */         if (mp1 != parammp && mp1.E.a(paramaqx) && (parammy == null || parammy.a(mp1))) {
/* 634 */           paramList.add(mp1);
/*     */           
/* 636 */           mp[] arrayOfMp = mp1.an();
/* 637 */           if (arrayOfMp != null) {
/* 638 */             for (byte b1 = 0; b1 < arrayOfMp.length; b1++) {
/* 639 */               mp1 = arrayOfMp[b1];
/* 640 */               if (mp1 != parammp && mp1.E.a(paramaqx) && (parammy == null || parammy.a(mp1))) {
/* 641 */                 paramList.add(mp1);
/*     */               }
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void a(Class paramClass, aqx paramaqx, List<mp> paramList, my parammy) {
/* 651 */     int i = kx.c((paramaqx.b - 2.0D) / 16.0D);
/* 652 */     int j = kx.c((paramaqx.e + 2.0D) / 16.0D);
/* 653 */     if (i < 0) {
/* 654 */       i = 0;
/* 655 */     } else if (i >= this.j.length) {
/* 656 */       i = this.j.length - 1;
/*     */     } 
/* 658 */     if (j >= this.j.length) {
/* 659 */       j = this.j.length - 1;
/* 660 */     } else if (j < 0) {
/* 661 */       j = 0;
/*     */     } 
/* 663 */     for (int k = i; k <= j; k++) {
/* 664 */       List<mp> list = this.j[k];
/* 665 */       for (byte b = 0; b < list.size(); b++) {
/* 666 */         mp mp = list.get(b);
/* 667 */         if (paramClass.isAssignableFrom(mp.getClass()) && mp.E.a(paramaqx) && (
/* 668 */           parammy == null || parammy.a(mp))) {
/* 669 */           paramList.add(mp);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(boolean paramBoolean) {
/* 685 */     if (paramBoolean)
/* 686 */     { if ((this.m && this.e.H() != this.n) || this.l) {
/* 687 */         return true;
/*     */       } }
/*     */     
/* 690 */     else if (this.m && this.e.H() >= this.n + 600L) { return true; }
/*     */ 
/*     */     
/* 693 */     return this.l;
/*     */   }
/*     */   
/*     */   public Random a(long paramLong) {
/* 697 */     return new Random(this.e.G() + (this.g * this.g * 4987142) + (this.g * 5947611) + (this.h * this.h) * 4392871L + (this.h * 389711) ^ paramLong);
/*     */   }
/*     */   
/*     */   public boolean g() {
/* 701 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(abt paramabt1, abt paramabt2, int paramInt1, int paramInt2) {
/* 718 */     if (!this.k && paramabt1.a(paramInt1 + 1, paramInt2 + 1) && paramabt1.a(paramInt1, paramInt2 + 1) && paramabt1.a(paramInt1 + 1, paramInt2)) {
/* 719 */       paramabt1.a(paramabt2, paramInt1, paramInt2);
/*     */     }
/* 721 */     if (paramabt1.a(paramInt1 - 1, paramInt2) && !(paramabt1.d(paramInt1 - 1, paramInt2)).k && paramabt1.a(paramInt1 - 1, paramInt2 + 1) && paramabt1.a(paramInt1, paramInt2 + 1) && paramabt1.a(paramInt1 - 1, paramInt2 + 1)) {
/* 722 */       paramabt1.a(paramabt2, paramInt1 - 1, paramInt2);
/*     */     }
/* 724 */     if (paramabt1.a(paramInt1, paramInt2 - 1) && !(paramabt1.d(paramInt1, paramInt2 - 1)).k && paramabt1.a(paramInt1 + 1, paramInt2 - 1) && paramabt1.a(paramInt1 + 1, paramInt2 - 1) && paramabt1.a(paramInt1 + 1, paramInt2)) {
/* 725 */       paramabt1.a(paramabt2, paramInt1, paramInt2 - 1);
/*     */     }
/* 727 */     if (paramabt1.a(paramInt1 - 1, paramInt2 - 1) && !(paramabt1.d(paramInt1 - 1, paramInt2 - 1)).k && paramabt1.a(paramInt1, paramInt2 - 1) && paramabt1.a(paramInt1 - 1, paramInt2)) {
/* 728 */       paramabt1.a(paramabt2, paramInt1 - 1, paramInt2 - 1);
/*     */     }
/*     */   }
/*     */   
/*     */   public int d(int paramInt1, int paramInt2) {
/* 733 */     int i = paramInt1 | paramInt2 << 4;
/* 734 */     int j = this.b[i];
/* 735 */     if (j == -999) {
/* 736 */       int k = h() + 15;
/* 737 */       j = -1;
/* 738 */       while (k > 0 && j == -1) {
/* 739 */         int m = a(paramInt1, k, paramInt2);
/* 740 */         aif aif = (m == 0) ? aif.a : (apa.r[m]).cO;
/* 741 */         if (!aif.c() && !aif.d()) {
/* 742 */           k--; continue;
/*     */         } 
/* 744 */         j = k + 1;
/*     */       } 
/*     */       
/* 747 */       this.b[i] = j;
/*     */     } 
/*     */     
/* 750 */     return j;
/*     */   }
/*     */   
/*     */   public void k() {
/* 754 */     if (this.t && !this.e.t.f) q(); 
/*     */   }
/*     */   
/*     */   public zu l() {
/* 758 */     return new zu(this.g, this.h);
/*     */   }
/*     */   
/*     */   public boolean c(int paramInt1, int paramInt2) {
/* 762 */     if (paramInt1 < 0) {
/* 763 */       paramInt1 = 0;
/*     */     }
/* 765 */     if (paramInt2 >= 256) {
/* 766 */       paramInt2 = 255;
/*     */     }
/* 768 */     for (int i = paramInt1; i <= paramInt2; i += 16) {
/* 769 */       abx abx1 = this.r[i >> 4];
/* 770 */       if (abx1 != null && !abx1.a()) {
/* 771 */         return false;
/*     */       }
/*     */     } 
/* 774 */     return true;
/*     */   }
/*     */   
/*     */   public void a(abx[] paramArrayOfabx) {
/* 778 */     this.r = paramArrayOfabx;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(byte[] paramArrayOfbyte, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 783 */     int i = 0;
/*     */     
/* 785 */     boolean bool = !this.e.t.f ? true : false;
/*     */     byte b;
/* 787 */     for (b = 0; b < this.r.length; b++) {
/* 788 */       if ((paramInt1 & 1 << b) != 0) {
/*     */         
/* 790 */         if (this.r[b] == null) {
/* 791 */           this.r[b] = new abx(b << 4, bool);
/*     */         }
/* 793 */         byte[] arrayOfByte = this.r[b].g();
/* 794 */         System.arraycopy(paramArrayOfbyte, i, arrayOfByte, 0, arrayOfByte.length);
/* 795 */         i += arrayOfByte.length;
/*     */       }
/* 797 */       else if (paramBoolean && this.r[b] != null) {
/* 798 */         this.r[b] = null;
/*     */       } 
/*     */     } 
/* 801 */     for (b = 0; b < this.r.length; b++) {
/* 802 */       if ((paramInt1 & 1 << b) != 0 && this.r[b] != null) {
/* 803 */         abu abu = this.r[b].j();
/* 804 */         System.arraycopy(paramArrayOfbyte, i, abu.a, 0, abu.a.length);
/* 805 */         i += abu.a.length;
/*     */       } 
/*     */     } 
/* 808 */     for (b = 0; b < this.r.length; b++) {
/* 809 */       if ((paramInt1 & 1 << b) != 0 && this.r[b] != null) {
/* 810 */         abu abu = this.r[b].k();
/* 811 */         System.arraycopy(paramArrayOfbyte, i, abu.a, 0, abu.a.length);
/* 812 */         i += abu.a.length;
/*     */       } 
/*     */     } 
/* 815 */     if (bool) {
/* 816 */       for (b = 0; b < this.r.length; b++) {
/* 817 */         if ((paramInt1 & 1 << b) != 0 && this.r[b] != null) {
/* 818 */           abu abu = this.r[b].l();
/* 819 */           System.arraycopy(paramArrayOfbyte, i, abu.a, 0, abu.a.length);
/* 820 */           i += abu.a.length;
/*     */         } 
/*     */       } 
/*     */     }
/* 824 */     for (b = 0; b < this.r.length; b++) {
/* 825 */       if ((paramInt2 & 1 << b) != 0) {
/* 826 */         if (this.r[b] == null) {
/* 827 */           i += 2048;
/*     */         } else {
/* 829 */           abu abu = this.r[b].i();
/* 830 */           if (abu == null) {
/* 831 */             abu = this.r[b].m();
/*     */           }
/* 833 */           System.arraycopy(paramArrayOfbyte, i, abu.a, 0, abu.a.length);
/* 834 */           i += abu.a.length;
/*     */         } 
/* 836 */       } else if (paramBoolean && this.r[b] != null && this.r[b].i() != null) {
/* 837 */         this.r[b].h();
/*     */       } 
/*     */     } 
/* 840 */     if (paramBoolean) {
/* 841 */       System.arraycopy(paramArrayOfbyte, i, this.s, 0, this.s.length);
/* 842 */       i += this.s.length;
/*     */     } 
/*     */     
/* 845 */     for (b = 0; b < this.r.length; b++) {
/* 846 */       if (this.r[b] != null && (paramInt1 & 1 << b) != 0) {
/* 847 */         this.r[b].e();
/*     */       }
/*     */     } 
/*     */     
/* 851 */     a();
/*     */     
/* 853 */     for (aqp aqp : this.i.values()) {
/* 854 */       aqp.i();
/*     */     }
/*     */   }
/*     */   
/*     */   public aav a(int paramInt1, int paramInt2, aba paramaba) {
/* 859 */     int i = this.s[paramInt2 << 4 | paramInt1] & 0xFF;
/* 860 */     if (i == 255) {
/* 861 */       aav aav = paramaba.a((this.g << 4) + paramInt1, (this.h << 4) + paramInt2);
/* 862 */       i = aav.N;
/* 863 */       this.s[paramInt2 << 4 | paramInt1] = (byte)(i & 0xFF);
/*     */     } 
/* 865 */     if (aav.a[i] == null) {
/* 866 */       return aav.c;
/*     */     }
/* 868 */     return aav.a[i];
/*     */   }
/*     */   
/*     */   public byte[] m() {
/* 872 */     return this.s;
/*     */   }
/*     */   
/*     */   public void a(byte[] paramArrayOfbyte) {
/* 876 */     this.s = paramArrayOfbyte;
/*     */   }
/*     */   
/*     */   public void n() {
/* 880 */     this.u = 0;
/*     */   }
/*     */   
/*     */   public void o() {
/* 884 */     for (byte b = 0; b < 8; b++) {
/* 885 */       if (this.u >= 4096) {
/*     */         return;
/*     */       }
/*     */       
/* 889 */       int i = this.u % 16;
/* 890 */       int j = this.u / 16 % 16;
/* 891 */       int k = this.u / 256;
/* 892 */       this.u++;
/*     */       
/* 894 */       int m = (this.g << 4) + j;
/* 895 */       int n = (this.h << 4) + k;
/*     */       
/* 897 */       for (byte b1 = 0; b1 < 16; b1++) {
/* 898 */         int i1 = (i << 4) + b1;
/* 899 */         if ((this.r[i] == null && (b1 == 0 || b1 == 15 || j == 0 || j == 15 || k == 0 || k == 15)) || (this.r[i] != null && this.r[i].a(j, b1, k) == 0)) {
/*     */           
/* 901 */           if (apa.v[this.e.a(m, i1 - 1, n)] > 0) {
/* 902 */             this.e.A(m, i1 - 1, n);
/*     */           }
/* 904 */           if (apa.v[this.e.a(m, i1 + 1, n)] > 0) {
/* 905 */             this.e.A(m, i1 + 1, n);
/*     */           }
/* 907 */           if (apa.v[this.e.a(m - 1, i1, n)] > 0) {
/* 908 */             this.e.A(m - 1, i1, n);
/*     */           }
/* 910 */           if (apa.v[this.e.a(m + 1, i1, n)] > 0) {
/* 911 */             this.e.A(m + 1, i1, n);
/*     */           }
/* 913 */           if (apa.v[this.e.a(m, i1, n - 1)] > 0) {
/* 914 */             this.e.A(m, i1, n - 1);
/*     */           }
/* 916 */           if (apa.v[this.e.a(m, i1, n + 1)] > 0) {
/* 917 */             this.e.A(m, i1, n + 1);
/*     */           }
/* 919 */           this.e.A(m, i1, n);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */