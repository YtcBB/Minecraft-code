/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class adu
/*     */   extends adj
/*     */ {
/*     */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/*  15 */     byte b1 = 3;
/*  16 */     int i = paramRandom.nextInt(2) + 2;
/*  17 */     int j = paramRandom.nextInt(2) + 2;
/*     */     
/*  19 */     byte b2 = 0; int k;
/*  20 */     for (k = paramInt1 - i - 1; k <= paramInt1 + i + 1; k++) {
/*  21 */       for (int m = paramInt2 - 1; m <= paramInt2 + b1 + 1; m++) {
/*  22 */         for (int n = paramInt3 - j - 1; n <= paramInt3 + j + 1; n++) {
/*  23 */           aif aif = paramaab.g(k, m, n);
/*  24 */           if (m == paramInt2 - 1 && !aif.a()) return false; 
/*  25 */           if (m == paramInt2 + b1 + 1 && !aif.a()) return false;
/*     */           
/*  27 */           if ((k == paramInt1 - i - 1 || k == paramInt1 + i + 1 || n == paramInt3 - j - 1 || n == paramInt3 + j + 1) && 
/*  28 */             m == paramInt2 && paramaab.c(k, m, n) && paramaab.c(k, m + 1, n)) {
/*  29 */             b2++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/*  37 */     if (b2 < 1 || b2 > 5) return false;
/*     */     
/*  39 */     for (k = paramInt1 - i - 1; k <= paramInt1 + i + 1; k++) {
/*  40 */       for (int m = paramInt2 + b1; m >= paramInt2 - 1; m--) {
/*  41 */         for (int n = paramInt3 - j - 1; n <= paramInt3 + j + 1; n++) {
/*     */           
/*  43 */           if (k == paramInt1 - i - 1 || m == paramInt2 - 1 || n == paramInt3 - j - 1 || k == paramInt1 + i + 1 || m == paramInt2 + b1 + 1 || n == paramInt3 + j + 1) {
/*  44 */             if (m >= 0 && !paramaab.g(k, m - 1, n).a()) {
/*  45 */               paramaab.i(k, m, n);
/*  46 */             } else if (paramaab.g(k, m, n).a()) {
/*  47 */               if (m == paramInt2 - 1 && paramRandom.nextInt(4) != 0) {
/*  48 */                 paramaab.f(k, m, n, apa.as.cz, 0, 2);
/*     */               } else {
/*  50 */                 paramaab.f(k, m, n, apa.A.cz, 0, 2);
/*     */               } 
/*     */             } 
/*     */           } else {
/*  54 */             paramaab.i(k, m, n);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  60 */     for (k = 0; k < 2; k++) {
/*  61 */       for (byte b = 0; b < 3; b++) {
/*  62 */         int m = paramInt1 + paramRandom.nextInt(i * 2 + 1) - i;
/*  63 */         int n = paramInt2;
/*  64 */         int i1 = paramInt3 + paramRandom.nextInt(j * 2 + 1) - j;
/*  65 */         if (paramaab.c(m, n, i1)) {
/*     */           
/*  67 */           byte b3 = 0;
/*  68 */           if (paramaab.g(m - 1, n, i1).a()) b3++; 
/*  69 */           if (paramaab.g(m + 1, n, i1).a()) b3++; 
/*  70 */           if (paramaab.g(m, n, i1 - 1).a()) b3++; 
/*  71 */           if (paramaab.g(m, n, i1 + 1).a()) b3++;
/*     */           
/*  73 */           if (b3 == 1) {
/*     */             
/*  75 */             paramaab.f(m, n, i1, apa.ay.cz, 0, 2);
/*  76 */             apy apy = (apy)paramaab.r(m, n, i1);
/*  77 */             if (apy != null)
/*  78 */               for (byte b4 = 0; b4 < 8; b4++) {
/*  79 */                 wm wm = a(paramRandom);
/*  80 */                 if (wm != null) apy.a(paramRandom.nextInt(apy.j_()), wm);
/*     */               
/*     */               }  
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  88 */     paramaab.f(paramInt1, paramInt2, paramInt3, apa.aw.cz, 0, 2);
/*  89 */     aqj aqj = (aqj)paramaab.r(paramInt1, paramInt2, paramInt3);
/*  90 */     if (aqj != null) {
/*  91 */       aqj.a().a(b(paramRandom));
/*     */     } else {
/*  93 */       System.err.println("Failed to fetch mob spawner entity at (" + paramInt1 + ", " + paramInt2 + ", " + paramInt3 + ")");
/*     */     } 
/*     */     
/*  96 */     return true;
/*     */   }
/*     */   
/*     */   private wm a(Random paramRandom) {
/* 100 */     int i = paramRandom.nextInt(12);
/* 101 */     if (i == 0) return new wm(wk.aB); 
/* 102 */     if (i == 1) return new wm(wk.p, paramRandom.nextInt(4) + 1); 
/* 103 */     if (i == 2) return new wm(wk.V); 
/* 104 */     if (i == 3) return new wm(wk.U, paramRandom.nextInt(4) + 1); 
/* 105 */     if (i == 4) return new wm(wk.N, paramRandom.nextInt(4) + 1); 
/* 106 */     if (i == 5) return new wm(wk.L, paramRandom.nextInt(4) + 1); 
/* 107 */     if (i == 6) return new wm(wk.ax); 
/* 108 */     if (i == 7 && paramRandom.nextInt(100) == 0) return new wm(wk.au); 
/* 109 */     if (i == 8 && paramRandom.nextInt(2) == 0) return new wm(wk.aD, paramRandom.nextInt(4) + 1); 
/* 110 */     if (i == 9 && paramRandom.nextInt(10) == 0) return new wm(wk.f[wk.cd.cp + paramRandom.nextInt(2)]); 
/* 111 */     if (i == 10) return new wm(wk.aX, 1, 3); 
/* 112 */     if (i == 11) return wk.bX.a(paramRandom);
/*     */     
/* 114 */     return null;
/*     */   }
/*     */   
/*     */   private String b(Random paramRandom) {
/* 118 */     int i = paramRandom.nextInt(4);
/* 119 */     if (i == 0) return "Skeleton"; 
/* 120 */     if (i == 1) return "Zombie"; 
/* 121 */     if (i == 2) return "Zombie"; 
/* 122 */     if (i == 3) return "Spider"; 
/* 123 */     return "";
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */