/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aay
/*    */ {
/* 18 */   public float[] a = new float[256];
/* 19 */   public float[] b = new float[256];
/* 20 */   public aav[] c = new aav[256];
/*    */   
/*    */   public int d;
/*    */   
/*    */   public aay(aax paramaax, int paramInt1, int paramInt2) {
/* 25 */     this.d = paramInt1;
/* 26 */     this.e = paramInt2;
/* 27 */     aax.a(paramaax).b(this.a, paramInt1 << 4, paramInt2 << 4, 16, 16);
/* 28 */     aax.a(paramaax).a(this.b, paramInt1 << 4, paramInt2 << 4, 16, 16);
/* 29 */     aax.a(paramaax).a(this.c, paramInt1 << 4, paramInt2 << 4, 16, 16, false);
/*    */   }
/*    */   public int e; public long f;
/*    */   public aav a(int paramInt1, int paramInt2) {
/* 33 */     return this.c[paramInt1 & 0xF | (paramInt2 & 0xF) << 4];
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aay.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */