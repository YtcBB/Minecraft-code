/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ans
/*    */   extends apa
/*    */ {
/*    */   public ans(int paramInt) {
/* 12 */     super(paramInt, aif.e);
/* 13 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 18 */     if (this.cz == apa.M.cz) return wk.n.cp; 
/* 19 */     if (this.cz == apa.aA.cz) return wk.o.cp; 
/* 20 */     if (this.cz == apa.R.cz) return wk.aX.cp; 
/* 21 */     if (this.cz == apa.bV.cz) return wk.bI.cp; 
/* 22 */     if (this.cz == apa.ct.cz) return wk.ca.cp; 
/* 23 */     return this.cz;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 28 */     if (this.cz == apa.R.cz) return 4 + paramRandom.nextInt(5); 
/* 29 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt, Random paramRandom) {
/* 34 */     if (paramInt > 0 && this.cz != a(0, paramRandom, paramInt)) {
/* 35 */       int i = paramRandom.nextInt(paramInt + 2) - 1;
/* 36 */       if (i < 0) {
/* 37 */         i = 0;
/*    */       }
/* 39 */       return a(paramRandom) * (i + 1);
/*    */     } 
/* 41 */     return a(paramRandom);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 46 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, paramInt5);
/*    */ 
/*    */     
/* 49 */     if (a(paramInt4, paramaab.s, paramInt5) != this.cz) {
/* 50 */       int i = 0;
/* 51 */       if (this.cz == apa.M.cz) {
/* 52 */         i = kx.a(paramaab.s, 0, 2);
/* 53 */       } else if (this.cz == apa.aA.cz) {
/* 54 */         i = kx.a(paramaab.s, 3, 7);
/* 55 */       } else if (this.cz == apa.bV.cz) {
/* 56 */         i = kx.a(paramaab.s, 3, 7);
/* 57 */       } else if (this.cz == apa.R.cz) {
/* 58 */         i = kx.a(paramaab.s, 2, 5);
/* 59 */       } else if (this.cz == apa.ct.cz) {
/* 60 */         i = kx.a(paramaab.s, 2, 5);
/*    */       } 
/* 62 */       j(paramaab, paramInt1, paramInt2, paramInt3, i);
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int a(int paramInt) {
/* 69 */     if (this.cz == apa.R.cz) return 4; 
/* 70 */     return 0;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ans.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */