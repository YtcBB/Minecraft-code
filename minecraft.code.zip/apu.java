/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class apu
/*    */   extends apa
/*    */ {
/* 11 */   public static final String[] a = new String[] { "oak", "spruce", "birch", "jungle" };
/*    */ 
/*    */   
/* 14 */   public static final String[] b = new String[] { "wood", "wood_spruce", "wood_birch", "wood_jungle" };
/*    */ 
/*    */   
/*    */   private lx[] c;
/*    */ 
/*    */   
/*    */   public apu(int paramInt) {
/* 21 */     super(paramInt, aif.d);
/* 22 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 27 */     if (paramInt2 < 0 || paramInt2 >= this.c.length) {
/* 28 */       paramInt2 = 0;
/*    */     }
/* 30 */     return this.c[paramInt2];
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt) {
/* 35 */     return paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 40 */     paramList.add(new wm(paramInt, 1, 0));
/* 41 */     paramList.add(new wm(paramInt, 1, 1));
/* 42 */     paramList.add(new wm(paramInt, 1, 2));
/* 43 */     paramList.add(new wm(paramInt, 1, 3));
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 48 */     this.c = new lx[b.length];
/*    */     
/* 50 */     for (byte b = 0; b < this.c.length; b++)
/* 51 */       this.c[b] = paramly.a(b[b]); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */