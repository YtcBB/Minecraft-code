/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ahi
/*     */   extends ahp
/*     */ {
/* 609 */   private int a = -1;
/*     */   private final boolean b;
/*     */   
/*     */   public ahi(ahm paramahm, int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 613 */     super(paramahm, paramInt1);
/*     */     
/* 615 */     this.f = paramInt2;
/* 616 */     this.e = paramaek;
/* 617 */     this.b = paramRandom.nextBoolean();
/*     */   }
/*     */ 
/*     */   
/*     */   public static ahi a(ahm paramahm, List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 622 */     aek aek = aek.a(paramInt1, paramInt2, paramInt3, 0, 0, 0, 5, 6, 5, paramInt4);
/*     */     
/* 624 */     if (agw.a(paramList, aek) != null) {
/* 625 */       return null;
/*     */     }
/*     */     
/* 628 */     return new ahi(paramahm, paramInt5, paramRandom, aek, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 634 */     if (this.a < 0) {
/* 635 */       this.a = b(paramaab, paramaek);
/* 636 */       if (this.a < 0) {
/* 637 */         return true;
/*     */       }
/* 639 */       this.e.a(0, this.a - this.e.e + 6 - 1, 0);
/*     */     } 
/*     */ 
/*     */     
/* 643 */     a(paramaab, paramaek, 0, 0, 0, 4, 0, 4, apa.A.cz, apa.A.cz, false);
/*     */     
/* 645 */     a(paramaab, paramaek, 0, 4, 0, 4, 4, 4, apa.N.cz, apa.N.cz, false);
/* 646 */     a(paramaab, paramaek, 1, 4, 1, 3, 4, 3, apa.B.cz, apa.B.cz, false);
/*     */ 
/*     */     
/* 649 */     a(paramaab, apa.A.cz, 0, 0, 1, 0, paramaek);
/* 650 */     a(paramaab, apa.A.cz, 0, 0, 2, 0, paramaek);
/* 651 */     a(paramaab, apa.A.cz, 0, 0, 3, 0, paramaek);
/* 652 */     a(paramaab, apa.A.cz, 0, 4, 1, 0, paramaek);
/* 653 */     a(paramaab, apa.A.cz, 0, 4, 2, 0, paramaek);
/* 654 */     a(paramaab, apa.A.cz, 0, 4, 3, 0, paramaek);
/* 655 */     a(paramaab, apa.A.cz, 0, 0, 1, 4, paramaek);
/* 656 */     a(paramaab, apa.A.cz, 0, 0, 2, 4, paramaek);
/* 657 */     a(paramaab, apa.A.cz, 0, 0, 3, 4, paramaek);
/* 658 */     a(paramaab, apa.A.cz, 0, 4, 1, 4, paramaek);
/* 659 */     a(paramaab, apa.A.cz, 0, 4, 2, 4, paramaek);
/* 660 */     a(paramaab, apa.A.cz, 0, 4, 3, 4, paramaek);
/* 661 */     a(paramaab, paramaek, 0, 1, 1, 0, 3, 3, apa.B.cz, apa.B.cz, false);
/* 662 */     a(paramaab, paramaek, 4, 1, 1, 4, 3, 3, apa.B.cz, apa.B.cz, false);
/* 663 */     a(paramaab, paramaek, 1, 1, 4, 3, 3, 4, apa.B.cz, apa.B.cz, false);
/* 664 */     a(paramaab, apa.bu.cz, 0, 0, 2, 2, paramaek);
/* 665 */     a(paramaab, apa.bu.cz, 0, 2, 2, 4, paramaek);
/* 666 */     a(paramaab, apa.bu.cz, 0, 4, 2, 2, paramaek);
/*     */ 
/*     */     
/* 669 */     a(paramaab, apa.B.cz, 0, 1, 1, 0, paramaek);
/* 670 */     a(paramaab, apa.B.cz, 0, 1, 2, 0, paramaek);
/* 671 */     a(paramaab, apa.B.cz, 0, 1, 3, 0, paramaek);
/* 672 */     a(paramaab, apa.B.cz, 0, 2, 3, 0, paramaek);
/* 673 */     a(paramaab, apa.B.cz, 0, 3, 3, 0, paramaek);
/* 674 */     a(paramaab, apa.B.cz, 0, 3, 2, 0, paramaek);
/* 675 */     a(paramaab, apa.B.cz, 0, 3, 1, 0, paramaek);
/* 676 */     if (a(paramaab, 2, 0, -1, paramaek) == 0 && a(paramaab, 2, -1, -1, paramaek) != 0) {
/* 677 */       a(paramaab, apa.aL.cz, c(apa.aL.cz, 3), 2, 0, -1, paramaek);
/*     */     }
/*     */ 
/*     */     
/* 681 */     a(paramaab, paramaek, 1, 1, 1, 3, 3, 3, 0, 0, false);
/*     */ 
/*     */     
/* 684 */     if (this.b) {
/* 685 */       a(paramaab, apa.bd.cz, 0, 0, 5, 0, paramaek);
/* 686 */       a(paramaab, apa.bd.cz, 0, 1, 5, 0, paramaek);
/* 687 */       a(paramaab, apa.bd.cz, 0, 2, 5, 0, paramaek);
/* 688 */       a(paramaab, apa.bd.cz, 0, 3, 5, 0, paramaek);
/* 689 */       a(paramaab, apa.bd.cz, 0, 4, 5, 0, paramaek);
/* 690 */       a(paramaab, apa.bd.cz, 0, 0, 5, 4, paramaek);
/* 691 */       a(paramaab, apa.bd.cz, 0, 1, 5, 4, paramaek);
/* 692 */       a(paramaab, apa.bd.cz, 0, 2, 5, 4, paramaek);
/* 693 */       a(paramaab, apa.bd.cz, 0, 3, 5, 4, paramaek);
/* 694 */       a(paramaab, apa.bd.cz, 0, 4, 5, 4, paramaek);
/* 695 */       a(paramaab, apa.bd.cz, 0, 4, 5, 1, paramaek);
/* 696 */       a(paramaab, apa.bd.cz, 0, 4, 5, 2, paramaek);
/* 697 */       a(paramaab, apa.bd.cz, 0, 4, 5, 3, paramaek);
/* 698 */       a(paramaab, apa.bd.cz, 0, 0, 5, 1, paramaek);
/* 699 */       a(paramaab, apa.bd.cz, 0, 0, 5, 2, paramaek);
/* 700 */       a(paramaab, apa.bd.cz, 0, 0, 5, 3, paramaek);
/*     */     } 
/*     */ 
/*     */     
/* 704 */     if (this.b) {
/* 705 */       int i = c(apa.aJ.cz, 3);
/* 706 */       a(paramaab, apa.aJ.cz, i, 3, 1, 3, paramaek);
/* 707 */       a(paramaab, apa.aJ.cz, i, 3, 2, 3, paramaek);
/* 708 */       a(paramaab, apa.aJ.cz, i, 3, 3, 3, paramaek);
/* 709 */       a(paramaab, apa.aJ.cz, i, 3, 4, 3, paramaek);
/*     */     } 
/*     */ 
/*     */     
/* 713 */     a(paramaab, apa.au.cz, 0, 2, 3, 1, paramaek);
/*     */     
/* 715 */     for (byte b = 0; b < 5; b++) {
/* 716 */       for (byte b1 = 0; b1 < 5; b1++) {
/* 717 */         b(paramaab, b1, 6, b, paramaek);
/* 718 */         b(paramaab, apa.A.cz, 0, b1, -1, b, paramaek);
/*     */       } 
/*     */     } 
/*     */     
/* 722 */     a(paramaab, paramaek, 1, 1, 2, 1);
/*     */     
/* 724 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ahi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */