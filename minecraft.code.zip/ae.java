/*    */ import java.util.List;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ae
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 19 */     return "effect";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 24 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 29 */     return paramab.a("commands.effect.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 33 */     if (paramArrayOfString.length >= 2) {
/* 34 */       jc jc = c(paramab, paramArrayOfString[0]);
/*    */       
/* 36 */       int i = a(paramab, paramArrayOfString[1], 1);
/* 37 */       int j = 600;
/* 38 */       int k = 30;
/* 39 */       int m = 0;
/*    */       
/* 41 */       if (i < 0 || i >= mk.a.length || mk.a[i] == null) {
/* 42 */         throw new at("commands.effect.notFound", new Object[] { Integer.valueOf(i) });
/*    */       }
/*    */       
/* 45 */       if (paramArrayOfString.length >= 3) {
/* 46 */         k = a(paramab, paramArrayOfString[2], 0, 1000000);
/* 47 */         if (mk.a[i].b()) {
/* 48 */           j = k;
/*    */         } else {
/*    */           
/* 51 */           j = k * 20;
/*    */         }
/*    */       
/* 54 */       } else if (mk.a[i].b()) {
/* 55 */         j = 1;
/*    */       } 
/*    */       
/* 58 */       if (paramArrayOfString.length >= 4) {
/* 59 */         m = a(paramab, paramArrayOfString[3], 0, 255);
/*    */       }
/*    */       
/* 62 */       if (k == 0) {
/* 63 */         if (jc.m(i)) {
/* 64 */           jc.o(i);
/* 65 */           a(paramab, "commands.effect.success.removed", new Object[] { bo.a(mk.a[i].a()), jc.am() });
/*    */         } else {
/* 67 */           throw new as("commands.effect.failure.notActive", new Object[] { bo.a(mk.a[i].a()), jc.am() });
/*    */         } 
/*    */       } else {
/* 70 */         ml ml = new ml(i, j, m);
/* 71 */         jc.d(ml);
/* 72 */         a(paramab, "commands.effect.success", new Object[] { bo.a(ml.f()), Integer.valueOf(i), Integer.valueOf(m), jc.am(), Integer.valueOf(k) });
/*    */       } 
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 78 */     throw new ax("commands.effect.usage", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public List a(ab paramab, String[] paramArrayOfString) {
/* 83 */     if (paramArrayOfString.length == 1) {
/* 84 */       return a(paramArrayOfString, d());
/*    */     }
/*    */     
/* 87 */     return null;
/*    */   }
/*    */   
/*    */   protected String[] d() {
/* 91 */     return MinecraftServer.D().A();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(String[] paramArrayOfString, int paramInt) {
/* 96 */     return (paramInt == 0);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ae.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */