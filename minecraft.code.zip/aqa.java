/*    */ 
/*    */ 
/*    */ public class aqa
/*    */   extends aqp
/*    */ {
/*  6 */   private int a = 0;
/*    */ 
/*    */   
/*    */   public void b(bs parambs) {
/* 10 */     super.b(parambs);
/* 11 */     parambs.a("OutputSignal", this.a);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(bs parambs) {
/* 16 */     super.a(parambs);
/* 17 */     this.a = parambs.e("OutputSignal");
/*    */   }
/*    */   
/*    */   public int a() {
/* 21 */     return this.a;
/*    */   }
/*    */   
/*    */   public void a(int paramInt) {
/* 25 */     this.a = paramInt;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqa.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */