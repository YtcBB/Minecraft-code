/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amp
/*     */   extends apa
/*     */ {
/*     */   private lx a;
/*     */   private lx b;
/*     */   private lx c;
/*     */   
/*     */   protected amp(int paramInt) {
/*  22 */     super(paramInt, aif.b);
/*  23 */     b(true);
/*  24 */     a(ve.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  29 */     if (paramInt1 == 1) return this.a; 
/*  30 */     if (paramInt1 == 0) return apa.z.m(paramInt1); 
/*  31 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx b_(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  36 */     if (paramInt4 == 1) return this.a; 
/*  37 */     if (paramInt4 == 0) return apa.z.m(paramInt4); 
/*  38 */     aif aif = paramaak.g(paramInt1, paramInt2 + 1, paramInt3);
/*  39 */     if (aif == aif.w || aif == aif.x) return this.b; 
/*  40 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  45 */     this.cQ = paramly.a("grass_side");
/*  46 */     this.a = paramly.a("grass_top");
/*  47 */     this.b = paramly.a("snow_side");
/*  48 */     this.c = paramly.a("grass_side_overlay");
/*     */   }
/*     */ 
/*     */   
/*     */   public int o() {
/*  53 */     double d1 = 0.5D;
/*  54 */     double d2 = 1.0D;
/*     */     
/*  56 */     return aaa.a(d1, d2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(int paramInt) {
/*  61 */     return o();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  67 */     int i = 0;
/*  68 */     int j = 0;
/*  69 */     int k = 0;
/*     */     
/*  71 */     for (byte b = -1; b <= 1; b++) {
/*  72 */       for (byte b1 = -1; b1 <= 1; b1++) {
/*  73 */         int m = paramaak.a(paramInt1 + b1, paramInt3 + b).k();
/*     */         
/*  75 */         i += (m & 0xFF0000) >> 16;
/*  76 */         j += (m & 0xFF00) >> 8;
/*  77 */         k += m & 0xFF;
/*     */       } 
/*     */     } 
/*     */     
/*  81 */     return (i / 9 & 0xFF) << 16 | (j / 9 & 0xFF) << 8 | k / 9 & 0xFF;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  86 */     if (paramaab.I)
/*     */       return; 
/*  88 */     if (paramaab.n(paramInt1, paramInt2 + 1, paramInt3) < 4 && apa.t[paramaab.a(paramInt1, paramInt2 + 1, paramInt3)] > 2) {
/*  89 */       paramaab.c(paramInt1, paramInt2, paramInt3, apa.z.cz);
/*     */     }
/*  91 */     else if (paramaab.n(paramInt1, paramInt2 + 1, paramInt3) >= 9) {
/*  92 */       for (byte b = 0; b < 4; b++) {
/*  93 */         int i = paramInt1 + paramRandom.nextInt(3) - 1;
/*  94 */         int j = paramInt2 + paramRandom.nextInt(5) - 3;
/*  95 */         int k = paramInt3 + paramRandom.nextInt(3) - 1;
/*  96 */         int m = paramaab.a(i, j + 1, k);
/*  97 */         if (paramaab.a(i, j, k) == apa.z.cz && paramaab.n(i, j + 1, k) >= 4 && apa.t[m] <= 2) {
/*  98 */           paramaab.c(i, j, k, apa.y.cz);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 107 */     return apa.z.a(0, paramRandom, paramInt2);
/*     */   }
/*     */   
/*     */   public static lx p() {
/* 111 */     return apa.y.c;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */