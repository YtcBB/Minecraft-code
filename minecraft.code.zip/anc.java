/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class anc
/*     */   extends apa
/*     */ {
/*     */   protected anc(int paramInt) {
/*  16 */     super(paramInt, aif.q);
/*  17 */     a(ve.d);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  22 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  31 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  36 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  41 */     return 12;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  46 */     if (paramInt4 == 0 && paramaab.u(paramInt1, paramInt2 + 1, paramInt3)) return true; 
/*  47 */     if (paramInt4 == 1 && paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) return true; 
/*  48 */     if (paramInt4 == 2 && paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) return true; 
/*  49 */     if (paramInt4 == 3 && paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) return true; 
/*  50 */     if (paramInt4 == 4 && paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) return true; 
/*  51 */     if (paramInt4 == 5 && paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) return true; 
/*  52 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  57 */     if (paramaab.u(paramInt1 - 1, paramInt2, paramInt3))
/*  58 */       return true; 
/*  59 */     if (paramaab.u(paramInt1 + 1, paramInt2, paramInt3))
/*  60 */       return true; 
/*  61 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 - 1))
/*  62 */       return true; 
/*  63 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 + 1))
/*  64 */       return true; 
/*  65 */     if (paramaab.w(paramInt1, paramInt2 - 1, paramInt3))
/*  66 */       return true; 
/*  67 */     if (paramaab.u(paramInt1, paramInt2 + 1, paramInt3)) {
/*  68 */       return true;
/*     */     }
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  75 */     int i = paramInt5;
/*     */     
/*  77 */     int j = i & 0x8;
/*  78 */     i &= 0x7;
/*     */     
/*  80 */     i = -1;
/*     */     
/*  82 */     if (paramInt4 == 0 && paramaab.u(paramInt1, paramInt2 + 1, paramInt3)) i = 0; 
/*  83 */     if (paramInt4 == 1 && paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) i = 5; 
/*  84 */     if (paramInt4 == 2 && paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) i = 4; 
/*  85 */     if (paramInt4 == 3 && paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) i = 3; 
/*  86 */     if (paramInt4 == 4 && paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) i = 2; 
/*  87 */     if (paramInt4 == 5 && paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) i = 1;
/*     */     
/*  89 */     return i + j;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/*  94 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  95 */     int j = i & 0x7;
/*  96 */     int k = i & 0x8;
/*     */     
/*  98 */     if (j == d(1)) {
/*  99 */       if ((kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x1) == 0) {
/* 100 */         paramaab.b(paramInt1, paramInt2, paramInt3, 0x5 | k, 2);
/*     */       } else {
/* 102 */         paramaab.b(paramInt1, paramInt2, paramInt3, 0x6 | k, 2);
/*     */       } 
/* 104 */     } else if (j == d(0)) {
/* 105 */       if ((kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x1) == 0) {
/* 106 */         paramaab.b(paramInt1, paramInt2, paramInt3, 0x7 | k, 2);
/*     */       } else {
/* 108 */         paramaab.b(paramInt1, paramInt2, paramInt3, 0x0 | k, 2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int d(int paramInt) {
/* 114 */     switch (paramInt) {
/*     */       case 0:
/* 116 */         return 0;
/*     */       case 1:
/* 118 */         return 5;
/*     */       case 2:
/* 120 */         return 4;
/*     */       case 3:
/* 122 */         return 3;
/*     */       case 4:
/* 124 */         return 2;
/*     */       case 5:
/* 126 */         return 1;
/*     */     } 
/* 128 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 133 */     if (k(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 134 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3) & 0x7;
/* 135 */       boolean bool = false;
/*     */       
/* 137 */       if (!paramaab.u(paramInt1 - 1, paramInt2, paramInt3) && i == 1) bool = true; 
/* 138 */       if (!paramaab.u(paramInt1 + 1, paramInt2, paramInt3) && i == 2) bool = true; 
/* 139 */       if (!paramaab.u(paramInt1, paramInt2, paramInt3 - 1) && i == 3) bool = true; 
/* 140 */       if (!paramaab.u(paramInt1, paramInt2, paramInt3 + 1) && i == 4) bool = true; 
/* 141 */       if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3) && i == 5) bool = true; 
/* 142 */       if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3) && i == 6) bool = true; 
/* 143 */       if (!paramaab.u(paramInt1, paramInt2 + 1, paramInt3) && i == 0) bool = true; 
/* 144 */       if (!paramaab.u(paramInt1, paramInt2 + 1, paramInt3) && i == 7) bool = true;
/*     */       
/* 146 */       if (bool) {
/* 147 */         c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 148 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 154 */     if (!c(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 155 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 156 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/* 157 */       return false;
/*     */     } 
/* 159 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 164 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3) & 0x7;
/* 165 */     float f = 0.1875F;
/* 166 */     if (i == 1) {
/* 167 */       a(0.0F, 0.2F, 0.5F - f, f * 2.0F, 0.8F, 0.5F + f);
/* 168 */     } else if (i == 2) {
/* 169 */       a(1.0F - f * 2.0F, 0.2F, 0.5F - f, 1.0F, 0.8F, 0.5F + f);
/* 170 */     } else if (i == 3) {
/* 171 */       a(0.5F - f, 0.2F, 0.0F, 0.5F + f, 0.8F, f * 2.0F);
/* 172 */     } else if (i == 4) {
/* 173 */       a(0.5F - f, 0.2F, 1.0F - f * 2.0F, 0.5F + f, 0.8F, 1.0F);
/* 174 */     } else if (i == 5 || i == 6) {
/* 175 */       f = 0.25F;
/* 176 */       a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.6F, 0.5F + f);
/* 177 */     } else if (i == 0 || i == 7) {
/* 178 */       f = 0.25F;
/* 179 */       a(0.5F - f, 0.4F, 0.5F - f, 0.5F + f, 1.0F, 0.5F + f);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 185 */     if (paramaab.I) return true; 
/* 186 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 187 */     int j = i & 0x7;
/* 188 */     int k = 8 - (i & 0x8);
/*     */     
/* 190 */     paramaab.b(paramInt1, paramInt2, paramInt3, j + k, 3);
/*     */     
/* 192 */     paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "random.click", 0.3F, (k > 0) ? 0.6F : 0.5F);
/*     */     
/* 194 */     paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/* 195 */     if (j == 1) {
/* 196 */       paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 197 */     } else if (j == 2) {
/* 198 */       paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 199 */     } else if (j == 3) {
/* 200 */       paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 201 */     } else if (j == 4) {
/* 202 */       paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/* 203 */     } else if (j == 5 || j == 6) {
/* 204 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/* 205 */     } else if (j == 0 || j == 7) {
/* 206 */       paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*     */     } 
/*     */     
/* 209 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 214 */     if ((paramInt5 & 0x8) > 0) {
/* 215 */       paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/* 216 */       int i = paramInt5 & 0x7;
/* 217 */       if (i == 1) {
/* 218 */         paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 219 */       } else if (i == 2) {
/* 220 */         paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 221 */       } else if (i == 3) {
/* 222 */         paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 223 */       } else if (i == 4) {
/* 224 */         paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/* 225 */       } else if (i == 5 || i == 6) {
/* 226 */         paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/* 227 */       } else if (i == 0 || i == 7) {
/* 228 */         paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*     */       } 
/*     */     } 
/* 231 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 236 */     return ((paramaak.h(paramInt1, paramInt2, paramInt3) & 0x8) > 0) ? 15 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 241 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 242 */     if ((i & 0x8) == 0) return 0; 
/* 243 */     int j = i & 0x7;
/*     */     
/* 245 */     if (j == 0 && paramInt4 == 0) return 15; 
/* 246 */     if (j == 7 && paramInt4 == 0) return 15; 
/* 247 */     if (j == 6 && paramInt4 == 1) return 15; 
/* 248 */     if (j == 5 && paramInt4 == 1) return 15; 
/* 249 */     if (j == 4 && paramInt4 == 2) return 15; 
/* 250 */     if (j == 3 && paramInt4 == 3) return 15; 
/* 251 */     if (j == 2 && paramInt4 == 4) return 15; 
/* 252 */     if (j == 1 && paramInt4 == 5) return 15;
/*     */     
/* 254 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f() {
/* 259 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */