/*    */ 
/*    */ public class aei
/*    */ {
/*  4 */   private int a = 1;
/*  5 */   private int b = 0;
/*  6 */   private int c = 0;
/*  7 */   private int d = 0;
/*    */   
/*    */   public aei(int paramInt1, int paramInt2) {
/* 10 */     this.a = paramInt1;
/* 11 */     this.b = paramInt2;
/*    */   }
/*    */   
/*    */   public aei(int paramInt1, int paramInt2, int paramInt3) {
/* 15 */     this(paramInt1, paramInt2);
/* 16 */     this.c = paramInt3;
/*    */   }
/*    */   
/*    */   public int a() {
/* 20 */     return this.a;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int b() {
/* 28 */     return this.b;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int c() {
/* 36 */     return this.c;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int d() {
/* 44 */     return this.d;
/*    */   }
/*    */   
/*    */   public void d(int paramInt) {
/* 48 */     this.d = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     String str = Integer.toString(this.b);
/*    */     
/* 55 */     if (this.a > 1) {
/* 56 */       str = this.a + "x" + str;
/*    */     }
/* 58 */     if (this.c > 0) {
/* 59 */       str = str + ":" + this.c;
/*    */     }
/*    */     
/* 62 */     return str;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aei.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */