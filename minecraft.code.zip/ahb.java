/*     */ import java.util.ArrayList;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ahb
/*     */ {
/*     */   public static ArrayList a(Random paramRandom, int paramInt) {
/*  46 */     ArrayList<ahg> arrayList = new ArrayList();
/*     */     
/*  48 */     arrayList.add(new ahg(ahi.class, 4, kx.a(paramRandom, 2 + paramInt, 4 + paramInt * 2)));
/*  49 */     arrayList.add(new ahg(ahk.class, 20, kx.a(paramRandom, 0 + paramInt, 1 + paramInt)));
/*  50 */     arrayList.add(new ahg(ahc.class, 20, kx.a(paramRandom, 0 + paramInt, 2 + paramInt)));
/*  51 */     arrayList.add(new ahg(ahj.class, 3, kx.a(paramRandom, 2 + paramInt, 5 + paramInt * 3)));
/*  52 */     arrayList.add(new ahg(ahh.class, 15, kx.a(paramRandom, 0 + paramInt, 2 + paramInt)));
/*  53 */     arrayList.add(new ahg(ahd.class, 3, kx.a(paramRandom, 1 + paramInt, 4 + paramInt)));
/*  54 */     arrayList.add(new ahg(ahe.class, 3, kx.a(paramRandom, 2 + paramInt, 4 + paramInt * 2)));
/*  55 */     arrayList.add(new ahg(ahl.class, 15, kx.a(paramRandom, 0, 1 + paramInt)));
/*  56 */     arrayList.add(new ahg(aho.class, 8, kx.a(paramRandom, 0 + paramInt, 3 + paramInt * 2)));
/*     */ 
/*     */     
/*  59 */     Iterator<ahg> iterator = arrayList.iterator();
/*  60 */     while (iterator.hasNext()) {
/*  61 */       if (((ahg)iterator.next()).d == 0) {
/*  62 */         iterator.remove();
/*     */       }
/*     */     } 
/*     */     
/*  66 */     return arrayList;
/*     */   }
/*     */   
/*     */   private static int a(List paramList) {
/*  70 */     boolean bool = false;
/*  71 */     int i = 0;
/*  72 */     for (ahg ahg : paramList) {
/*  73 */       if (ahg.d > 0 && ahg.c < ahg.d) {
/*  74 */         bool = true;
/*     */       }
/*  76 */       i += ahg.b;
/*     */     } 
/*  78 */     return bool ? i : -1;
/*     */   }
/*     */ 
/*     */   
/*     */   private static ahp a(ahm paramahm, ahg paramahg, List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*     */     aho aho;
/*  84 */     Class<ahi> clazz = paramahg.a;
/*  85 */     ahi ahi = null;
/*     */     
/*  87 */     if (clazz == ahi.class) {
/*  88 */       ahi = ahi.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*  89 */     } else if (clazz == ahk.class) {
/*  90 */       ahk ahk = ahk.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*  91 */     } else if (clazz == ahc.class) {
/*  92 */       ahc ahc = ahc.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*  93 */     } else if (clazz == ahj.class) {
/*  94 */       ahj ahj = ahj.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*  95 */     } else if (clazz == ahh.class) {
/*  96 */       ahh ahh = ahh.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*  97 */     } else if (clazz == ahd.class) {
/*  98 */       ahd ahd = ahd.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*  99 */     } else if (clazz == ahe.class) {
/* 100 */       ahe ahe = ahe.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 101 */     } else if (clazz == ahl.class) {
/* 102 */       ahl ahl = ahl.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 103 */     } else if (clazz == aho.class) {
/* 104 */       aho = aho.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */     } 
/*     */     
/* 107 */     return aho;
/*     */   }
/*     */ 
/*     */   
/*     */   private static ahp c(ahm paramahm, List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 112 */     int i = a(paramahm.h);
/* 113 */     if (i <= 0) {
/* 114 */       return null;
/*     */     }
/*     */     
/* 117 */     byte b = 0;
/* 118 */     while (b < 5) {
/* 119 */       b++;
/*     */       
/* 121 */       int j = paramRandom.nextInt(i);
/* 122 */       for (ahg ahg : paramahm.h) {
/* 123 */         j -= ahg.b;
/* 124 */         if (j < 0) {
/*     */           
/* 126 */           if (!ahg.a(paramInt5) || (ahg == paramahm.d && paramahm.h.size() > 1)) {
/*     */             break;
/*     */           }
/*     */           
/* 130 */           ahp ahp = a(paramahm, ahg, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 131 */           if (ahp != null) {
/* 132 */             ahg.c++;
/* 133 */             paramahm.d = ahg;
/*     */             
/* 135 */             if (!ahg.a()) {
/* 136 */               paramahm.h.remove(ahg);
/*     */             }
/* 138 */             return ahp;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 146 */     aek aek = ahf.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4);
/* 147 */     if (aek != null) {
/* 148 */       return new ahf(paramahm, paramInt5, paramRandom, aek, paramInt4);
/*     */     }
/*     */     
/* 151 */     return null;
/*     */   }
/*     */   
/*     */   private static agw d(ahm paramahm, List<ahp> paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 155 */     if (paramInt5 > 50) {
/* 156 */       return null;
/*     */     }
/* 158 */     if (Math.abs(paramInt1 - (paramahm.b()).a) > 112 || Math.abs(paramInt3 - (paramahm.b()).c) > 112) {
/* 159 */       return null;
/*     */     }
/*     */     
/* 162 */     ahp ahp = c(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5 + 1);
/* 163 */     if (ahp != null) {
/* 164 */       int i = (ahp.e.a + ahp.e.d) / 2;
/* 165 */       int j = (ahp.e.c + ahp.e.f) / 2;
/* 166 */       int k = ahp.e.d - ahp.e.a;
/* 167 */       int m = ahp.e.f - ahp.e.c;
/* 168 */       int n = (k > m) ? k : m;
/* 169 */       if (paramahm.d().a(i, j, n / 2 + 4, agz.e)) {
/* 170 */         paramList.add(ahp);
/* 171 */         paramahm.i.add(ahp);
/* 172 */         return ahp;
/*     */       } 
/*     */     } 
/* 175 */     return null;
/*     */   }
/*     */   
/*     */   private static agw e(ahm paramahm, List<ahn> paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 179 */     if (paramInt5 > 3 + paramahm.c) {
/* 180 */       return null;
/*     */     }
/* 182 */     if (Math.abs(paramInt1 - (paramahm.b()).a) > 112 || Math.abs(paramInt3 - (paramahm.b()).c) > 112) {
/* 183 */       return null;
/*     */     }
/*     */     
/* 186 */     aek aek = ahn.a(paramahm, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4);
/* 187 */     if (aek != null && aek.b > 10) {
/* 188 */       ahn ahn = new ahn(paramahm, paramInt5, paramRandom, aek, paramInt4);
/* 189 */       int i = (ahn.e.a + ahn.e.d) / 2;
/* 190 */       int j = (ahn.e.c + ahn.e.f) / 2;
/* 191 */       int k = ahn.e.d - ahn.e.a;
/* 192 */       int m = ahn.e.f - ahn.e.c;
/* 193 */       int n = (k > m) ? k : m;
/* 194 */       if (paramahm.d().a(i, j, n / 2 + 4, agz.e)) {
/* 195 */         paramList.add(ahn);
/* 196 */         paramahm.j.add(ahn);
/* 197 */         return ahn;
/*     */       } 
/*     */     } 
/*     */     
/* 201 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ahb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */