/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aky
/*     */   extends amt
/*     */ {
/*  22 */   public static final String[] a = new String[] { "intact", "slightlyDamaged", "veryDamaged" };
/*     */ 
/*     */ 
/*     */   
/*  26 */   private static final String[] d = new String[] { "anvil_top", "anvil_top_damaged_1", "anvil_top_damaged_2" };
/*     */ 
/*     */ 
/*     */   
/*  30 */   public int b = 0;
/*     */   private lx[] e;
/*     */   
/*     */   protected aky(int paramInt) {
/*  34 */     super(paramInt, aif.g);
/*  35 */     k(0);
/*  36 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  41 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  46 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  51 */     if (this.b == 3 && paramInt1 == 1) {
/*  52 */       int i = (paramInt2 >> 2) % this.e.length;
/*  53 */       return this.e[i];
/*     */     } 
/*  55 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  60 */     this.cQ = paramly.a("anvil_base");
/*  61 */     this.e = new lx[d.length];
/*     */     
/*  63 */     for (byte b = 0; b < this.e.length; b++) {
/*  64 */       this.e[b] = paramly.a(d[b]);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/*  70 */     int i = kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3;
/*  71 */     int j = paramaab.h(paramInt1, paramInt2, paramInt3) >> 2;
/*     */     
/*  73 */     i = ++i % 4;
/*  74 */     if (i == 0) paramaab.b(paramInt1, paramInt2, paramInt3, 0x2 | j << 2, 2); 
/*  75 */     if (i == 1) paramaab.b(paramInt1, paramInt2, paramInt3, 0x3 | j << 2, 2); 
/*  76 */     if (i == 2) paramaab.b(paramInt1, paramInt2, paramInt3, 0x0 | j << 2, 2); 
/*  77 */     if (i == 3) paramaab.b(paramInt1, paramInt2, paramInt3, 0x1 | j << 2, 2);
/*     */   
/*     */   }
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  82 */     if (paramaab.I) {
/*  83 */       return true;
/*     */     }
/*  85 */     paramsq.c(paramInt1, paramInt2, paramInt3);
/*  86 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  91 */     return 35;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/*  96 */     return paramInt >> 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 101 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3) & 0x3;
/*     */     
/* 103 */     if (i == 3 || i == 1) {
/* 104 */       a(0.0F, 0.0F, 0.125F, 1.0F, 1.0F, 0.875F);
/*     */     } else {
/* 106 */       a(0.125F, 0.0F, 0.0F, 0.875F, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 112 */     paramList.add(new wm(paramInt, 1, 0));
/* 113 */     paramList.add(new wm(paramInt, 1, 1));
/* 114 */     paramList.add(new wm(paramInt, 1, 2));
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(rg paramrg) {
/* 119 */     paramrg.a(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 124 */     paramaab.e(1022, paramInt1, paramInt2, paramInt3, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 129 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aky.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */