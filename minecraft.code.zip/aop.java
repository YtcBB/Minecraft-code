/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aop
/*    */   extends apa
/*    */ {
/*    */   protected aop(int paramInt) {
/* 10 */     super(paramInt, aif.m);
/* 11 */     a(ve.b);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aop.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */