/*    */ 
/*    */ 
/*    */ public class aix
/*    */   extends ait
/*    */ {
/*    */   private ait b;
/*    */   private ait c;
/*    */   
/*    */   public aix(long paramLong, ait paramait1, ait paramait2) {
/* 10 */     super(paramLong);
/* 11 */     this.b = paramait1;
/* 12 */     this.c = paramait2;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(long paramLong) {
/* 17 */     this.b.a(paramLong);
/* 18 */     this.c.a(paramLong);
/* 19 */     super.a(paramLong);
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 24 */     int[] arrayOfInt1 = this.b.a(paramInt1, paramInt2, paramInt3, paramInt4);
/* 25 */     int[] arrayOfInt2 = this.c.a(paramInt1, paramInt2, paramInt3, paramInt4);
/*    */     
/* 27 */     int[] arrayOfInt3 = air.a(paramInt3 * paramInt4);
/* 28 */     for (byte b = 0; b < paramInt3 * paramInt4; b++) {
/* 29 */       if (arrayOfInt1[b] == aav.b.N)
/* 30 */       { arrayOfInt3[b] = arrayOfInt1[b]; }
/*    */       
/* 32 */       else if (arrayOfInt2[b] >= 0)
/* 33 */       { if (arrayOfInt1[b] == aav.n.N) { arrayOfInt3[b] = aav.m.N; }
/* 34 */         else if (arrayOfInt1[b] == aav.p.N || arrayOfInt1[b] == aav.q.N)
/* 35 */         { arrayOfInt3[b] = aav.q.N; }
/* 36 */         else { arrayOfInt3[b] = arrayOfInt2[b]; }
/*    */          }
/* 38 */       else { arrayOfInt3[b] = arrayOfInt1[b]; }
/*    */     
/*    */     } 
/*    */ 
/*    */     
/* 43 */     return arrayOfInt3;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aix.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */