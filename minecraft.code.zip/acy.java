/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class acy
/*     */   implements abt
/*     */ {
/*     */   private Random k;
/*     */   private ahw l;
/*     */   private ahw m;
/*     */   private ahw n;
/*     */   private ahw o;
/*     */   public ahw a;
/*     */   public ahw b;
/*     */   public ahw c;
/*     */   private aab p;
/*     */   private final boolean q;
/*     */   private double[] r;
/*     */   private double[] s;
/*     */   private acw t;
/*     */   private afv u;
/*     */   private agz v;
/*     */   private ael w;
/*     */   private afm x;
/*     */   private acw y;
/*     */   private aav[] z;
/*     */   double[] d;
/*     */   double[] e;
/*     */   double[] f;
/*     */   double[] g;
/*     */   double[] h;
/*     */   float[] i;
/*     */   int[][] j;
/*     */   
/*     */   public acy(aab paramaab, long paramLong, boolean paramBoolean) {
/* 129 */     this.s = new double[256];
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 194 */     this.t = new acv();
/* 195 */     this.u = new afv();
/* 196 */     this.v = new agz();
/* 197 */     this.w = new ael();
/* 198 */     this.x = new afm();
/* 199 */     this.y = new acr();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 357 */     this.j = new int[32][32]; this.p = paramaab; this.q = paramBoolean; this.k = new Random(paramLong); this.l = new ahw(this.k, 16); this.m = new ahw(this.k, 16); this.n = new ahw(this.k, 8); this.o = new ahw(this.k, 4); this.a = new ahw(this.k, 10); this.b = new ahw(this.k, 16); this.c = new ahw(this.k, 8);
/*     */   }
/*     */   public void a(int paramInt1, int paramInt2, byte[] paramArrayOfbyte) { byte b1 = 4; byte b2 = 16; byte b3 = 63; int i = b1 + 1; byte b4 = 17; int j = b1 + 1; this.z = this.p.u().a(this.z, paramInt1 * 4 - 2, paramInt2 * 4 - 2, i + 5, j + 5); this.r = a(this.r, paramInt1 * b1, 0, paramInt2 * b1, i, b4, j); for (byte b5 = 0; b5 < b1; b5++) { for (byte b = 0; b < b1; b++) { for (byte b6 = 0; b6 < b2; b6++) { double d1 = 0.125D; double d2 = this.r[((b5 + 0) * j + b + 0) * b4 + b6 + 0]; double d3 = this.r[((b5 + 0) * j + b + 1) * b4 + b6 + 0]; double d4 = this.r[((b5 + 1) * j + b + 0) * b4 + b6 + 0]; double d5 = this.r[((b5 + 1) * j + b + 1) * b4 + b6 + 0]; double d6 = (this.r[((b5 + 0) * j + b + 0) * b4 + b6 + 1] - d2) * d1; double d7 = (this.r[((b5 + 0) * j + b + 1) * b4 + b6 + 1] - d3) * d1; double d8 = (this.r[((b5 + 1) * j + b + 0) * b4 + b6 + 1] - d4) * d1; double d9 = (this.r[((b5 + 1) * j + b + 1) * b4 + b6 + 1] - d5) * d1; for (byte b7 = 0; b7 < 8; b7++) { double d10 = 0.25D; double d11 = d2; double d12 = d3; double d13 = (d4 - d2) * d10; double d14 = (d5 - d3) * d10; for (byte b8 = 0; b8 < 4; b8++) { int k = b8 + b5 * 4 << 11 | 0 + b * 4 << 7 | b6 * 8 + b7; char c = ''; k -= c; double d15 = 0.25D; double d16 = d11; double d17 = (d12 - d11) * d15; d16 -= d17; for (byte b9 = 0; b9 < 4; b9++) { if ((d16 += d17) > 0.0D) {
/*     */                   paramArrayOfbyte[k += c] = (byte)apa.x.cz;
/*     */                 } else if (b6 * 8 + b7 < b3) {
/*     */                   paramArrayOfbyte[k += c] = (byte)apa.F.cz;
/*     */                 } else {
/*     */                   paramArrayOfbyte[k += c] = 0;
/*     */                 }  }
/*     */                d11 += d13; d12 += d14; }
/*     */              d2 += d6; d3 += d7; d4 += d8; d5 += d9; }
/*     */            }
/*     */          }
/*     */        }
/*     */      }
/*     */   public void a(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, aav[] paramArrayOfaav) { byte b1 = 63; double d = 0.03125D; this.s = this.o.a(this.s, paramInt1 * 16, paramInt2 * 16, 0, 16, 16, 1, d * 2.0D, d * 2.0D, d * 2.0D); for (byte b2 = 0; b2 < 16; b2++) {
/*     */       for (byte b = 0; b < 16; b++) {
/*     */         aav aav1 = paramArrayOfaav[b + b2 * 16]; float f = aav1.j(); int i = (int)(this.s[b2 + b * 16] / 3.0D + 3.0D + this.k.nextDouble() * 0.25D); int j = -1; byte b3 = aav1.A; byte b4 = aav1.B; for (byte b5 = 127; b5 >= 0; b5--) {
/*     */           int k = (b * 16 + b2) * 128 + b5; if (b5 <= 0 + this.k.nextInt(5)) {
/*     */             paramArrayOfbyte[k] = (byte)apa.D.cz;
/*     */           } else {
/*     */             byte b6 = paramArrayOfbyte[k]; if (b6 == 0) {
/*     */               j = -1;
/*     */             } else if (b6 == apa.x.cz) {
/*     */               if (j == -1) {
/*     */                 if (i <= 0) {
/*     */                   b3 = 0; b4 = (byte)apa.x.cz;
/*     */                 } else if (b5 >= b1 - 4 && b5 <= b1 + 1) {
/*     */                   b3 = aav1.A; b4 = aav1.B;
/*     */                 }  if (b5 < b1 && b3 == 0)
/*     */                   if (f < 0.15F) {
/*     */                     b3 = (byte)apa.aX.cz;
/*     */                   } else {
/*     */                     b3 = (byte)apa.F.cz;
/*     */                   }   j = i; if (b5 >= b1 - 1) {
/*     */                   paramArrayOfbyte[k] = b3;
/*     */                 } else {
/*     */                   paramArrayOfbyte[k] = b4;
/*     */                 } 
/*     */               } else if (j > 0) {
/*     */                 j--; paramArrayOfbyte[k] = b4; if (j == 0 && b4 == apa.I.cz) {
/*     */                   j = this.k.nextInt(4); b4 = (byte)apa.U.cz;
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 405 */     }  } public abw c(int paramInt1, int paramInt2) { return d(paramInt1, paramInt2); } public void a(abt paramabt, int paramInt1, int paramInt2) { amt.c = true;
/* 406 */     int i = paramInt1 * 16;
/* 407 */     int j = paramInt2 * 16;
/* 408 */     aav aav1 = this.p.a(i + 16, j + 16);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 414 */     this.k.setSeed(this.p.G());
/* 415 */     long l1 = this.k.nextLong() / 2L * 2L + 1L;
/* 416 */     long l2 = this.k.nextLong() / 2L * 2L + 1L;
/* 417 */     this.k.setSeed(paramInt1 * l1 + paramInt2 * l2 ^ this.p.G());
/*     */     
/* 419 */     boolean bool = false;
/*     */     
/* 421 */     if (this.q) {
/* 422 */       this.w.a(this.p, this.k, paramInt1, paramInt2);
/* 423 */       bool = this.v.a(this.p, this.k, paramInt1, paramInt2);
/* 424 */       this.u.a(this.p, this.k, paramInt1, paramInt2);
/* 425 */       this.x.a(this.p, this.k, paramInt1, paramInt2);
/*     */     } 
/*     */     
/* 428 */     if (!bool && this.k.nextInt(4) == 0) {
/* 429 */       int k = i + this.k.nextInt(16) + 8;
/* 430 */       int m = this.k.nextInt(128);
/* 431 */       int n = j + this.k.nextInt(16) + 8;
/* 432 */       (new adr(apa.F.cz)).a(this.p, this.k, k, m, n);
/*     */     } 
/*     */     
/* 435 */     if (!bool && this.k.nextInt(8) == 0) {
/* 436 */       int k = i + this.k.nextInt(16) + 8;
/* 437 */       int m = this.k.nextInt(this.k.nextInt(120) + 8);
/* 438 */       int n = j + this.k.nextInt(16) + 8;
/* 439 */       if (m < 63 || this.k.nextInt(10) == 0) (new adr(apa.H.cz)).a(this.p, this.k, k, m, n); 
/*     */     } 
/*     */     byte b;
/* 442 */     for (b = 0; b < 8; b++) {
/* 443 */       int k = i + this.k.nextInt(16) + 8;
/* 444 */       int m = this.k.nextInt(128);
/* 445 */       int n = j + this.k.nextInt(16) + 8;
/* 446 */       if ((new adu()).a(this.p, this.k, k, m, n));
/*     */     } 
/*     */ 
/*     */     
/* 450 */     aav1.a(this.p, this.k, i, j);
/*     */     
/* 452 */     aan.a(this.p, aav1, i + 8, j + 8, 16, 16, this.k);
/*     */     
/* 454 */     i += 8;
/* 455 */     j += 8;
/* 456 */     for (b = 0; b < 16; b++) {
/* 457 */       for (byte b1 = 0; b1 < 16; b1++) {
/* 458 */         int k = this.p.h(i + b, j + b1);
/*     */         
/* 460 */         if (this.p.x(b + i, k - 1, b1 + j)) {
/* 461 */           this.p.f(b + i, k - 1, b1 + j, apa.aX.cz, 0, 2);
/*     */         }
/* 463 */         if (this.p.z(b + i, k, b1 + j)) {
/* 464 */           this.p.f(b + i, k, b1 + j, apa.aW.cz, 0, 2);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 469 */     amt.c = false; }
/*     */   public abw d(int paramInt1, int paramInt2) { this.k.setSeed(paramInt1 * 341873128712L + paramInt2 * 132897987541L); byte[] arrayOfByte1 = new byte[32768]; a(paramInt1, paramInt2, arrayOfByte1); this.z = this.p.u().b(this.z, paramInt1 * 16, paramInt2 * 16, 16, 16); a(paramInt1, paramInt2, arrayOfByte1, this.z); this.t.a(this, this.p, paramInt1, paramInt2, arrayOfByte1); this.y.a(this, this.p, paramInt1, paramInt2, arrayOfByte1); if (this.q) { this.w.a(this, this.p, paramInt1, paramInt2, arrayOfByte1); this.v.a(this, this.p, paramInt1, paramInt2, arrayOfByte1); this.u.a(this, this.p, paramInt1, paramInt2, arrayOfByte1); this.x.a(this, this.p, paramInt1, paramInt2, arrayOfByte1); }  abw abw = new abw(this.p, arrayOfByte1, paramInt1, paramInt2); byte[] arrayOfByte2 = abw.m(); for (byte b = 0; b < arrayOfByte2.length; b++) arrayOfByte2[b] = (byte)(this.z[b]).N;  abw.b(); return abw; }
/*     */   private double[] a(double[] paramArrayOfdouble, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) { if (paramArrayOfdouble == null) paramArrayOfdouble = new double[paramInt4 * paramInt5 * paramInt6];  if (this.i == null) { this.i = new float[25]; for (byte b = -2; b <= 2; b++) { for (byte b4 = -2; b4 <= 2; b4++) { float f = 10.0F / kx.c((b * b + b4 * b4) + 0.2F); this.i[b + 2 + (b4 + 2) * 5] = f; }  }  }  double d1 = 684.412D; double d2 = 684.412D; this.g = this.a.a(this.g, paramInt1, paramInt3, paramInt4, paramInt6, 1.121D, 1.121D, 0.5D); this.h = this.b.a(this.h, paramInt1, paramInt3, paramInt4, paramInt6, 200.0D, 200.0D, 0.5D); this.d = this.n.a(this.d, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1 / 80.0D, d2 / 160.0D, d1 / 80.0D); this.e = this.l.a(this.e, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1, d2, d1); this.f = this.m.a(this.f, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, paramInt6, d1, d2, d1); paramInt1 = paramInt3 = 0; byte b1 = 0; byte b2 = 0; for (byte b3 = 0; b3 < paramInt4; b3++) { for (byte b = 0; b < paramInt6; b++) { float f1 = 0.0F; float f2 = 0.0F; float f3 = 0.0F; byte b4 = 2; aav aav1 = this.z[b3 + 2 + (b + 2) * (paramInt4 + 5)]; for (byte b5 = -b4; b5 <= b4; b5++) { for (byte b7 = -b4; b7 <= b4; b7++) { aav aav2 = this.z[b3 + b5 + 2 + (b + b7 + 2) * (paramInt4 + 5)]; float f = this.i[b5 + 2 + (b7 + 2) * 5] / (aav2.D + 2.0F); if (aav2.D > aav1.D) f /= 2.0F;  f1 += aav2.E * f; f2 += aav2.D * f; f3 += f; }  }  f1 /= f3; f2 /= f3; f1 = f1 * 0.9F + 0.1F; f2 = (f2 * 4.0F - 1.0F) / 8.0F; double d = this.h[b2] / 8000.0D; if (d < 0.0D) d = -d * 0.3D;  d = d * 3.0D - 2.0D; if (d < 0.0D) { d /= 2.0D; if (d < -1.0D) d = -1.0D;  d /= 1.4D; d /= 2.0D; } else { if (d > 1.0D) d = 1.0D;  d /= 8.0D; }  b2++; for (byte b6 = 0; b6 < paramInt5; b6++) { double d3 = f2; double d4 = f1; d3 += d * 0.2D; d3 = d3 * paramInt5 / 16.0D; double d5 = paramInt5 / 2.0D + d3 * 4.0D; double d6 = 0.0D; double d7 = (b6 - d5) * 12.0D * 128.0D / 128.0D / d4; if (d7 < 0.0D)
/*     */             d7 *= 4.0D;  double d8 = this.e[b1] / 512.0D; double d9 = this.f[b1] / 512.0D; double d10 = (this.d[b1] / 10.0D + 1.0D) / 2.0D; if (d10 < 0.0D) { d6 = d8; } else if (d10 > 1.0D) { d6 = d9; } else { d6 = d8 + (d9 - d8) * d10; }  d6 -= d7; if (b6 > paramInt5 - 4) { double d11 = ((b6 - paramInt5 - 4) / 3.0F); d6 = d6 * (1.0D - d11) + -10.0D * d11; }  paramArrayOfdouble[b1] = d6; b1++; }  }  }  return paramArrayOfdouble; }
/* 473 */   public boolean a(int paramInt1, int paramInt2) { return true; } public boolean a(boolean paramBoolean, lc paramlc) { return true; }
/*     */ 
/*     */ 
/*     */   
/*     */   public void b() {}
/*     */   
/*     */   public boolean c() {
/* 480 */     return false;
/*     */   }
/*     */   
/*     */   public boolean d() {
/* 484 */     return true;
/*     */   }
/*     */   
/*     */   public String e() {
/* 488 */     return "RandomLevelSource";
/*     */   }
/*     */   
/*     */   public List a(nn paramnn, int paramInt1, int paramInt2, int paramInt3) {
/* 492 */     aav aav1 = this.p.a(paramInt1, paramInt3);
/* 493 */     if (aav1 == null) {
/* 494 */       return null;
/*     */     }
/* 496 */     if (aav1 == aav.h && paramnn == nn.a && this.x.a(paramInt1, paramInt2, paramInt3)) {
/* 497 */       return this.x.a();
/*     */     }
/* 499 */     return aav1.a(paramnn);
/*     */   }
/*     */   
/*     */   public aat a(aab paramaab, String paramString, int paramInt1, int paramInt2, int paramInt3) {
/* 503 */     if ("Stronghold".equals(paramString) && this.u != null) {
/* 504 */       return this.u.a(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     }
/* 506 */     return null;
/*     */   }
/*     */   
/*     */   public int f() {
/* 510 */     return 0;
/*     */   }
/*     */   
/*     */   public void e(int paramInt1, int paramInt2) {
/* 514 */     if (this.q) {
/* 515 */       this.w.a(this, this.p, paramInt1, paramInt2, null);
/* 516 */       this.v.a(this, this.p, paramInt1, paramInt2, null);
/* 517 */       this.u.a(this, this.p, paramInt1, paramInt2, null);
/* 518 */       this.x.a(this, this.p, paramInt1, paramInt2, null);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */