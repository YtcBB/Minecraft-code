/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ajv
/*     */ {
/*     */   private long a;
/*  13 */   private aal b = aal.b;
/*  14 */   private String c = "";
/*     */   
/*     */   private int d;
/*     */   
/*     */   private int e;
/*     */   
/*     */   private int f;
/*     */   private long g;
/*     */   private long h;
/*     */   private long i;
/*     */   private long j;
/*     */   private bs k;
/*     */   private int l;
/*     */   private String m;
/*     */   private int n;
/*     */   private boolean o;
/*     */   private int p;
/*     */   private boolean q;
/*     */   private int r;
/*     */   private aaj s;
/*     */   private boolean t;
/*     */   private boolean u;
/*     */   private boolean v;
/*     */   private boolean w;
/*  38 */   private zy x = new zy();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ajv(bs parambs) {
/*  46 */     this.a = parambs.f("RandomSeed");
/*  47 */     if (parambs.b("generatorName")) {
/*  48 */       String str = parambs.i("generatorName");
/*  49 */       this.b = aal.a(str);
/*  50 */       if (this.b == null) {
/*  51 */         this.b = aal.b;
/*  52 */       } else if (this.b.e()) {
/*  53 */         int i = 0;
/*  54 */         if (parambs.b("generatorVersion")) {
/*  55 */           i = parambs.e("generatorVersion");
/*     */         }
/*  57 */         this.b = this.b.a(i);
/*     */       } 
/*     */       
/*  60 */       if (parambs.b("generatorOptions")) this.c = parambs.i("generatorOptions"); 
/*     */     } 
/*  62 */     this.s = aaj.a(parambs.e("GameType"));
/*  63 */     if (parambs.b("MapFeatures")) {
/*  64 */       this.t = parambs.n("MapFeatures");
/*     */     } else {
/*  66 */       this.t = true;
/*     */     } 
/*  68 */     this.d = parambs.e("SpawnX");
/*  69 */     this.e = parambs.e("SpawnY");
/*  70 */     this.f = parambs.e("SpawnZ");
/*  71 */     this.g = parambs.f("Time");
/*  72 */     if (parambs.b("DayTime")) {
/*  73 */       this.h = parambs.f("DayTime");
/*     */     } else {
/*  75 */       this.h = this.g;
/*     */     } 
/*  77 */     this.i = parambs.f("LastPlayed");
/*  78 */     this.j = parambs.f("SizeOnDisk");
/*  79 */     this.m = parambs.i("LevelName");
/*  80 */     this.n = parambs.e("version");
/*  81 */     this.p = parambs.e("rainTime");
/*  82 */     this.o = parambs.n("raining");
/*  83 */     this.r = parambs.e("thunderTime");
/*  84 */     this.q = parambs.n("thundering");
/*  85 */     this.u = parambs.n("hardcore");
/*     */     
/*  87 */     if (parambs.b("initialized")) {
/*  88 */       this.w = parambs.n("initialized");
/*     */     } else {
/*  90 */       this.w = true;
/*     */     } 
/*     */     
/*  93 */     if (parambs.b("allowCommands")) {
/*  94 */       this.v = parambs.n("allowCommands");
/*     */     } else {
/*  96 */       this.v = (this.s == aaj.c);
/*     */     } 
/*     */     
/*  99 */     if (parambs.b("Player")) {
/* 100 */       this.k = parambs.l("Player");
/* 101 */       this.l = this.k.e("Dimension");
/*     */     } 
/*     */     
/* 104 */     if (parambs.b("GameRules")) {
/* 105 */       this.x.a(parambs.l("GameRules"));
/*     */     }
/*     */   }
/*     */   
/*     */   public ajv(aai paramaai, String paramString) {
/* 110 */     this.a = paramaai.d();
/* 111 */     this.s = paramaai.e();
/* 112 */     this.t = paramaai.g();
/* 113 */     this.m = paramString;
/* 114 */     this.u = paramaai.f();
/* 115 */     this.b = paramaai.h();
/* 116 */     this.c = paramaai.j();
/* 117 */     this.v = paramaai.i();
/* 118 */     this.w = false;
/*     */   }
/*     */   
/*     */   public ajv(ajv paramajv) {
/* 122 */     this.a = paramajv.a;
/* 123 */     this.b = paramajv.b;
/* 124 */     this.c = paramajv.c;
/* 125 */     this.s = paramajv.s;
/* 126 */     this.t = paramajv.t;
/* 127 */     this.d = paramajv.d;
/* 128 */     this.e = paramajv.e;
/* 129 */     this.f = paramajv.f;
/* 130 */     this.g = paramajv.g;
/* 131 */     this.h = paramajv.h;
/* 132 */     this.i = paramajv.i;
/* 133 */     this.j = paramajv.j;
/* 134 */     this.k = paramajv.k;
/* 135 */     this.l = paramajv.l;
/* 136 */     this.m = paramajv.m;
/* 137 */     this.n = paramajv.n;
/* 138 */     this.p = paramajv.p;
/* 139 */     this.o = paramajv.o;
/* 140 */     this.r = paramajv.r;
/* 141 */     this.q = paramajv.q;
/* 142 */     this.u = paramajv.u;
/* 143 */     this.v = paramajv.v;
/* 144 */     this.w = paramajv.w;
/* 145 */     this.x = paramajv.x;
/*     */   }
/*     */   
/*     */   public bs a() {
/* 149 */     bs bs1 = new bs();
/*     */     
/* 151 */     a(bs1, this.k);
/*     */     
/* 153 */     return bs1;
/*     */   }
/*     */   
/*     */   public bs a(bs parambs) {
/* 157 */     bs bs1 = new bs();
/* 158 */     a(bs1, parambs);
/*     */     
/* 160 */     return bs1;
/*     */   }
/*     */   
/*     */   private void a(bs parambs1, bs parambs2) {
/* 164 */     parambs1.a("RandomSeed", this.a);
/* 165 */     parambs1.a("generatorName", this.b.a());
/* 166 */     parambs1.a("generatorVersion", this.b.c());
/* 167 */     parambs1.a("generatorOptions", this.c);
/* 168 */     parambs1.a("GameType", this.s.a());
/* 169 */     parambs1.a("MapFeatures", this.t);
/* 170 */     parambs1.a("SpawnX", this.d);
/* 171 */     parambs1.a("SpawnY", this.e);
/* 172 */     parambs1.a("SpawnZ", this.f);
/* 173 */     parambs1.a("Time", this.g);
/* 174 */     parambs1.a("DayTime", this.h);
/* 175 */     parambs1.a("SizeOnDisk", this.j);
/* 176 */     parambs1.a("LastPlayed", System.currentTimeMillis());
/* 177 */     parambs1.a("LevelName", this.m);
/* 178 */     parambs1.a("version", this.n);
/* 179 */     parambs1.a("rainTime", this.p);
/* 180 */     parambs1.a("raining", this.o);
/* 181 */     parambs1.a("thunderTime", this.r);
/* 182 */     parambs1.a("thundering", this.q);
/* 183 */     parambs1.a("hardcore", this.u);
/* 184 */     parambs1.a("allowCommands", this.v);
/* 185 */     parambs1.a("initialized", this.w);
/* 186 */     parambs1.a("GameRules", this.x.a());
/*     */     
/* 188 */     if (parambs2 != null) {
/* 189 */       parambs1.a("Player", parambs2);
/*     */     }
/*     */   }
/*     */   
/*     */   public long b() {
/* 194 */     return this.a;
/*     */   }
/*     */   
/*     */   public int c() {
/* 198 */     return this.d;
/*     */   }
/*     */   
/*     */   public int d() {
/* 202 */     return this.e;
/*     */   }
/*     */   
/*     */   public int e() {
/* 206 */     return this.f;
/*     */   }
/*     */   
/*     */   public long f() {
/* 210 */     return this.g;
/*     */   }
/*     */   
/*     */   public long g() {
/* 214 */     return this.h;
/*     */   }
/*     */   
/*     */   public long h() {
/* 218 */     return this.j;
/*     */   }
/*     */   
/*     */   public bs i() {
/* 222 */     return this.k;
/*     */   }
/*     */   
/*     */   public int j() {
/* 226 */     return this.l;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(int paramInt) {
/* 234 */     this.d = paramInt;
/*     */   }
/*     */   
/*     */   public void b(int paramInt) {
/* 238 */     this.e = paramInt;
/*     */   }
/*     */   
/*     */   public void c(int paramInt) {
/* 242 */     this.f = paramInt;
/*     */   }
/*     */   
/*     */   public void b(long paramLong) {
/* 246 */     this.g = paramLong;
/*     */   }
/*     */   
/*     */   public void c(long paramLong) {
/* 250 */     this.h = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(int paramInt1, int paramInt2, int paramInt3) {
/* 266 */     this.d = paramInt1;
/* 267 */     this.e = paramInt2;
/* 268 */     this.f = paramInt3;
/*     */   }
/*     */   
/*     */   public String k() {
/* 272 */     return this.m;
/*     */   }
/*     */   
/*     */   public void a(String paramString) {
/* 276 */     this.m = paramString;
/*     */   }
/*     */   
/*     */   public int l() {
/* 280 */     return this.n;
/*     */   }
/*     */   
/*     */   public void e(int paramInt) {
/* 284 */     this.n = paramInt;
/*     */   }
/*     */   
/*     */   public long m() {
/* 288 */     return this.i;
/*     */   }
/*     */   
/*     */   public boolean n() {
/* 292 */     return this.q;
/*     */   }
/*     */   
/*     */   public void a(boolean paramBoolean) {
/* 296 */     this.q = paramBoolean;
/*     */   }
/*     */   
/*     */   public int o() {
/* 300 */     return this.r;
/*     */   }
/*     */   
/*     */   public void f(int paramInt) {
/* 304 */     this.r = paramInt;
/*     */   }
/*     */   
/*     */   public boolean p() {
/* 308 */     return this.o;
/*     */   }
/*     */   
/*     */   public void b(boolean paramBoolean) {
/* 312 */     this.o = paramBoolean;
/*     */   }
/*     */   
/*     */   public int q() {
/* 316 */     return this.p;
/*     */   }
/*     */   
/*     */   public void g(int paramInt) {
/* 320 */     this.p = paramInt;
/*     */   }
/*     */   
/*     */   public aaj r() {
/* 324 */     return this.s;
/*     */   }
/*     */   
/*     */   public boolean s() {
/* 328 */     return this.t;
/*     */   }
/*     */   
/*     */   public void a(aaj paramaaj) {
/* 332 */     this.s = paramaaj;
/*     */   }
/*     */   
/*     */   public boolean t() {
/* 336 */     return this.u;
/*     */   }
/*     */   
/*     */   public aal u() {
/* 340 */     return this.b;
/*     */   }
/*     */   
/*     */   public void a(aal paramaal) {
/* 344 */     this.b = paramaal;
/*     */   }
/*     */   
/*     */   public String y() {
/* 348 */     return this.c;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean v() {
/* 356 */     return this.v;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean w() {
/* 364 */     return this.w;
/*     */   }
/*     */   
/*     */   public void d(boolean paramBoolean) {
/* 368 */     this.w = paramBoolean;
/*     */   }
/*     */   
/*     */   public zy x() {
/* 372 */     return this.x;
/*     */   }
/*     */   
/*     */   public void a(m paramm) {
/* 376 */     paramm.a("Level seed", new ajw(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 382 */     paramm.a("Level generator", new ajx(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 388 */     paramm.a("Level generator options", new ajy(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 394 */     paramm.a("Level spawn location", new ajz(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 400 */     paramm.a("Level time", new aka(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 406 */     paramm.a("Level dimension", new akb(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 412 */     paramm.a("Level storage version", new akc(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 431 */     paramm.a("Level weather", new akd(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 437 */     paramm.a("Level game mode", new ake(this));
/*     */   }
/*     */   
/*     */   protected ajv() {}
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */