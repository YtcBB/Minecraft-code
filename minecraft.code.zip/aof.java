/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aof
/*     */   extends apa
/*     */ {
/*     */   private boolean a;
/*     */   
/*     */   public aof(int paramInt, boolean paramBoolean) {
/*  15 */     super(paramInt, aif.e);
/*  16 */     if (paramBoolean) {
/*  17 */       b(true);
/*     */     }
/*  19 */     this.a = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  24 */     return 30;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {
/*  29 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*  30 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramsq);
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/*  35 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*  36 */     super.b(paramaab, paramInt1, paramInt2, paramInt3, parammp);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  41 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*  42 */     return super.a(paramaab, paramInt1, paramInt2, paramInt3, paramsq, paramInt4, paramFloat1, paramFloat2, paramFloat3);
/*     */   }
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  46 */     m(paramaab, paramInt1, paramInt2, paramInt3);
/*  47 */     if (this.cz == apa.aR.cz) {
/*  48 */       paramaab.c(paramInt1, paramInt2, paramInt3, apa.aS.cz);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  54 */     if (this.cz == apa.aS.cz) {
/*  55 */       paramaab.c(paramInt1, paramInt2, paramInt3, apa.aR.cz);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  61 */     return wk.aD.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt, Random paramRandom) {
/*  66 */     return a(paramRandom) + paramRandom.nextInt(paramInt + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/*  71 */     return 4 + paramRandom.nextInt(2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/*  76 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, paramInt5);
/*     */ 
/*     */     
/*  79 */     if (a(paramInt4, paramaab.s, paramInt5) != this.cz) {
/*  80 */       int i = 1 + paramaab.s.nextInt(5);
/*  81 */       j(paramaab, paramInt1, paramInt2, paramInt3, i);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  87 */     if (this.a) {
/*  88 */       m(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */   }
/*     */   
/*     */   private void m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  93 */     Random random = paramaab.s;
/*  94 */     double d = 0.0625D;
/*  95 */     for (byte b = 0; b < 6; b++) {
/*  96 */       double d1 = (paramInt1 + random.nextFloat());
/*  97 */       double d2 = (paramInt2 + random.nextFloat());
/*  98 */       double d3 = (paramInt3 + random.nextFloat());
/*  99 */       if (b == 0 && !paramaab.t(paramInt1, paramInt2 + 1, paramInt3)) d2 = (paramInt2 + 1) + d; 
/* 100 */       if (b == 1 && !paramaab.t(paramInt1, paramInt2 - 1, paramInt3)) d2 = (paramInt2 + 0) - d; 
/* 101 */       if (b == 2 && !paramaab.t(paramInt1, paramInt2, paramInt3 + 1)) d3 = (paramInt3 + 1) + d; 
/* 102 */       if (b == 3 && !paramaab.t(paramInt1, paramInt2, paramInt3 - 1)) d3 = (paramInt3 + 0) - d; 
/* 103 */       if (b == 4 && !paramaab.t(paramInt1 + 1, paramInt2, paramInt3)) d1 = (paramInt1 + 1) + d; 
/* 104 */       if (b == 5 && !paramaab.t(paramInt1 - 1, paramInt2, paramInt3)) d1 = (paramInt1 + 0) - d; 
/* 105 */       if (d1 < paramInt1 || d1 > (paramInt1 + 1) || d2 < 0.0D || d2 > (paramInt2 + 1) || d3 < paramInt3 || d3 > (paramInt3 + 1)) {
/* 106 */         paramaab.a("reddust", d1, d2, d3, 0.0D, 0.0D, 0.0D);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected wm c_(int paramInt) {
/* 113 */     return new wm(apa.aR);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aof.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */