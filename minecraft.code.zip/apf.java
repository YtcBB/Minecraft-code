/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apf
/*     */   extends apa
/*     */ {
/*     */   private lx a;
/*     */   private lx b;
/*     */   
/*     */   public apf(int paramInt) {
/*  24 */     super(paramInt, aif.t);
/*  25 */     a(ve.d);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  30 */     if (paramInt1 == 0) return this.b; 
/*  31 */     if (paramInt1 == 1) return this.a; 
/*  32 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  37 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/*  38 */     if (paramaab.C(paramInt1, paramInt2, paramInt3)) {
/*  39 */       g(paramaab, paramInt1, paramInt2, paramInt3, 1);
/*  40 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  47 */     if (paramaab.C(paramInt1, paramInt2, paramInt3)) {
/*  48 */       g(paramaab, paramInt1, paramInt2, paramInt3, 1);
/*  49 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/*  56 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, zw paramzw) {
/*  61 */     if (paramaab.I)
/*     */       return; 
/*  63 */     rr rr = new rr(paramaab, (paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), paramzw.c());
/*  64 */     rr.a = paramaab.s.nextInt(rr.a / 4) + rr.a / 8;
/*  65 */     paramaab.d(rr);
/*     */   }
/*     */ 
/*     */   
/*     */   public void g(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  70 */     a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, (ng)null);
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, ng paramng) {
/*  74 */     if (paramaab.I)
/*     */       return; 
/*  76 */     if ((paramInt4 & 0x1) == 1) {
/*  77 */       rr rr = new rr(paramaab, (paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), paramng);
/*  78 */       paramaab.d(rr);
/*  79 */       paramaab.a(rr, "random.fuse", 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  85 */     if (paramsq.cd() != null && (paramsq.cd()).c == wk.j.cp) {
/*  86 */       a(paramaab, paramInt1, paramInt2, paramInt3, 1, paramsq);
/*  87 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*  88 */       return true;
/*     */     } 
/*  90 */     return super.a(paramaab, paramInt1, paramInt2, paramInt3, paramsq, paramInt4, paramFloat1, paramFloat2, paramFloat3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/*  95 */     if (parammp instanceof ss && !paramaab.I) {
/*  96 */       ss ss = (ss)parammp;
/*  97 */       if (ss.ae()) {
/*  98 */         a(paramaab, paramInt1, paramInt2, paramInt3, 1, (ss.c instanceof ng) ? (ng)ss.c : null);
/*  99 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(zw paramzw) {
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 111 */     this.cQ = paramly.a("tnt_side");
/* 112 */     this.a = paramly.a("tnt_top");
/* 113 */     this.b = paramly.a("tnt_bottom");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */