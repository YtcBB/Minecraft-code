/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aqb
/*    */   extends aqp
/*    */ {
/*    */   public void h() {
/* 13 */     if (this.k != null && !this.k.I && this.k.H() % 20L == 0L) {
/* 14 */       this.q = q();
/* 15 */       if (this.q != null && this.q instanceof alv)
/* 16 */         ((alv)this.q).i_(this.k, this.l, this.m, this.n); 
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */