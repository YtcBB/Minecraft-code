/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adv
/*    */   extends adj
/*    */ {
/*    */   private int a;
/*    */   private int b;
/*    */   private int c;
/*    */   
/*    */   public adv(int paramInt1, int paramInt2) {
/* 15 */     this(paramInt1, paramInt2, apa.x.cz);
/*    */   }
/*    */   
/*    */   public adv(int paramInt1, int paramInt2, int paramInt3) {
/* 19 */     this.a = paramInt1;
/* 20 */     this.b = paramInt2;
/* 21 */     this.c = paramInt3;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 27 */     float f = paramRandom.nextFloat() * 3.1415927F;
/*    */     
/* 29 */     double d1 = ((paramInt1 + 8) + kx.a(f) * this.b / 8.0F);
/* 30 */     double d2 = ((paramInt1 + 8) - kx.a(f) * this.b / 8.0F);
/* 31 */     double d3 = ((paramInt3 + 8) + kx.b(f) * this.b / 8.0F);
/* 32 */     double d4 = ((paramInt3 + 8) - kx.b(f) * this.b / 8.0F);
/*    */     
/* 34 */     double d5 = (paramInt2 + paramRandom.nextInt(3) - 2);
/* 35 */     double d6 = (paramInt2 + paramRandom.nextInt(3) - 2);
/*    */     
/* 37 */     for (byte b = 0; b <= this.b; b++) {
/* 38 */       double d7 = d1 + (d2 - d1) * b / this.b;
/* 39 */       double d8 = d5 + (d6 - d5) * b / this.b;
/* 40 */       double d9 = d3 + (d4 - d3) * b / this.b;
/*    */       
/* 42 */       double d10 = paramRandom.nextDouble() * this.b / 16.0D;
/* 43 */       double d11 = (kx.a(b * 3.1415927F / this.b) + 1.0F) * d10 + 1.0D;
/* 44 */       double d12 = (kx.a(b * 3.1415927F / this.b) + 1.0F) * d10 + 1.0D;
/*    */       
/* 46 */       int i = kx.c(d7 - d11 / 2.0D);
/* 47 */       int j = kx.c(d8 - d12 / 2.0D);
/* 48 */       int k = kx.c(d9 - d11 / 2.0D);
/*    */       
/* 50 */       int m = kx.c(d7 + d11 / 2.0D);
/* 51 */       int n = kx.c(d8 + d12 / 2.0D);
/* 52 */       int i1 = kx.c(d9 + d11 / 2.0D);
/*    */       
/* 54 */       for (int i2 = i; i2 <= m; i2++) {
/* 55 */         double d = (i2 + 0.5D - d7) / d11 / 2.0D;
/* 56 */         if (d * d < 1.0D) {
/* 57 */           for (int i3 = j; i3 <= n; i3++) {
/* 58 */             double d13 = (i3 + 0.5D - d8) / d12 / 2.0D;
/* 59 */             if (d * d + d13 * d13 < 1.0D) {
/* 60 */               for (int i4 = k; i4 <= i1; i4++) {
/* 61 */                 double d14 = (i4 + 0.5D - d9) / d11 / 2.0D;
/* 62 */                 if (d * d + d13 * d13 + d14 * d14 < 1.0D && 
/* 63 */                   paramaab.a(i2, i3, i4) == this.c) paramaab.f(i2, i3, i4, this.a, 0, 2);
/*    */               
/*    */               } 
/*    */             }
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/*    */     
/* 72 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */