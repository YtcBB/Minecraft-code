/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class act
/*     */   implements abt
/*     */ {
/*     */   private aab a;
/*     */   private Random b;
/*  22 */   private final byte[] c = new byte[256];
/*  23 */   private final byte[] d = new byte[256];
/*     */   private final aeh e;
/*  25 */   private final List f = new ArrayList();
/*     */   private final boolean g;
/*     */   private final boolean h;
/*     */   private adr i;
/*     */   private adr j;
/*     */   
/*     */   public act(aab paramaab, long paramLong, boolean paramBoolean, String paramString) {
/*  32 */     this.a = paramaab;
/*  33 */     this.b = new Random(paramLong);
/*  34 */     this.e = aeh.a(paramString);
/*     */     
/*  36 */     if (paramBoolean) {
/*  37 */       Map map = this.e.b();
/*     */       
/*  39 */       if (map.containsKey("village")) {
/*  40 */         Map<String, String> map1 = (Map)map.get("village");
/*  41 */         if (!map1.containsKey("size")) map1.put("size", "1"); 
/*  42 */         this.f.add(new agz(map1));
/*     */       } 
/*     */       
/*  45 */       if (map.containsKey("biome_1")) this.f.add(new afm((Map)map.get("biome_1"))); 
/*  46 */       if (map.containsKey("mineshaft")) this.f.add(new ael((Map)map.get("mineshaft"))); 
/*  47 */       if (map.containsKey("stronghold")) this.f.add(new afv((Map)map.get("stronghold")));
/*     */     
/*     */     } 
/*  50 */     this.g = this.e.b().containsKey("decoration");
/*  51 */     if (this.e.b().containsKey("lake")) this.i = new adr(apa.F.cz); 
/*  52 */     if (this.e.b().containsKey("lava_lake")) this.j = new adr(apa.H.cz); 
/*  53 */     this.h = this.e.b().containsKey("dungeon");
/*     */     
/*  55 */     for (aei aei : this.e.c()) {
/*  56 */       for (int i = aei.d(); i < aei.d() + aei.a(); i++) {
/*  57 */         this.c[i] = (byte)(aei.b() & 0xFF);
/*  58 */         this.d[i] = (byte)aei.c();
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public abw c(int paramInt1, int paramInt2) {
/*  64 */     return d(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public abw d(int paramInt1, int paramInt2) {
/*  68 */     abw abw = new abw(this.a, paramInt1, paramInt2);
/*     */     
/*  70 */     for (byte b1 = 0; b1 < this.c.length; b1++) {
/*  71 */       int i = b1 >> 4;
/*  72 */       abx abx = abw.i()[i];
/*     */       
/*  74 */       if (abx == null) {
/*  75 */         abx = new abx(b1, !this.a.t.f);
/*  76 */         abw.i()[i] = abx;
/*     */       } 
/*     */       
/*  79 */       for (byte b = 0; b < 16; b++) {
/*  80 */         for (byte b3 = 0; b3 < 16; b3++) {
/*  81 */           abx.a(b, b1 & 0xF, b3, this.c[b1] & 0xFF);
/*  82 */           abx.b(b, b1 & 0xF, b3, this.d[b1]);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  87 */     abw.b();
/*     */     
/*  89 */     aav[] arrayOfAav = this.a.u().b((aav[])null, paramInt1 * 16, paramInt2 * 16, 16, 16);
/*  90 */     byte[] arrayOfByte = abw.m();
/*     */     
/*  92 */     for (byte b2 = 0; b2 < arrayOfByte.length; b2++) {
/*  93 */       arrayOfByte[b2] = (byte)(arrayOfAav[b2]).N;
/*     */     }
/*     */     
/*  96 */     for (ags ags : this.f) {
/*  97 */       ags.a(this, this.a, paramInt1, paramInt2, null);
/*     */     }
/*     */     
/* 100 */     abw.b();
/*     */     
/* 102 */     return abw;
/*     */   }
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2) {
/* 106 */     return true;
/*     */   }
/*     */   
/*     */   public void a(abt paramabt, int paramInt1, int paramInt2) {
/* 110 */     int i = paramInt1 * 16;
/* 111 */     int j = paramInt2 * 16;
/* 112 */     aav aav = this.a.a(i + 16, j + 16);
/* 113 */     boolean bool = false;
/*     */     
/* 115 */     this.b.setSeed(this.a.G());
/* 116 */     long l1 = this.b.nextLong() / 2L * 2L + 1L;
/* 117 */     long l2 = this.b.nextLong() / 2L * 2L + 1L;
/* 118 */     this.b.setSeed(paramInt1 * l1 + paramInt2 * l2 ^ this.a.G());
/*     */     
/* 120 */     for (ags ags : this.f) {
/* 121 */       boolean bool1 = ags.a(this.a, this.b, paramInt1, paramInt2);
/* 122 */       if (ags instanceof agz) bool |= bool1;
/*     */     
/*     */     } 
/* 125 */     if (this.i != null && !bool && this.b.nextInt(4) == 0) {
/* 126 */       int k = i + this.b.nextInt(16) + 8;
/* 127 */       int m = this.b.nextInt(128);
/* 128 */       int n = j + this.b.nextInt(16) + 8;
/* 129 */       this.i.a(this.a, this.b, k, m, n);
/*     */     } 
/*     */     
/* 132 */     if (this.j != null && !bool && this.b.nextInt(8) == 0) {
/* 133 */       int k = i + this.b.nextInt(16) + 8;
/* 134 */       int m = this.b.nextInt(this.b.nextInt(120) + 8);
/* 135 */       int n = j + this.b.nextInt(16) + 8;
/* 136 */       if (m < 63 || this.b.nextInt(10) == 0) {
/* 137 */         this.j.a(this.a, this.b, k, m, n);
/*     */       }
/*     */     } 
/*     */     
/* 141 */     if (this.h) {
/* 142 */       for (byte b = 0; b < 8; b++) {
/* 143 */         int k = i + this.b.nextInt(16) + 8;
/* 144 */         int m = this.b.nextInt(128);
/* 145 */         int n = j + this.b.nextInt(16) + 8;
/* 146 */         (new adu()).a(this.a, this.b, k, m, n);
/*     */       } 
/*     */     }
/*     */     
/* 150 */     if (this.g) {
/* 151 */       aav.a(this.a, this.b, i, j);
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean a(boolean paramBoolean, lc paramlc) {
/* 156 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void b() {}
/*     */   
/*     */   public boolean c() {
/* 163 */     return false;
/*     */   }
/*     */   
/*     */   public boolean d() {
/* 167 */     return true;
/*     */   }
/*     */   
/*     */   public String e() {
/* 171 */     return "FlatLevelSource";
/*     */   }
/*     */   
/*     */   public List a(nn paramnn, int paramInt1, int paramInt2, int paramInt3) {
/* 175 */     aav aav = this.a.a(paramInt1, paramInt3);
/* 176 */     if (aav == null) {
/* 177 */       return null;
/*     */     }
/* 179 */     return aav.a(paramnn);
/*     */   }
/*     */   
/*     */   public aat a(aab paramaab, String paramString, int paramInt1, int paramInt2, int paramInt3) {
/* 183 */     if ("Stronghold".equals(paramString)) {
/* 184 */       for (ags ags : this.f) {
/* 185 */         if (ags instanceof afv) {
/* 186 */           return ags.a(paramaab, paramInt1, paramInt2, paramInt3);
/*     */         }
/*     */       } 
/*     */     }
/* 190 */     return null;
/*     */   }
/*     */   
/*     */   public int f() {
/* 194 */     return 0;
/*     */   }
/*     */   
/*     */   public void e(int paramInt1, int paramInt2) {
/* 198 */     for (ags ags : this.f)
/* 199 */       ags.a(this, this.a, paramInt1, paramInt2, null); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\act.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */