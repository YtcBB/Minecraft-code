/*    */ import java.util.ArrayList;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class aet
/*    */   extends agy
/*    */ {
/*    */   public aet(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 61 */     afl afl = new afl(paramRandom, (paramInt1 << 4) + 2, (paramInt2 << 4) + 2);
/* 62 */     this.a.add(afl);
/* 63 */     afl.a(afl, this.a, paramRandom);
/*    */     
/* 65 */     ArrayList<agw> arrayList = afl.d;
/* 66 */     while (!arrayList.isEmpty()) {
/* 67 */       int i = paramRandom.nextInt(arrayList.size());
/* 68 */       agw agw = arrayList.remove(i);
/* 69 */       agw.a(afl, this.a, paramRandom);
/*    */     } 
/*    */     
/* 72 */     c();
/* 73 */     a(paramaab, paramRandom, 48, 70);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */