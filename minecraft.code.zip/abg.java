/*   */ 
/*   */ public class abg
/*   */   extends aav
/*   */ {
/*   */   public abg(int paramInt) {
/* 6 */     super(paramInt);
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */