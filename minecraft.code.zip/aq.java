/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ public class aq
/*    */   extends x
/*    */ {
/*    */   public String c() {
/*  8 */     return "toggledownfall";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 13 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 18 */     d();
/* 19 */     a(paramab, "commands.downfall.success", new Object[0]);
/*    */   }
/*    */   
/*    */   protected void d() {
/* 23 */     (MinecraftServer.D()).b[0].A();
/* 24 */     (MinecraftServer.D()).b[0].M().a(true);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */