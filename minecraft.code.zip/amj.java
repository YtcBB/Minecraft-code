/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amj
/*     */   extends alz
/*     */ {
/*     */   public amj(int paramInt) {
/*  17 */     super(paramInt, aif.d);
/*  18 */     a(ve.d);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  23 */     return apa.B.m(paramInt1);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  28 */     if (!paramaab.g(paramInt1, paramInt2 - 1, paramInt3).a()) return false; 
/*  29 */     return super.c(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  34 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  35 */     if (k_(i)) {
/*  36 */       return null;
/*     */     }
/*  38 */     if (i == 2 || i == 0) {
/*  39 */       return aqx.a().a(paramInt1, paramInt2, (paramInt3 + 0.375F), (paramInt1 + 1), (paramInt2 + 1.5F), (paramInt3 + 0.625F));
/*     */     }
/*  41 */     return aqx.a().a((paramInt1 + 0.375F), paramInt2, paramInt3, (paramInt1 + 0.625F), (paramInt2 + 1.5F), (paramInt3 + 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  46 */     int i = j(paramaak.h(paramInt1, paramInt2, paramInt3));
/*  47 */     if (i == 2 || i == 0) {
/*  48 */       a(0.0F, 0.0F, 0.375F, 1.0F, 1.0F, 0.625F);
/*     */     } else {
/*  50 */       a(0.375F, 0.0F, 0.0F, 0.625F, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  70 */     return k_(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  75 */     return 21;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/*  80 */     int i = (kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3) % 4;
/*  81 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  86 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  87 */     if (k_(i)) {
/*  88 */       paramaab.b(paramInt1, paramInt2, paramInt3, i & 0xFFFFFFFB, 2);
/*     */     } else {
/*     */       
/*  91 */       int j = (kx.c((paramsq.A * 4.0F / 360.0F) + 0.5D) & 0x3) % 4;
/*  92 */       int k = j(i);
/*  93 */       if (k == (j + 2) % 4) {
/*  94 */         i = j;
/*     */       }
/*  96 */       paramaab.b(paramInt1, paramInt2, paramInt3, i | 0x4, 2);
/*     */     } 
/*  98 */     paramaab.a(paramsq, 1003, paramInt1, paramInt2, paramInt3, 0);
/*  99 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 104 */     if (paramaab.I)
/*     */       return; 
/* 106 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/* 108 */     boolean bool = paramaab.C(paramInt1, paramInt2, paramInt3);
/* 109 */     if (bool || (paramInt4 > 0 && apa.r[paramInt4].f())) {
/* 110 */       if (bool && !k_(i)) {
/* 111 */         paramaab.b(paramInt1, paramInt2, paramInt3, i | 0x4, 2);
/* 112 */         paramaab.a((sq)null, 1003, paramInt1, paramInt2, paramInt3, 0);
/* 113 */       } else if (!bool && k_(i)) {
/* 114 */         paramaab.b(paramInt1, paramInt2, paramInt3, i & 0xFFFFFFFB, 2);
/* 115 */         paramaab.a((sq)null, 1003, paramInt1, paramInt2, paramInt3, 0);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean k_(int paramInt) {
/* 121 */     return ((paramInt & 0x4) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 126 */     return true;
/*     */   }
/*     */   
/*     */   public void a(ly paramly) {}
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */