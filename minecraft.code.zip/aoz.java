/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aoz
/*     */   extends apa
/*     */ {
/*     */   private final String a;
/*     */   private final boolean b;
/*     */   private final String c;
/*     */   private lx d;
/*     */   
/*     */   protected aoz(int paramInt, String paramString1, String paramString2, aif paramaif, boolean paramBoolean) {
/*  20 */     super(paramInt, paramaif);
/*  21 */     this.a = paramString2;
/*  22 */     this.b = paramBoolean;
/*  23 */     this.c = paramString1;
/*  24 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  29 */     if (!this.b) {
/*  30 */       return 0;
/*     */     }
/*  32 */     return super.a(paramInt1, paramRandom, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  37 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  42 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  47 */     return 18;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  52 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/*  53 */     if (i == this.cz) return false; 
/*  54 */     return super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/*  59 */     boolean bool1 = d(paramaab.a(paramInt1, paramInt2, paramInt3 - 1));
/*  60 */     boolean bool2 = d(paramaab.a(paramInt1, paramInt2, paramInt3 + 1));
/*  61 */     boolean bool3 = d(paramaab.a(paramInt1 - 1, paramInt2, paramInt3));
/*  62 */     boolean bool4 = d(paramaab.a(paramInt1 + 1, paramInt2, paramInt3));
/*     */     
/*  64 */     if ((bool3 && bool4) || (!bool3 && !bool4 && !bool1 && !bool2)) {
/*  65 */       a(0.0F, 0.0F, 0.4375F, 1.0F, 1.0F, 0.5625F);
/*  66 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  67 */     } else if (bool3 && !bool4) {
/*  68 */       a(0.0F, 0.0F, 0.4375F, 0.5F, 1.0F, 0.5625F);
/*  69 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  70 */     } else if (!bool3 && bool4) {
/*  71 */       a(0.5F, 0.0F, 0.4375F, 1.0F, 1.0F, 0.5625F);
/*  72 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     } 
/*  74 */     if ((bool1 && bool2) || (!bool3 && !bool4 && !bool1 && !bool2)) {
/*  75 */       a(0.4375F, 0.0F, 0.0F, 0.5625F, 1.0F, 1.0F);
/*  76 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  77 */     } else if (bool1 && !bool2) {
/*  78 */       a(0.4375F, 0.0F, 0.0F, 0.5625F, 1.0F, 0.5F);
/*  79 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  80 */     } else if (!bool1 && bool2) {
/*  81 */       a(0.4375F, 0.0F, 0.5F, 0.5625F, 1.0F, 1.0F);
/*  82 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  88 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  93 */     float f1 = 0.4375F;
/*  94 */     float f2 = 0.5625F;
/*  95 */     float f3 = 0.4375F;
/*  96 */     float f4 = 0.5625F;
/*     */     
/*  98 */     boolean bool1 = d(paramaak.a(paramInt1, paramInt2, paramInt3 - 1));
/*  99 */     boolean bool2 = d(paramaak.a(paramInt1, paramInt2, paramInt3 + 1));
/* 100 */     boolean bool3 = d(paramaak.a(paramInt1 - 1, paramInt2, paramInt3));
/* 101 */     boolean bool4 = d(paramaak.a(paramInt1 + 1, paramInt2, paramInt3));
/*     */     
/* 103 */     if ((bool3 && bool4) || (!bool3 && !bool4 && !bool1 && !bool2)) {
/* 104 */       f1 = 0.0F;
/* 105 */       f2 = 1.0F;
/* 106 */     } else if (bool3 && !bool4) {
/* 107 */       f1 = 0.0F;
/* 108 */     } else if (!bool3 && bool4) {
/* 109 */       f2 = 1.0F;
/*     */     } 
/* 111 */     if ((bool1 && bool2) || (!bool3 && !bool4 && !bool1 && !bool2)) {
/* 112 */       f3 = 0.0F;
/* 113 */       f4 = 1.0F;
/* 114 */     } else if (bool1 && !bool2) {
/* 115 */       f3 = 0.0F;
/* 116 */     } else if (!bool1 && bool2) {
/* 117 */       f4 = 1.0F;
/*     */     } 
/*     */     
/* 120 */     a(f1, 0.0F, f3, f2, 1.0F, f4);
/*     */   }
/*     */   
/*     */   public lx q() {
/* 124 */     return this.d;
/*     */   }
/*     */   
/*     */   public final boolean d(int paramInt) {
/* 128 */     return (apa.s[paramInt] || paramInt == this.cz || paramInt == apa.Q.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean r_() {
/* 133 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected wm c_(int paramInt) {
/* 138 */     return new wm(this.cz, 1, paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 143 */     this.cQ = paramly.a(this.c);
/* 144 */     this.d = paramly.a(this.a);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */