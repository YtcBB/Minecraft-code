/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class aly
/*     */   extends alz
/*     */ {
/*     */   protected final boolean a;
/*     */   
/*     */   protected aly(int paramInt, boolean paramBoolean) {
/*  18 */     super(paramInt, aif.q);
/*  19 */     this.a = paramBoolean;
/*  20 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  25 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  30 */     if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) {
/*  31 */       return false;
/*     */     }
/*  33 */     return super.c(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  38 */     if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) {
/*  39 */       return false;
/*     */     }
/*  41 */     return super.f(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  46 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  48 */     if (!e(paramaab, paramInt1, paramInt2, paramInt3, i)) {
/*  49 */       boolean bool = d(paramaab, paramInt1, paramInt2, paramInt3, i);
/*  50 */       if (this.a && !bool) {
/*  51 */         paramaab.f(paramInt1, paramInt2, paramInt3, (j()).cz, i, 2);
/*  52 */       } else if (!this.a) {
/*     */ 
/*     */ 
/*     */         
/*  56 */         paramaab.f(paramInt1, paramInt2, paramInt3, (i()).cz, i, 2);
/*  57 */         if (!bool) {
/*  58 */           paramaab.a(paramInt1, paramInt2, paramInt3, (i()).cz, h(i), -1);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  67 */     if (paramInt1 == 0) {
/*  68 */       if (this.a) {
/*  69 */         return apa.aU.m(paramInt1);
/*     */       }
/*  71 */       return apa.aT.m(paramInt1);
/*     */     } 
/*  73 */     if (paramInt1 == 1) {
/*  74 */       return this.cQ;
/*     */     }
/*     */     
/*  77 */     return apa.an.m(1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  82 */     this.cQ = paramly.a(this.a ? "repeater_lit" : "repeater");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  87 */     if (paramInt4 == 0 || paramInt4 == 1)
/*     */     {
/*  89 */       return false;
/*     */     }
/*  91 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  96 */     return 36;
/*     */   }
/*     */   
/*     */   protected boolean c(int paramInt) {
/* 100 */     return this.a;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 105 */     return b(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 111 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 112 */     if (!c(i)) {
/* 113 */       return 0;
/*     */     }
/*     */     
/* 116 */     int j = j(i);
/*     */     
/* 118 */     if (j == 0 && paramInt4 == 3) return d(paramaak, paramInt1, paramInt2, paramInt3, i); 
/* 119 */     if (j == 1 && paramInt4 == 4) return d(paramaak, paramInt1, paramInt2, paramInt3, i); 
/* 120 */     if (j == 2 && paramInt4 == 2) return d(paramaak, paramInt1, paramInt2, paramInt3, i); 
/* 121 */     if (j == 3 && paramInt4 == 5) return d(paramaak, paramInt1, paramInt2, paramInt3, i);
/*     */     
/* 123 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 128 */     if (!f(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 129 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 130 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/* 131 */       paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 132 */       paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 133 */       paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/* 134 */       paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 135 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/* 136 */       paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*     */       
/*     */       return;
/*     */     } 
/* 140 */     f(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   protected void f(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 144 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/* 146 */     if (!e(paramaab, paramInt1, paramInt2, paramInt3, i)) {
/* 147 */       boolean bool = d(paramaab, paramInt1, paramInt2, paramInt3, i);
/* 148 */       if (((this.a && !bool) || (!this.a && bool)) && !paramaab.a(paramInt1, paramInt2, paramInt3, this.cz)) {
/* 149 */         byte b = -1;
/*     */ 
/*     */         
/* 152 */         if (h(paramaab, paramInt1, paramInt2, paramInt3, i)) {
/* 153 */           b = -3;
/* 154 */         } else if (this.a) {
/* 155 */           b = -2;
/*     */         } 
/*     */         
/* 158 */         paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, i_(i), b);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean e(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 164 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 168 */     return (e(paramaab, paramInt1, paramInt2, paramInt3, paramInt4) > 0);
/*     */   }
/*     */   
/*     */   protected int e(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 172 */     int i = j(paramInt4);
/*     */     
/* 174 */     int j = paramInt1 + r.a[i];
/* 175 */     int k = paramInt3 + r.b[i];
/* 176 */     int m = paramaab.l(j, paramInt2, k, r.d[i]);
/*     */     
/* 178 */     if (m >= 15) return m; 
/* 179 */     return Math.max(m, (paramaab.a(j, paramInt2, k) == apa.az.cz) ? paramaab.h(j, paramInt2, k) : 0);
/*     */   }
/*     */   
/*     */   protected int f(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 183 */     int i = j(paramInt4);
/*     */     
/* 185 */     switch (i) {
/*     */       case 0:
/*     */       case 2:
/* 188 */         return Math.max(g(paramaak, paramInt1 - 1, paramInt2, paramInt3, 4), g(paramaak, paramInt1 + 1, paramInt2, paramInt3, 5));
/*     */       case 1:
/*     */       case 3:
/* 191 */         return Math.max(g(paramaak, paramInt1, paramInt2, paramInt3 + 1, 3), g(paramaak, paramInt1, paramInt2, paramInt3 - 1, 2));
/*     */     } 
/*     */     
/* 194 */     return 0;
/*     */   }
/*     */   
/*     */   protected int g(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 198 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/*     */     
/* 200 */     if (e(i)) {
/* 201 */       if (i == apa.az.cz) {
/* 202 */         return paramaak.h(paramInt1, paramInt2, paramInt3);
/*     */       }
/* 204 */       return paramaak.j(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/*     */ 
/*     */     
/* 208 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f() {
/* 213 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 218 */     int i = ((kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3) + 2) % 4;
/* 219 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 3);
/*     */     
/* 221 */     boolean bool = d(paramaab, paramInt1, paramInt2, paramInt3, i);
/* 222 */     if (bool) {
/* 223 */       paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, 1);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 229 */     h_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   protected void h_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 233 */     int i = j(paramaab.h(paramInt1, paramInt2, paramInt3));
/* 234 */     if (i == 1) {
/* 235 */       paramaab.g(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 236 */       paramaab.c(paramInt1 + 1, paramInt2, paramInt3, this.cz, 4);
/*     */     } 
/* 238 */     if (i == 3) {
/* 239 */       paramaab.g(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 240 */       paramaab.c(paramInt1 - 1, paramInt2, paramInt3, this.cz, 5);
/*     */     } 
/* 242 */     if (i == 2) {
/* 243 */       paramaab.g(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/* 244 */       paramaab.c(paramInt1, paramInt2, paramInt3 + 1, this.cz, 2);
/*     */     } 
/* 246 */     if (i == 0) {
/* 247 */       paramaab.g(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 248 */       paramaab.c(paramInt1, paramInt2, paramInt3 - 1, this.cz, 3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void g(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 254 */     if (this.a) {
/* 255 */       paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 256 */       paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 257 */       paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/* 258 */       paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 259 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/* 260 */       paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*     */     } 
/* 262 */     super.g(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/* 267 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean e(int paramInt) {
/* 277 */     apa apa = apa.r[paramInt];
/* 278 */     return (apa != null && apa.f());
/*     */   }
/*     */   
/*     */   protected int d(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 282 */     return 15;
/*     */   }
/*     */   
/*     */   public static boolean f(int paramInt) {
/* 286 */     return (apa.bl.g(paramInt) || apa.cp.g(paramInt));
/*     */   }
/*     */   
/*     */   public boolean g(int paramInt) {
/* 290 */     return (paramInt == (i()).cz || paramInt == (j()).cz);
/*     */   }
/*     */   
/*     */   public boolean h(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 294 */     int i = j(paramInt4);
/* 295 */     if (f(paramaab.a(paramInt1 - r.a[i], paramInt2, paramInt3 - r.b[i]))) {
/* 296 */       int j = paramaab.h(paramInt1 - r.a[i], paramInt2, paramInt3 - r.b[i]);
/* 297 */       int k = j(j);
/* 298 */       return (k != i);
/*     */     } 
/* 300 */     return false;
/*     */   }
/*     */   
/*     */   protected int h(int paramInt) {
/* 304 */     return i_(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract int i_(int paramInt);
/*     */   
/*     */   protected abstract aly i();
/*     */   
/*     */   protected abstract aly j();
/*     */   
/*     */   public boolean i(int paramInt) {
/* 315 */     return g(paramInt);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aly.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */