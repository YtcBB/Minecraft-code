/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ahk
/*     */   extends ahp
/*     */ {
/* 734 */   private int a = -1;
/*     */   
/*     */   public ahk(ahm paramahm, int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 737 */     super(paramahm, paramInt1);
/*     */     
/* 739 */     this.f = paramInt2;
/* 740 */     this.e = paramaek;
/*     */   }
/*     */ 
/*     */   
/*     */   public static ahk a(ahm paramahm, List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 745 */     aek aek = aek.a(paramInt1, paramInt2, paramInt3, 0, 0, 0, 5, 12, 9, paramInt4);
/*     */     
/* 747 */     if (!a(aek) || agw.a(paramList, aek) != null) {
/* 748 */       return null;
/*     */     }
/*     */     
/* 751 */     return new ahk(paramahm, paramInt5, paramRandom, aek, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 757 */     if (this.a < 0) {
/* 758 */       this.a = b(paramaab, paramaek);
/* 759 */       if (this.a < 0) {
/* 760 */         return true;
/*     */       }
/* 762 */       this.e.a(0, this.a - this.e.e + 12 - 1, 0);
/*     */     } 
/*     */ 
/*     */     
/* 766 */     a(paramaab, paramaek, 1, 1, 1, 3, 3, 7, 0, 0, false);
/* 767 */     a(paramaab, paramaek, 1, 5, 1, 3, 9, 3, 0, 0, false);
/*     */ 
/*     */     
/* 770 */     a(paramaab, paramaek, 1, 0, 0, 3, 0, 8, apa.A.cz, apa.A.cz, false);
/*     */ 
/*     */     
/* 773 */     a(paramaab, paramaek, 1, 1, 0, 3, 10, 0, apa.A.cz, apa.A.cz, false);
/*     */     
/* 775 */     a(paramaab, paramaek, 0, 1, 1, 0, 10, 3, apa.A.cz, apa.A.cz, false);
/*     */     
/* 777 */     a(paramaab, paramaek, 4, 1, 1, 4, 10, 3, apa.A.cz, apa.A.cz, false);
/*     */     
/* 779 */     a(paramaab, paramaek, 0, 0, 4, 0, 4, 7, apa.A.cz, apa.A.cz, false);
/*     */     
/* 781 */     a(paramaab, paramaek, 4, 0, 4, 4, 4, 7, apa.A.cz, apa.A.cz, false);
/*     */     
/* 783 */     a(paramaab, paramaek, 1, 1, 8, 3, 4, 8, apa.A.cz, apa.A.cz, false);
/*     */     
/* 785 */     a(paramaab, paramaek, 1, 5, 4, 3, 10, 4, apa.A.cz, apa.A.cz, false);
/*     */ 
/*     */     
/* 788 */     a(paramaab, paramaek, 1, 5, 5, 3, 5, 7, apa.A.cz, apa.A.cz, false);
/*     */     
/* 790 */     a(paramaab, paramaek, 0, 9, 0, 4, 9, 4, apa.A.cz, apa.A.cz, false);
/*     */     
/* 792 */     a(paramaab, paramaek, 0, 4, 0, 4, 4, 4, apa.A.cz, apa.A.cz, false);
/* 793 */     a(paramaab, apa.A.cz, 0, 0, 11, 2, paramaek);
/* 794 */     a(paramaab, apa.A.cz, 0, 4, 11, 2, paramaek);
/* 795 */     a(paramaab, apa.A.cz, 0, 2, 11, 0, paramaek);
/* 796 */     a(paramaab, apa.A.cz, 0, 2, 11, 4, paramaek);
/*     */ 
/*     */     
/* 799 */     a(paramaab, apa.A.cz, 0, 1, 1, 6, paramaek);
/* 800 */     a(paramaab, apa.A.cz, 0, 1, 1, 7, paramaek);
/* 801 */     a(paramaab, apa.A.cz, 0, 2, 1, 7, paramaek);
/* 802 */     a(paramaab, apa.A.cz, 0, 3, 1, 6, paramaek);
/* 803 */     a(paramaab, apa.A.cz, 0, 3, 1, 7, paramaek);
/* 804 */     a(paramaab, apa.aL.cz, c(apa.aL.cz, 3), 1, 1, 5, paramaek);
/* 805 */     a(paramaab, apa.aL.cz, c(apa.aL.cz, 3), 2, 1, 6, paramaek);
/* 806 */     a(paramaab, apa.aL.cz, c(apa.aL.cz, 3), 3, 1, 5, paramaek);
/* 807 */     a(paramaab, apa.aL.cz, c(apa.aL.cz, 1), 1, 2, 7, paramaek);
/* 808 */     a(paramaab, apa.aL.cz, c(apa.aL.cz, 0), 3, 2, 7, paramaek);
/*     */ 
/*     */     
/* 811 */     a(paramaab, apa.bu.cz, 0, 0, 2, 2, paramaek);
/* 812 */     a(paramaab, apa.bu.cz, 0, 0, 3, 2, paramaek);
/* 813 */     a(paramaab, apa.bu.cz, 0, 4, 2, 2, paramaek);
/* 814 */     a(paramaab, apa.bu.cz, 0, 4, 3, 2, paramaek);
/* 815 */     a(paramaab, apa.bu.cz, 0, 0, 6, 2, paramaek);
/* 816 */     a(paramaab, apa.bu.cz, 0, 0, 7, 2, paramaek);
/* 817 */     a(paramaab, apa.bu.cz, 0, 4, 6, 2, paramaek);
/* 818 */     a(paramaab, apa.bu.cz, 0, 4, 7, 2, paramaek);
/* 819 */     a(paramaab, apa.bu.cz, 0, 2, 6, 0, paramaek);
/* 820 */     a(paramaab, apa.bu.cz, 0, 2, 7, 0, paramaek);
/* 821 */     a(paramaab, apa.bu.cz, 0, 2, 6, 4, paramaek);
/* 822 */     a(paramaab, apa.bu.cz, 0, 2, 7, 4, paramaek);
/* 823 */     a(paramaab, apa.bu.cz, 0, 0, 3, 6, paramaek);
/* 824 */     a(paramaab, apa.bu.cz, 0, 4, 3, 6, paramaek);
/* 825 */     a(paramaab, apa.bu.cz, 0, 2, 3, 8, paramaek);
/*     */ 
/*     */     
/* 828 */     a(paramaab, apa.au.cz, 0, 2, 4, 7, paramaek);
/* 829 */     a(paramaab, apa.au.cz, 0, 1, 4, 6, paramaek);
/* 830 */     a(paramaab, apa.au.cz, 0, 3, 4, 6, paramaek);
/* 831 */     a(paramaab, apa.au.cz, 0, 2, 4, 5, paramaek);
/*     */ 
/*     */     
/* 834 */     int i = c(apa.aJ.cz, 4); byte b;
/* 835 */     for (b = 1; b <= 9; b++) {
/* 836 */       a(paramaab, apa.aJ.cz, i, 3, b, 3, paramaek);
/*     */     }
/*     */ 
/*     */     
/* 840 */     a(paramaab, 0, 0, 2, 1, 0, paramaek);
/* 841 */     a(paramaab, 0, 0, 2, 2, 0, paramaek);
/* 842 */     a(paramaab, paramaek, paramRandom, 2, 1, 0, c(apa.aI.cz, 1));
/* 843 */     if (a(paramaab, 2, 0, -1, paramaek) == 0 && a(paramaab, 2, -1, -1, paramaek) != 0) {
/* 844 */       a(paramaab, apa.aL.cz, c(apa.aL.cz, 3), 2, 0, -1, paramaek);
/*     */     }
/*     */     
/* 847 */     for (b = 0; b < 9; b++) {
/* 848 */       for (byte b1 = 0; b1 < 5; b1++) {
/* 849 */         b(paramaab, b1, 12, b, paramaek);
/* 850 */         b(paramaab, apa.A.cz, 0, b1, -1, b, paramaek);
/*     */       } 
/*     */     } 
/*     */     
/* 854 */     a(paramaab, paramaek, 2, 1, 2, 1);
/*     */     
/* 856 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int b(int paramInt) {
/* 861 */     return 2;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ahk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */