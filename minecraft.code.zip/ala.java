/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ala
/*     */   extends apa
/*     */ {
/*     */   private String a;
/*     */   
/*     */   protected ala(int paramInt, String paramString, aif paramaif) {
/*  18 */     super(paramInt, paramaif);
/*  19 */     this.a = paramString;
/*  20 */     a(ve.d);
/*  21 */     b(true);
/*  22 */     b_(d(15));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  27 */     b_(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   protected void b_(int paramInt) {
/*  31 */     boolean bool = (c(paramInt) > 0) ? true : false;
/*  32 */     float f = 0.0625F;
/*     */     
/*  34 */     if (bool) {
/*  35 */       a(f, 0.0F, f, 1.0F - f, 0.03125F, 1.0F - f);
/*     */     } else {
/*  37 */       a(f, 0.0F, f, 1.0F - f, 0.0625F, 1.0F - f);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  43 */     return 20;
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  48 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  53 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  67 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  72 */     return (paramaab.w(paramInt1, paramInt2 - 1, paramInt3) || amk.l_(paramaab.a(paramInt1, paramInt2 - 1, paramInt3)));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  77 */     boolean bool = false;
/*     */     
/*  79 */     if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3) && !amk.l_(paramaab.a(paramInt1, paramInt2 - 1, paramInt3))) bool = true;
/*     */     
/*  81 */     if (bool) {
/*  82 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/*  83 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  89 */     if (paramaab.I)
/*  90 */       return;  int i = c(paramaab.h(paramInt1, paramInt2, paramInt3));
/*  91 */     if (i > 0) b(paramaab, paramInt1, paramInt2, paramInt3, i);
/*     */   
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/*  96 */     if (paramaab.I)
/*  97 */       return;  int i = c(paramaab.h(paramInt1, paramInt2, paramInt3));
/*  98 */     if (i == 0) b(paramaab, paramInt1, paramInt2, paramInt3, i); 
/*     */   }
/*     */   
/*     */   protected void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 102 */     int i = e(paramaab, paramInt1, paramInt2, paramInt3);
/* 103 */     boolean bool1 = (paramInt4 > 0) ? true : false;
/* 104 */     boolean bool2 = (i > 0) ? true : false;
/*     */     
/* 106 */     if (paramInt4 != i) {
/* 107 */       paramaab.b(paramInt1, paramInt2, paramInt3, d(i), 2);
/* 108 */       b_(paramaab, paramInt1, paramInt2, paramInt3);
/* 109 */       paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/* 112 */     if (!bool2 && bool1) {
/* 113 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.1D, paramInt3 + 0.5D, "random.click", 0.3F, 0.5F);
/* 114 */     } else if (bool2 && !bool1) {
/* 115 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.1D, paramInt3 + 0.5D, "random.click", 0.3F, 0.6F);
/*     */     } 
/*     */     
/* 118 */     if (bool2) {
/* 119 */       paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */     }
/*     */   }
/*     */   
/*     */   protected aqx a(int paramInt1, int paramInt2, int paramInt3) {
/* 124 */     float f = 0.125F;
/* 125 */     return aqx.a().a((paramInt1 + f), paramInt2, (paramInt3 + f), ((paramInt1 + 1) - f), paramInt2 + 0.25D, ((paramInt3 + 1) - f));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 130 */     if (c(paramInt5) > 0) {
/* 131 */       b_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */     
/* 134 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */   
/*     */   protected void b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 138 */     paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/* 139 */     paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 144 */     return c(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 149 */     if (paramInt4 == 1) {
/* 150 */       return c(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */     }
/* 152 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean f() {
/* 158 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/* 163 */     float f1 = 0.5F;
/* 164 */     float f2 = 0.125F;
/* 165 */     float f3 = 0.5F;
/* 166 */     a(0.5F - f1, 0.5F - f2, 0.5F - f3, 0.5F + f1, 0.5F + f2, 0.5F + f3);
/*     */   }
/*     */ 
/*     */   
/*     */   public int h() {
/* 171 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected abstract int e(aab paramaab, int paramInt1, int paramInt2, int paramInt3);
/*     */   
/*     */   protected abstract int c(int paramInt);
/*     */   
/*     */   protected abstract int d(int paramInt);
/*     */   
/*     */   public void a(ly paramly) {
/* 182 */     this.cQ = paramly.a(this.a);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ala.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */