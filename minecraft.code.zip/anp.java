/*     */ import java.util.ArrayList;
/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class anp
/*     */   extends aph
/*     */ {
/*     */   private boolean a = false;
/*  27 */   private static Map b = new HashMap<Object, Object>();
/*     */   
/*     */   private boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/*  30 */     if (!b.containsKey(paramaab)) b.put(paramaab, new ArrayList());
/*     */     
/*  32 */     List<anq> list = (List)b.get(paramaab);
/*  33 */     if (paramBoolean) list.add(new anq(paramInt1, paramInt2, paramInt3, paramaab.H())); 
/*  34 */     byte b1 = 0;
/*  35 */     for (byte b2 = 0; b2 < list.size(); b2++) {
/*  36 */       anq anq = list.get(b2);
/*     */       
/*  38 */       b1++;
/*  39 */       if (anq.a == paramInt1 && anq.b == paramInt2 && anq.c == paramInt3 && b1 >= 8) {
/*  40 */         return true;
/*     */       }
/*     */     } 
/*     */     
/*  44 */     return false;
/*     */   }
/*     */   
/*     */   protected anp(int paramInt, boolean paramBoolean) {
/*  48 */     super(paramInt);
/*  49 */     this.a = paramBoolean;
/*  50 */     b(true);
/*  51 */     a((ve)null);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  56 */     return 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  61 */     if (paramaab.h(paramInt1, paramInt2, paramInt3) == 0) super.a(paramaab, paramInt1, paramInt2, paramInt3); 
/*  62 */     if (this.a) {
/*  63 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/*  64 */       paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*  65 */       paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/*  66 */       paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/*  67 */       paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/*  68 */       paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  74 */     if (this.a) {
/*  75 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/*  76 */       paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*  77 */       paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/*  78 */       paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/*  79 */       paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/*  80 */       paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  86 */     if (!this.a) return 0;
/*     */     
/*  88 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  90 */     if (i == 5 && paramInt4 == 1) return 0; 
/*  91 */     if (i == 3 && paramInt4 == 3) return 0; 
/*  92 */     if (i == 4 && paramInt4 == 2) return 0; 
/*  93 */     if (i == 1 && paramInt4 == 5) return 0; 
/*  94 */     if (i == 2 && paramInt4 == 4) return 0;
/*     */     
/*  96 */     return 15;
/*     */   }
/*     */   
/*     */   private boolean m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 100 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/* 102 */     if (i == 5 && paramaab.k(paramInt1, paramInt2 - 1, paramInt3, 0)) return true; 
/* 103 */     if (i == 3 && paramaab.k(paramInt1, paramInt2, paramInt3 - 1, 2)) return true; 
/* 104 */     if (i == 4 && paramaab.k(paramInt1, paramInt2, paramInt3 + 1, 3)) return true; 
/* 105 */     if (i == 1 && paramaab.k(paramInt1 - 1, paramInt2, paramInt3, 4)) return true; 
/* 106 */     if (i == 2 && paramaab.k(paramInt1 + 1, paramInt2, paramInt3, 5)) return true; 
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 112 */     boolean bool = m(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     
/* 114 */     List list = (List)b.get(paramaab);
/* 115 */     while (list != null && !list.isEmpty() && paramaab.H() - ((anq)list.get(0)).d > 60L) {
/* 116 */       list.remove(0);
/*     */     }
/*     */     
/* 119 */     if (this.a) {
/* 120 */       if (bool) {
/* 121 */         paramaab.f(paramInt1, paramInt2, paramInt3, apa.aT.cz, paramaab.h(paramInt1, paramInt2, paramInt3), 3);
/*     */         
/* 123 */         if (a(paramaab, paramInt1, paramInt2, paramInt3, true)) {
/* 124 */           paramaab.a((paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), "random.fizz", 0.5F, 2.6F + (paramaab.s.nextFloat() - paramaab.s.nextFloat()) * 0.8F);
/* 125 */           for (byte b = 0; b < 5; b++) {
/* 126 */             double d1 = paramInt1 + paramRandom.nextDouble() * 0.6D + 0.2D;
/* 127 */             double d2 = paramInt2 + paramRandom.nextDouble() * 0.6D + 0.2D;
/* 128 */             double d3 = paramInt3 + paramRandom.nextDouble() * 0.6D + 0.2D;
/*     */             
/* 130 */             paramaab.a("smoke", d1, d2, d3, 0.0D, 0.0D, 0.0D);
/*     */           }
/*     */         
/*     */         } 
/*     */       } 
/* 135 */     } else if (!bool && 
/* 136 */       !a(paramaab, paramInt1, paramInt2, paramInt3, false)) {
/* 137 */       paramaab.f(paramInt1, paramInt2, paramInt3, apa.aU.cz, paramaab.h(paramInt1, paramInt2, paramInt3), 3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 145 */     if (d(paramaab, paramInt1, paramInt2, paramInt3, paramInt4)) {
/*     */       return;
/*     */     }
/*     */     
/* 149 */     boolean bool = m(paramaab, paramInt1, paramInt2, paramInt3);
/* 150 */     if ((this.a && bool) || (!this.a && !bool)) {
/* 151 */       paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 157 */     if (paramInt4 == 0) {
/* 158 */       return b(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     }
/* 160 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 165 */     return apa.aU.cz;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f() {
/* 170 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 175 */     if (!this.a)
/* 176 */       return;  int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 177 */     double d1 = (paramInt1 + 0.5F) + (paramRandom.nextFloat() - 0.5F) * 0.2D;
/* 178 */     double d2 = (paramInt2 + 0.7F) + (paramRandom.nextFloat() - 0.5F) * 0.2D;
/* 179 */     double d3 = (paramInt3 + 0.5F) + (paramRandom.nextFloat() - 0.5F) * 0.2D;
/* 180 */     double d4 = 0.2199999988079071D;
/* 181 */     double d5 = 0.27000001072883606D;
/* 182 */     if (i == 1) {
/* 183 */       paramaab.a("reddust", d1 - d5, d2 + d4, d3, 0.0D, 0.0D, 0.0D);
/* 184 */     } else if (i == 2) {
/* 185 */       paramaab.a("reddust", d1 + d5, d2 + d4, d3, 0.0D, 0.0D, 0.0D);
/* 186 */     } else if (i == 3) {
/* 187 */       paramaab.a("reddust", d1, d2 + d4, d3 - d5, 0.0D, 0.0D, 0.0D);
/* 188 */     } else if (i == 4) {
/* 189 */       paramaab.a("reddust", d1, d2 + d4, d3 + d5, 0.0D, 0.0D, 0.0D);
/*     */     } else {
/* 191 */       paramaab.a("reddust", d1, d2, d3, 0.0D, 0.0D, 0.0D);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 197 */     return apa.aU.cz;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean i(int paramInt) {
/* 213 */     return (paramInt == apa.aT.cz || paramInt == apa.aU.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 218 */     if (this.a) {
/* 219 */       this.cQ = paramly.a("redtorch_lit");
/*     */     } else {
/* 221 */       this.cQ = paramly.a("redtorch");
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */