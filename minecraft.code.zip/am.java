/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class am
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 10 */     return "kill";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 15 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 20 */     jc jc = c(paramab);
/*    */     
/* 22 */     jc.a(mg.i, 1000);
/*    */     
/* 24 */     paramab.a("Ouch. That looks like it hurt.");
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\am.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */