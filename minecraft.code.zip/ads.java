/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ads
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 11 */     if (!paramaab.c(paramInt1, paramInt2, paramInt3)) return false; 
/* 12 */     if (paramaab.a(paramInt1, paramInt2 + 1, paramInt3) != apa.bf.cz) return false; 
/* 13 */     paramaab.f(paramInt1, paramInt2, paramInt3, apa.bh.cz, 0, 2);
/*    */     
/* 15 */     for (byte b = 0; b < 'ל'; b++) {
/* 16 */       int i = paramInt1 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 17 */       int j = paramInt2 - paramRandom.nextInt(12);
/* 18 */       int k = paramInt3 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 19 */       if (paramaab.a(i, j, k) == 0) {
/*    */         
/* 21 */         byte b1 = 0;
/* 22 */         for (byte b2 = 0; b2 < 6; b2++) {
/* 23 */           int m = 0;
/* 24 */           if (b2 == 0) m = paramaab.a(i - 1, j, k); 
/* 25 */           if (b2 == 1) m = paramaab.a(i + 1, j, k); 
/* 26 */           if (b2 == 2) m = paramaab.a(i, j - 1, k); 
/* 27 */           if (b2 == 3) m = paramaab.a(i, j + 1, k); 
/* 28 */           if (b2 == 4) m = paramaab.a(i, j, k - 1); 
/* 29 */           if (b2 == 5) m = paramaab.a(i, j, k + 1);
/*    */           
/* 31 */           if (m == apa.bh.cz) b1++;
/*    */         
/*    */         } 
/* 34 */         if (b1 == 1) paramaab.f(i, j, k, apa.bh.cz, 0, 2); 
/*    */       } 
/*    */     } 
/* 37 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ads.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */