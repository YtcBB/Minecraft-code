/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ado
/*    */   extends adj
/*    */ {
/*    */   private int a;
/*    */   private boolean b = false;
/*    */   
/*    */   public ado(int paramInt, boolean paramBoolean) {
/* 13 */     this.a = paramInt;
/* 14 */     this.b = paramBoolean;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 19 */     if (paramaab.a(paramInt1, paramInt2 + 1, paramInt3) != apa.bf.cz) return false; 
/* 20 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) != 0 && paramaab.a(paramInt1, paramInt2, paramInt3) != apa.bf.cz) return false;
/*    */     
/* 22 */     byte b1 = 0;
/* 23 */     if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == apa.bf.cz) b1++; 
/* 24 */     if (paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == apa.bf.cz) b1++; 
/* 25 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == apa.bf.cz) b1++; 
/* 26 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == apa.bf.cz) b1++; 
/* 27 */     if (paramaab.a(paramInt1, paramInt2 - 1, paramInt3) == apa.bf.cz) b1++;
/*    */     
/* 29 */     byte b2 = 0;
/* 30 */     if (paramaab.c(paramInt1 - 1, paramInt2, paramInt3)) b2++; 
/* 31 */     if (paramaab.c(paramInt1 + 1, paramInt2, paramInt3)) b2++; 
/* 32 */     if (paramaab.c(paramInt1, paramInt2, paramInt3 - 1)) b2++; 
/* 33 */     if (paramaab.c(paramInt1, paramInt2, paramInt3 + 1)) b2++; 
/* 34 */     if (paramaab.c(paramInt1, paramInt2 - 1, paramInt3)) b2++;
/*    */     
/* 36 */     if ((!this.b && b1 == 4 && b2 == 1) || b1 == 5) {
/* 37 */       paramaab.f(paramInt1, paramInt2, paramInt3, this.a, 0, 2);
/* 38 */       paramaab.d = true;
/* 39 */       apa.r[this.a].a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/* 40 */       paramaab.d = false;
/*    */     } 
/*    */     
/* 43 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ado.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */