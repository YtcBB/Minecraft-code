/*     */ import java.awt.Color;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class aav
/*     */ {
/*  16 */   public static final aav[] a = new aav[256];
/*     */   
/*  18 */   public static final aav b = (new abj(0)).b(112).a("Ocean").b(-1.0F, 0.4F);
/*  19 */   public static final aav c = (new abk(1)).b(9286496).a("Plains").a(0.8F, 0.4F);
/*  20 */   public static final aav d = (new abb(2)).b(16421912).a("Desert").m().a(2.0F, 0.0F).b(0.1F, 0.2F);
/*     */   
/*  22 */   public static final aav e = (new abc(3)).b(6316128).a("Extreme Hills").b(0.3F, 1.5F).a(0.2F, 0.3F);
/*  23 */   public static final aav f = (new abe(4)).b(353825).a("Forest").a(5159473).a(0.7F, 0.8F);
/*  24 */   public static final aav g = (new abo(5)).b(747097).a("Taiga").a(5159473).b().a(0.05F, 0.8F).b(0.1F, 0.4F);
/*     */   
/*  26 */   public static final aav h = (new abn(6)).b(522674).a("Swampland").a(9154376).b(-0.2F, 0.1F).a(0.8F, 0.9F);
/*  27 */   public static final aav i = (new abm(7)).b(255).a("River").b(-0.5F, 0.0F);
/*     */   
/*  29 */   public static final aav j = (new abf(8)).b(16711680).a("Hell").m().a(2.0F, 0.0F);
/*  30 */   public static final aav k = (new abp(9)).b(8421631).a("Sky").m();
/*     */   
/*  32 */   public static final aav l = (new abj(10)).b(9474208).a("FrozenOcean").b().b(-1.0F, 0.5F).a(0.0F, 0.5F);
/*  33 */   public static final aav m = (new abm(11)).b(10526975).a("FrozenRiver").b().b(-0.5F, 0.0F).a(0.0F, 0.5F);
/*  34 */   public static final aav n = (new abg(12)).b(16777215).a("Ice Plains").b().a(0.0F, 0.5F);
/*  35 */   public static final aav o = (new abg(13)).b(10526880).a("Ice Mountains").b().b(0.3F, 1.3F).a(0.0F, 0.5F);
/*     */   
/*  37 */   public static final aav p = (new abi(14)).b(16711935).a("MushroomIsland").a(0.9F, 1.0F).b(0.2F, 1.0F);
/*  38 */   public static final aav q = (new abi(15)).b(10486015).a("MushroomIslandShore").a(0.9F, 1.0F).b(-1.0F, 0.1F);
/*     */   
/*  40 */   public static final aav r = (new aau(16)).b(16440917).a("Beach").a(0.8F, 0.4F).b(0.0F, 0.1F);
/*  41 */   public static final aav s = (new abb(17)).b(13786898).a("DesertHills").m().a(2.0F, 0.0F).b(0.3F, 0.8F);
/*  42 */   public static final aav t = (new abe(18)).b(2250012).a("ForestHills").a(5159473).a(0.7F, 0.8F).b(0.3F, 0.7F);
/*  43 */   public static final aav u = (new abo(19)).b(1456435).a("TaigaHills").b().a(5159473).a(0.05F, 0.8F).b(0.3F, 0.8F);
/*     */   
/*  45 */   public static final aav v = (new abc(20)).b(7501978).a("Extreme Hills Edge").b(0.2F, 0.8F).a(0.2F, 0.3F);
/*     */   
/*  47 */   public static final aav w = (new abh(21)).b(5470985).a("Jungle").a(5470985).a(1.2F, 0.9F).b(0.2F, 0.4F);
/*  48 */   public static final aav x = (new abh(22)).b(2900485).a("JungleHills").a(5470985).a(1.2F, 0.9F).b(1.8F, 0.5F);
/*     */   
/*     */   public String y;
/*     */   public int z;
/*  52 */   public byte A = (byte)apa.y.cz;
/*  53 */   public byte B = (byte)apa.z.cz;
/*  54 */   public int C = 5169201;
/*  55 */   public float D = 0.1F;
/*  56 */   public float E = 0.3F;
/*  57 */   public float F = 0.5F;
/*  58 */   public float G = 0.5F;
/*  59 */   public int H = 16777215;
/*     */   
/*     */   public aaz I;
/*     */   
/*  63 */   protected List J = new ArrayList();
/*  64 */   protected List K = new ArrayList();
/*  65 */   protected List L = new ArrayList();
/*  66 */   protected List M = new ArrayList();
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean S;
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean T = true;
/*     */ 
/*     */ 
/*     */   
/*     */   public final int N;
/*     */ 
/*     */ 
/*     */   
/*     */   protected aef O;
/*     */ 
/*     */ 
/*     */   
/*     */   protected adb P;
/*     */ 
/*     */   
/*     */   protected adc Q;
/*     */ 
/*     */   
/*     */   protected aed R;
/*     */ 
/*     */ 
/*     */   
/*     */   protected aaz a() {
/*  97 */     return new aaz(this);
/*     */   }
/*     */   
/*     */   private aav a(float paramFloat1, float paramFloat2) {
/* 101 */     if (paramFloat1 > 0.1F && paramFloat1 < 0.2F) throw new IllegalArgumentException("Please avoid temperatures in the range 0.1 - 0.2 because of snow");
/*     */     
/* 103 */     this.F = paramFloat1;
/* 104 */     this.G = paramFloat2;
/* 105 */     return this;
/*     */   }
/*     */   
/*     */   private aav b(float paramFloat1, float paramFloat2) {
/* 109 */     this.D = paramFloat1;
/* 110 */     this.E = paramFloat2;
/* 111 */     return this;
/*     */   }
/*     */   
/*     */   private aav m() {
/* 115 */     this.T = false;
/* 116 */     return this;
/*     */   }
/*     */   
/* 119 */   protected aav(int paramInt) { this.O = new aef(false);
/* 120 */     this.P = new adb(false);
/* 121 */     this.Q = new adc(false);
/* 122 */     this.R = new aed(); this.N = paramInt; a[paramInt] = this; this.I = a(); this.K.add(new aaw(qo.class, 12, 4, 4)); this.K.add(new aaw(qn.class, 10, 4, 4)); this.K.add(new aaw(qi.class, 10, 4, 4)); this.K.add(new aaw(qj.class, 8, 4, 4)); this.J.add(new aaw(sh.class, 10, 4, 4)); this.J.add(new aaw(sj.class, 10, 4, 4)); this.J.add(new aaw(sf.class, 10, 4, 4)); this.J.add(new aaw(ru.class, 10, 4, 4)); this.J.add(new aaw(sg.class, 10, 4, 4));
/*     */     this.J.add(new aaw(rv.class, 1, 1, 4));
/*     */     this.L.add(new aaw(qr.class, 10, 4, 4));
/* 125 */     this.M.add(new aaw(qg.class, 10, 8, 8)); } public adj a(Random paramRandom) { if (paramRandom.nextInt(10) == 0) {
/* 126 */       return this.P;
/*     */     }
/* 128 */     return this.O; }
/*     */ 
/*     */   
/*     */   public adj b(Random paramRandom) {
/* 132 */     return new aee(apa.ab.cz, 1);
/*     */   }
/*     */   
/*     */   protected aav b() {
/* 136 */     this.S = true;
/* 137 */     return this;
/*     */   }
/*     */   
/*     */   protected aav a(String paramString) {
/* 141 */     this.y = paramString;
/* 142 */     return this;
/*     */   }
/*     */   
/*     */   protected aav a(int paramInt) {
/* 146 */     this.C = paramInt;
/* 147 */     return this;
/*     */   }
/*     */   
/*     */   protected aav b(int paramInt) {
/* 151 */     this.z = paramInt;
/* 152 */     return this;
/*     */   }
/*     */   
/*     */   public int a(float paramFloat) {
/* 156 */     paramFloat /= 3.0F;
/* 157 */     if (paramFloat < -1.0F) paramFloat = -1.0F; 
/* 158 */     if (paramFloat > 1.0F) paramFloat = 1.0F; 
/* 159 */     return Color.getHSBColor(0.62222224F - paramFloat * 0.05F, 0.5F + paramFloat * 0.1F, 1.0F).getRGB();
/*     */   }
/*     */   
/*     */   public List a(nn paramnn) {
/* 163 */     if (paramnn == nn.a) return this.J; 
/* 164 */     if (paramnn == nn.b) return this.K; 
/* 165 */     if (paramnn == nn.d) return this.L; 
/* 166 */     if (paramnn == nn.c) return this.M; 
/* 167 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/* 184 */     return this.S;
/*     */   }
/*     */   
/*     */   public boolean d() {
/* 188 */     if (this.S) return false; 
/* 189 */     return this.T;
/*     */   }
/*     */   
/*     */   public boolean e() {
/* 193 */     return (this.G > 0.85F);
/*     */   }
/*     */   
/*     */   public float f() {
/* 197 */     return 0.1F;
/*     */   }
/*     */   
/*     */   public final int g() {
/* 201 */     return (int)(this.G * 65536.0F);
/*     */   }
/*     */   
/*     */   public final int h() {
/* 205 */     return (int)(this.F * 65536.0F);
/*     */   }
/*     */   
/*     */   public final float i() {
/* 209 */     return this.G;
/*     */   }
/*     */   
/*     */   public final float j() {
/* 213 */     return this.F;
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 217 */     this.I.a(paramaab, paramRandom, paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public int k() {
/* 221 */     double d1 = kx.a(j(), 0.0F, 1.0F);
/* 222 */     double d2 = kx.a(i(), 0.0F, 1.0F);
/*     */     
/* 224 */     return aaa.a(d1, d2);
/*     */   }
/*     */   
/*     */   public int l() {
/* 228 */     double d1 = kx.a(j(), 0.0F, 1.0F);
/* 229 */     double d2 = kx.a(i(), 0.0F, 1.0F);
/*     */     
/* 231 */     return zx.a(d1, d2);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aav.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */