/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aev
/*     */   extends afh
/*     */ {
/*     */   public aev(int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 427 */     super(paramInt1);
/*     */     
/* 429 */     this.f = paramInt2;
/* 430 */     this.e = paramaek;
/*     */   }
/*     */ 
/*     */   
/*     */   protected aev(Random paramRandom, int paramInt1, int paramInt2) {
/* 435 */     super(0);
/*     */     
/* 437 */     this.f = paramRandom.nextInt(4);
/*     */     
/* 439 */     switch (this.f) {
/*     */       case 0:
/*     */       case 2:
/* 442 */         this.e = new aek(paramInt1, 64, paramInt2, paramInt1 + 19 - 1, 73, paramInt2 + 19 - 1);
/*     */         return;
/*     */     } 
/* 445 */     this.e = new aek(paramInt1, 64, paramInt2, paramInt1 + 19 - 1, 73, paramInt2 + 19 - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/* 453 */     a((afl)paramagw, paramList, paramRandom, 8, 3, false);
/* 454 */     b((afl)paramagw, paramList, paramRandom, 3, 8, false);
/* 455 */     c((afl)paramagw, paramList, paramRandom, 3, 8, false);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static aev a(List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 461 */     aek aek = aek.a(paramInt1, paramInt2, paramInt3, -8, -3, 0, 19, 10, 19, paramInt4);
/*     */     
/* 463 */     if (!a(aek) || agw.a(paramList, aek) != null) {
/* 464 */       return null;
/*     */     }
/*     */     
/* 467 */     return new aev(paramInt5, paramRandom, aek, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 474 */     a(paramaab, paramaek, 7, 3, 0, 11, 4, 18, apa.bE.cz, apa.bE.cz, false);
/* 475 */     a(paramaab, paramaek, 0, 3, 7, 18, 4, 11, apa.bE.cz, apa.bE.cz, false);
/*     */     
/* 477 */     a(paramaab, paramaek, 8, 5, 0, 10, 7, 18, 0, 0, false);
/* 478 */     a(paramaab, paramaek, 0, 5, 8, 18, 7, 10, 0, 0, false);
/*     */     
/* 480 */     a(paramaab, paramaek, 7, 5, 0, 7, 5, 7, apa.bE.cz, apa.bE.cz, false);
/* 481 */     a(paramaab, paramaek, 7, 5, 11, 7, 5, 18, apa.bE.cz, apa.bE.cz, false);
/* 482 */     a(paramaab, paramaek, 11, 5, 0, 11, 5, 7, apa.bE.cz, apa.bE.cz, false);
/* 483 */     a(paramaab, paramaek, 11, 5, 11, 11, 5, 18, apa.bE.cz, apa.bE.cz, false);
/* 484 */     a(paramaab, paramaek, 0, 5, 7, 7, 5, 7, apa.bE.cz, apa.bE.cz, false);
/* 485 */     a(paramaab, paramaek, 11, 5, 7, 18, 5, 7, apa.bE.cz, apa.bE.cz, false);
/* 486 */     a(paramaab, paramaek, 0, 5, 11, 7, 5, 11, apa.bE.cz, apa.bE.cz, false);
/* 487 */     a(paramaab, paramaek, 11, 5, 11, 18, 5, 11, apa.bE.cz, apa.bE.cz, false);
/*     */ 
/*     */     
/* 490 */     a(paramaab, paramaek, 7, 2, 0, 11, 2, 5, apa.bE.cz, apa.bE.cz, false);
/* 491 */     a(paramaab, paramaek, 7, 2, 13, 11, 2, 18, apa.bE.cz, apa.bE.cz, false);
/* 492 */     a(paramaab, paramaek, 7, 0, 0, 11, 1, 3, apa.bE.cz, apa.bE.cz, false);
/* 493 */     a(paramaab, paramaek, 7, 0, 15, 11, 1, 18, apa.bE.cz, apa.bE.cz, false); byte b;
/* 494 */     for (b = 7; b <= 11; b++) {
/* 495 */       for (byte b1 = 0; b1 <= 2; b1++) {
/* 496 */         b(paramaab, apa.bE.cz, 0, b, -1, b1, paramaek);
/* 497 */         b(paramaab, apa.bE.cz, 0, b, -1, 18 - b1, paramaek);
/*     */       } 
/*     */     } 
/*     */     
/* 501 */     a(paramaab, paramaek, 0, 2, 7, 5, 2, 11, apa.bE.cz, apa.bE.cz, false);
/* 502 */     a(paramaab, paramaek, 13, 2, 7, 18, 2, 11, apa.bE.cz, apa.bE.cz, false);
/* 503 */     a(paramaab, paramaek, 0, 0, 7, 3, 1, 11, apa.bE.cz, apa.bE.cz, false);
/* 504 */     a(paramaab, paramaek, 15, 0, 7, 18, 1, 11, apa.bE.cz, apa.bE.cz, false);
/* 505 */     for (b = 0; b <= 2; b++) {
/* 506 */       for (byte b1 = 7; b1 <= 11; b1++) {
/* 507 */         b(paramaab, apa.bE.cz, 0, b, -1, b1, paramaek);
/* 508 */         b(paramaab, apa.bE.cz, 0, 18 - b, -1, b1, paramaek);
/*     */       } 
/*     */     } 
/*     */     
/* 512 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aev.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */