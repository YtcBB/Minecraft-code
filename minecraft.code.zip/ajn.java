/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ajn
/*    */ {
/*    */   public byte a;
/*    */   public byte b;
/*    */   public byte c;
/*    */   public byte d;
/*    */   
/*    */   public ajn(ajl paramajl, byte paramByte1, byte paramByte2, byte paramByte3, byte paramByte4) {
/* 23 */     this.a = paramByte1;
/* 24 */     this.b = paramByte2;
/* 25 */     this.c = paramByte3;
/* 26 */     this.d = paramByte4;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */