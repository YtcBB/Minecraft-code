/*    */ public class aiv
/*    */   extends ait
/*    */ {
/*    */   public aiv(long paramLong, ait paramait) {
/*  5 */     super(paramLong);
/*  6 */     this.a = paramait;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 11 */     int[] arrayOfInt1 = this.a.a(paramInt1, paramInt2, paramInt3, paramInt4);
/*    */     
/* 13 */     int[] arrayOfInt2 = air.a(paramInt3 * paramInt4);
/* 14 */     for (byte b = 0; b < paramInt4; b++) {
/* 15 */       for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 16 */         a((b1 + paramInt1), (b + paramInt2));
/* 17 */         arrayOfInt2[b1 + b * paramInt3] = (arrayOfInt1[b1 + b * paramInt3] > 0) ? (a(2) + 2) : 0;
/*    */       } 
/*    */     } 
/*    */     
/* 21 */     return arrayOfInt2;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aiv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */