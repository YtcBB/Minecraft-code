/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adi
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 12 */     while (paramaab.c(paramInt1, paramInt2, paramInt3) && paramInt2 > 2) {
/* 13 */       paramInt2--;
/*    */     }
/* 15 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3);
/* 16 */     if (i != apa.I.cz) {
/* 17 */       return false;
/*    */     }
/*    */     
/*    */     byte b;
/* 21 */     for (b = -2; b <= 2; b++) {
/* 22 */       for (byte b1 = -2; b1 <= 2; b1++) {
/* 23 */         if (paramaab.c(paramInt1 + b, paramInt2 - 1, paramInt3 + b1) && paramaab.c(paramInt1 + b, paramInt2 - 2, paramInt3 + b1)) {
/* 24 */           return false;
/*    */         }
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 30 */     for (b = -1; b <= 0; b++) {
/* 31 */       for (byte b1 = -2; b1 <= 2; b1++) {
/* 32 */         for (byte b2 = -2; b2 <= 2; b2++) {
/* 33 */           paramaab.f(paramInt1 + b1, paramInt2 + b, paramInt3 + b2, apa.U.cz, 0, 2);
/*    */         }
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 39 */     paramaab.f(paramInt1, paramInt2, paramInt3, apa.E.cz, 0, 2);
/* 40 */     paramaab.f(paramInt1 - 1, paramInt2, paramInt3, apa.E.cz, 0, 2);
/* 41 */     paramaab.f(paramInt1 + 1, paramInt2, paramInt3, apa.E.cz, 0, 2);
/* 42 */     paramaab.f(paramInt1, paramInt2, paramInt3 - 1, apa.E.cz, 0, 2);
/* 43 */     paramaab.f(paramInt1, paramInt2, paramInt3 + 1, apa.E.cz, 0, 2);
/*    */ 
/*    */     
/* 46 */     for (b = -2; b <= 2; b++) {
/* 47 */       for (byte b1 = -2; b1 <= 2; b1++) {
/* 48 */         if (b == -2 || b == 2 || b1 == -2 || b1 == 2) {
/* 49 */           paramaab.f(paramInt1 + b, paramInt2 + 1, paramInt3 + b1, apa.U.cz, 0, 2);
/*    */         }
/*    */       } 
/*    */     } 
/* 53 */     paramaab.f(paramInt1 + 2, paramInt2 + 1, paramInt3, apa.ao.cz, 1, 2);
/* 54 */     paramaab.f(paramInt1 - 2, paramInt2 + 1, paramInt3, apa.ao.cz, 1, 2);
/* 55 */     paramaab.f(paramInt1, paramInt2 + 1, paramInt3 + 2, apa.ao.cz, 1, 2);
/* 56 */     paramaab.f(paramInt1, paramInt2 + 1, paramInt3 - 2, apa.ao.cz, 1, 2);
/*    */ 
/*    */     
/* 59 */     for (b = -1; b <= 1; b++) {
/* 60 */       for (byte b1 = -1; b1 <= 1; b1++) {
/* 61 */         if (b == 0 && b1 == 0) {
/* 62 */           paramaab.f(paramInt1 + b, paramInt2 + 4, paramInt3 + b1, apa.U.cz, 0, 2);
/*    */         } else {
/* 64 */           paramaab.f(paramInt1 + b, paramInt2 + 4, paramInt3 + b1, apa.ao.cz, 1, 2);
/*    */         } 
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 70 */     for (b = 1; b <= 3; b++) {
/* 71 */       paramaab.f(paramInt1 - 1, paramInt2 + b, paramInt3 - 1, apa.U.cz, 0, 2);
/* 72 */       paramaab.f(paramInt1 - 1, paramInt2 + b, paramInt3 + 1, apa.U.cz, 0, 2);
/* 73 */       paramaab.f(paramInt1 + 1, paramInt2 + b, paramInt3 - 1, apa.U.cz, 0, 2);
/* 74 */       paramaab.f(paramInt1 + 1, paramInt2 + b, paramInt3 + 1, apa.U.cz, 0, 2);
/*    */     } 
/*    */     
/* 77 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */