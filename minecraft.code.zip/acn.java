/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class acn
/*     */ {
/*     */   public aab a;
/*     */   public aal b;
/*     */   public String c;
/*     */   public aba d;
/*     */   public boolean e = false;
/*     */   public boolean f = false;
/*  20 */   public float[] g = new float[16];
/*  21 */   public int h = 0;
/*     */   
/*     */   public final void a(aab paramaab) {
/*  24 */     this.a = paramaab;
/*  25 */     this.b = paramaab.M().u();
/*  26 */     this.c = paramaab.M().y();
/*  27 */     b();
/*  28 */     a();
/*     */   }
/*     */   
/*     */   protected void a() {
/*  32 */     float f = 0.0F;
/*  33 */     for (byte b = 0; b <= 15; b++) {
/*  34 */       float f1 = 1.0F - b / 15.0F;
/*  35 */       this.g[b] = (1.0F - f1) / (f1 * 3.0F + 1.0F) * (1.0F - f) + f;
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void b() {
/*  40 */     if (this.a.M().u() == aal.c) {
/*  41 */       aeh aeh = aeh.a(this.a.M().y());
/*  42 */       this.d = new abd(aav.a[aeh.a()], 0.5F, 0.5F);
/*     */     } else {
/*  44 */       this.d = new aba(this.a);
/*     */     } 
/*     */   }
/*     */   
/*     */   public abt c() {
/*  49 */     if (this.b == aal.c)
/*     */     {
/*  51 */       return new act(this.a, this.a.G(), this.a.M().s(), this.c);
/*     */     }
/*  53 */     return new acy(this.a, this.a.G(), this.a.M().s());
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2) {
/*  58 */     int i = this.a.b(paramInt1, paramInt2);
/*     */     
/*  60 */     if (i != apa.y.cz) return false;
/*     */     
/*  62 */     return true;
/*     */   }
/*     */   
/*     */   public float a(long paramLong, float paramFloat) {
/*  66 */     int i = (int)(paramLong % 24000L);
/*  67 */     float f1 = (i + paramFloat) / 24000.0F - 0.25F;
/*  68 */     if (f1 < 0.0F) f1++; 
/*  69 */     if (f1 > 1.0F) f1--; 
/*  70 */     float f2 = f1;
/*  71 */     f1 = 1.0F - (float)((Math.cos(f1 * Math.PI) + 1.0D) / 2.0D);
/*  72 */     f1 = f2 + (f1 - f2) / 3.0F;
/*  73 */     return f1;
/*     */   }
/*     */   
/*     */   public int a(long paramLong) {
/*  77 */     return (int)(paramLong / 24000L) % 8;
/*     */   }
/*     */   
/*     */   public boolean d() {
/*  81 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*  86 */   private float[] i = new float[4];
/*     */ 
/*     */   
/*     */   public float[] a(float paramFloat1, float paramFloat2) {
/*  90 */     float f1 = 0.4F;
/*  91 */     float f2 = kx.b(paramFloat1 * 3.1415927F * 2.0F) - 0.0F;
/*  92 */     float f3 = -0.0F;
/*  93 */     if (f2 >= f3 - f1 && f2 <= f3 + f1) {
/*  94 */       float f4 = (f2 - f3) / f1 * 0.5F + 0.5F;
/*  95 */       float f5 = 1.0F - (1.0F - kx.a(f4 * 3.1415927F)) * 0.99F;
/*  96 */       f5 *= f5;
/*  97 */       this.i[0] = f4 * 0.3F + 0.7F;
/*  98 */       this.i[1] = f4 * f4 * 0.7F + 0.2F;
/*  99 */       this.i[2] = f4 * f4 * 0.0F + 0.2F;
/* 100 */       this.i[3] = f5;
/* 101 */       return this.i;
/*     */     } 
/*     */     
/* 104 */     return null;
/*     */   }
/*     */   
/*     */   public arc b(float paramFloat1, float paramFloat2) {
/* 108 */     float f1 = kx.b(paramFloat1 * 3.1415927F * 2.0F) * 2.0F + 0.5F;
/* 109 */     if (f1 < 0.0F) f1 = 0.0F; 
/* 110 */     if (f1 > 1.0F) f1 = 1.0F;
/*     */     
/* 112 */     float f2 = 0.7529412F;
/* 113 */     float f3 = 0.84705883F;
/* 114 */     float f4 = 1.0F;
/* 115 */     f2 *= f1 * 0.94F + 0.06F;
/* 116 */     f3 *= f1 * 0.94F + 0.06F;
/* 117 */     f4 *= f1 * 0.91F + 0.09F;
/*     */     
/* 119 */     return this.a.U().a(f2, f3, f4);
/*     */   }
/*     */   
/*     */   public boolean e() {
/* 123 */     return true;
/*     */   }
/*     */   
/*     */   public static acn a(int paramInt) {
/* 127 */     if (paramInt == -1) return new aco(); 
/* 128 */     if (paramInt == 0) return new acp(); 
/* 129 */     if (paramInt == 1) return new acq(); 
/* 130 */     return null;
/*     */   }
/*     */   
/*     */   public float f() {
/* 134 */     return 128.0F;
/*     */   }
/*     */   
/*     */   public boolean g() {
/* 138 */     return true;
/*     */   }
/*     */   
/*     */   public t h() {
/* 142 */     return null;
/*     */   }
/*     */   
/*     */   public int i() {
/* 146 */     if (this.b == aal.c) {
/* 147 */       return 4;
/*     */     }
/* 149 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean j() {
/* 153 */     return (this.b != aal.c && !this.f);
/*     */   }
/*     */   
/*     */   public double k() {
/* 157 */     if (this.b == aal.c) {
/* 158 */       return 1.0D;
/*     */     }
/* 160 */     return 0.03125D;
/*     */   }
/*     */   
/*     */   public boolean b(int paramInt1, int paramInt2) {
/* 164 */     return false;
/*     */   }
/*     */   
/*     */   public abstract String l();
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */