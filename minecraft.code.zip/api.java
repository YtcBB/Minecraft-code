/*    */ 
/*    */ 
/*    */ 
/*    */ public class api
/*    */   extends apa
/*    */ {
/*    */   protected boolean d;
/*    */   
/*    */   protected api(int paramInt, aif paramaif, boolean paramBoolean) {
/* 10 */     super(paramInt, paramaif);
/* 11 */     this.d = paramBoolean;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 16 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 21 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/* 22 */     if (!this.d && i == this.cz) return false; 
/* 23 */     return super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\api.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */