/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amb
/*     */   extends akz
/*     */ {
/*  24 */   public static final bk a = new bc(new bb());
/*  25 */   protected Random b = new Random();
/*     */   protected lx c;
/*     */   protected lx d;
/*     */   protected lx e;
/*     */   
/*     */   protected amb(int paramInt) {
/*  31 */     super(paramInt, aif.e);
/*  32 */     a(ve.d);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  37 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  42 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/*  43 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  47 */     if (paramaab.I) {
/*     */       return;
/*     */     }
/*     */     
/*  51 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3 - 1);
/*  52 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3 + 1);
/*  53 */     int k = paramaab.a(paramInt1 - 1, paramInt2, paramInt3);
/*  54 */     int m = paramaab.a(paramInt1 + 1, paramInt2, paramInt3);
/*     */     
/*  56 */     byte b = 3;
/*  57 */     if (apa.s[i] && !apa.s[j]) b = 3; 
/*  58 */     if (apa.s[j] && !apa.s[i]) b = 2; 
/*  59 */     if (apa.s[k] && !apa.s[m]) b = 5; 
/*  60 */     if (apa.s[m] && !apa.s[k]) b = 4; 
/*  61 */     paramaab.b(paramInt1, paramInt2, paramInt3, b, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  66 */     int i = paramInt2 & 0x7;
/*     */     
/*  68 */     if (paramInt1 == i) {
/*  69 */       if (i == 1 || i == 0) {
/*  70 */         return this.e;
/*     */       }
/*  72 */       return this.d;
/*     */     } 
/*     */ 
/*     */     
/*  76 */     if (i == 1 || i == 0)
/*  77 */       return this.c; 
/*  78 */     if (paramInt1 == 1 || paramInt1 == 0) {
/*  79 */       return this.c;
/*     */     }
/*     */     
/*  82 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  87 */     this.cQ = paramly.a("furnace_side");
/*  88 */     this.c = paramly.a("furnace_top");
/*  89 */     this.d = paramly.a("dispenser_front");
/*  90 */     this.e = paramly.a("dispenser_front_vertical");
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  95 */     if (paramaab.I) {
/*  96 */       return true;
/*     */     }
/*  98 */     aqc aqc = (aqc)paramaab.r(paramInt1, paramInt2, paramInt3);
/*  99 */     if (aqc != null) paramsq.a(aqc);
/*     */     
/* 101 */     return true;
/*     */   }
/*     */   
/*     */   protected void j_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 105 */     ba ba = new ba(paramaab, paramInt1, paramInt2, paramInt3);
/* 106 */     aqc aqc = (aqc)ba.j();
/* 107 */     if (aqc == null)
/*     */       return; 
/* 109 */     int i = aqc.j();
/* 110 */     if (i < 0) {
/* 111 */       paramaab.e(1001, paramInt1, paramInt2, paramInt3, 0);
/*     */     } else {
/* 113 */       wm wm = aqc.a(i);
/* 114 */       bd bd = a(wm);
/*     */       
/* 116 */       if (bd != bd.a) {
/* 117 */         wm wm1 = bd.a(ba, wm);
/*     */         
/* 119 */         aqc.a(i, (wm1.a == 0) ? null : wm1);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected bd a(wm paramwm) {
/* 125 */     return (bd)a.a(paramwm.b());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 131 */     boolean bool1 = (paramaab.C(paramInt1, paramInt2, paramInt3) || paramaab.C(paramInt1, paramInt2 + 1, paramInt3)) ? true : false;
/* 132 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 133 */     boolean bool2 = ((i & 0x8) != 0) ? true : false;
/*     */     
/* 135 */     if (bool1 && !bool2) {
/* 136 */       paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/* 137 */       paramaab.b(paramInt1, paramInt2, paramInt3, i | 0x8, 4);
/*     */     }
/* 139 */     else if (!bool1 && bool2) {
/* 140 */       paramaab.b(paramInt1, paramInt2, paramInt3, i & 0xFFFFFFF7, 4);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 147 */     if (!paramaab.I) {
/* 148 */       j_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/* 153 */     return new aqc();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 158 */     int i = aqt.a(paramaab, paramInt1, paramInt2, paramInt3, paramng);
/*     */     
/* 160 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */     
/* 162 */     if (paramwm.t()) {
/* 163 */       ((aqc)paramaab.r(paramInt1, paramInt2, paramInt3)).a(paramwm.s());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 169 */     aqc aqc = (aqc)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 170 */     if (aqc != null) {
/* 171 */       for (byte b = 0; b < aqc.j_(); b++) {
/* 172 */         wm wm = aqc.a(b);
/* 173 */         if (wm != null) {
/* 174 */           float f1 = this.b.nextFloat() * 0.8F + 0.1F;
/* 175 */           float f2 = this.b.nextFloat() * 0.8F + 0.1F;
/* 176 */           float f3 = this.b.nextFloat() * 0.8F + 0.1F;
/*     */           
/* 178 */           while (wm.a > 0) {
/* 179 */             int i = this.b.nextInt(21) + 10;
/* 180 */             if (i > wm.a) i = wm.a; 
/* 181 */             wm.a -= i;
/*     */             
/* 183 */             rh rh = new rh(paramaab, (paramInt1 + f1), (paramInt2 + f2), (paramInt3 + f3), new wm(wm.c, i, wm.k()));
/*     */             
/* 185 */             if (wm.p()) {
/* 186 */               rh.d().d((bs)wm.q().b());
/*     */             }
/*     */             
/* 189 */             float f = 0.05F;
/* 190 */             rh.x = ((float)this.b.nextGaussian() * f);
/* 191 */             rh.y = ((float)this.b.nextGaussian() * f + 0.2F);
/* 192 */             rh.z = ((float)this.b.nextGaussian() * f);
/* 193 */             paramaab.d(rh);
/*     */           } 
/*     */         } 
/*     */       } 
/* 197 */       paramaab.m(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/* 199 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */   
/*     */   public static bi a(az paramaz) {
/* 203 */     bf bf = j_(paramaz.h());
/*     */     
/* 205 */     double d1 = paramaz.a() + 0.7D * bf.c();
/* 206 */     double d2 = paramaz.b() + 0.7D * bf.d();
/* 207 */     double d3 = paramaz.c() + 0.7D * bf.e();
/*     */     
/* 209 */     return new bj(d1, d2, d3);
/*     */   }
/*     */   
/*     */   public static bf j_(int paramInt) {
/* 213 */     return bf.a(paramInt & 0x7);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean q_() {
/* 218 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 223 */     return tj.b((lt)paramaab.r(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */