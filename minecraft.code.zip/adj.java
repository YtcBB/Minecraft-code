/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class adj
/*    */ {
/*    */   private final boolean a;
/*    */   
/*    */   public adj() {
/* 12 */     this.a = false;
/*    */   }
/*    */   
/*    */   public adj(boolean paramBoolean) {
/* 16 */     this.a = paramBoolean;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public abstract boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3);
/*    */ 
/*    */   
/*    */   public void a(double paramDouble1, double paramDouble2, double paramDouble3) {}
/*    */ 
/*    */   
/*    */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 28 */     a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, 0);
/*    */   }
/*    */   
/*    */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 32 */     if (this.a) {
/* 33 */       paramaab.f(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, 3);
/*    */     } else {
/* 35 */       paramaab.f(paramInt1, paramInt2, paramInt3, paramInt4, paramInt5, 2);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */