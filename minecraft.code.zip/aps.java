/*    */ 
/*    */ 
/*    */ 
/*    */ public class aps
/*    */   extends ali
/*    */ {
/*    */   protected aps(int paramInt) {
/*  8 */     super(paramInt, true);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 13 */     return apa.B.m(1);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aps.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */