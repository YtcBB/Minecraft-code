/*    */ public class aii
/*    */   extends aif
/*    */ {
/*    */   public aii(aih paramaih) {
/*  5 */     super(paramaih);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a() {
/* 10 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b() {
/* 15 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 20 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aii.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */