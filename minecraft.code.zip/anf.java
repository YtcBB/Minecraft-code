/*     */ import java.util.Random;
/*     */ 
/*     */ public class anf
/*     */   extends ane {
/*     */   int a;
/*     */   boolean[] b;
/*     */   int[] c;
/*     */   
/*     */   protected anf(int paramInt, aif paramaif) {
/*  10 */     super(paramInt, paramaif);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  18 */     this.a = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 127 */     this.b = new boolean[4];
/* 128 */     this.c = new int[4]; }
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) { int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     paramaab.f(paramInt1, paramInt2, paramInt3, this.cz + 1, i, 2); }
/* 131 */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) { return (this.cO != aif.i); } private int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) { int i = 1000;
/* 132 */     for (byte b = 0; b < 4; b++) {
/* 133 */       if ((b != 0 || paramInt5 != 1) && (
/* 134 */         b != 1 || paramInt5 != 0) && (
/* 135 */         b != 2 || paramInt5 != 3) && (
/* 136 */         b != 3 || paramInt5 != 2)) {
/*     */         
/* 138 */         int j = paramInt1;
/* 139 */         int k = paramInt2;
/* 140 */         int m = paramInt3;
/*     */         
/* 142 */         if (b == 0) j--; 
/* 143 */         if (b == 1) j++; 
/* 144 */         if (b == 2) m--; 
/* 145 */         if (b == 3) m++;
/*     */         
/* 147 */         if (!n(paramaab, j, k, m))
/*     */         {
/* 149 */           if (paramaab.g(j, k, m) != this.cO || paramaab.h(j, k, m) != 0)
/*     */           {
/*     */             
/* 152 */             if (n(paramaab, j, k - 1, m)) {
/* 153 */               if (paramInt4 < 4) {
/* 154 */                 int n = d(paramaab, j, k, m, paramInt4 + 1, b);
/* 155 */                 if (n < i) i = n; 
/*     */               } 
/*     */             } else {
/* 158 */               return paramInt4;
/*     */             }  }  } 
/*     */       } 
/*     */     } 
/* 162 */     return i; }
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) { int i = k_(paramaab, paramInt1, paramInt2, paramInt3); byte b = 1; if (this.cO == aif.i && !paramaab.t.e) b = 2;  boolean bool = true; if (i > 0) { int j = -100; this.a = 0; j = d(paramaab, paramInt1 - 1, paramInt2, paramInt3, j); j = d(paramaab, paramInt1 + 1, paramInt2, paramInt3, j); j = d(paramaab, paramInt1, paramInt2, paramInt3 - 1, j); j = d(paramaab, paramInt1, paramInt2, paramInt3 + 1, j); int k = j + b; if (k >= 8 || j < 0) k = -1;  if (k_(paramaab, paramInt1, paramInt2 + 1, paramInt3) >= 0) { int m = k_(paramaab, paramInt1, paramInt2 + 1, paramInt3); if (m >= 8) { k = m; } else { k = m + 8; }  }  if (this.a >= 2 && this.cO == aif.h) if (paramaab.g(paramInt1, paramInt2 - 1, paramInt3).a()) { k = 0; } else if (paramaab.g(paramInt1, paramInt2 - 1, paramInt3) == this.cO && paramaab.h(paramInt1, paramInt2 - 1, paramInt3) == 0) { k = 0; }   if (this.cO == aif.i && i < 8 && k < 8 && k > i && paramRandom.nextInt(4) != 0) { k = i; bool = false; }  if (k == i) { if (bool) k(paramaab, paramInt1, paramInt2, paramInt3);  } else { i = k; if (i < 0) { paramaab.i(paramInt1, paramInt2, paramInt3); } else { paramaab.b(paramInt1, paramInt2, paramInt3, i, 2); paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab)); paramaab.f(paramInt1, paramInt2, paramInt3, this.cz); }  }  } else { k(paramaab, paramInt1, paramInt2, paramInt3); }  if (o(paramaab, paramInt1, paramInt2 - 1, paramInt3)) { if (this.cO == aif.i && paramaab.g(paramInt1, paramInt2 - 1, paramInt3) == aif.h) { paramaab.c(paramInt1, paramInt2 - 1, paramInt3, apa.x.cz); j(paramaab, paramInt1, paramInt2 - 1, paramInt3); return; }  if (i >= 8) { e(paramaab, paramInt1, paramInt2 - 1, paramInt3, i); } else { e(paramaab, paramInt1, paramInt2 - 1, paramInt3, i + 8); }  } else if (i >= 0 && (i == 0 || n(paramaab, paramInt1, paramInt2 - 1, paramInt3))) { boolean[] arrayOfBoolean = m(paramaab, paramInt1, paramInt2, paramInt3); int j = i + b; if (i >= 8) j = 1;  if (j >= 8) return;  if (arrayOfBoolean[0]) e(paramaab, paramInt1 - 1, paramInt2, paramInt3, j);  if (arrayOfBoolean[1]) e(paramaab, paramInt1 + 1, paramInt2, paramInt3, j);  if (arrayOfBoolean[2]) e(paramaab, paramInt1, paramInt2, paramInt3 - 1, j);  if (arrayOfBoolean[3])
/*     */         e(paramaab, paramInt1, paramInt2, paramInt3 + 1, j);  }  }
/*     */   private void e(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) { if (o(paramaab, paramInt1, paramInt2, paramInt3)) { int i = paramaab.a(paramInt1, paramInt2, paramInt3); if (i > 0)
/* 166 */         if (this.cO == aif.i) { j(paramaab, paramInt1, paramInt2, paramInt3); } else { apa.r[i].c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0); }   paramaab.f(paramInt1, paramInt2, paramInt3, this.cz, paramInt4, 3); }  } private boolean[] m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) { int i; for (i = 0; i < 4; i++) {
/* 167 */       this.c[i] = 1000;
/* 168 */       int j = paramInt1;
/* 169 */       int k = paramInt2;
/* 170 */       int m = paramInt3;
/*     */       
/* 172 */       if (i == 0) j--; 
/* 173 */       if (i == 1) j++; 
/* 174 */       if (i == 2) m--; 
/* 175 */       if (i == 3) m++; 
/* 176 */       if (!n(paramaab, j, k, m))
/*     */       {
/* 178 */         if (paramaab.g(j, k, m) != this.cO || paramaab.h(j, k, m) != 0)
/*     */         {
/*     */           
/* 181 */           if (n(paramaab, j, k - 1, m)) {
/* 182 */             this.c[i] = d(paramaab, j, k, m, 1, i);
/*     */           } else {
/* 184 */             this.c[i] = 0;
/*     */           } 
/*     */         }
/*     */       }
/*     */     } 
/* 189 */     i = this.c[0]; byte b;
/* 190 */     for (b = 1; b < 4; b++) {
/* 191 */       if (this.c[b] < i) i = this.c[b];
/*     */     
/*     */     } 
/* 194 */     for (b = 0; b < 4; b++) {
/* 195 */       this.b[b] = (this.c[b] == i);
/*     */     }
/* 197 */     return this.b; }
/*     */ 
/*     */   
/*     */   private boolean n(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 201 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3);
/* 202 */     if (i == apa.aI.cz || i == apa.aP.cz || i == apa.aH.cz || i == apa.aJ.cz || i == apa.bb.cz) {
/* 203 */       return true;
/*     */     }
/* 205 */     if (i == 0) return false; 
/* 206 */     aif aif = (apa.r[i]).cO;
/* 207 */     if (aif == aif.C) return true; 
/* 208 */     if (aif.c()) return true; 
/* 209 */     return false;
/*     */   }
/*     */   
/*     */   protected int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 213 */     int i = k_(paramaab, paramInt1, paramInt2, paramInt3);
/* 214 */     if (i < 0) return paramInt4; 
/* 215 */     if (i == 0) this.a++; 
/* 216 */     if (i >= 8) {
/* 217 */       i = 0;
/*     */     }
/* 219 */     return (paramInt4 < 0 || i < paramInt4) ? i : paramInt4;
/*     */   }
/*     */   
/*     */   private boolean o(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 223 */     aif aif = paramaab.g(paramInt1, paramInt2, paramInt3);
/* 224 */     if (aif == this.cO) return false; 
/* 225 */     if (aif == aif.i) return false; 
/* 226 */     return !n(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 231 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/* 232 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) == this.cz) {
/* 233 */       paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean l() {
/* 239 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */