/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class anz
/*     */   extends alz
/*     */ {
/*     */   private boolean a;
/*     */   private lx b;
/*     */   private lx c;
/*     */   
/*     */   protected anz(int paramInt, boolean paramBoolean) {
/*  28 */     super(paramInt, aif.A);
/*  29 */     b(true);
/*  30 */     this.a = paramBoolean;
/*  31 */     a(ve.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  36 */     if (paramInt1 == 1) return this.b; 
/*  37 */     if (paramInt1 == 0) return this.b;
/*     */     
/*  39 */     if (paramInt2 == 2 && paramInt1 == 2) return this.c; 
/*  40 */     if (paramInt2 == 3 && paramInt1 == 5) return this.c; 
/*  41 */     if (paramInt2 == 0 && paramInt1 == 3) return this.c; 
/*  42 */     if (paramInt2 == 1 && paramInt1 == 4) return this.c;
/*     */     
/*  44 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  49 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/*  50 */     if (paramaab.a(paramInt1, paramInt2 - 1, paramInt3) == apa.aY.cz && paramaab.a(paramInt1, paramInt2 - 2, paramInt3) == apa.aY.cz) {
/*  51 */       if (!paramaab.I) {
/*  52 */         paramaab.f(paramInt1, paramInt2, paramInt3, 0, 0, 2);
/*  53 */         paramaab.f(paramInt1, paramInt2 - 1, paramInt3, 0, 0, 2);
/*  54 */         paramaab.f(paramInt1, paramInt2 - 2, paramInt3, 0, 0, 2);
/*  55 */         qq qq = new qq(paramaab);
/*  56 */         qq.b(paramInt1 + 0.5D, paramInt2 - 1.95D, paramInt3 + 0.5D, 0.0F, 0.0F);
/*  57 */         paramaab.d(qq);
/*     */         
/*  59 */         paramaab.d(paramInt1, paramInt2, paramInt3, 0);
/*  60 */         paramaab.d(paramInt1, paramInt2 - 1, paramInt3, 0);
/*  61 */         paramaab.d(paramInt1, paramInt2 - 2, paramInt3, 0);
/*     */       } 
/*  63 */       for (byte b = 0; b < 120; b++) {
/*  64 */         paramaab.a("snowshovel", paramInt1 + paramaab.s.nextDouble(), (paramInt2 - 2) + paramaab.s.nextDouble() * 2.5D, paramInt3 + paramaab.s.nextDouble(), 0.0D, 0.0D, 0.0D);
/*     */       }
/*  66 */     } else if (paramaab.a(paramInt1, paramInt2 - 1, paramInt3) == apa.am.cz && paramaab.a(paramInt1, paramInt2 - 2, paramInt3) == apa.am.cz) {
/*     */       
/*  68 */       boolean bool1 = (paramaab.a(paramInt1 - 1, paramInt2 - 1, paramInt3) == apa.am.cz && paramaab.a(paramInt1 + 1, paramInt2 - 1, paramInt3) == apa.am.cz) ? true : false;
/*  69 */       boolean bool2 = (paramaab.a(paramInt1, paramInt2 - 1, paramInt3 - 1) == apa.am.cz && paramaab.a(paramInt1, paramInt2 - 1, paramInt3 + 1) == apa.am.cz) ? true : false;
/*  70 */       if (bool1 || bool2) {
/*  71 */         paramaab.f(paramInt1, paramInt2, paramInt3, 0, 0, 2);
/*  72 */         paramaab.f(paramInt1, paramInt2 - 1, paramInt3, 0, 0, 2);
/*  73 */         paramaab.f(paramInt1, paramInt2 - 2, paramInt3, 0, 0, 2);
/*  74 */         if (bool1) {
/*  75 */           paramaab.f(paramInt1 - 1, paramInt2 - 1, paramInt3, 0, 0, 2);
/*  76 */           paramaab.f(paramInt1 + 1, paramInt2 - 1, paramInt3, 0, 0, 2);
/*     */         } else {
/*  78 */           paramaab.f(paramInt1, paramInt2 - 1, paramInt3 - 1, 0, 0, 2);
/*  79 */           paramaab.f(paramInt1, paramInt2 - 1, paramInt3 + 1, 0, 0, 2);
/*     */         } 
/*     */         
/*  82 */         qs qs = new qs(paramaab);
/*  83 */         qs.i(true);
/*  84 */         qs.b(paramInt1 + 0.5D, paramInt2 - 1.95D, paramInt3 + 0.5D, 0.0F, 0.0F);
/*  85 */         paramaab.d(qs);
/*     */         
/*  87 */         for (byte b = 0; b < 120; b++) {
/*  88 */           paramaab.a("snowballpoof", paramInt1 + paramaab.s.nextDouble(), (paramInt2 - 2) + paramaab.s.nextDouble() * 3.9D, paramInt3 + paramaab.s.nextDouble(), 0.0D, 0.0D, 0.0D);
/*     */         }
/*     */         
/*  91 */         paramaab.d(paramInt1, paramInt2, paramInt3, 0);
/*  92 */         paramaab.d(paramInt1, paramInt2 - 1, paramInt3, 0);
/*  93 */         paramaab.d(paramInt1, paramInt2 - 2, paramInt3, 0);
/*  94 */         if (bool1) {
/*  95 */           paramaab.d(paramInt1 - 1, paramInt2 - 1, paramInt3, 0);
/*  96 */           paramaab.d(paramInt1 + 1, paramInt2 - 1, paramInt3, 0);
/*     */         } else {
/*  98 */           paramaab.d(paramInt1, paramInt2 - 1, paramInt3 - 1, 0);
/*  99 */           paramaab.d(paramInt1, paramInt2 - 1, paramInt3 + 1, 0);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 107 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3);
/* 108 */     return ((i == 0 || (apa.r[i]).cO.j()) && paramaab.w(paramInt1, paramInt2 - 1, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 113 */     int i = kx.c((paramng.A * 4.0F / 360.0F) + 2.5D) & 0x3;
/* 114 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 119 */     this.c = paramly.a(this.a ? "pumpkin_jack" : "pumpkin_face");
/* 120 */     this.b = paramly.a("pumpkin_top");
/* 121 */     this.cQ = paramly.a("pumpkin_side");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */