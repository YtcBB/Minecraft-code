/*    */ import java.util.List;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class af
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 15 */     return "enchant";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 20 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 25 */     return paramab.a("commands.enchant.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 29 */     if (paramArrayOfString.length >= 2) {
/* 30 */       jc jc = c(paramab, paramArrayOfString[0]);
/*    */       
/* 32 */       int i = a(paramab, paramArrayOfString[1], 0, yz.b.length - 1);
/* 33 */       int j = 1;
/*    */       
/* 35 */       wm wm = jc.cd();
/* 36 */       if (wm == null) {
/* 37 */         a(paramab, "commands.enchant.noItem", new Object[0]);
/*    */         
/*    */         return;
/*    */       } 
/* 41 */       yz yz = yz.b[i];
/* 42 */       if (yz == null) {
/* 43 */         throw new at("commands.enchant.notFound", new Object[] { Integer.valueOf(i) });
/*    */       }
/*    */       
/* 46 */       if (!yz.a(wm)) {
/* 47 */         a(paramab, "commands.enchant.cantEnchant", new Object[0]);
/*    */         
/*    */         return;
/*    */       } 
/* 51 */       if (paramArrayOfString.length >= 3) {
/* 52 */         j = a(paramab, paramArrayOfString[2], yz.d(), yz.b());
/*    */       }
/*    */       
/* 55 */       if (wm.p()) {
/* 56 */         ca ca = wm.r();
/* 57 */         if (ca != null) {
/* 58 */           for (byte b = 0; b < ca.c(); b++) {
/* 59 */             short s = ((bs)ca.b(b)).d("id");
/*    */             
/* 61 */             if (yz.b[s] != null) {
/* 62 */               yz yz1 = yz.b[s];
/* 63 */               if (!yz1.a(yz)) {
/* 64 */                 a(paramab, "commands.enchant.cantCombine", new Object[] { yz.c(j), yz1.c(((bs)ca.b(b)).d("lvl")) });
/*    */                 
/*    */                 return;
/*    */               } 
/*    */             } 
/*    */           } 
/*    */         }
/*    */       } 
/* 72 */       wm.a(yz, j);
/*    */       
/* 74 */       a(paramab, "commands.enchant.success", new Object[0]);
/*    */       
/*    */       return;
/*    */     } 
/* 78 */     throw new ax("commands.enchant.usage", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public List a(ab paramab, String[] paramArrayOfString) {
/* 83 */     if (paramArrayOfString.length == 1) {
/* 84 */       return a(paramArrayOfString, d());
/*    */     }
/*    */     
/* 87 */     return null;
/*    */   }
/*    */   
/*    */   protected String[] d() {
/* 91 */     return MinecraftServer.D().A();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(String[] paramArrayOfString, int paramInt) {
/* 96 */     return (paramInt == 0);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\af.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */