/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aog
/*    */   extends apa
/*    */ {
/*    */   private final boolean a;
/*    */   
/*    */   public aog(int paramInt, boolean paramBoolean) {
/* 13 */     super(paramInt, aif.s);
/* 14 */     this.a = paramBoolean;
/*    */     
/* 16 */     if (paramBoolean) {
/* 17 */       a(1.0F);
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 23 */     if (this.a) {
/* 24 */       this.cQ = paramly.a("redstoneLight_lit");
/*    */     } else {
/* 26 */       this.cQ = paramly.a("redstoneLight");
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 32 */     if (!paramaab.I) {
/* 33 */       if (this.a && !paramaab.C(paramInt1, paramInt2, paramInt3)) {
/* 34 */         paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, 4);
/* 35 */       } else if (!this.a && paramaab.C(paramInt1, paramInt2, paramInt3)) {
/* 36 */         paramaab.f(paramInt1, paramInt2, paramInt3, apa.bQ.cz, 0, 2);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 43 */     if (!paramaab.I) {
/* 44 */       if (this.a && !paramaab.C(paramInt1, paramInt2, paramInt3)) {
/* 45 */         paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, 4);
/* 46 */       } else if (!this.a && paramaab.C(paramInt1, paramInt2, paramInt3)) {
/* 47 */         paramaab.f(paramInt1, paramInt2, paramInt3, apa.bQ.cz, 0, 2);
/*    */       } 
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 54 */     if (!paramaab.I && 
/* 55 */       this.a && !paramaab.C(paramInt1, paramInt2, paramInt3)) {
/* 56 */       paramaab.f(paramInt1, paramInt2, paramInt3, apa.bP.cz, 0, 2);
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 63 */     return apa.bP.cz;
/*    */   }
/*    */ 
/*    */   
/*    */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 68 */     return apa.bP.cz;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aog.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */