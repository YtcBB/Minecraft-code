/*    */ import java.util.List;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ah
/*    */   extends x
/*    */ {
/* 13 */   private static final String[] a = new String[] { "options.difficulty.peaceful", "options.difficulty.easy", "options.difficulty.normal", "options.difficulty.hard" };
/*    */ 
/*    */ 
/*    */   
/*    */   public String c() {
/* 18 */     return "difficulty";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 23 */     return 2;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 29 */     return paramab.a("commands.difficulty.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 33 */     if (paramArrayOfString.length > 0) {
/* 34 */       int i = e(paramab, paramArrayOfString[0]);
/*    */       
/* 36 */       MinecraftServer.D().c(i);
/*    */       
/* 38 */       String str = bo.a(a[i]);
/* 39 */       a(paramab, "commands.difficulty.success", new Object[] { str });
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 44 */     throw new ax("commands.difficulty.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   protected int e(ab paramab, String paramString) {
/* 48 */     if (paramString.equalsIgnoreCase("peaceful") || paramString.equalsIgnoreCase("p"))
/* 49 */       return 0; 
/* 50 */     if (paramString.equalsIgnoreCase("easy") || paramString.equalsIgnoreCase("e"))
/* 51 */       return 1; 
/* 52 */     if (paramString.equalsIgnoreCase("normal") || paramString.equalsIgnoreCase("n"))
/* 53 */       return 2; 
/* 54 */     if (paramString.equalsIgnoreCase("hard") || paramString.equalsIgnoreCase("h")) {
/* 55 */       return 3;
/*    */     }
/* 57 */     return a(paramab, paramString, 0, 3);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List a(ab paramab, String[] paramArrayOfString) {
/* 63 */     if (paramArrayOfString.length == 1) {
/* 64 */       return a(paramArrayOfString, new String[] { "peaceful", "easy", "normal", "hard" });
/*    */     }
/*    */     
/* 67 */     return null;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ah.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */