/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aml
/*     */   extends apa
/*     */ {
/*  29 */   private int[] a = new int[256];
/*  30 */   private int[] b = new int[256];
/*     */   private lx[] c;
/*     */   
/*     */   protected aml(int paramInt) {
/*  34 */     super(paramInt, aif.o);
/*     */     
/*  36 */     b(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public void s_() {
/*  41 */     a(apa.B.cz, 5, 20);
/*  42 */     a(apa.bR.cz, 5, 20);
/*  43 */     a(apa.bS.cz, 5, 20);
/*  44 */     a(apa.bd.cz, 5, 20);
/*  45 */     a(apa.ax.cz, 5, 20);
/*  46 */     a(apa.cb.cz, 5, 20);
/*  47 */     a(apa.ca.cz, 5, 20);
/*  48 */     a(apa.cc.cz, 5, 20);
/*  49 */     a(apa.N.cz, 5, 5);
/*  50 */     a(apa.O.cz, 30, 60);
/*  51 */     a(apa.ar.cz, 30, 20);
/*  52 */     a(apa.aq.cz, 15, 100);
/*  53 */     a(apa.ab.cz, 60, 100);
/*  54 */     a(apa.af.cz, 30, 60);
/*  55 */     a(apa.by.cz, 15, 100);
/*     */   }
/*     */   
/*     */   private void a(int paramInt1, int paramInt2, int paramInt3) {
/*  59 */     this.a[paramInt1] = paramInt2;
/*  60 */     this.b[paramInt1] = paramInt3;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  66 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  75 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  80 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  85 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/*  90 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  95 */     return 30;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 101 */     if (!paramaab.N().b("doFireTick")) {
/*     */       return;
/*     */     }
/*     */     
/* 105 */     boolean bool = (paramaab.a(paramInt1, paramInt2 - 1, paramInt3) == apa.bf.cz) ? true : false;
/* 106 */     if (paramaab.t instanceof acq && 
/* 107 */       paramaab.a(paramInt1, paramInt2 - 1, paramInt3) == apa.D.cz) bool = true;
/*     */ 
/*     */     
/* 110 */     if (!c(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 111 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */     
/* 114 */     if (!bool && paramaab.P() && (
/* 115 */       paramaab.F(paramInt1, paramInt2, paramInt3) || paramaab.F(paramInt1 - 1, paramInt2, paramInt3) || paramaab.F(paramInt1 + 1, paramInt2, paramInt3) || paramaab.F(paramInt1, paramInt2, paramInt3 - 1) || paramaab.F(paramInt1, paramInt2, paramInt3 + 1))) {
/* 116 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 121 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 122 */     if (i < 15) {
/* 123 */       paramaab.b(paramInt1, paramInt2, paramInt3, i + paramRandom.nextInt(3) / 2, 4);
/*     */     }
/* 125 */     paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab) + paramRandom.nextInt(10));
/*     */     
/* 127 */     if (!bool && !k(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 128 */       if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3) || i > 3) paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       
/*     */       return;
/*     */     } 
/* 132 */     if (!bool && !d(paramaab, paramInt1, paramInt2 - 1, paramInt3) && 
/* 133 */       i == 15 && paramRandom.nextInt(4) == 0) {
/* 134 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       
/*     */       return;
/*     */     } 
/*     */     
/* 139 */     boolean bool1 = paramaab.G(paramInt1, paramInt2, paramInt3);
/* 140 */     byte b = 0;
/* 141 */     if (bool1) {
/* 142 */       b = -50;
/*     */     }
/* 144 */     a(paramaab, paramInt1 + 1, paramInt2, paramInt3, 300 + b, paramRandom, i);
/* 145 */     a(paramaab, paramInt1 - 1, paramInt2, paramInt3, 300 + b, paramRandom, i);
/* 146 */     a(paramaab, paramInt1, paramInt2 - 1, paramInt3, 250 + b, paramRandom, i);
/* 147 */     a(paramaab, paramInt1, paramInt2 + 1, paramInt3, 250 + b, paramRandom, i);
/* 148 */     a(paramaab, paramInt1, paramInt2, paramInt3 - 1, 300 + b, paramRandom, i);
/* 149 */     a(paramaab, paramInt1, paramInt2, paramInt3 + 1, 300 + b, paramRandom, i);
/*     */     
/* 151 */     for (int j = paramInt1 - 1; j <= paramInt1 + 1; j++) {
/* 152 */       for (int k = paramInt3 - 1; k <= paramInt3 + 1; k++) {
/* 153 */         for (int m = paramInt2 - 1; m <= paramInt2 + 4; m++) {
/* 154 */           if (j != paramInt1 || m != paramInt2 || k != paramInt3) {
/*     */             
/* 156 */             int n = 100;
/* 157 */             if (m > paramInt2 + 1) {
/* 158 */               n += (m - paramInt2 + 1) * 100;
/*     */             }
/*     */             
/* 161 */             int i1 = m(paramaab, j, m, k);
/* 162 */             if (i1 > 0) {
/* 163 */               int i2 = (i1 + 40 + paramaab.r * 7) / (i + 30);
/* 164 */               if (bool1) {
/* 165 */                 i2 /= 2;
/*     */               }
/* 167 */               if (i2 > 0 && paramRandom.nextInt(n) <= i2 && (
/* 168 */                 !paramaab.P() || !paramaab.F(j, m, k)) && !paramaab.F(j - 1, m, paramInt3) && !paramaab.F(j + 1, m, k) && !paramaab.F(j, m, k - 1) && !paramaab.F(j, m, k + 1)) {
/*     */ 
/*     */ 
/*     */ 
/*     */                 
/* 173 */                 int i3 = i + paramRandom.nextInt(5) / 4;
/* 174 */                 if (i3 > 15) i3 = 15; 
/* 175 */                 paramaab.f(j, m, k, this.cz, i3, 3);
/*     */               } 
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean l() {
/* 186 */     return false;
/*     */   }
/*     */   
/*     */   private void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Random paramRandom, int paramInt5) {
/* 190 */     int i = this.b[paramaab.a(paramInt1, paramInt2, paramInt3)];
/* 191 */     if (paramRandom.nextInt(paramInt4) < i) {
/* 192 */       boolean bool = (paramaab.a(paramInt1, paramInt2, paramInt3) == apa.aq.cz) ? true : false;
/* 193 */       if (paramRandom.nextInt(paramInt5 + 10) < 5 && !paramaab.F(paramInt1, paramInt2, paramInt3)) {
/* 194 */         int j = paramInt5 + paramRandom.nextInt(5) / 4;
/* 195 */         if (j > 15) j = 15; 
/* 196 */         paramaab.f(paramInt1, paramInt2, paramInt3, this.cz, j, 3);
/*     */       } else {
/* 198 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       } 
/* 200 */       if (bool) {
/* 201 */         apa.aq.g(paramaab, paramInt1, paramInt2, paramInt3, 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 207 */     if (d(paramaab, paramInt1 + 1, paramInt2, paramInt3)) return true; 
/* 208 */     if (d(paramaab, paramInt1 - 1, paramInt2, paramInt3)) return true; 
/* 209 */     if (d(paramaab, paramInt1, paramInt2 - 1, paramInt3)) return true; 
/* 210 */     if (d(paramaab, paramInt1, paramInt2 + 1, paramInt3)) return true; 
/* 211 */     if (d(paramaab, paramInt1, paramInt2, paramInt3 - 1)) return true; 
/* 212 */     if (d(paramaab, paramInt1, paramInt2, paramInt3 + 1)) return true;
/*     */     
/* 214 */     return false;
/*     */   }
/*     */   
/*     */   private int m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 218 */     int i = 0;
/* 219 */     if (!paramaab.c(paramInt1, paramInt2, paramInt3)) return 0;
/*     */     
/* 221 */     i = d(paramaab, paramInt1 + 1, paramInt2, paramInt3, i);
/* 222 */     i = d(paramaab, paramInt1 - 1, paramInt2, paramInt3, i);
/* 223 */     i = d(paramaab, paramInt1, paramInt2 - 1, paramInt3, i);
/* 224 */     i = d(paramaab, paramInt1, paramInt2 + 1, paramInt3, i);
/* 225 */     i = d(paramaab, paramInt1, paramInt2, paramInt3 - 1, i);
/* 226 */     i = d(paramaab, paramInt1, paramInt2, paramInt3 + 1, i);
/*     */     
/* 228 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean m() {
/* 233 */     return false;
/*     */   }
/*     */   
/*     */   public boolean d(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 237 */     return (this.a[paramaak.a(paramInt1, paramInt2, paramInt3)] > 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 242 */     int i = this.a[paramaab.a(paramInt1, paramInt2, paramInt3)];
/* 243 */     if (i > paramInt4) return i; 
/* 244 */     return paramInt4;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 249 */     return (paramaab.w(paramInt1, paramInt2 - 1, paramInt3) || k(paramaab, paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 254 */     if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3) && !k(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 255 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 261 */     if (paramaab.t.h <= 0 && paramaab.a(paramInt1, paramInt2 - 1, paramInt3) == apa.at.cz && 
/* 262 */       apa.bi.n_(paramaab, paramInt1, paramInt2, paramInt3)) {
/*     */       return;
/*     */     }
/*     */     
/* 266 */     if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3) && !k(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 267 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       
/*     */       return;
/*     */     } 
/* 271 */     paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab) + paramaab.s.nextInt(10));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 280 */     if (paramRandom.nextInt(24) == 0) {
/* 281 */       paramaab.a((paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), "fire.fire", 1.0F + paramRandom.nextFloat(), paramRandom.nextFloat() * 0.7F + 0.3F, false);
/*     */     }
/*     */     
/* 284 */     if (paramaab.w(paramInt1, paramInt2 - 1, paramInt3) || apa.av.d(paramaab, paramInt1, paramInt2 - 1, paramInt3)) {
/* 285 */       for (byte b = 0; b < 3; b++) {
/* 286 */         float f1 = paramInt1 + paramRandom.nextFloat();
/* 287 */         float f2 = paramInt2 + paramRandom.nextFloat() * 0.5F + 0.5F;
/* 288 */         float f3 = paramInt3 + paramRandom.nextFloat();
/* 289 */         paramaab.a("largesmoke", f1, f2, f3, 0.0D, 0.0D, 0.0D);
/*     */       } 
/*     */     } else {
/* 292 */       if (apa.av.d(paramaab, paramInt1 - 1, paramInt2, paramInt3)) {
/* 293 */         for (byte b = 0; b < 2; b++) {
/* 294 */           float f1 = paramInt1 + paramRandom.nextFloat() * 0.1F;
/* 295 */           float f2 = paramInt2 + paramRandom.nextFloat();
/* 296 */           float f3 = paramInt3 + paramRandom.nextFloat();
/* 297 */           paramaab.a("largesmoke", f1, f2, f3, 0.0D, 0.0D, 0.0D);
/*     */         } 
/*     */       }
/* 300 */       if (apa.av.d(paramaab, paramInt1 + 1, paramInt2, paramInt3)) {
/* 301 */         for (byte b = 0; b < 2; b++) {
/* 302 */           float f1 = (paramInt1 + 1) - paramRandom.nextFloat() * 0.1F;
/* 303 */           float f2 = paramInt2 + paramRandom.nextFloat();
/* 304 */           float f3 = paramInt3 + paramRandom.nextFloat();
/* 305 */           paramaab.a("largesmoke", f1, f2, f3, 0.0D, 0.0D, 0.0D);
/*     */         } 
/*     */       }
/* 308 */       if (apa.av.d(paramaab, paramInt1, paramInt2, paramInt3 - 1)) {
/* 309 */         for (byte b = 0; b < 2; b++) {
/* 310 */           float f1 = paramInt1 + paramRandom.nextFloat();
/* 311 */           float f2 = paramInt2 + paramRandom.nextFloat();
/* 312 */           float f3 = paramInt3 + paramRandom.nextFloat() * 0.1F;
/* 313 */           paramaab.a("largesmoke", f1, f2, f3, 0.0D, 0.0D, 0.0D);
/*     */         } 
/*     */       }
/* 316 */       if (apa.av.d(paramaab, paramInt1, paramInt2, paramInt3 + 1)) {
/* 317 */         for (byte b = 0; b < 2; b++) {
/* 318 */           float f1 = paramInt1 + paramRandom.nextFloat();
/* 319 */           float f2 = paramInt2 + paramRandom.nextFloat();
/* 320 */           float f3 = (paramInt3 + 1) - paramRandom.nextFloat() * 0.1F;
/* 321 */           paramaab.a("largesmoke", f1, f2, f3, 0.0D, 0.0D, 0.0D);
/*     */         } 
/*     */       }
/* 324 */       if (apa.av.d(paramaab, paramInt1, paramInt2 + 1, paramInt3)) {
/* 325 */         for (byte b = 0; b < 2; b++) {
/* 326 */           float f1 = paramInt1 + paramRandom.nextFloat();
/* 327 */           float f2 = (paramInt2 + 1) - paramRandom.nextFloat() * 0.1F;
/* 328 */           float f3 = paramInt3 + paramRandom.nextFloat();
/* 329 */           paramaab.a("largesmoke", f1, f2, f3, 0.0D, 0.0D, 0.0D);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 337 */     this.c = new lx[] { paramly.a("fire_0"), paramly.a("fire_1") };
/*     */   }
/*     */   
/*     */   public lx c(int paramInt) {
/* 341 */     return this.c[paramInt];
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/* 346 */     return this.c[0];
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aml.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */