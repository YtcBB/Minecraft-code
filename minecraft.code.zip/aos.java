/*    */ 
/*    */ 
/*    */ 
/*    */ public class aos
/*    */   extends ali
/*    */ {
/*    */   protected aos(int paramInt) {
/*  8 */     super(paramInt, false);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 13 */     return apa.x.m(1);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aos.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */