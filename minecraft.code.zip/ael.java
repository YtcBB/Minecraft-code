/*    */ import java.util.Map;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ael
/*    */   extends ags
/*    */ {
/* 10 */   private double e = 0.01D;
/*    */   
/*    */   public ael() {}
/*    */   
/*    */   public ael(Map paramMap) {
/* 15 */     for (Map.Entry entry : paramMap.entrySet()) {
/* 16 */       if (((String)entry.getKey()).equals("chance")) {
/* 17 */         this.e = kx.a((String)entry.getValue(), this.e);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean a(int paramInt1, int paramInt2) {
/* 24 */     return (this.b.nextDouble() < this.e && this.b.nextInt(80) < Math.max(Math.abs(paramInt1), Math.abs(paramInt2)));
/*    */   }
/*    */ 
/*    */   
/*    */   protected agy b(int paramInt1, int paramInt2) {
/* 29 */     return new aer(this.c, this.b, paramInt1, paramInt2);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ael.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */