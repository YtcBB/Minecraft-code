/*     */ 
/*     */ public class ajg
/*     */ {
/*   4 */   private ajh[] a = new ajh[1024];
/*     */   
/*   6 */   private int b = 0;
/*     */   
/*     */   public ajh a(ajh paramajh) {
/*   9 */     if (paramajh.d >= 0) throw new IllegalStateException("OW KNOWS!");
/*     */     
/*  11 */     if (this.b == this.a.length) {
/*  12 */       ajh[] arrayOfAjh = new ajh[this.b << 1];
/*  13 */       System.arraycopy(this.a, 0, arrayOfAjh, 0, this.b);
/*  14 */       this.a = arrayOfAjh;
/*     */     } 
/*     */ 
/*     */     
/*  18 */     this.a[this.b] = paramajh;
/*  19 */     paramajh.d = this.b;
/*  20 */     a(this.b++);
/*     */     
/*  22 */     return paramajh;
/*     */   }
/*     */   
/*     */   public void a() {
/*  26 */     this.b = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ajh c() {
/*  34 */     ajh ajh1 = this.a[0];
/*  35 */     this.a[0] = this.a[--this.b];
/*  36 */     this.a[this.b] = null;
/*  37 */     if (this.b > 0) b(0); 
/*  38 */     ajh1.d = -1;
/*  39 */     return ajh1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(ajh paramajh, float paramFloat) {
/*  58 */     float f = paramajh.g;
/*  59 */     paramajh.g = paramFloat;
/*  60 */     if (paramFloat < f) {
/*  61 */       a(paramajh.d);
/*     */     } else {
/*  63 */       b(paramajh.d);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void a(int paramInt) {
/*  72 */     ajh ajh1 = this.a[paramInt];
/*  73 */     float f = ajh1.g;
/*  74 */     while (paramInt > 0) {
/*  75 */       int i = paramInt - 1 >> 1;
/*  76 */       ajh ajh2 = this.a[i];
/*  77 */       if (f < ajh2.g) {
/*  78 */         this.a[paramInt] = ajh2;
/*  79 */         ajh2.d = paramInt;
/*  80 */         paramInt = i;
/*     */       } 
/*     */     } 
/*  83 */     this.a[paramInt] = ajh1;
/*  84 */     ajh1.d = paramInt;
/*     */   }
/*     */   
/*     */   private void b(int paramInt) {
/*  88 */     ajh ajh1 = this.a[paramInt];
/*  89 */     float f = ajh1.g; while (true) {
/*     */       ajh ajh3;
/*     */       float f2;
/*  92 */       int i = 1 + (paramInt << 1);
/*  93 */       int j = i + 1;
/*     */       
/*  95 */       if (i >= this.b) {
/*     */         break;
/*     */       }
/*  98 */       ajh ajh2 = this.a[i];
/*  99 */       float f1 = ajh2.g;
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 104 */       if (j >= this.b) {
/*     */         
/* 106 */         ajh3 = null;
/* 107 */         f2 = Float.POSITIVE_INFINITY;
/*     */       } else {
/* 109 */         ajh3 = this.a[j];
/* 110 */         f2 = ajh3.g;
/*     */       } 
/*     */ 
/*     */ 
/*     */       
/* 115 */       if (f1 < f2) {
/* 116 */         if (f1 < f) {
/* 117 */           this.a[paramInt] = ajh2;
/* 118 */           ajh2.d = paramInt;
/* 119 */           paramInt = i; continue;
/*     */         }  break;
/*     */       } 
/* 122 */       if (f2 < f) {
/* 123 */         this.a[paramInt] = ajh3;
/* 124 */         ajh3.d = paramInt;
/* 125 */         paramInt = j;
/*     */         continue;
/*     */       } 
/*     */       break;
/*     */     } 
/* 130 */     this.a[paramInt] = ajh1;
/* 131 */     ajh1.d = paramInt;
/*     */   }
/*     */   
/*     */   public boolean e() {
/* 135 */     return (this.b == 0);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */