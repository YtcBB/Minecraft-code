/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ahn
/*     */   extends ahq
/*     */ {
/*     */   private int a;
/*     */   
/*     */   public ahn(ahm paramahm, int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 501 */     super(paramahm, paramInt1);
/*     */     
/* 503 */     this.f = paramInt2;
/* 504 */     this.e = paramaek;
/* 505 */     this.a = Math.max(paramaek.b(), paramaek.d());
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/* 511 */     boolean bool = false;
/*     */ 
/*     */     
/* 514 */     int i = paramRandom.nextInt(5);
/* 515 */     while (i < this.a - 8) {
/* 516 */       agw agw1 = a((ahm)paramagw, paramList, paramRandom, 0, i);
/* 517 */       if (agw1 != null) {
/* 518 */         i += Math.max(agw1.e.b(), agw1.e.d());
/* 519 */         bool = true;
/*     */       } 
/* 521 */       i += 2 + paramRandom.nextInt(5);
/*     */     } 
/*     */ 
/*     */     
/* 525 */     i = paramRandom.nextInt(5);
/* 526 */     while (i < this.a - 8) {
/* 527 */       agw agw1 = b((ahm)paramagw, paramList, paramRandom, 0, i);
/* 528 */       if (agw1 != null) {
/* 529 */         i += Math.max(agw1.e.b(), agw1.e.d());
/* 530 */         bool = true;
/*     */       } 
/* 532 */       i += 2 + paramRandom.nextInt(5);
/*     */     } 
/*     */     
/* 535 */     if (bool && paramRandom.nextInt(3) > 0) {
/* 536 */       switch (this.f) {
/*     */         case 2:
/* 538 */           ahb.b((ahm)paramagw, paramList, paramRandom, this.e.a - 1, this.e.b, this.e.c, 1, c());
/*     */           break;
/*     */         case 0:
/* 541 */           ahb.b((ahm)paramagw, paramList, paramRandom, this.e.a - 1, this.e.b, this.e.f - 2, 1, c());
/*     */           break;
/*     */         case 3:
/* 544 */           ahb.b((ahm)paramagw, paramList, paramRandom, this.e.d - 2, this.e.b, this.e.c - 1, 2, c());
/*     */           break;
/*     */         case 1:
/* 547 */           ahb.b((ahm)paramagw, paramList, paramRandom, this.e.a, this.e.b, this.e.c - 1, 2, c());
/*     */           break;
/*     */       } 
/*     */     }
/* 551 */     if (bool && paramRandom.nextInt(3) > 0) {
/* 552 */       switch (this.f) {
/*     */         case 2:
/* 554 */           ahb.b((ahm)paramagw, paramList, paramRandom, this.e.d + 1, this.e.b, this.e.c, 3, c());
/*     */           break;
/*     */         case 0:
/* 557 */           ahb.b((ahm)paramagw, paramList, paramRandom, this.e.d + 1, this.e.b, this.e.f - 2, 3, c());
/*     */           break;
/*     */         case 3:
/* 560 */           ahb.b((ahm)paramagw, paramList, paramRandom, this.e.d - 2, this.e.b, this.e.f + 1, 0, c());
/*     */           break;
/*     */         case 1:
/* 563 */           ahb.b((ahm)paramagw, paramList, paramRandom, this.e.a, this.e.b, this.e.f + 1, 0, c());
/*     */           break;
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static aek a(ahm paramahm, List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 572 */     int i = 7 * kx.a(paramRandom, 3, 5);
/*     */     
/* 574 */     while (i >= 7) {
/* 575 */       aek aek = aek.a(paramInt1, paramInt2, paramInt3, 0, 0, 0, 3, 3, i, paramInt4);
/*     */       
/* 577 */       if (agw.a(paramList, aek) == null) {
/* 578 */         return aek;
/*     */       }
/* 580 */       i -= 7;
/*     */     } 
/*     */     
/* 583 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 589 */     int i = d(apa.J.cz, 0);
/* 590 */     for (int j = this.e.a; j <= this.e.d; j++) {
/* 591 */       for (int k = this.e.c; k <= this.e.f; k++) {
/* 592 */         if (paramaek.b(j, 64, k)) {
/* 593 */           int m = paramaab.i(j, k) - 1;
/* 594 */           paramaab.f(j, m, k, i, 0, 2);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 599 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ahn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */