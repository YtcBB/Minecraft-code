/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aok
/*     */   extends alh
/*     */ {
/*  21 */   public static final String[] a = new String[] { "oak", "spruce", "birch", "jungle" };
/*     */ 
/*     */ 
/*     */   
/*  25 */   private static final String[] b = new String[] { "sapling", "sapling_spruce", "sapling_birch", "sapling_jungle" };
/*     */ 
/*     */   
/*     */   private lx[] c;
/*     */ 
/*     */   
/*     */   protected aok(int paramInt) {
/*  32 */     super(paramInt);
/*     */     
/*  34 */     float f = 0.4F;
/*  35 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f * 2.0F, 0.5F + f);
/*  36 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  41 */     if (paramaab.I)
/*     */       return; 
/*  43 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*     */     
/*  45 */     if (paramaab.n(paramInt1, paramInt2 + 1, paramInt3) >= 9 && 
/*  46 */       paramRandom.nextInt(7) == 0) {
/*  47 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  54 */     paramInt2 &= 0x3;
/*  55 */     return this.c[paramInt2];
/*     */   }
/*     */   
/*     */   public void c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  59 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  60 */     if ((i & 0x8) == 0) {
/*  61 */       paramaab.b(paramInt1, paramInt2, paramInt3, i | 0x8, 4);
/*     */     } else {
/*  63 */       d(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*     */     } 
/*     */   }
/*     */   public void d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*     */     adb adb;
/*  68 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3) & 0x3;
/*     */     
/*  70 */     aec aec = null;
/*     */     
/*  72 */     byte b1 = 0, b2 = 0;
/*  73 */     boolean bool = false;
/*     */     
/*  75 */     if (i == 1) {
/*  76 */       aec = new aec(true);
/*  77 */     } else if (i == 2) {
/*  78 */       adc adc = new adc(true);
/*  79 */     } else if (i == 3) {
/*     */       adt adt;
/*     */       
/*  82 */       for (b1 = 0; b1 >= -1; b1--) {
/*  83 */         for (b2 = 0; b2 >= -1; b2--) {
/*  84 */           if (d(paramaab, paramInt1 + b1, paramInt2, paramInt3 + b2, 3) && d(paramaab, paramInt1 + b1 + 1, paramInt2, paramInt3 + b2, 3) && d(paramaab, paramInt1 + b1, paramInt2, paramInt3 + b2 + 1, 3) && d(paramaab, paramInt1 + b1 + 1, paramInt2, paramInt3 + b2 + 1, 3)) {
/*     */             
/*  86 */             adt = new adt(true, 10 + paramRandom.nextInt(20), 3, 3);
/*  87 */             bool = true;
/*     */             break;
/*     */           } 
/*     */         } 
/*  91 */         if (adt != null) {
/*     */           break;
/*     */         }
/*     */       } 
/*  95 */       if (adt == null) {
/*  96 */         b1 = b2 = 0;
/*  97 */         aef aef = new aef(true, 4 + paramRandom.nextInt(7), 3, 3, false);
/*     */       } 
/*     */     } else {
/* 100 */       aef aef = new aef(true);
/* 101 */       if (paramRandom.nextInt(10) == 0) {
/* 102 */         adb = new adb(true);
/*     */       }
/*     */     } 
/*     */     
/* 106 */     if (bool) {
/* 107 */       paramaab.f(paramInt1 + b1, paramInt2, paramInt3 + b2, 0, 0, 4);
/* 108 */       paramaab.f(paramInt1 + b1 + 1, paramInt2, paramInt3 + b2, 0, 0, 4);
/* 109 */       paramaab.f(paramInt1 + b1, paramInt2, paramInt3 + b2 + 1, 0, 0, 4);
/* 110 */       paramaab.f(paramInt1 + b1 + 1, paramInt2, paramInt3 + b2 + 1, 0, 0, 4);
/*     */     } else {
/* 112 */       paramaab.f(paramInt1, paramInt2, paramInt3, 0, 0, 4);
/*     */     } 
/*     */     
/* 115 */     if (!adb.a(paramaab, paramRandom, paramInt1 + b1, paramInt2, paramInt3 + b2)) {
/* 116 */       if (bool) {
/* 117 */         paramaab.f(paramInt1 + b1, paramInt2, paramInt3 + b2, this.cz, i, 4);
/* 118 */         paramaab.f(paramInt1 + b1 + 1, paramInt2, paramInt3 + b2, this.cz, i, 4);
/* 119 */         paramaab.f(paramInt1 + b1, paramInt2, paramInt3 + b2 + 1, this.cz, i, 4);
/* 120 */         paramaab.f(paramInt1 + b1 + 1, paramInt2, paramInt3 + b2 + 1, this.cz, i, 4);
/*     */       } else {
/* 122 */         paramaab.f(paramInt1, paramInt2, paramInt3, this.cz, i, 4);
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public boolean d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 128 */     return (paramaab.a(paramInt1, paramInt2, paramInt3) == this.cz && (paramaab.h(paramInt1, paramInt2, paramInt3) & 0x3) == paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/* 133 */     return paramInt & 0x3;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 138 */     paramList.add(new wm(paramInt, 1, 0));
/* 139 */     paramList.add(new wm(paramInt, 1, 1));
/* 140 */     paramList.add(new wm(paramInt, 1, 2));
/* 141 */     paramList.add(new wm(paramInt, 1, 3));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 146 */     this.c = new lx[b.length];
/*     */     
/* 148 */     for (byte b = 0; b < this.c.length; b++)
/* 149 */       this.c[b] = paramly.a(b[b]); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aok.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */