/*    */ 
/*    */ 
/*    */ public class aiy
/*    */   extends ait
/*    */ {
/*    */   public aiy(long paramLong, ait paramait) {
/*  7 */     super(paramLong);
/*  8 */     this.a = paramait;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 13 */     int[] arrayOfInt1 = this.a.a(paramInt1 - 1, paramInt2 - 1, paramInt3 + 2, paramInt4 + 2);
/*    */     
/* 15 */     int[] arrayOfInt2 = air.a(paramInt3 * paramInt4);
/* 16 */     for (byte b = 0; b < paramInt4; b++) {
/* 17 */       for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 18 */         a((b1 + paramInt1), (b + paramInt2));
/* 19 */         int i = arrayOfInt1[b1 + 1 + (b + 1) * (paramInt3 + 2)];
/* 20 */         if (i == aav.p.N) {
/* 21 */           int j = arrayOfInt1[b1 + 1 + (b + 1 - 1) * (paramInt3 + 2)];
/* 22 */           int k = arrayOfInt1[b1 + 1 + 1 + (b + 1) * (paramInt3 + 2)];
/* 23 */           int m = arrayOfInt1[b1 + 1 - 1 + (b + 1) * (paramInt3 + 2)];
/* 24 */           int n = arrayOfInt1[b1 + 1 + (b + 1 + 1) * (paramInt3 + 2)];
/* 25 */           if (j == aav.b.N || k == aav.b.N || m == aav.b.N || n == aav.b.N) {
/* 26 */             arrayOfInt2[b1 + b * paramInt3] = aav.q.N;
/*    */           } else {
/* 28 */             arrayOfInt2[b1 + b * paramInt3] = i;
/*    */           } 
/* 30 */         } else if (i != aav.b.N && i != aav.i.N && i != aav.h.N && i != aav.e.N) {
/* 31 */           int j = arrayOfInt1[b1 + 1 + (b + 1 - 1) * (paramInt3 + 2)];
/* 32 */           int k = arrayOfInt1[b1 + 1 + 1 + (b + 1) * (paramInt3 + 2)];
/* 33 */           int m = arrayOfInt1[b1 + 1 - 1 + (b + 1) * (paramInt3 + 2)];
/* 34 */           int n = arrayOfInt1[b1 + 1 + (b + 1 + 1) * (paramInt3 + 2)];
/* 35 */           if (j == aav.b.N || k == aav.b.N || m == aav.b.N || n == aav.b.N) {
/* 36 */             arrayOfInt2[b1 + b * paramInt3] = aav.r.N;
/*    */           } else {
/* 38 */             arrayOfInt2[b1 + b * paramInt3] = i;
/*    */           } 
/* 40 */         } else if (i == aav.e.N) {
/* 41 */           int j = arrayOfInt1[b1 + 1 + (b + 1 - 1) * (paramInt3 + 2)];
/* 42 */           int k = arrayOfInt1[b1 + 1 + 1 + (b + 1) * (paramInt3 + 2)];
/* 43 */           int m = arrayOfInt1[b1 + 1 - 1 + (b + 1) * (paramInt3 + 2)];
/* 44 */           int n = arrayOfInt1[b1 + 1 + (b + 1 + 1) * (paramInt3 + 2)];
/* 45 */           if (j != aav.e.N || k != aav.e.N || m != aav.e.N || n != aav.e.N) {
/* 46 */             arrayOfInt2[b1 + b * paramInt3] = aav.v.N;
/*    */           } else {
/* 48 */             arrayOfInt2[b1 + b * paramInt3] = i;
/*    */           } 
/*    */         } else {
/* 51 */           arrayOfInt2[b1 + b * paramInt3] = i;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */ 
/*    */     
/* 57 */     return arrayOfInt2;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aiy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */