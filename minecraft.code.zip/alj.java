/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class alj
/*     */   extends apa
/*     */ {
/*     */   private lx a;
/*     */   private lx b;
/*     */   
/*     */   protected alj(int paramInt) {
/*  20 */     super(paramInt, aif.y);
/*  21 */     b(true);
/*  22 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  27 */     if (paramaab.c(paramInt1, paramInt2 + 1, paramInt3)) {
/*  28 */       byte b = 1;
/*  29 */       while (paramaab.a(paramInt1, paramInt2 - b, paramInt3) == this.cz) {
/*  30 */         b++;
/*     */       }
/*  32 */       if (b < 3) {
/*  33 */         int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  34 */         if (i == 15) {
/*  35 */           paramaab.c(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*  36 */           paramaab.b(paramInt1, paramInt2, paramInt3, 0, 4);
/*  37 */           a(paramaab, paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*     */         } else {
/*  39 */           paramaab.b(paramInt1, paramInt2, paramInt3, i + 1, 4);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  47 */     float f = 0.0625F;
/*  48 */     return aqx.a().a((paramInt1 + f), paramInt2, (paramInt3 + f), ((paramInt1 + 1) - f), ((paramInt2 + 1) - f), ((paramInt3 + 1) - f));
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  53 */     float f = 0.0625F;
/*  54 */     return aqx.a().a((paramInt1 + f), paramInt2, (paramInt3 + f), ((paramInt1 + 1) - f), (paramInt2 + 1), ((paramInt3 + 1) - f));
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  59 */     if (paramInt1 == 1) return this.a; 
/*  60 */     if (paramInt1 == 0) return this.b; 
/*  61 */     return this.cQ;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  66 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  71 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  76 */     return 13;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  81 */     if (!super.c(paramaab, paramInt1, paramInt2, paramInt3)) return false;
/*     */     
/*  83 */     return f(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  88 */     if (!f(paramaab, paramInt1, paramInt2, paramInt3)) {
/*  89 */       paramaab.a(paramInt1, paramInt2, paramInt3, true);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  95 */     if (paramaab.g(paramInt1 - 1, paramInt2, paramInt3).a()) return false; 
/*  96 */     if (paramaab.g(paramInt1 + 1, paramInt2, paramInt3).a()) return false; 
/*  97 */     if (paramaab.g(paramInt1, paramInt2, paramInt3 - 1).a()) return false; 
/*  98 */     if (paramaab.g(paramInt1, paramInt2, paramInt3 + 1).a()) return false; 
/*  99 */     int i = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/* 100 */     return (i == apa.aZ.cz || i == apa.I.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/* 105 */     parammp.a(mg.g, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 110 */     this.cQ = paramly.a("cactus_side");
/* 111 */     this.a = paramly.a("cactus_top");
/* 112 */     this.b = paramly.a("cactus_bottom");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */