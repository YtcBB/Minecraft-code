/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amn
/*     */   extends akz
/*     */ {
/*  21 */   private final Random a = new Random();
/*     */   private final boolean b;
/*     */   private static boolean c = false;
/*     */   private lx d;
/*     */   private lx e;
/*     */   
/*     */   protected amn(int paramInt, boolean paramBoolean) {
/*  28 */     super(paramInt, aif.e);
/*  29 */     this.b = paramBoolean;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  34 */     return apa.aF.cz;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  39 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/*  40 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  45 */     if (paramaab.I) {
/*     */       return;
/*     */     }
/*     */     
/*  49 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3 - 1);
/*  50 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3 + 1);
/*  51 */     int k = paramaab.a(paramInt1 - 1, paramInt2, paramInt3);
/*  52 */     int m = paramaab.a(paramInt1 + 1, paramInt2, paramInt3);
/*     */     
/*  54 */     byte b = 3;
/*  55 */     if (apa.s[i] && !apa.s[j]) b = 3; 
/*  56 */     if (apa.s[j] && !apa.s[i]) b = 2; 
/*  57 */     if (apa.s[k] && !apa.s[m]) b = 5; 
/*  58 */     if (apa.s[m] && !apa.s[k]) b = 4; 
/*  59 */     paramaab.b(paramInt1, paramInt2, paramInt3, b, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  64 */     if (paramInt1 == 1) return this.d; 
/*  65 */     if (paramInt1 == 0) return this.d;
/*     */     
/*  67 */     if (paramInt1 != paramInt2) return this.cQ; 
/*  68 */     return this.e;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  73 */     this.cQ = paramly.a("furnace_side");
/*  74 */     this.e = paramly.a(this.b ? "furnace_front_lit" : "furnace_front");
/*  75 */     this.d = paramly.a("furnace_top");
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  80 */     if (!this.b)
/*     */       return; 
/*  82 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  84 */     float f1 = paramInt1 + 0.5F;
/*  85 */     float f2 = paramInt2 + 0.0F + paramRandom.nextFloat() * 6.0F / 16.0F;
/*  86 */     float f3 = paramInt3 + 0.5F;
/*  87 */     float f4 = 0.52F;
/*  88 */     float f5 = paramRandom.nextFloat() * 0.6F - 0.3F;
/*     */     
/*  90 */     if (i == 4) {
/*  91 */       paramaab.a("smoke", (f1 - f4), f2, (f3 + f5), 0.0D, 0.0D, 0.0D);
/*  92 */       paramaab.a("flame", (f1 - f4), f2, (f3 + f5), 0.0D, 0.0D, 0.0D);
/*  93 */     } else if (i == 5) {
/*  94 */       paramaab.a("smoke", (f1 + f4), f2, (f3 + f5), 0.0D, 0.0D, 0.0D);
/*  95 */       paramaab.a("flame", (f1 + f4), f2, (f3 + f5), 0.0D, 0.0D, 0.0D);
/*  96 */     } else if (i == 2) {
/*  97 */       paramaab.a("smoke", (f1 + f5), f2, (f3 - f4), 0.0D, 0.0D, 0.0D);
/*  98 */       paramaab.a("flame", (f1 + f5), f2, (f3 - f4), 0.0D, 0.0D, 0.0D);
/*  99 */     } else if (i == 3) {
/* 100 */       paramaab.a("smoke", (f1 + f5), f2, (f3 + f4), 0.0D, 0.0D, 0.0D);
/* 101 */       paramaab.a("flame", (f1 + f5), f2, (f3 + f4), 0.0D, 0.0D, 0.0D);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 107 */     if (paramaab.I) {
/* 108 */       return true;
/*     */     }
/* 110 */     aqg aqg = (aqg)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 111 */     if (aqg != null) paramsq.a(aqg); 
/* 112 */     return true;
/*     */   }
/*     */   
/*     */   public static void a(boolean paramBoolean, aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 116 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 117 */     aqp aqp = paramaab.r(paramInt1, paramInt2, paramInt3);
/*     */     
/* 119 */     c = true;
/* 120 */     if (paramBoolean) { paramaab.c(paramInt1, paramInt2, paramInt3, apa.aG.cz); }
/* 121 */     else { paramaab.c(paramInt1, paramInt2, paramInt3, apa.aF.cz); }
/* 122 */      c = false;
/*     */     
/* 124 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */     
/* 126 */     if (aqp != null) {
/* 127 */       aqp.s();
/* 128 */       paramaab.a(paramInt1, paramInt2, paramInt3, aqp);
/*     */     } 
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/* 133 */     return new aqg();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 138 */     int i = kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3;
/*     */     
/* 140 */     if (i == 0) paramaab.b(paramInt1, paramInt2, paramInt3, 2, 2); 
/* 141 */     if (i == 1) paramaab.b(paramInt1, paramInt2, paramInt3, 5, 2); 
/* 142 */     if (i == 2) paramaab.b(paramInt1, paramInt2, paramInt3, 3, 2); 
/* 143 */     if (i == 3) paramaab.b(paramInt1, paramInt2, paramInt3, 4, 2);
/*     */     
/* 145 */     if (paramwm.t()) {
/* 146 */       ((aqg)paramaab.r(paramInt1, paramInt2, paramInt3)).a(paramwm.s());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 152 */     if (!c) {
/* 153 */       aqg aqg = (aqg)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 154 */       if (aqg != null) {
/* 155 */         for (byte b = 0; b < aqg.j_(); b++) {
/* 156 */           wm wm = aqg.a(b);
/* 157 */           if (wm != null) {
/* 158 */             float f1 = this.a.nextFloat() * 0.8F + 0.1F;
/* 159 */             float f2 = this.a.nextFloat() * 0.8F + 0.1F;
/* 160 */             float f3 = this.a.nextFloat() * 0.8F + 0.1F;
/*     */             
/* 162 */             while (wm.a > 0) {
/* 163 */               int i = this.a.nextInt(21) + 10;
/* 164 */               if (i > wm.a) i = wm.a; 
/* 165 */               wm.a -= i;
/*     */               
/* 167 */               rh rh = new rh(paramaab, (paramInt1 + f1), (paramInt2 + f2), (paramInt3 + f3), new wm(wm.c, i, wm.k()));
/*     */               
/* 169 */               if (wm.p()) {
/* 170 */                 rh.d().d((bs)wm.q().b());
/*     */               }
/*     */               
/* 173 */               float f = 0.05F;
/* 174 */               rh.x = ((float)this.a.nextGaussian() * f);
/* 175 */               rh.y = ((float)this.a.nextGaussian() * f + 0.2F);
/* 176 */               rh.z = ((float)this.a.nextGaussian() * f);
/* 177 */               paramaab.d(rh);
/*     */             } 
/*     */           } 
/*     */         } 
/* 181 */         paramaab.m(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */       } 
/*     */     } 
/* 184 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean q_() {
/* 189 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 194 */     return tj.b((lt)paramaab.r(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 199 */     return apa.aF.cz;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */