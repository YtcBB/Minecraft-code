public interface ab {
  String c_();
  
  void a(String paramString);
  
  boolean a(int paramInt, String paramString);
  
  String a(String paramString, Object... paramVarArgs);
  
  t b();
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ab.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */