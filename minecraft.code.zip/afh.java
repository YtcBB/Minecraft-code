/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ abstract class afh
/*     */   extends agw
/*     */ {
/*     */   protected afh(int paramInt) {
/* 101 */     super(paramInt);
/*     */   }
/*     */   
/*     */   private int a(List paramList) {
/* 105 */     boolean bool = false;
/* 106 */     int i = 0;
/* 107 */     for (afi afi : paramList) {
/* 108 */       if (afi.d > 0 && afi.c < afi.d) {
/* 109 */         bool = true;
/*     */       }
/* 111 */       i += afi.b;
/*     */     } 
/* 113 */     return bool ? i : -1;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private afh a(afl paramafl, List paramList1, List paramList2, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 119 */     int i = a(paramList1);
/* 120 */     boolean bool = (i > 0 && paramInt5 <= 30) ? true : false;
/*     */     
/* 122 */     byte b = 0;
/* 123 */     while (b < 5 && bool) {
/* 124 */       b++;
/*     */       
/* 126 */       int j = paramRandom.nextInt(i);
/* 127 */       for (afi afi : paramList1) {
/* 128 */         j -= afi.b;
/* 129 */         if (j < 0) {
/*     */           
/* 131 */           if (!afi.a(paramInt5) || (afi == paramafl.a && !afi.e)) {
/*     */             break;
/*     */           }
/*     */           
/* 135 */           afh afh1 = aeu.a(afi, paramList2, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 136 */           if (afh1 != null) {
/* 137 */             afi.c++;
/* 138 */             paramafl.a = afi;
/*     */             
/* 140 */             if (!afi.a()) {
/* 141 */               paramList1.remove(afi);
/*     */             }
/* 143 */             return afh1;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 148 */     return aew.a(paramList2, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */   
/*     */   private agw a(afl paramafl, List<afh> paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean) {
/* 152 */     if (Math.abs(paramInt1 - (paramafl.b()).a) > 112 || Math.abs(paramInt3 - (paramafl.b()).c) > 112) {
/* 153 */       return aew.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */     }
/* 155 */     List list = paramafl.b;
/* 156 */     if (paramBoolean) {
/* 157 */       list = paramafl.c;
/*     */     }
/* 159 */     afh afh1 = a(paramafl, list, paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5 + 1);
/* 160 */     if (afh1 != null) {
/* 161 */       paramList.add(afh1);
/* 162 */       paramafl.d.add(afh1);
/*     */     } 
/* 164 */     return afh1;
/*     */   }
/*     */   
/*     */   protected agw a(afl paramafl, List paramList, Random paramRandom, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 168 */     switch (this.f) {
/*     */       case 2:
/* 170 */         return a(paramafl, paramList, paramRandom, this.e.a + paramInt1, this.e.b + paramInt2, this.e.c - 1, this.f, c(), paramBoolean);
/*     */       case 0:
/* 172 */         return a(paramafl, paramList, paramRandom, this.e.a + paramInt1, this.e.b + paramInt2, this.e.f + 1, this.f, c(), paramBoolean);
/*     */       case 1:
/* 174 */         return a(paramafl, paramList, paramRandom, this.e.a - 1, this.e.b + paramInt2, this.e.c + paramInt1, this.f, c(), paramBoolean);
/*     */       case 3:
/* 176 */         return a(paramafl, paramList, paramRandom, this.e.d + 1, this.e.b + paramInt2, this.e.c + paramInt1, this.f, c(), paramBoolean);
/*     */     } 
/* 178 */     return null;
/*     */   }
/*     */   
/*     */   protected agw b(afl paramafl, List paramList, Random paramRandom, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 182 */     switch (this.f) {
/*     */       case 2:
/* 184 */         return a(paramafl, paramList, paramRandom, this.e.a - 1, this.e.b + paramInt1, this.e.c + paramInt2, 1, c(), paramBoolean);
/*     */       case 0:
/* 186 */         return a(paramafl, paramList, paramRandom, this.e.a - 1, this.e.b + paramInt1, this.e.c + paramInt2, 1, c(), paramBoolean);
/*     */       case 1:
/* 188 */         return a(paramafl, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.c - 1, 2, c(), paramBoolean);
/*     */       case 3:
/* 190 */         return a(paramafl, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.c - 1, 2, c(), paramBoolean);
/*     */     } 
/* 192 */     return null;
/*     */   }
/*     */   
/*     */   protected agw c(afl paramafl, List paramList, Random paramRandom, int paramInt1, int paramInt2, boolean paramBoolean) {
/* 196 */     switch (this.f) {
/*     */       case 2:
/* 198 */         return a(paramafl, paramList, paramRandom, this.e.d + 1, this.e.b + paramInt1, this.e.c + paramInt2, 3, c(), paramBoolean);
/*     */       case 0:
/* 200 */         return a(paramafl, paramList, paramRandom, this.e.d + 1, this.e.b + paramInt1, this.e.c + paramInt2, 3, c(), paramBoolean);
/*     */       case 1:
/* 202 */         return a(paramafl, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.f + 1, 0, c(), paramBoolean);
/*     */       case 3:
/* 204 */         return a(paramafl, paramList, paramRandom, this.e.a + paramInt2, this.e.b + paramInt1, this.e.f + 1, 0, c(), paramBoolean);
/*     */     } 
/* 206 */     return null;
/*     */   }
/*     */   
/*     */   protected static boolean a(aek paramaek) {
/* 210 */     return (paramaek != null && paramaek.b > 10);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */