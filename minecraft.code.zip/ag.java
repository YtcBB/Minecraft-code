/*    */ import java.util.List;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ag
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 13 */     return "xp";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 18 */     return 2;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 24 */     return paramab.a("commands.xp.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 28 */     if (paramArrayOfString.length > 0) {
/*    */       jc jc;
/* 30 */       String str = paramArrayOfString[0];
/*    */       
/* 32 */       boolean bool1 = (str.endsWith("l") || str.endsWith("L")) ? true : false;
/* 33 */       if (bool1 && str.length() > 1) str = str.substring(0, str.length() - 1);
/*    */       
/* 35 */       int i = a(paramab, str);
/* 36 */       boolean bool2 = (i < 0) ? true : false;
/*    */       
/* 38 */       if (bool2) i *= -1;
/*    */       
/* 40 */       if (paramArrayOfString.length > 1) {
/* 41 */         jc = c(paramab, paramArrayOfString[1]);
/*    */       } else {
/* 43 */         jc = c(paramab);
/*    */       } 
/*    */       
/* 46 */       if (bool1) {
/* 47 */         if (bool2) {
/* 48 */           jc.a(-i);
/* 49 */           a(paramab, "commands.xp.success.negative.levels", new Object[] { Integer.valueOf(i), jc.am() });
/*    */         } else {
/* 51 */           jc.a(i);
/* 52 */           a(paramab, "commands.xp.success.levels", new Object[] { Integer.valueOf(i), jc.am() });
/*    */         } 
/*    */       } else {
/* 55 */         if (bool2) {
/* 56 */           throw new ax("commands.xp.failure.widthdrawXp", new Object[0]);
/*    */         }
/* 58 */         jc.w(i);
/* 59 */         a(paramab, "commands.xp.success", new Object[] { Integer.valueOf(i), jc.am() });
/*    */       } 
/*    */ 
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 66 */     throw new ax("commands.xp.usage", new Object[0]);
/*    */   }
/*    */ 
/*    */   
/*    */   public List a(ab paramab, String[] paramArrayOfString) {
/* 71 */     if (paramArrayOfString.length == 2) {
/* 72 */       return a(paramArrayOfString, d());
/*    */     }
/*    */     
/* 75 */     return null;
/*    */   }
/*    */   
/*    */   protected String[] d() {
/* 79 */     return MinecraftServer.D().A();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(String[] paramArrayOfString, int paramInt) {
/* 84 */     return (paramInt == 1);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */