/*     */ import java.util.HashMap;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class aan
/*     */ {
/*     */   protected static aat a(aab paramaab, int paramInt1, int paramInt2) {
/*  22 */     abw abw = paramaab.e(paramInt1, paramInt2);
/*  23 */     int i = paramInt1 * 16 + paramaab.s.nextInt(16);
/*  24 */     int j = paramInt2 * 16 + paramaab.s.nextInt(16);
/*  25 */     int k = paramaab.s.nextInt((abw == null) ? paramaab.R() : (abw.h() + 16 - 1));
/*     */     
/*  27 */     return new aat(i, k, j);
/*     */   }
/*     */   
/*  30 */   private static HashMap b = new HashMap<Object, Object>();
/*     */   
/*     */   public static final int a(iz paramiz, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3) {
/*  33 */     if (!paramBoolean1 && !paramBoolean2) {
/*  34 */       return 0;
/*     */     }
/*     */     
/*  37 */     b.clear();
/*     */     int i;
/*  39 */     for (i = 0; i < paramiz.h.size(); i++) {
/*  40 */       sq sq = paramiz.h.get(i);
/*  41 */       int j = kx.c(sq.u / 16.0D);
/*  42 */       int k = kx.c(sq.w / 16.0D);
/*     */       
/*  44 */       byte b1 = 8;
/*  45 */       for (byte b2 = -b1; b2 <= b1; b2++) {
/*  46 */         for (byte b = -b1; b <= b1; b++) {
/*  47 */           boolean bool = (b2 == -b1 || b2 == b1 || b == -b1 || b == b1) ? true : false;
/*  48 */           zu zu = new zu(b2 + j, b + k);
/*  49 */           if (!bool) {
/*  50 */             b.put(zu, Boolean.valueOf(false));
/*  51 */           } else if (!b.containsKey(zu)) {
/*     */ 
/*     */             
/*  54 */             b.put(zu, Boolean.valueOf(true));
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*  59 */     i = 0;
/*  60 */     t t = paramiz.J();
/*     */     
/*  62 */     for (nn nn : nn.values()) {
/*     */       
/*  64 */       if ((!nn.d() || paramBoolean2) && (nn.d() || paramBoolean1) && (!nn.e() || paramBoolean3))
/*     */       {
/*     */ 
/*     */         
/*  68 */         if (paramiz.a(nn.a()) <= nn.b() * b.size() / 256)
/*     */         {
/*     */ 
/*     */           
/*  72 */           label90: for (zu zu : b.keySet()) {
/*     */             
/*  74 */             if (((Boolean)b.get(zu)).booleanValue()) {
/*     */               continue;
/*     */             }
/*     */ 
/*     */ 
/*     */             
/*  80 */             aat aat = a(paramiz, zu.a, zu.b);
/*  81 */             int j = aat.a;
/*  82 */             int k = aat.b;
/*  83 */             int m = aat.c;
/*     */             
/*  85 */             if (paramiz.u(j, k, m) || 
/*  86 */               paramiz.g(j, k, m) != nn.c())
/*     */               continue; 
/*  88 */             byte b1 = 0;
/*     */             
/*  90 */             for (byte b2 = 0; b2 < 3; b2++) {
/*  91 */               int n = j;
/*  92 */               int i1 = k;
/*  93 */               int i2 = m;
/*  94 */               byte b3 = 6;
/*     */               
/*  96 */               aaw aaw = null;
/*     */               
/*  98 */               for (byte b4 = 0; b4 < 4; b4++) {
/*  99 */                 n += paramiz.s.nextInt(b3) - paramiz.s.nextInt(b3);
/* 100 */                 i1 += paramiz.s.nextInt(1) - paramiz.s.nextInt(1);
/* 101 */                 i2 += paramiz.s.nextInt(b3) - paramiz.s.nextInt(b3);
/*     */                 
/* 103 */                 if (a(nn, paramiz, n, i1, i2)) {
/* 104 */                   float f1 = n + 0.5F;
/* 105 */                   float f2 = i1;
/* 106 */                   float f3 = i2 + 0.5F;
/* 107 */                   if (paramiz.a(f1, f2, f3, 24.0D) == null) {
/*     */ 
/*     */                     
/* 110 */                     float f4 = f1 - t.a;
/* 111 */                     float f5 = f2 - t.b;
/* 112 */                     float f6 = f3 - t.c;
/* 113 */                     float f7 = f4 * f4 + f5 * f5 + f6 * f6;
/* 114 */                     if (f7 >= 576.0F)
/*     */                     { ng ng;
/*     */ 
/*     */ 
/*     */                       
/* 119 */                       if (aaw == null) {
/* 120 */                         aaw = paramiz.a(nn, n, i1, i2);
/* 121 */                         if (aaw == null) {
/*     */                           break;
/*     */                         }
/*     */                       } 
/*     */ 
/*     */                       
/*     */                       try {
/* 128 */                         ng = aaw.b.getConstructor(new Class[] { aab.class }).newInstance(new Object[] { paramiz });
/* 129 */                       } catch (Exception exception) {
/* 130 */                         exception.printStackTrace();
/* 131 */                         return i;
/*     */                       } 
/*     */                       
/* 134 */                       ng.b(f1, f2, f3, paramiz.s.nextFloat() * 360.0F, 0.0F);
/*     */                       
/* 136 */                       if (ng.bv()) {
/* 137 */                         b1++;
/* 138 */                         paramiz.d(ng);
/* 139 */                         a(ng, paramiz, f1, f2, f3);
/* 140 */                         if (b1 >= ng.by())
/*     */                           continue label90; 
/* 142 */                       }  i += b1; } 
/*     */                   } 
/*     */                 } 
/*     */               } 
/*     */             } 
/*     */           }  }  } 
/* 148 */     }  return i;
/*     */   }
/*     */   
/*     */   public static boolean a(nn paramnn, aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 152 */     if (paramnn.c() == aif.h) {
/* 153 */       return (paramaab.g(paramInt1, paramInt2, paramInt3).d() && paramaab.g(paramInt1, paramInt2 - 1, paramInt3).d() && !paramaab.u(paramInt1, paramInt2 + 1, paramInt3));
/*     */     }
/* 155 */     if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) return false; 
/* 156 */     int i = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/* 157 */     return (i != apa.D.cz && !paramaab.u(paramInt1, paramInt2, paramInt3) && !paramaab.g(paramInt1, paramInt2, paramInt3).d() && !paramaab.u(paramInt1, paramInt2 + 1, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   private static void a(ng paramng, aab paramaab, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 162 */     paramng.bJ();
/*     */   }
/*     */ 
/*     */   
/* 166 */   protected static final Class[] a = new Class[] { sh.class, sj.class, sf.class };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void a(aab paramaab, aav paramaav, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Random paramRandom) {
/* 263 */     List list = paramaav.a(nn.b);
/* 264 */     if (list.isEmpty()) {
/*     */       return;
/*     */     }
/*     */     
/* 268 */     while (paramRandom.nextFloat() < paramaav.f()) {
/*     */       
/* 270 */       aaw aaw = (aaw)ln.a(paramaab.s, list);
/* 271 */       int i = aaw.c + paramRandom.nextInt(1 + aaw.d - aaw.c);
/*     */       
/* 273 */       int j = paramInt1 + paramRandom.nextInt(paramInt3);
/* 274 */       int k = paramInt2 + paramRandom.nextInt(paramInt4);
/* 275 */       int m = j, n = k;
/*     */       
/* 277 */       for (byte b = 0; b < i; b++) {
/* 278 */         boolean bool = false;
/* 279 */         for (byte b1 = 0; !bool && b1 < 4; b1++) {
/*     */           
/* 281 */           int i1 = paramaab.i(j, k);
/* 282 */           if (a(nn.b, paramaab, j, i1, k)) {
/*     */             ng ng;
/* 284 */             float f1 = j + 0.5F;
/* 285 */             float f2 = i1;
/* 286 */             float f3 = k + 0.5F;
/*     */ 
/*     */             
/*     */             try {
/* 290 */               ng = aaw.b.getConstructor(new Class[] { aab.class }).newInstance(new Object[] { paramaab });
/* 291 */             } catch (Exception exception) {
/* 292 */               exception.printStackTrace();
/*     */             } 
/*     */ 
/*     */             
/* 296 */             ng.b(f1, f2, f3, paramRandom.nextFloat() * 360.0F, 0.0F);
/*     */             
/* 298 */             paramaab.d(ng);
/* 299 */             a(ng, paramaab, f1, f2, f3);
/* 300 */             bool = true;
/*     */           } 
/*     */           
/* 303 */           j += paramRandom.nextInt(5) - paramRandom.nextInt(5);
/* 304 */           k += paramRandom.nextInt(5) - paramRandom.nextInt(5);
/* 305 */           while (j < paramInt1 || j >= paramInt1 + paramInt3 || k < paramInt2 || k >= paramInt2 + paramInt3) {
/* 306 */             j = m + paramRandom.nextInt(5) - paramRandom.nextInt(5);
/* 307 */             k = n + paramRandom.nextInt(5) - paramRandom.nextInt(5);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aan.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */