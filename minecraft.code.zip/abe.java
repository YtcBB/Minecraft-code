/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class abe
/*    */   extends aav
/*    */ {
/*    */   public abe(int paramInt) {
/* 11 */     super(paramInt);
/* 12 */     this.K.add(new aaw(qu.class, 5, 4, 4));
/* 13 */     this.I.z = 10;
/* 14 */     this.I.B = 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public adj a(Random paramRandom) {
/* 19 */     if (paramRandom.nextInt(5) == 0) {
/* 20 */       return this.Q;
/*    */     }
/* 22 */     if (paramRandom.nextInt(10) == 0) {
/* 23 */       return this.P;
/*    */     }
/* 25 */     return this.O;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abe.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */