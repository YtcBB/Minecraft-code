/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aeu
/*    */ {
/* 44 */   private static final afi[] a = new afi[] { new afi(aex.class, 30, 0, true), new afi(aev.class, 10, 4), new afi(afj.class, 10, 4), new afi(afk.class, 10, 3), new afi(afg.class, 5, 2), new afi(afa.class, 5, 1) };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 52 */   private static final afi[] b = new afi[] { new afi(afd.class, 25, 0, true), new afi(afb.class, 15, 5), new afi(afe.class, 5, 10), new afi(afc.class, 5, 10), new afi(aey.class, 10, 3, true), new afi(aez.class, 7, 2), new afi(aff.class, 5, 2) };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   private static afh b(afi paramafi, List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*    */     aff aff;
/* 65 */     Class<aex> clazz = paramafi.a;
/* 66 */     aex aex = null;
/*    */     
/* 68 */     if (clazz == aex.class) {
/* 69 */       aex = aex.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 70 */     } else if (clazz == aev.class) {
/* 71 */       aev aev = aev.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 72 */     } else if (clazz == afj.class) {
/* 73 */       afj afj = afj.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 74 */     } else if (clazz == afk.class) {
/* 75 */       afk afk = afk.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 76 */     } else if (clazz == afg.class) {
/* 77 */       afg afg = afg.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 78 */     } else if (clazz == afa.class) {
/* 79 */       afa afa = afa.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 80 */     } else if (clazz == afd.class) {
/* 81 */       afd afd = afd.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 82 */     } else if (clazz == afe.class) {
/* 83 */       afe afe = afe.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 84 */     } else if (clazz == afc.class) {
/* 85 */       afc afc = afc.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 86 */     } else if (clazz == aey.class) {
/* 87 */       aey aey = aey.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 88 */     } else if (clazz == aez.class) {
/* 89 */       aez aez = aez.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 90 */     } else if (clazz == afb.class) {
/* 91 */       afb afb = afb.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 92 */     } else if (clazz == aff.class) {
/* 93 */       aff = aff.a(paramList, paramRandom, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*    */     } 
/* 95 */     return aff;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aeu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */