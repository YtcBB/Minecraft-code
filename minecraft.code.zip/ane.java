/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ane
/*     */   extends apa
/*     */ {
/*     */   private lx[] a;
/*     */   
/*     */   protected ane(int paramInt, aif paramaif) {
/*  22 */     super(paramInt, paramaif);
/*  23 */     float f1 = 0.0F;
/*  24 */     float f2 = 0.0F;
/*     */     
/*  26 */     a(0.0F + f2, 0.0F + f1, 0.0F + f2, 1.0F + f2, 1.0F + f1, 1.0F + f2);
/*  27 */     b(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  32 */     return (this.cO != aif.i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int o() {
/*  37 */     return 16777215;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  42 */     if (this.cO == aif.h) {
/*  43 */       int i = 0;
/*  44 */       int j = 0;
/*  45 */       int k = 0;
/*     */       
/*  47 */       for (byte b = -1; b <= 1; b++) {
/*  48 */         for (byte b1 = -1; b1 <= 1; b1++) {
/*  49 */           int m = (paramaak.a(paramInt1 + b1, paramInt3 + b)).H;
/*     */           
/*  51 */           i += (m & 0xFF0000) >> 16;
/*  52 */           j += (m & 0xFF00) >> 8;
/*  53 */           k += m & 0xFF;
/*     */         } 
/*     */       } 
/*     */       
/*  57 */       return (i / 9 & 0xFF) << 16 | (j / 9 & 0xFF) << 8 | k / 9 & 0xFF;
/*     */     } 
/*  59 */     return 16777215;
/*     */   }
/*     */   
/*     */   public static float d(int paramInt) {
/*  63 */     if (paramInt >= 8) paramInt = 0; 
/*  64 */     return (paramInt + 1) / 9.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  69 */     if (paramInt1 == 0 || paramInt1 == 1) {
/*  70 */       return this.a[0];
/*     */     }
/*  72 */     return this.a[1];
/*     */   }
/*     */ 
/*     */   
/*     */   protected int k_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  77 */     if (paramaab.g(paramInt1, paramInt2, paramInt3) == this.cO) return paramaab.h(paramInt1, paramInt2, paramInt3); 
/*  78 */     return -1;
/*     */   }
/*     */   
/*     */   protected int d(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  82 */     if (paramaak.g(paramInt1, paramInt2, paramInt3) != this.cO) return -1; 
/*  83 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*  84 */     if (i >= 8) i = 0; 
/*  85 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  90 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  95 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt, boolean paramBoolean) {
/* 100 */     return (paramBoolean && paramInt == 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a_(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 105 */     aif aif = paramaak.g(paramInt1, paramInt2, paramInt3);
/* 106 */     if (aif == this.cO) return false; 
/* 107 */     if (paramInt4 == 1) return true; 
/* 108 */     if (aif == aif.v) return false; 
/* 109 */     return super.a_(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 114 */     aif aif = paramaak.g(paramInt1, paramInt2, paramInt3);
/* 115 */     if (aif == this.cO) return false; 
/* 116 */     if (paramInt4 == 1) {
/* 117 */       return true;
/*     */     }
/* 119 */     if (aif == aif.v) return false; 
/* 120 */     return super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 125 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 130 */     return 4;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 135 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 140 */     return 0;
/*     */   }
/*     */   
/*     */   private arc g(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 144 */     arc arc = paramaak.U().a(0.0D, 0.0D, 0.0D);
/* 145 */     int i = d(paramaak, paramInt1, paramInt2, paramInt3); byte b;
/* 146 */     for (b = 0; b < 4; b++) {
/*     */       
/* 148 */       int j = paramInt1;
/* 149 */       int k = paramInt2;
/* 150 */       int m = paramInt3;
/*     */       
/* 152 */       if (b == 0) j--; 
/* 153 */       if (b == 1) m--; 
/* 154 */       if (b == 2) j++; 
/* 155 */       if (b == 3) m++;
/*     */       
/* 157 */       int n = d(paramaak, j, k, m);
/* 158 */       if (n < 0) {
/* 159 */         if (!paramaak.g(j, k, m).c()) {
/* 160 */           n = d(paramaak, j, k - 1, m);
/* 161 */           if (n >= 0) {
/* 162 */             int i1 = n - i - 8;
/* 163 */             arc = arc.c(((j - paramInt1) * i1), ((k - paramInt2) * i1), ((m - paramInt3) * i1));
/*     */           }
/*     */         
/*     */         } 
/* 167 */       } else if (n >= 0) {
/* 168 */         int i1 = n - i;
/* 169 */         arc = arc.c(((j - paramInt1) * i1), ((k - paramInt2) * i1), ((m - paramInt3) * i1));
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 174 */     if (paramaak.h(paramInt1, paramInt2, paramInt3) >= 8) {
/* 175 */       b = 0;
/* 176 */       if (b != 0 || a_(paramaak, paramInt1, paramInt2, paramInt3 - 1, 2)) b = 1; 
/* 177 */       if (b != 0 || a_(paramaak, paramInt1, paramInt2, paramInt3 + 1, 3)) b = 1; 
/* 178 */       if (b != 0 || a_(paramaak, paramInt1 - 1, paramInt2, paramInt3, 4)) b = 1; 
/* 179 */       if (b != 0 || a_(paramaak, paramInt1 + 1, paramInt2, paramInt3, 5)) b = 1; 
/* 180 */       if (b != 0 || a_(paramaak, paramInt1, paramInt2 + 1, paramInt3 - 1, 2)) b = 1; 
/* 181 */       if (b != 0 || a_(paramaak, paramInt1, paramInt2 + 1, paramInt3 + 1, 3)) b = 1; 
/* 182 */       if (b != 0 || a_(paramaak, paramInt1 - 1, paramInt2 + 1, paramInt3, 4)) b = 1; 
/* 183 */       if (b != 0 || a_(paramaak, paramInt1 + 1, paramInt2 + 1, paramInt3, 5)) b = 1; 
/* 184 */       if (b != 0) arc = arc.a().c(0.0D, -6.0D, 0.0D); 
/*     */     } 
/* 186 */     arc = arc.a();
/* 187 */     return arc;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp, arc paramarc) {
/* 192 */     arc arc1 = g(paramaab, paramInt1, paramInt2, paramInt3);
/* 193 */     paramarc.c += arc1.c;
/* 194 */     paramarc.d += arc1.d;
/* 195 */     paramarc.e += arc1.e;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/* 200 */     if (this.cO == aif.h) return 5; 
/* 201 */     if (this.cO == aif.i) {
/* 202 */       if (paramaab.t.f) {
/* 203 */         return 10;
/*     */       }
/* 205 */       return 30;
/*     */     } 
/*     */     
/* 208 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int e(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 213 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3, 0);
/* 214 */     int j = paramaak.h(paramInt1, paramInt2 + 1, paramInt3, 0);
/*     */     
/* 216 */     int k = i & 0xFF;
/* 217 */     int m = j & 0xFF;
/* 218 */     int n = i >> 16 & 0xFF;
/* 219 */     int i1 = j >> 16 & 0xFF;
/*     */     
/* 221 */     return ((k > m) ? k : m) | ((n > i1) ? n : i1) << 16;
/*     */   }
/*     */ 
/*     */   
/*     */   public float f(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 226 */     float f1 = paramaak.q(paramInt1, paramInt2, paramInt3);
/* 227 */     float f2 = paramaak.q(paramInt1, paramInt2 + 1, paramInt3);
/* 228 */     return (f1 > f2) ? f1 : f2;
/*     */   }
/*     */ 
/*     */   
/*     */   public int n() {
/* 233 */     return (this.cO == aif.h) ? 1 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 238 */     if (this.cO == aif.h) {
/* 239 */       if (paramRandom.nextInt(10) == 0) {
/* 240 */         int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 241 */         if (i <= 0 || i >= 8) {
/* 242 */           paramaab.a("suspended", (paramInt1 + paramRandom.nextFloat()), (paramInt2 + paramRandom.nextFloat()), (paramInt3 + paramRandom.nextFloat()), 0.0D, 0.0D, 0.0D);
/*     */         }
/*     */       } 
/* 245 */       for (byte b = 0; b; b++) {
/*     */ 
/*     */         
/* 248 */         int i = paramRandom.nextInt(4);
/* 249 */         int j = paramInt1;
/* 250 */         int k = paramInt3;
/* 251 */         if (i == 0) j--; 
/* 252 */         if (i == 1) j++; 
/* 253 */         if (i == 2) k--; 
/* 254 */         if (i == 3) k++; 
/* 255 */         if (paramaab.g(j, paramInt2, k) == aif.a && (paramaab.g(j, paramInt2 - 1, k).c() || paramaab.g(j, paramInt2 - 1, k).d())) {
/* 256 */           float f = 0.0625F;
/* 257 */           double d1 = (paramInt1 + paramRandom.nextFloat());
/* 258 */           double d2 = (paramInt2 + paramRandom.nextFloat());
/* 259 */           double d3 = (paramInt3 + paramRandom.nextFloat());
/* 260 */           if (i == 0) d1 = (paramInt1 - f); 
/* 261 */           if (i == 1) d1 = ((paramInt1 + 1) + f); 
/* 262 */           if (i == 2) d3 = (paramInt3 - f); 
/* 263 */           if (i == 3) d3 = ((paramInt3 + 1) + f);
/*     */           
/* 265 */           double d4 = 0.0D;
/* 266 */           double d5 = 0.0D;
/*     */           
/* 268 */           if (i == 0) d4 = -f; 
/* 269 */           if (i == 1) d4 = f; 
/* 270 */           if (i == 2) d5 = -f; 
/* 271 */           if (i == 3) d5 = f;
/*     */           
/* 273 */           paramaab.a("splash", d1, d2, d3, d4, 0.0D, d5);
/*     */         } 
/*     */       } 
/*     */     } 
/* 277 */     if (this.cO == aif.h && paramRandom.nextInt(64) == 0) {
/* 278 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 279 */       if (i > 0 && i < 8) {
/* 280 */         paramaab.a((paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), "liquid.water", paramRandom.nextFloat() * 0.25F + 0.75F, paramRandom.nextFloat() * 1.0F + 0.5F, false);
/*     */       }
/*     */     } 
/* 283 */     if (this.cO == aif.i && 
/* 284 */       paramaab.g(paramInt1, paramInt2 + 1, paramInt3) == aif.a && !paramaab.t(paramInt1, paramInt2 + 1, paramInt3)) {
/* 285 */       if (paramRandom.nextInt(100) == 0) {
/* 286 */         double d1 = (paramInt1 + paramRandom.nextFloat());
/* 287 */         double d2 = paramInt2 + this.cK;
/* 288 */         double d3 = (paramInt3 + paramRandom.nextFloat());
/* 289 */         paramaab.a("lava", d1, d2, d3, 0.0D, 0.0D, 0.0D);
/* 290 */         paramaab.a(d1, d2, d3, "liquid.lavapop", 0.2F + paramRandom.nextFloat() * 0.2F, 0.9F + paramRandom.nextFloat() * 0.15F, false);
/*     */       } 
/* 292 */       if (paramRandom.nextInt(200) == 0) {
/* 293 */         paramaab.a(paramInt1, paramInt2, paramInt3, "liquid.lava", 0.2F + paramRandom.nextFloat() * 0.2F, 0.9F + paramRandom.nextFloat() * 0.15F, false);
/*     */       }
/*     */     } 
/*     */     
/* 297 */     if (paramRandom.nextInt(10) == 0 && 
/* 298 */       paramaab.w(paramInt1, paramInt2 - 1, paramInt3) && !paramaab.g(paramInt1, paramInt2 - 2, paramInt3).c()) {
/* 299 */       double d1 = (paramInt1 + paramRandom.nextFloat());
/* 300 */       double d2 = paramInt2 - 1.05D;
/* 301 */       double d3 = (paramInt3 + paramRandom.nextFloat());
/*     */       
/* 303 */       if (this.cO == aif.h) { paramaab.a("dripWater", d1, d2, d3, 0.0D, 0.0D, 0.0D); }
/* 304 */       else { paramaab.a("dripLava", d1, d2, d3, 0.0D, 0.0D, 0.0D); }
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public static double a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, aif paramaif) {
/* 310 */     arc arc = null;
/* 311 */     if (paramaif == aif.h) arc = apa.E.g(paramaak, paramInt1, paramInt2, paramInt3); 
/* 312 */     if (paramaif == aif.i) arc = apa.G.g(paramaak, paramInt1, paramInt2, paramInt3); 
/* 313 */     if (arc.c == 0.0D && arc.e == 0.0D) return -1000.0D; 
/* 314 */     return Math.atan2(arc.e, arc.c) - 1.5707963267948966D;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 319 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 324 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 328 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) != this.cz)
/* 329 */       return;  if (this.cO == aif.i) {
/* 330 */       boolean bool = false;
/* 331 */       if (bool || paramaab.g(paramInt1, paramInt2, paramInt3 - 1) == aif.h) bool = true; 
/* 332 */       if (bool || paramaab.g(paramInt1, paramInt2, paramInt3 + 1) == aif.h) bool = true; 
/* 333 */       if (bool || paramaab.g(paramInt1 - 1, paramInt2, paramInt3) == aif.h) bool = true; 
/* 334 */       if (bool || paramaab.g(paramInt1 + 1, paramInt2, paramInt3) == aif.h) bool = true; 
/* 335 */       if (bool || paramaab.g(paramInt1, paramInt2 + 1, paramInt3) == aif.h) bool = true; 
/* 336 */       if (bool) {
/* 337 */         int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 338 */         if (i == 0) {
/* 339 */           paramaab.c(paramInt1, paramInt2, paramInt3, apa.at.cz);
/* 340 */         } else if (i <= 4) {
/* 341 */           paramaab.c(paramInt1, paramInt2, paramInt3, apa.A.cz);
/*     */         } 
/* 343 */         j(paramaab, paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void j(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 349 */     paramaab.a((paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), "random.fizz", 0.5F, 2.6F + (paramaab.s.nextFloat() - paramaab.s.nextFloat()) * 0.8F);
/* 350 */     for (byte b = 0; b < 8; b++) {
/* 351 */       paramaab.a("largesmoke", paramInt1 + Math.random(), paramInt2 + 1.2D, paramInt3 + Math.random(), 0.0D, 0.0D, 0.0D);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 357 */     if (this.cO == aif.i) {
/* 358 */       this.a = new lx[] { paramly.a("lava"), paramly.a("lava_flow") };
/*     */     }
/*     */     else {
/*     */       
/* 362 */       this.a = new lx[] { paramly.a("water"), paramly.a("water_flow") };
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static lx b(String paramString) {
/* 369 */     if (paramString == "water") return apa.E.a[0]; 
/* 370 */     if (paramString == "water_flow") return apa.E.a[1]; 
/* 371 */     if (paramString == "lava") return apa.G.a[0]; 
/* 372 */     if (paramString == "lava_flow") return apa.G.a[1]; 
/* 373 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ane.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */