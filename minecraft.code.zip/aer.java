/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aer
/*    */   extends agy
/*    */ {
/*    */   public aer(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 13 */     aep aep = new aep(0, paramRandom, (paramInt1 << 4) + 2, (paramInt2 << 4) + 2);
/* 14 */     this.a.add(aep);
/* 15 */     aep.a(aep, this.a, paramRandom);
/*    */     
/* 17 */     c();
/* 18 */     a(paramaab, paramRandom, 10);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */