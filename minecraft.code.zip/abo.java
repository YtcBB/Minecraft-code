/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class abo
/*    */   extends aav
/*    */ {
/*    */   public abo(int paramInt) {
/* 11 */     super(paramInt);
/*    */     
/* 13 */     this.K.add(new aaw(qu.class, 8, 4, 4));
/*    */     
/* 15 */     this.I.z = 10;
/* 16 */     this.I.B = 1;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public adj a(Random paramRandom) {
/* 22 */     if (paramRandom.nextInt(3) == 0) {
/* 23 */       return new adw();
/*    */     }
/* 25 */     return new aec(false);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */