/*    */ 
/*    */ 
/*    */ public class aal
/*    */ {
/*  5 */   public static final aal[] a = new aal[16];
/*    */   
/*  7 */   public static final aal b = (new aal(0, "default", 1)).g();
/*  8 */   public static final aal c = new aal(1, "flat");
/*  9 */   public static final aal d = new aal(2, "largeBiomes");
/*    */   
/* 11 */   public static final aal e = (new aal(8, "default_1_1", 0)).a(false);
/*    */   
/*    */   private final int f;
/*    */   private final String g;
/*    */   private final int h;
/*    */   private boolean i;
/*    */   private boolean j;
/*    */   
/*    */   private aal(int paramInt, String paramString) {
/* 20 */     this(paramInt, paramString, 0);
/*    */   }
/*    */   
/*    */   private aal(int paramInt1, String paramString, int paramInt2) {
/* 24 */     this.g = paramString;
/* 25 */     this.h = paramInt2;
/* 26 */     this.i = true;
/* 27 */     this.f = paramInt1;
/* 28 */     a[paramInt1] = this;
/*    */   }
/*    */   
/*    */   public String a() {
/* 32 */     return this.g;
/*    */   }
/*    */   
/*    */   public String b() {
/* 36 */     return "generator." + this.g;
/*    */   }
/*    */   
/*    */   public int c() {
/* 40 */     return this.h;
/*    */   }
/*    */   
/*    */   public aal a(int paramInt) {
/* 44 */     if (this == b && paramInt == 0) {
/* 45 */       return e;
/*    */     }
/* 47 */     return this;
/*    */   }
/*    */   
/*    */   private aal a(boolean paramBoolean) {
/* 51 */     this.i = paramBoolean;
/* 52 */     return this;
/*    */   }
/*    */   
/*    */   public boolean d() {
/* 56 */     return this.i;
/*    */   }
/*    */   
/*    */   private aal g() {
/* 60 */     this.j = true;
/* 61 */     return this;
/*    */   }
/*    */   
/*    */   public boolean e() {
/* 65 */     return this.j;
/*    */   }
/*    */   
/*    */   public static aal a(String paramString) {
/* 69 */     for (byte b = 0; b < a.length; b++) {
/* 70 */       if (a[b] != null && (a[b]).g.equalsIgnoreCase(paramString)) {
/* 71 */         return a[b];
/*    */       }
/*    */     } 
/* 74 */     return null;
/*    */   }
/*    */   
/*    */   public int f() {
/* 78 */     return this.f;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aal.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */