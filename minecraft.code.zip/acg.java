/*     */ import java.io.BufferedInputStream;
/*     */ import java.io.ByteArrayInputStream;
/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.IOException;
/*     */ import java.io.RandomAccessFile;
/*     */ import java.util.ArrayList;
/*     */ import java.util.zip.DeflaterOutputStream;
/*     */ import java.util.zip.GZIPInputStream;
/*     */ import java.util.zip.InflaterInputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class acg
/*     */ {
/*  74 */   private static final byte[] a = new byte[4096];
/*     */   
/*     */   private final File b;
/*     */   private RandomAccessFile c;
/*     */   private final int[] d;
/*     */   private final int[] e;
/*     */   private ArrayList f;
/*     */   private int g;
/*  82 */   private long h = 0L;
/*     */   
/*     */   public acg(File paramFile) {
/*  85 */     this.d = new int[1024];
/*  86 */     this.e = new int[1024];
/*     */     
/*  88 */     this.b = paramFile;
/*     */     
/*  90 */     this.g = 0;
/*     */     
/*     */     try {
/*  93 */       if (paramFile.exists()) {
/*  94 */         this.h = paramFile.lastModified();
/*     */       }
/*     */       
/*  97 */       this.c = new RandomAccessFile(paramFile, "rw");
/*     */       
/*  99 */       if (this.c.length() < 4096L) {
/*     */         byte b1;
/* 101 */         for (b1 = 0; b1 < 'Ѐ'; b1++) {
/* 102 */           this.c.writeInt(0);
/*     */         }
/*     */         
/* 105 */         for (b1 = 0; b1 < 'Ѐ'; b1++) {
/* 106 */           this.c.writeInt(0);
/*     */         }
/*     */         
/* 109 */         this.g += 8192;
/*     */       } 
/*     */       
/* 112 */       if ((this.c.length() & 0xFFFL) != 0L)
/*     */       {
/* 114 */         for (byte b1 = 0; b1 < (this.c.length() & 0xFFFL); b1++) {
/* 115 */           this.c.write(0);
/*     */         }
/*     */       }
/*     */ 
/*     */       
/* 120 */       int i = (int)this.c.length() / 4096;
/* 121 */       this.f = new ArrayList(i);
/*     */       byte b;
/* 123 */       for (b = 0; b < i; b++) {
/* 124 */         this.f.add(Boolean.valueOf(true));
/*     */       }
/*     */       
/* 127 */       this.f.set(0, Boolean.valueOf(false));
/* 128 */       this.f.set(1, Boolean.valueOf(false));
/*     */       
/* 130 */       this.c.seek(0L);
/* 131 */       for (b = 0; b < 'Ѐ'; b++) {
/* 132 */         int j = this.c.readInt();
/* 133 */         this.d[b] = j;
/* 134 */         if (j != 0 && (j >> 8) + (j & 0xFF) <= this.f.size()) {
/* 135 */           for (byte b1 = 0; b1 < (j & 0xFF); b1++) {
/* 136 */             this.f.set((j >> 8) + b1, Boolean.valueOf(false));
/*     */           }
/*     */         }
/*     */       } 
/* 140 */       for (b = 0; b < 'Ѐ'; b++) {
/* 141 */         int j = this.c.readInt();
/* 142 */         this.e[b] = j;
/*     */       } 
/* 144 */     } catch (IOException iOException) {
/* 145 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public synchronized DataInputStream a(int paramInt1, int paramInt2) {
/* 166 */     if (d(paramInt1, paramInt2)) {
/* 167 */       return null;
/*     */     }
/*     */     
/*     */     try {
/* 171 */       int i = e(paramInt1, paramInt2);
/* 172 */       if (i == 0) {
/* 173 */         return null;
/*     */       }
/*     */       
/* 176 */       int j = i >> 8;
/* 177 */       int k = i & 0xFF;
/*     */       
/* 179 */       if (j + k > this.f.size()) {
/* 180 */         return null;
/*     */       }
/*     */       
/* 183 */       this.c.seek((j * 4096));
/* 184 */       int m = this.c.readInt();
/*     */       
/* 186 */       if (m > 4096 * k)
/* 187 */         return null; 
/* 188 */       if (m <= 0) {
/* 189 */         return null;
/*     */       }
/*     */       
/* 192 */       byte b = this.c.readByte();
/* 193 */       if (b == 1) {
/* 194 */         byte[] arrayOfByte = new byte[m - 1];
/* 195 */         this.c.read(arrayOfByte);
/* 196 */         return new DataInputStream(new BufferedInputStream(new GZIPInputStream(new ByteArrayInputStream(arrayOfByte))));
/* 197 */       }  if (b == 2) {
/* 198 */         byte[] arrayOfByte = new byte[m - 1];
/* 199 */         this.c.read(arrayOfByte);
/* 200 */         return new DataInputStream(new BufferedInputStream(new InflaterInputStream(new ByteArrayInputStream(arrayOfByte))));
/*     */       } 
/*     */       
/* 203 */       return null;
/* 204 */     } catch (IOException iOException) {
/* 205 */       return null;
/*     */     } 
/*     */   }
/*     */   
/*     */   public DataOutputStream b(int paramInt1, int paramInt2) {
/* 210 */     if (d(paramInt1, paramInt2)) return null;
/*     */     
/* 212 */     return new DataOutputStream(new DeflaterOutputStream(new ach(this, paramInt1, paramInt2)));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected synchronized void a(int paramInt1, int paramInt2, byte[] paramArrayOfbyte, int paramInt3) {
/*     */     try {
/* 237 */       int i = e(paramInt1, paramInt2);
/* 238 */       int j = i >> 8;
/* 239 */       int k = i & 0xFF;
/* 240 */       int m = (paramInt3 + 5) / 4096 + 1;
/*     */ 
/*     */       
/* 243 */       if (m >= 256) {
/*     */         return;
/*     */       }
/*     */       
/* 247 */       if (j != 0 && k == m) {
/*     */         
/* 249 */         a(j, paramArrayOfbyte, paramInt3);
/*     */       } else {
/*     */         int n;
/*     */ 
/*     */         
/* 254 */         for (n = 0; n < k; n++) {
/* 255 */           this.f.set(j + n, Boolean.valueOf(true));
/*     */         }
/*     */ 
/*     */         
/* 259 */         n = this.f.indexOf(Boolean.valueOf(true));
/* 260 */         byte b = 0;
/* 261 */         if (n != -1) {
/* 262 */           for (int i1 = n; i1 < this.f.size(); i1++) {
/* 263 */             if (b) {
/* 264 */               if (((Boolean)this.f.get(i1)).booleanValue()) { b++; }
/* 265 */               else { b = 0; } 
/* 266 */             } else if (((Boolean)this.f.get(i1)).booleanValue()) {
/* 267 */               n = i1;
/* 268 */               b = 1;
/*     */             } 
/* 270 */             if (b >= m) {
/*     */               break;
/*     */             }
/*     */           } 
/*     */         }
/*     */         
/* 276 */         if (b >= m) {
/*     */           
/* 278 */           j = n;
/* 279 */           a(paramInt1, paramInt2, j << 8 | m);
/* 280 */           for (byte b1 = 0; b1 < m; b1++) {
/* 281 */             this.f.set(j + b1, Boolean.valueOf(false));
/*     */           }
/* 283 */           a(j, paramArrayOfbyte, paramInt3);
/*     */         } else {
/*     */           
/* 286 */           this.c.seek(this.c.length());
/* 287 */           j = this.f.size();
/* 288 */           for (byte b1 = 0; b1 < m; b1++) {
/* 289 */             this.c.write(a);
/* 290 */             this.f.add(Boolean.valueOf(false));
/*     */           } 
/* 292 */           this.g += 4096 * m;
/*     */           
/* 294 */           a(j, paramArrayOfbyte, paramInt3);
/* 295 */           a(paramInt1, paramInt2, j << 8 | m);
/*     */         } 
/*     */       } 
/* 298 */       b(paramInt1, paramInt2, (int)(System.currentTimeMillis() / 1000L));
/* 299 */     } catch (IOException iOException) {
/* 300 */       iOException.printStackTrace();
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void a(int paramInt1, byte[] paramArrayOfbyte, int paramInt2) {
/* 306 */     this.c.seek((paramInt1 * 4096));
/* 307 */     this.c.writeInt(paramInt2 + 1);
/* 308 */     this.c.writeByte(2);
/* 309 */     this.c.write(paramArrayOfbyte, 0, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean d(int paramInt1, int paramInt2) {
/* 314 */     return (paramInt1 < 0 || paramInt1 >= 32 || paramInt2 < 0 || paramInt2 >= 32);
/*     */   }
/*     */   
/*     */   private int e(int paramInt1, int paramInt2) {
/* 318 */     return this.d[paramInt1 + paramInt2 * 32];
/*     */   }
/*     */   
/*     */   public boolean c(int paramInt1, int paramInt2) {
/* 322 */     return (e(paramInt1, paramInt2) != 0);
/*     */   }
/*     */   
/*     */   private void a(int paramInt1, int paramInt2, int paramInt3) {
/* 326 */     this.d[paramInt1 + paramInt2 * 32] = paramInt3;
/* 327 */     this.c.seek(((paramInt1 + paramInt2 * 32) * 4));
/* 328 */     this.c.writeInt(paramInt3);
/*     */   }
/*     */   
/*     */   private void b(int paramInt1, int paramInt2, int paramInt3) {
/* 332 */     this.e[paramInt1 + paramInt2 * 32] = paramInt3;
/* 333 */     this.c.seek((4096 + (paramInt1 + paramInt2 * 32) * 4));
/* 334 */     this.c.writeInt(paramInt3);
/*     */   }
/*     */   
/*     */   public void c() {
/* 338 */     if (this.c != null) this.c.close(); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */