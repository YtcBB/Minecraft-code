/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aoo
/*    */   extends apa
/*    */ {
/*    */   protected aoo(int paramInt) {
/* 11 */     super(paramInt, aif.x);
/* 12 */     b(true);
/* 13 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 18 */     return wk.aE.cp;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 23 */     return 4;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 28 */     if (paramaab.b(aam.b, paramInt1, paramInt2, paramInt3) > 11) {
/* 29 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 30 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */