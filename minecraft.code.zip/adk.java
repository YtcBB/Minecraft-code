/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adk
/*    */   extends adj
/*    */ {
/*    */   private int a;
/*    */   
/*    */   public adk(int paramInt) {
/* 12 */     this.a = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 17 */     for (byte b = 0; b < 64; b++) {
/* 18 */       int i = paramInt1 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 19 */       int j = paramInt2 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 20 */       int k = paramInt3 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 21 */       if (paramaab.c(i, j, k) && (!paramaab.t.f || j < 127) && 
/* 22 */         apa.r[this.a].f(paramaab, i, j, k)) {
/* 23 */         paramaab.f(i, j, k, this.a, 0, 2);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 28 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */