/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aen
/*     */   extends agw
/*     */ {
/*     */   private final boolean a;
/*     */   private final boolean b;
/*     */   private boolean c;
/*     */   private int d;
/*     */   
/*     */   public aen(int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 174 */     super(paramInt1);
/* 175 */     this.f = paramInt2;
/* 176 */     this.e = paramaek;
/* 177 */     this.a = (paramRandom.nextInt(3) == 0);
/* 178 */     this.b = (!this.a && paramRandom.nextInt(23) == 0);
/*     */     
/* 180 */     if (this.f == 2 || this.f == 0) {
/* 181 */       this.d = paramaek.d() / 5;
/*     */     } else {
/* 183 */       this.d = paramaek.b() / 5;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public static aek a(List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 189 */     aek aek = new aek(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2 + 2, paramInt3);
/*     */     
/* 191 */     int i = paramRandom.nextInt(3) + 2;
/* 192 */     while (i > 0) {
/* 193 */       int j = i * 5;
/*     */       
/* 195 */       switch (paramInt4) {
/*     */         case 2:
/* 197 */           aek.d = paramInt1 + 2;
/* 198 */           aek.c = paramInt3 - j - 1;
/*     */           break;
/*     */         case 0:
/* 201 */           aek.d = paramInt1 + 2;
/* 202 */           aek.f = paramInt3 + j - 1;
/*     */           break;
/*     */         case 1:
/* 205 */           aek.a = paramInt1 - j - 1;
/* 206 */           aek.f = paramInt3 + 2;
/*     */           break;
/*     */         case 3:
/* 209 */           aek.d = paramInt1 + j - 1;
/* 210 */           aek.f = paramInt3 + 2;
/*     */           break;
/*     */       } 
/*     */       
/* 214 */       if (agw.a(paramList, aek) != null) {
/* 215 */         i--;
/*     */       }
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 221 */     if (i > 0) {
/* 222 */       return aek;
/*     */     }
/*     */     
/* 225 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/* 230 */     int i = c();
/* 231 */     int j = paramRandom.nextInt(4);
/* 232 */     switch (this.f) {
/*     */       case 2:
/* 234 */         if (j <= 1) {
/* 235 */           aem.a(paramagw, paramList, paramRandom, this.e.a, this.e.b - 1 + paramRandom.nextInt(3), this.e.c - 1, this.f, i); break;
/* 236 */         }  if (j == 2) {
/* 237 */           aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b - 1 + paramRandom.nextInt(3), this.e.c, 1, i); break;
/*     */         } 
/* 239 */         aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b - 1 + paramRandom.nextInt(3), this.e.c, 3, i);
/*     */         break;
/*     */       
/*     */       case 0:
/* 243 */         if (j <= 1) {
/* 244 */           aem.a(paramagw, paramList, paramRandom, this.e.a, this.e.b - 1 + paramRandom.nextInt(3), this.e.f + 1, this.f, i); break;
/* 245 */         }  if (j == 2) {
/* 246 */           aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b - 1 + paramRandom.nextInt(3), this.e.f - 3, 1, i); break;
/*     */         } 
/* 248 */         aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b - 1 + paramRandom.nextInt(3), this.e.f - 3, 3, i);
/*     */         break;
/*     */       
/*     */       case 1:
/* 252 */         if (j <= 1) {
/* 253 */           aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b - 1 + paramRandom.nextInt(3), this.e.c, this.f, i); break;
/* 254 */         }  if (j == 2) {
/* 255 */           aem.a(paramagw, paramList, paramRandom, this.e.a, this.e.b - 1 + paramRandom.nextInt(3), this.e.c - 1, 2, i); break;
/*     */         } 
/* 257 */         aem.a(paramagw, paramList, paramRandom, this.e.a, this.e.b - 1 + paramRandom.nextInt(3), this.e.f + 1, 0, i);
/*     */         break;
/*     */       
/*     */       case 3:
/* 261 */         if (j <= 1) {
/* 262 */           aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b - 1 + paramRandom.nextInt(3), this.e.c, this.f, i); break;
/* 263 */         }  if (j == 2) {
/* 264 */           aem.a(paramagw, paramList, paramRandom, this.e.d - 3, this.e.b - 1 + paramRandom.nextInt(3), this.e.c - 1, 2, i); break;
/*     */         } 
/* 266 */         aem.a(paramagw, paramList, paramRandom, this.e.d - 3, this.e.b - 1 + paramRandom.nextInt(3), this.e.f + 1, 0, i);
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 272 */     if (i < 8) {
/* 273 */       if (this.f == 2 || this.f == 0) {
/* 274 */         for (int k = this.e.c + 3; k + 3 <= this.e.f; k += 5) {
/* 275 */           int m = paramRandom.nextInt(5);
/* 276 */           if (m == 0) {
/* 277 */             aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b, k, 1, i + 1);
/* 278 */           } else if (m == 1) {
/* 279 */             aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b, k, 3, i + 1);
/*     */           } 
/*     */         } 
/*     */       } else {
/* 283 */         for (int k = this.e.a + 3; k + 3 <= this.e.d; k += 5) {
/* 284 */           int m = paramRandom.nextInt(5);
/* 285 */           if (m == 0) {
/* 286 */             aem.a(paramagw, paramList, paramRandom, k, this.e.b, this.e.c - 1, 2, i + 1);
/* 287 */           } else if (m == 1) {
/* 288 */             aem.a(paramagw, paramList, paramRandom, k, this.e.b, this.e.f + 1, 0, i + 1);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean a(aab paramaab, aek paramaek, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, lp[] paramArrayOflp, int paramInt4) {
/* 297 */     int i = a(paramInt1, paramInt3);
/* 298 */     int j = a(paramInt2);
/* 299 */     int k = b(paramInt1, paramInt3);
/*     */     
/* 301 */     if (paramaek.b(i, j, k) && 
/* 302 */       paramaab.a(i, j, k) == 0) {
/* 303 */       paramaab.f(i, j, k, apa.aK.cz, c(apa.aK.cz, paramRandom.nextBoolean() ? 1 : 0), 2);
/* 304 */       rj rj = new rj(paramaab, (i + 0.5F), (j + 0.5F), (k + 0.5F));
/* 305 */       lp.a(paramRandom, paramArrayOflp, rj, paramInt4);
/* 306 */       paramaab.d(rj);
/* 307 */       return true;
/*     */     } 
/*     */ 
/*     */     
/* 311 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 317 */     if (a(paramaab, paramaek)) {
/* 318 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 325 */     int i = this.d * 5 - 1;
/*     */ 
/*     */     
/* 328 */     a(paramaab, paramaek, 0, 0, 0, 2, 1, i, 0, 0, false);
/* 329 */     a(paramaab, paramaek, paramRandom, 0.8F, 0, 2, 0, 2, 2, i, 0, 0, false);
/*     */     
/* 331 */     if (this.b) {
/* 332 */       a(paramaab, paramaek, paramRandom, 0.6F, 0, 0, 0, 2, 1, i, apa.aa.cz, 0, false);
/*     */     }
/*     */     
/*     */     byte b;
/* 336 */     for (b = 0; b < this.d; b++) {
/*     */       
/* 338 */       int j = 2 + b * 5;
/*     */       
/* 340 */       a(paramaab, paramaek, 0, 0, j, 0, 1, j, apa.bd.cz, 0, false);
/* 341 */       a(paramaab, paramaek, 2, 0, j, 2, 1, j, apa.bd.cz, 0, false);
/* 342 */       if (paramRandom.nextInt(4) == 0) {
/* 343 */         a(paramaab, paramaek, 0, 2, j, 0, 2, j, apa.B.cz, 0, false);
/* 344 */         a(paramaab, paramaek, 2, 2, j, 2, 2, j, apa.B.cz, 0, false);
/*     */       } else {
/* 346 */         a(paramaab, paramaek, 0, 2, j, 2, 2, j, apa.B.cz, 0, false);
/*     */       } 
/* 348 */       a(paramaab, paramaek, paramRandom, 0.1F, 0, 2, j - 1, apa.aa.cz, 0);
/* 349 */       a(paramaab, paramaek, paramRandom, 0.1F, 2, 2, j - 1, apa.aa.cz, 0);
/* 350 */       a(paramaab, paramaek, paramRandom, 0.1F, 0, 2, j + 1, apa.aa.cz, 0);
/* 351 */       a(paramaab, paramaek, paramRandom, 0.1F, 2, 2, j + 1, apa.aa.cz, 0);
/* 352 */       a(paramaab, paramaek, paramRandom, 0.05F, 0, 2, j - 2, apa.aa.cz, 0);
/* 353 */       a(paramaab, paramaek, paramRandom, 0.05F, 2, 2, j - 2, apa.aa.cz, 0);
/* 354 */       a(paramaab, paramaek, paramRandom, 0.05F, 0, 2, j + 2, apa.aa.cz, 0);
/* 355 */       a(paramaab, paramaek, paramRandom, 0.05F, 2, 2, j + 2, apa.aa.cz, 0);
/*     */       
/* 357 */       a(paramaab, paramaek, paramRandom, 0.05F, 1, 2, j - 1, apa.au.cz, 0);
/* 358 */       a(paramaab, paramaek, paramRandom, 0.05F, 1, 2, j + 1, apa.au.cz, 0);
/*     */       
/* 360 */       if (paramRandom.nextInt(100) == 0) {
/* 361 */         a(paramaab, paramaek, paramRandom, 2, 0, j - 1, lp.a(aem.a(), new lp[] { wk.bX.b(paramRandom) }), 3 + paramRandom.nextInt(4));
/*     */       }
/* 363 */       if (paramRandom.nextInt(100) == 0) {
/* 364 */         a(paramaab, paramaek, paramRandom, 0, 0, j + 1, lp.a(aem.a(), new lp[] { wk.bX.b(paramRandom) }), 3 + paramRandom.nextInt(4));
/*     */       }
/* 366 */       if (this.b && !this.c) {
/* 367 */         int k = a(0), m = j - 1 + paramRandom.nextInt(3);
/* 368 */         int n = a(1, m);
/* 369 */         m = b(1, m);
/* 370 */         if (paramaek.b(n, k, m)) {
/* 371 */           this.c = true;
/* 372 */           paramaab.f(n, k, m, apa.aw.cz, 0, 2);
/* 373 */           aqj aqj = (aqj)paramaab.r(n, k, m);
/* 374 */           if (aqj != null) aqj.a().a("CaveSpider");
/*     */         
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 380 */     for (b = 0; b <= 2; b++) {
/* 381 */       for (byte b1 = 0; b1 <= i; b1++) {
/* 382 */         int j = a(paramaab, b, -1, b1, paramaek);
/* 383 */         if (j == 0) {
/* 384 */           a(paramaab, apa.B.cz, 0, b, -1, b1, paramaek);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 389 */     if (this.a) {
/* 390 */       for (b = 0; b <= i; b++) {
/* 391 */         int j = a(paramaab, 1, -1, b, paramaek);
/* 392 */         if (j > 0 && apa.s[j]) {
/* 393 */           a(paramaab, paramaek, paramRandom, 0.7F, 1, 0, b, apa.aK.cz, c(apa.aK.cz, 0));
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 398 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aen.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */