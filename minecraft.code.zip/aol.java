/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aol
/*     */   extends akz
/*     */ {
/*     */   private Class a;
/*     */   private boolean b;
/*     */   
/*     */   protected aol(int paramInt, Class paramClass, boolean paramBoolean) {
/*  18 */     super(paramInt, aif.d);
/*  19 */     this.b = paramBoolean;
/*  20 */     this.a = paramClass;
/*  21 */     float f1 = 0.25F;
/*  22 */     float f2 = 1.0F;
/*  23 */     a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, f2, 0.5F + f1);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  28 */     return apa.B.m(paramInt1);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  33 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  38 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  39 */     return super.c_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  44 */     if (this.b)
/*     */       return; 
/*  46 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  48 */     float f1 = 0.28125F;
/*  49 */     float f2 = 0.78125F;
/*  50 */     float f3 = 0.0F;
/*  51 */     float f4 = 1.0F;
/*     */     
/*  53 */     float f5 = 0.125F;
/*     */     
/*  55 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*  56 */     if (i == 2) a(f3, f1, 1.0F - f5, f4, f2, 1.0F); 
/*  57 */     if (i == 3) a(f3, f1, 0.0F, f4, f2, f5); 
/*  58 */     if (i == 4) a(1.0F - f5, f1, f3, 1.0F, f2, f4); 
/*  59 */     if (i == 5) a(0.0F, f1, f3, f5, f2, f4);
/*     */   
/*     */   }
/*     */   
/*     */   public int d() {
/*  64 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  74 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  79 */     return false;
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/*     */     try {
/*  84 */       return this.a.newInstance();
/*  85 */     } catch (Exception exception) {
/*  86 */       throw new RuntimeException(exception);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  92 */     return wk.av.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  97 */     boolean bool = false;
/*     */     
/*  99 */     if (this.b) {
/* 100 */       if (!paramaab.g(paramInt1, paramInt2 - 1, paramInt3).a()) bool = true; 
/*     */     } else {
/* 102 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 103 */       bool = true;
/* 104 */       if (i == 2 && paramaab.g(paramInt1, paramInt2, paramInt3 + 1).a()) bool = false; 
/* 105 */       if (i == 3 && paramaab.g(paramInt1, paramInt2, paramInt3 - 1).a()) bool = false; 
/* 106 */       if (i == 4 && paramaab.g(paramInt1 + 1, paramInt2, paramInt3).a()) bool = false; 
/* 107 */       if (i == 5 && paramaab.g(paramInt1 - 1, paramInt2, paramInt3).a()) bool = false; 
/*     */     } 
/* 109 */     if (bool) {
/* 110 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 111 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/* 114 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 119 */     return wk.av.cp;
/*     */   }
/*     */   
/*     */   public void a(ly paramly) {}
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aol.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */