/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aor
/*     */   extends alh
/*     */ {
/*     */   private final apa a;
/*     */   private lx b;
/*     */   
/*     */   protected aor(int paramInt, apa paramapa) {
/*  18 */     super(paramInt);
/*     */     
/*  20 */     this.a = paramapa;
/*     */     
/*  22 */     b(true);
/*  23 */     float f = 0.125F;
/*  24 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.25F, 0.5F + f);
/*  25 */     a((ve)null);
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean f_(int paramInt) {
/*  30 */     return (paramInt == apa.aE.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  35 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*  36 */     if (paramaab.n(paramInt1, paramInt2 + 1, paramInt3) >= 9) {
/*     */       
/*  38 */       float f = m(paramaab, paramInt1, paramInt2, paramInt3);
/*     */       
/*  40 */       if (paramRandom.nextInt((int)(25.0F / f) + 1) == 0) {
/*  41 */         int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  42 */         if (i < 7) {
/*  43 */           i++;
/*  44 */           paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */         } else {
/*  46 */           if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == this.a.cz)
/*  47 */             return;  if (paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == this.a.cz)
/*  48 */             return;  if (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == this.a.cz)
/*  49 */             return;  if (paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == this.a.cz)
/*     */             return; 
/*  51 */           int j = paramRandom.nextInt(4);
/*  52 */           int k = paramInt1;
/*  53 */           int m = paramInt3;
/*  54 */           if (j == 0) k--; 
/*  55 */           if (j == 1) k++; 
/*  56 */           if (j == 2) m--; 
/*  57 */           if (j == 3) m++; 
/*  58 */           int n = paramaab.a(k, paramInt2 - 1, m);
/*  59 */           if (paramaab.a(k, paramInt2, m) == 0 && (n == apa.aE.cz || n == apa.z.cz || n == apa.y.cz)) {
/*  60 */             paramaab.c(k, paramInt2, m, this.a.cz);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  69 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3) + kx.a(paramaab.s, 2, 5);
/*  70 */     if (i > 7) i = 7; 
/*  71 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */   }
/*     */   
/*     */   private float m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  75 */     float f = 1.0F;
/*     */     
/*  77 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3 - 1);
/*  78 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3 + 1);
/*  79 */     int k = paramaab.a(paramInt1 - 1, paramInt2, paramInt3);
/*  80 */     int m = paramaab.a(paramInt1 + 1, paramInt2, paramInt3);
/*     */     
/*  82 */     int n = paramaab.a(paramInt1 - 1, paramInt2, paramInt3 - 1);
/*  83 */     int i1 = paramaab.a(paramInt1 + 1, paramInt2, paramInt3 - 1);
/*  84 */     int i2 = paramaab.a(paramInt1 + 1, paramInt2, paramInt3 + 1);
/*  85 */     int i3 = paramaab.a(paramInt1 - 1, paramInt2, paramInt3 + 1);
/*     */     
/*  87 */     boolean bool1 = (k == this.cz || m == this.cz) ? true : false;
/*  88 */     boolean bool2 = (i == this.cz || j == this.cz) ? true : false;
/*  89 */     boolean bool3 = (n == this.cz || i1 == this.cz || i2 == this.cz || i3 == this.cz) ? true : false;
/*     */     
/*  91 */     for (int i4 = paramInt1 - 1; i4 <= paramInt1 + 1; i4++) {
/*  92 */       for (int i5 = paramInt3 - 1; i5 <= paramInt3 + 1; i5++) {
/*  93 */         int i6 = paramaab.a(i4, paramInt2 - 1, i5);
/*     */         
/*  95 */         float f1 = 0.0F;
/*  96 */         if (i6 == apa.aE.cz) {
/*  97 */           f1 = 1.0F;
/*  98 */           if (paramaab.h(i4, paramInt2 - 1, i5) > 0) f1 = 3.0F;
/*     */         
/*     */         } 
/* 101 */         if (i4 != paramInt1 || i5 != paramInt3) f1 /= 4.0F;
/*     */         
/* 103 */         f += f1;
/*     */       } 
/*     */     } 
/* 106 */     if (bool3 || (bool1 && bool2)) f /= 2.0F;
/*     */     
/* 108 */     return f;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(int paramInt) {
/* 113 */     int i = paramInt * 32;
/* 114 */     int j = 255 - paramInt * 8;
/* 115 */     int k = paramInt * 4;
/* 116 */     return i << 16 | j << 8 | k;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 121 */     return b(paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/* 126 */     float f = 0.125F;
/* 127 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.25F, 0.5F + f);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 132 */     this.cK = ((paramaak.h(paramInt1, paramInt2, paramInt3) * 2 + 2) / 16.0F);
/* 133 */     float f = 0.125F;
/* 134 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, (float)this.cK, 0.5F + f);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 139 */     return 19;
/*     */   }
/*     */   
/*     */   public int d(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 143 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 144 */     if (i < 7) return -1; 
/* 145 */     if (paramaak.a(paramInt1 - 1, paramInt2, paramInt3) == this.a.cz) return 0; 
/* 146 */     if (paramaak.a(paramInt1 + 1, paramInt2, paramInt3) == this.a.cz) return 1; 
/* 147 */     if (paramaak.a(paramInt1, paramInt2, paramInt3 - 1) == this.a.cz) return 2; 
/* 148 */     if (paramaak.a(paramInt1, paramInt2, paramInt3 + 1) == this.a.cz) return 3; 
/* 149 */     return -1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 158 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, paramInt5);
/*     */     
/* 160 */     if (paramaab.I) {
/*     */       return;
/*     */     }
/*     */     
/* 164 */     wk wk = null;
/* 165 */     if (this.a == apa.be) wk = wk.bh; 
/* 166 */     if (this.a == apa.bv) wk = wk.bi; 
/* 167 */     for (byte b = 0; b < 3; b++) {
/* 168 */       if (paramaab.s.nextInt(15) <= paramInt4) {
/* 169 */         b(paramaab, paramInt1, paramInt2, paramInt3, new wm(wk));
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 175 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 180 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 185 */     if (this.a == apa.be)
/* 186 */       return wk.bh.cp; 
/* 187 */     if (this.a == apa.bv) {
/* 188 */       return wk.bi.cp;
/*     */     }
/*     */     
/* 191 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 196 */     this.cQ = paramly.a("stem_straight");
/* 197 */     this.b = paramly.a("stem_bent");
/*     */   }
/*     */   
/*     */   public lx q() {
/* 201 */     return this.b;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aor.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */