/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class afy
/*    */   extends agg
/*    */ {
/*    */   afy(Class paramClass, int paramInt1, int paramInt2) {
/* 56 */     super(paramClass, paramInt1, paramInt2);
/*    */   }
/*    */   public boolean a(int paramInt) {
/* 59 */     return (super.a(paramInt) && paramInt > 4);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */