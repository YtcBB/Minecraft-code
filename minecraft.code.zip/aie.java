/*    */ public class aie
/*    */   extends aif
/*    */ {
/*    */   public aie(aih paramaih) {
/*  5 */     super(paramaih);
/*  6 */     i();
/*  7 */     n();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean d() {
/* 12 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 17 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a() {
/* 22 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aie.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */