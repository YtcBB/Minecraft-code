/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class alh
/*    */   extends apa
/*    */ {
/*    */   protected alh(int paramInt, aif paramaif) {
/* 12 */     super(paramInt, paramaif);
/* 13 */     b(true);
/* 14 */     float f = 0.2F;
/* 15 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f * 3.0F, 0.5F + f);
/* 16 */     a(ve.c);
/*    */   }
/*    */   
/*    */   protected alh(int paramInt) {
/* 20 */     this(paramInt, aif.k);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 25 */     return (super.c(paramaab, paramInt1, paramInt2, paramInt3) && f_(paramaab.a(paramInt1, paramInt2 - 1, paramInt3)));
/*    */   }
/*    */   
/*    */   protected boolean f_(int paramInt) {
/* 29 */     return (paramInt == apa.y.cz || paramInt == apa.z.cz || paramInt == apa.aE.cz);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 34 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/* 35 */     e(paramaab, paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 40 */     e(paramaab, paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */   
/*    */   protected final void e(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 44 */     if (!f(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 45 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 46 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 52 */     return ((paramaab.m(paramInt1, paramInt2, paramInt3) >= 8 || paramaab.l(paramInt1, paramInt2, paramInt3)) && f_(paramaab.a(paramInt1, paramInt2 - 1, paramInt3)));
/*    */   }
/*    */ 
/*    */   
/*    */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 57 */     return null;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 66 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b() {
/* 71 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int d() {
/* 76 */     return 1;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */