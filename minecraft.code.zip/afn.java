/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class afn
/*    */   extends agy
/*    */ {
/*    */   public afn(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 82 */     aav aav = paramaab.a(paramInt1 * 16 + 8, paramInt2 * 16 + 8);
/* 83 */     if (aav == aav.w || aav == aav.x) {
/* 84 */       afr afr = new afr(paramRandom, paramInt1 * 16, paramInt2 * 16);
/* 85 */       this.a.add(afr);
/* 86 */     } else if (aav == aav.h) {
/* 87 */       afu afu = new afu(paramRandom, paramInt1 * 16, paramInt2 * 16);
/* 88 */       this.a.add(afu);
/*    */     } else {
/*    */       
/* 91 */       afq afq = new afq(paramRandom, paramInt1 * 16, paramInt2 * 16);
/* 92 */       this.a.add(afq);
/*    */     } 
/*    */     
/* 95 */     c();
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */