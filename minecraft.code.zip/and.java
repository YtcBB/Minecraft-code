/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class and
/*    */   extends apa
/*    */ {
/*    */   public and(int paramInt, aif paramaif) {
/* 11 */     super(paramInt, paramaif);
/* 12 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt, Random paramRandom) {
/* 17 */     return kx.a(a(paramRandom) + paramRandom.nextInt(paramInt + 1), 1, 4);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 22 */     return 2 + paramRandom.nextInt(3);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 27 */     return wk.aU.cp;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\and.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */