/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ami
/*     */   extends apa
/*     */ {
/*     */   private lx a;
/*     */   private lx b;
/*     */   
/*     */   protected ami(int paramInt) {
/*  20 */     super(paramInt, aif.c);
/*  21 */     b(true);
/*  22 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.9375F, 1.0F);
/*  23 */     k(255);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  28 */     return aqx.a().a((paramInt1 + 0), (paramInt2 + 0), (paramInt3 + 0), (paramInt1 + 1), (paramInt2 + 1), (paramInt3 + 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  33 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  38 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  43 */     if (paramInt1 == 1) {
/*  44 */       if (paramInt2 > 0) {
/*  45 */         return this.a;
/*     */       }
/*  47 */       return this.b;
/*     */     } 
/*     */     
/*  50 */     return apa.z.m(paramInt1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  55 */     if (m(paramaab, paramInt1, paramInt2, paramInt3) || paramaab.F(paramInt1, paramInt2 + 1, paramInt3)) {
/*  56 */       paramaab.b(paramInt1, paramInt2, paramInt3, 7, 2);
/*     */     } else {
/*  58 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  59 */       if (i > 0) {
/*  60 */         paramaab.b(paramInt1, paramInt2, paramInt3, i - 1, 2);
/*     */       }
/*  62 */       else if (!k(paramaab, paramInt1, paramInt2, paramInt3)) {
/*  63 */         paramaab.c(paramInt1, paramInt2, paramInt3, apa.z.cz);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp, float paramFloat) {
/*  71 */     if (!paramaab.I && paramaab.s.nextFloat() < paramFloat - 0.5F) {
/*  72 */       if (!(parammp instanceof sq) && !paramaab.N().b("mobGriefing")) {
/*     */         return;
/*     */       }
/*  75 */       paramaab.c(paramInt1, paramInt2, paramInt3, apa.z.cz);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  80 */     byte b = 0;
/*  81 */     for (int i = paramInt1 - b; i <= paramInt1 + b; i++) {
/*  82 */       for (int j = paramInt3 - b; j <= paramInt3 + b; j++) {
/*  83 */         int k = paramaab.a(i, paramInt2 + 1, j);
/*  84 */         if (k == apa.aD.cz || k == apa.bx.cz || k == apa.bw.cz || k == apa.ci.cz || k == apa.ch.cz)
/*  85 */           return true; 
/*     */       } 
/*     */     } 
/*  88 */     return false;
/*     */   }
/*     */   
/*     */   private boolean m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  92 */     for (int i = paramInt1 - 4; i <= paramInt1 + 4; i++) {
/*  93 */       for (int j = paramInt2; j <= paramInt2 + 1; j++) {
/*  94 */         for (int k = paramInt3 - 4; k <= paramInt3 + 4; k++) {
/*  95 */           if (paramaab.g(i, j, k) == aif.h)
/*  96 */             return true; 
/*     */         } 
/*     */       } 
/*  99 */     }  return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 104 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/* 105 */     aif aif = paramaab.g(paramInt1, paramInt2 + 1, paramInt3);
/* 106 */     if (aif.a()) {
/* 107 */       paramaab.c(paramInt1, paramInt2, paramInt3, apa.z.cz);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 117 */     return apa.z.a(0, paramRandom, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 122 */     return apa.z.cz;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 127 */     this.a = paramly.a("farmland_wet");
/* 128 */     this.b = paramly.a("farmland_dry");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ami.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */