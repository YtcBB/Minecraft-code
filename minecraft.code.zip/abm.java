/*   */ 
/*   */ public class abm
/*   */   extends aav
/*   */ {
/*   */   public abm(int paramInt) {
/* 6 */     super(paramInt);
/*   */     
/* 8 */     this.K.clear();
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */