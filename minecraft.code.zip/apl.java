/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apl
/*     */   extends apa
/*     */ {
/*     */   public apl(int paramInt) {
/*  20 */     super(paramInt, aif.q);
/*  21 */     a(ve.d);
/*  22 */     b(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  27 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  36 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  41 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  46 */     return 29;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  51 */     return 10;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  56 */     if (paramInt4 == 2 && paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) return true; 
/*  57 */     if (paramInt4 == 3 && paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) return true; 
/*  58 */     if (paramInt4 == 4 && paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) return true; 
/*  59 */     if (paramInt4 == 5 && paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) return true; 
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  65 */     if (paramaab.u(paramInt1 - 1, paramInt2, paramInt3))
/*  66 */       return true; 
/*  67 */     if (paramaab.u(paramInt1 + 1, paramInt2, paramInt3))
/*  68 */       return true; 
/*  69 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 - 1))
/*  70 */       return true; 
/*  71 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) {
/*  72 */       return true;
/*     */     }
/*  74 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  79 */     byte b = 0;
/*     */     
/*  81 */     if (paramInt4 == 2 && paramaab.c(paramInt1, paramInt2, paramInt3 + 1, true)) b = 2; 
/*  82 */     if (paramInt4 == 3 && paramaab.c(paramInt1, paramInt2, paramInt3 - 1, true)) b = 0; 
/*  83 */     if (paramInt4 == 4 && paramaab.c(paramInt1 + 1, paramInt2, paramInt3, true)) b = 1; 
/*  84 */     if (paramInt4 == 5 && paramaab.c(paramInt1 - 1, paramInt2, paramInt3, true)) b = 3;
/*     */     
/*  86 */     return b;
/*     */   }
/*     */ 
/*     */   
/*     */   public void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  91 */     a(paramaab, paramInt1, paramInt2, paramInt3, this.cz, paramInt4, false, -1, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  96 */     if (paramInt4 == this.cz)
/*  97 */       return;  if (k(paramaab, paramInt1, paramInt2, paramInt3)) {
/*  98 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  99 */       int j = i & 0x3;
/* 100 */       boolean bool = false;
/*     */       
/* 102 */       if (!paramaab.u(paramInt1 - 1, paramInt2, paramInt3) && j == 3) bool = true; 
/* 103 */       if (!paramaab.u(paramInt1 + 1, paramInt2, paramInt3) && j == 1) bool = true; 
/* 104 */       if (!paramaab.u(paramInt1, paramInt2, paramInt3 - 1) && j == 0) bool = true; 
/* 105 */       if (!paramaab.u(paramInt1, paramInt2, paramInt3 + 1) && j == 2) bool = true;
/*     */       
/* 107 */       if (bool) {
/* 108 */         c(paramaab, paramInt1, paramInt2, paramInt3, i, 0);
/* 109 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, boolean paramBoolean, int paramInt6, int paramInt7) {
/* 115 */     int i = paramInt5 & 0x3;
/* 116 */     int j = ((paramInt5 & 0x4) == 4) ? 1 : 0;
/* 117 */     boolean bool1 = ((paramInt5 & 0x8) == 8) ? true : false;
/* 118 */     int k = (paramInt4 == apa.bX.cz) ? 1 : 0;
/* 119 */     int m = 0;
/* 120 */     boolean bool2 = !paramaab.w(paramInt1, paramInt2 - 1, paramInt3) ? true : false;
/* 121 */     int n = r.a[i];
/* 122 */     int i1 = r.b[i];
/* 123 */     int i2 = 0;
/* 124 */     int[] arrayOfInt = new int[42];
/*     */     int i3;
/* 126 */     for (i3 = 1; i3 < 42; i3++) {
/* 127 */       int i4 = paramInt1 + n * i3;
/* 128 */       int i5 = paramInt3 + i1 * i3;
/* 129 */       int i6 = paramaab.a(i4, paramInt2, i5);
/*     */       
/* 131 */       if (i6 == apa.bX.cz) {
/* 132 */         int i7 = paramaab.h(i4, paramInt2, i5);
/*     */         
/* 134 */         if ((i7 & 0x3) == r.f[i]) {
/* 135 */           i2 = i3;
/*     */         }
/*     */         break;
/*     */       } 
/* 139 */       if (i6 == apa.bY.cz || i3 == paramInt6) {
/* 140 */         int i7 = (i3 == paramInt6) ? paramInt7 : paramaab.h(i4, paramInt2, i5);
/* 141 */         byte b = ((i7 & 0x8) != 8) ? 1 : 0;
/* 142 */         boolean bool3 = ((i7 & 0x1) == 1) ? true : false;
/* 143 */         boolean bool4 = ((i7 & 0x2) == 2) ? true : false;
/* 144 */         k &= (bool4 == bool2) ? 1 : 0;
/* 145 */         m |= (b && bool3) ? 1 : 0;
/*     */         
/* 147 */         arrayOfInt[i3] = i7;
/*     */         
/* 149 */         if (i3 == paramInt6) {
/* 150 */           paramaab.a(paramInt1, paramInt2, paramInt3, paramInt4, a(paramaab));
/* 151 */           k &= b;
/*     */         } 
/*     */       } else {
/* 154 */         arrayOfInt[i3] = -1;
/* 155 */         k = 0;
/*     */       } 
/*     */     } 
/*     */     
/* 159 */     k &= (i2 > 1) ? 1 : 0;
/* 160 */     m &= k;
/* 161 */     i3 = ((k != 0) ? 4 : 0) | ((m != 0) ? 8 : 0);
/* 162 */     paramInt5 = i | i3;
/*     */     
/* 164 */     if (i2 > 0) {
/* 165 */       int i4 = paramInt1 + n * i2;
/* 166 */       int i5 = paramInt3 + i1 * i2;
/* 167 */       int i6 = r.f[i];
/* 168 */       paramaab.b(i4, paramInt2, i5, i6 | i3, 3);
/* 169 */       d(paramaab, i4, paramInt2, i5, i6);
/*     */       
/* 171 */       a(paramaab, i4, paramInt2, i5, k, m, j, bool1);
/*     */     } 
/*     */     
/* 174 */     a(paramaab, paramInt1, paramInt2, paramInt3, k, m, j, bool1);
/*     */     
/* 176 */     if (paramInt4 > 0) {
/* 177 */       paramaab.b(paramInt1, paramInt2, paramInt3, paramInt5, 3);
/* 178 */       if (paramBoolean) d(paramaab, paramInt1, paramInt2, paramInt3, i);
/*     */     
/*     */     } 
/* 181 */     if (j != k) {
/* 182 */       for (byte b = 1; b < i2; b++) {
/* 183 */         int i4 = paramInt1 + n * b;
/* 184 */         int i5 = paramInt3 + i1 * b;
/* 185 */         int i6 = arrayOfInt[b];
/* 186 */         if (i6 >= 0) {
/*     */           
/* 188 */           if (k != 0) {
/* 189 */             i6 |= 0x4;
/*     */           } else {
/* 191 */             i6 &= 0xFFFFFFFB;
/*     */           } 
/*     */           
/* 194 */           paramaab.b(i4, paramInt2, i5, i6, 3);
/*     */         } 
/*     */       } 
/*     */     }
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 201 */     a(paramaab, paramInt1, paramInt2, paramInt3, this.cz, paramaab.h(paramInt1, paramInt2, paramInt3), true, -1, 0);
/*     */   }
/*     */   
/*     */   private void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4) {
/* 205 */     if (paramBoolean2 && !paramBoolean4) {
/* 206 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.1D, paramInt3 + 0.5D, "random.click", 0.4F, 0.6F);
/* 207 */     } else if (!paramBoolean2 && paramBoolean4) {
/* 208 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.1D, paramInt3 + 0.5D, "random.click", 0.4F, 0.5F);
/* 209 */     } else if (paramBoolean1 && !paramBoolean3) {
/* 210 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.1D, paramInt3 + 0.5D, "random.click", 0.4F, 0.7F);
/* 211 */     } else if (!paramBoolean1 && paramBoolean3) {
/* 212 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.1D, paramInt3 + 0.5D, "random.bowhit", 0.4F, 1.2F / (paramaab.s.nextFloat() * 0.2F + 0.9F));
/*     */     } 
/*     */   }
/*     */   
/*     */   private void d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 217 */     paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/*     */     
/* 219 */     if (paramInt4 == 3) {
/* 220 */       paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 221 */     } else if (paramInt4 == 1) {
/* 222 */       paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 223 */     } else if (paramInt4 == 0) {
/* 224 */       paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 225 */     } else if (paramInt4 == 2) {
/* 226 */       paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 231 */     if (!c(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 232 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 233 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/* 234 */       return false;
/*     */     } 
/*     */     
/* 237 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 242 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3) & 0x3;
/* 243 */     float f = 0.1875F;
/*     */     
/* 245 */     if (i == 3) {
/* 246 */       a(0.0F, 0.2F, 0.5F - f, f * 2.0F, 0.8F, 0.5F + f);
/* 247 */     } else if (i == 1) {
/* 248 */       a(1.0F - f * 2.0F, 0.2F, 0.5F - f, 1.0F, 0.8F, 0.5F + f);
/* 249 */     } else if (i == 0) {
/* 250 */       a(0.5F - f, 0.2F, 0.0F, 0.5F + f, 0.8F, f * 2.0F);
/* 251 */     } else if (i == 2) {
/* 252 */       a(0.5F - f, 0.2F, 1.0F - f * 2.0F, 0.5F + f, 0.8F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 258 */     boolean bool1 = ((paramInt5 & 0x4) == 4) ? true : false;
/* 259 */     boolean bool2 = ((paramInt5 & 0x8) == 8) ? true : false;
/*     */     
/* 261 */     if (bool1 || bool2) {
/* 262 */       a(paramaab, paramInt1, paramInt2, paramInt3, 0, paramInt5, false, -1, 0);
/*     */     }
/*     */ 
/*     */     
/* 266 */     if (bool2) {
/* 267 */       paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/* 268 */       int i = paramInt5 & 0x3;
/*     */       
/* 270 */       if (i == 3) {
/* 271 */         paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 272 */       } else if (i == 1) {
/* 273 */         paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 274 */       } else if (i == 0) {
/* 275 */         paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 276 */       } else if (i == 2) {
/* 277 */         paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/*     */       } 
/*     */     } 
/*     */     
/* 281 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 286 */     return ((paramaak.h(paramInt1, paramInt2, paramInt3) & 0x8) == 8) ? 15 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 291 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 292 */     if ((i & 0x8) != 8) return 0; 
/* 293 */     int j = i & 0x3;
/*     */     
/* 295 */     if (j == 2 && paramInt4 == 2) return 15; 
/* 296 */     if (j == 0 && paramInt4 == 3) return 15; 
/* 297 */     if (j == 1 && paramInt4 == 4) return 15; 
/* 298 */     if (j == 3 && paramInt4 == 5) return 15;
/*     */     
/* 300 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f() {
/* 305 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */