/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class amy
/*    */   extends ams
/*    */ {
/*    */   public amy(int paramInt) {
/* 15 */     super(paramInt, "ice", aif.v, false);
/* 16 */     this.cP = 0.98F;
/* 17 */     b(true);
/* 18 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public int n() {
/* 23 */     return 1;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 28 */     return super.a(paramaak, paramInt1, paramInt2, paramInt3, 1 - paramInt4);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 33 */     paramsq.a(kf.C[this.cz], 1);
/* 34 */     paramsq.j(0.025F);
/*    */     
/* 36 */     if (r_() && zb.e(paramsq)) {
/* 37 */       wm wm = c_(paramInt4);
/* 38 */       if (wm != null) {
/* 39 */         b(paramaab, paramInt1, paramInt2, paramInt3, wm);
/*    */       }
/*    */     } else {
/* 42 */       if (paramaab.t.e) {
/* 43 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*    */         
/*    */         return;
/*    */       } 
/* 47 */       int i = zb.f(paramsq);
/* 48 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, i);
/*    */       
/* 50 */       aif aif = paramaab.g(paramInt1, paramInt2 - 1, paramInt3);
/* 51 */       if (aif.c() || aif.d()) {
/* 52 */         paramaab.c(paramInt1, paramInt2, paramInt3, apa.E.cz);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 59 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 64 */     if (paramaab.b(aam.b, paramInt1, paramInt2, paramInt3) > 11 - apa.t[this.cz]) {
/* 65 */       if (paramaab.t.e) {
/* 66 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*    */         
/*    */         return;
/*    */       } 
/* 70 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 71 */       paramaab.c(paramInt1, paramInt2, paramInt3, apa.F.cz);
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public int h() {
/* 77 */     return 0;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */