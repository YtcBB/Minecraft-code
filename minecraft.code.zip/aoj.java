/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aoj
/*    */   extends apa
/*    */ {
/* 16 */   public static final String[] a = new String[] { "default", "chiseled", "smooth" };
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/* 22 */   private static final String[] b = new String[] { "sandstone_side", "sandstone_carved", "sandstone_smooth" };
/*    */   
/*    */   private lx[] c;
/*    */   
/*    */   private lx d;
/*    */   
/*    */   private lx e;
/*    */   
/*    */   public aoj(int paramInt) {
/* 31 */     super(paramInt, aif.e);
/* 32 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 37 */     if (paramInt1 == 1 || (paramInt1 == 0 && (paramInt2 == 1 || paramInt2 == 2))) {
/* 38 */       return this.d;
/*    */     }
/* 40 */     if (paramInt1 == 0) {
/* 41 */       return this.e;
/*    */     }
/* 43 */     if (paramInt2 < 0 || paramInt2 >= this.c.length) paramInt2 = 0; 
/* 44 */     return this.c[paramInt2];
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt) {
/* 49 */     return paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 54 */     paramList.add(new wm(paramInt, 1, 0));
/* 55 */     paramList.add(new wm(paramInt, 1, 1));
/* 56 */     paramList.add(new wm(paramInt, 1, 2));
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 61 */     this.c = new lx[b.length];
/*    */     
/* 63 */     for (byte b = 0; b < this.c.length; b++) {
/* 64 */       this.c[b] = paramly.a(b[b]);
/*    */     }
/*    */     
/* 67 */     this.d = paramly.a("sandstone_top");
/* 68 */     this.e = paramly.a("sandstone_bottom");
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */