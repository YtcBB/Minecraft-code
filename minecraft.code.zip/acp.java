/*   */ 
/*   */ public class acp
/*   */   extends acn
/*   */ {
/*   */   public String l() {
/* 6 */     return "Overworld";
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */