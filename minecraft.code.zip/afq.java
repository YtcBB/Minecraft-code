/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class afq
/*     */   extends aft
/*     */ {
/*  73 */   private boolean[] h = new boolean[4];
/*     */ 
/*     */   
/*  76 */   private static final lp[] i = new lp[] { new lp(wk.o.cp, 0, 1, 3, 3), new lp(wk.p.cp, 0, 1, 5, 10), new lp(wk.q.cp, 0, 2, 7, 15), new lp(wk.bI.cp, 0, 1, 3, 2), new lp(wk.aY.cp, 0, 4, 6, 20), new lp(wk.bn.cp, 0, 3, 7, 16) };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public afq(Random paramRandom, int paramInt1, int paramInt2) {
/*  87 */     super(paramRandom, paramInt1, 64, paramInt2, 21, 15, 21);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/*  94 */     a(paramaab, paramaek, 0, -4, 0, this.a - 1, 0, this.c - 1, apa.U.cz, apa.U.cz, false); int i;
/*  95 */     for (i = 1; i <= 9; i++) {
/*  96 */       a(paramaab, paramaek, i, i, i, this.a - 1 - i, i, this.c - 1 - i, apa.U.cz, apa.U.cz, false);
/*  97 */       a(paramaab, paramaek, i + 1, i, i + 1, this.a - 2 - i, i, this.c - 2 - i, 0, 0, false);
/*     */     } 
/*  99 */     for (i = 0; i < this.a; i++) {
/* 100 */       for (byte b1 = 0; b1 < this.c; b1++) {
/* 101 */         b(paramaab, apa.U.cz, 0, i, -5, b1, paramaek);
/*     */       }
/*     */     } 
/*     */     
/* 105 */     i = c(apa.bU.cz, 3);
/* 106 */     int j = c(apa.bU.cz, 2);
/* 107 */     int k = c(apa.bU.cz, 0);
/* 108 */     int m = c(apa.bU.cz, 1);
/* 109 */     boolean bool = true;
/* 110 */     byte b = 11;
/*     */ 
/*     */     
/* 113 */     a(paramaab, paramaek, 0, 0, 0, 4, 9, 4, apa.U.cz, 0, false);
/* 114 */     a(paramaab, paramaek, 1, 10, 1, 3, 10, 3, apa.U.cz, apa.U.cz, false);
/* 115 */     a(paramaab, apa.bU.cz, i, 2, 10, 0, paramaek);
/* 116 */     a(paramaab, apa.bU.cz, j, 2, 10, 4, paramaek);
/* 117 */     a(paramaab, apa.bU.cz, k, 0, 10, 2, paramaek);
/* 118 */     a(paramaab, apa.bU.cz, m, 4, 10, 2, paramaek);
/* 119 */     a(paramaab, paramaek, this.a - 5, 0, 0, this.a - 1, 9, 4, apa.U.cz, 0, false);
/* 120 */     a(paramaab, paramaek, this.a - 4, 10, 1, this.a - 2, 10, 3, apa.U.cz, apa.U.cz, false);
/* 121 */     a(paramaab, apa.bU.cz, i, this.a - 3, 10, 0, paramaek);
/* 122 */     a(paramaab, apa.bU.cz, j, this.a - 3, 10, 4, paramaek);
/* 123 */     a(paramaab, apa.bU.cz, k, this.a - 5, 10, 2, paramaek);
/* 124 */     a(paramaab, apa.bU.cz, m, this.a - 1, 10, 2, paramaek);
/*     */ 
/*     */     
/* 127 */     a(paramaab, paramaek, 8, 0, 0, 12, 4, 4, apa.U.cz, 0, false);
/* 128 */     a(paramaab, paramaek, 9, 1, 0, 11, 3, 4, 0, 0, false);
/* 129 */     a(paramaab, apa.U.cz, 2, 9, 1, 1, paramaek);
/* 130 */     a(paramaab, apa.U.cz, 2, 9, 2, 1, paramaek);
/* 131 */     a(paramaab, apa.U.cz, 2, 9, 3, 1, paramaek);
/* 132 */     a(paramaab, apa.U.cz, 2, 10, 3, 1, paramaek);
/* 133 */     a(paramaab, apa.U.cz, 2, 11, 3, 1, paramaek);
/* 134 */     a(paramaab, apa.U.cz, 2, 11, 2, 1, paramaek);
/* 135 */     a(paramaab, apa.U.cz, 2, 11, 1, 1, paramaek);
/*     */ 
/*     */     
/* 138 */     a(paramaab, paramaek, 4, 1, 1, 8, 3, 3, apa.U.cz, 0, false);
/* 139 */     a(paramaab, paramaek, 4, 1, 2, 8, 2, 2, 0, 0, false);
/* 140 */     a(paramaab, paramaek, 12, 1, 1, 16, 3, 3, apa.U.cz, 0, false);
/* 141 */     a(paramaab, paramaek, 12, 1, 2, 16, 2, 2, 0, 0, false);
/*     */ 
/*     */     
/* 144 */     a(paramaab, paramaek, 5, 4, 5, this.a - 6, 4, this.c - 6, apa.U.cz, apa.U.cz, false);
/* 145 */     a(paramaab, paramaek, 9, 4, 9, 11, 4, 11, 0, 0, false);
/* 146 */     a(paramaab, paramaek, 8, 1, 8, 8, 3, 8, apa.U.cz, 2, apa.U.cz, 2, false);
/* 147 */     a(paramaab, paramaek, 12, 1, 8, 12, 3, 8, apa.U.cz, 2, apa.U.cz, 2, false);
/* 148 */     a(paramaab, paramaek, 8, 1, 12, 8, 3, 12, apa.U.cz, 2, apa.U.cz, 2, false);
/* 149 */     a(paramaab, paramaek, 12, 1, 12, 12, 3, 12, apa.U.cz, 2, apa.U.cz, 2, false);
/*     */ 
/*     */     
/* 152 */     a(paramaab, paramaek, 1, 1, 5, 4, 4, 11, apa.U.cz, apa.U.cz, false);
/* 153 */     a(paramaab, paramaek, this.a - 5, 1, 5, this.a - 2, 4, 11, apa.U.cz, apa.U.cz, false);
/* 154 */     a(paramaab, paramaek, 6, 7, 9, 6, 7, 11, apa.U.cz, apa.U.cz, false);
/* 155 */     a(paramaab, paramaek, this.a - 7, 7, 9, this.a - 7, 7, 11, apa.U.cz, apa.U.cz, false);
/* 156 */     a(paramaab, paramaek, 5, 5, 9, 5, 7, 11, apa.U.cz, 2, apa.U.cz, 2, false);
/* 157 */     a(paramaab, paramaek, this.a - 6, 5, 9, this.a - 6, 7, 11, apa.U.cz, 2, apa.U.cz, 2, false);
/* 158 */     a(paramaab, 0, 0, 5, 5, 10, paramaek);
/* 159 */     a(paramaab, 0, 0, 5, 6, 10, paramaek);
/* 160 */     a(paramaab, 0, 0, 6, 6, 10, paramaek);
/* 161 */     a(paramaab, 0, 0, this.a - 6, 5, 10, paramaek);
/* 162 */     a(paramaab, 0, 0, this.a - 6, 6, 10, paramaek);
/* 163 */     a(paramaab, 0, 0, this.a - 7, 6, 10, paramaek);
/*     */ 
/*     */     
/* 166 */     a(paramaab, paramaek, 2, 4, 4, 2, 6, 4, 0, 0, false);
/* 167 */     a(paramaab, paramaek, this.a - 3, 4, 4, this.a - 3, 6, 4, 0, 0, false);
/* 168 */     a(paramaab, apa.bU.cz, i, 2, 4, 5, paramaek);
/* 169 */     a(paramaab, apa.bU.cz, i, 2, 3, 4, paramaek);
/* 170 */     a(paramaab, apa.bU.cz, i, this.a - 3, 4, 5, paramaek);
/* 171 */     a(paramaab, apa.bU.cz, i, this.a - 3, 3, 4, paramaek);
/* 172 */     a(paramaab, paramaek, 1, 1, 3, 2, 2, 3, apa.U.cz, apa.U.cz, false);
/* 173 */     a(paramaab, paramaek, this.a - 3, 1, 3, this.a - 2, 2, 3, apa.U.cz, apa.U.cz, false);
/* 174 */     a(paramaab, apa.bU.cz, 0, 1, 1, 2, paramaek);
/* 175 */     a(paramaab, apa.bU.cz, 0, this.a - 2, 1, 2, paramaek);
/* 176 */     a(paramaab, apa.ao.cz, 1, 1, 2, 2, paramaek);
/* 177 */     a(paramaab, apa.ao.cz, 1, this.a - 2, 2, 2, paramaek);
/* 178 */     a(paramaab, apa.bU.cz, m, 2, 1, 2, paramaek);
/* 179 */     a(paramaab, apa.bU.cz, k, this.a - 3, 1, 2, paramaek);
/*     */ 
/*     */     
/* 182 */     a(paramaab, paramaek, 4, 3, 5, 4, 3, 18, apa.U.cz, apa.U.cz, false);
/* 183 */     a(paramaab, paramaek, this.a - 5, 3, 5, this.a - 5, 3, 17, apa.U.cz, apa.U.cz, false);
/* 184 */     a(paramaab, paramaek, 3, 1, 5, 4, 2, 16, 0, 0, false);
/* 185 */     a(paramaab, paramaek, this.a - 6, 1, 5, this.a - 5, 2, 16, 0, 0, false); int n;
/* 186 */     for (n = 5; n <= 17; n += 2) {
/* 187 */       a(paramaab, apa.U.cz, 2, 4, 1, n, paramaek);
/* 188 */       a(paramaab, apa.U.cz, 1, 4, 2, n, paramaek);
/* 189 */       a(paramaab, apa.U.cz, 2, this.a - 5, 1, n, paramaek);
/* 190 */       a(paramaab, apa.U.cz, 1, this.a - 5, 2, n, paramaek);
/*     */     } 
/* 192 */     a(paramaab, apa.af.cz, bool, 10, 0, 7, paramaek);
/* 193 */     a(paramaab, apa.af.cz, bool, 10, 0, 8, paramaek);
/* 194 */     a(paramaab, apa.af.cz, bool, 9, 0, 9, paramaek);
/* 195 */     a(paramaab, apa.af.cz, bool, 11, 0, 9, paramaek);
/* 196 */     a(paramaab, apa.af.cz, bool, 8, 0, 10, paramaek);
/* 197 */     a(paramaab, apa.af.cz, bool, 12, 0, 10, paramaek);
/* 198 */     a(paramaab, apa.af.cz, bool, 7, 0, 10, paramaek);
/* 199 */     a(paramaab, apa.af.cz, bool, 13, 0, 10, paramaek);
/* 200 */     a(paramaab, apa.af.cz, bool, 9, 0, 11, paramaek);
/* 201 */     a(paramaab, apa.af.cz, bool, 11, 0, 11, paramaek);
/* 202 */     a(paramaab, apa.af.cz, bool, 10, 0, 12, paramaek);
/* 203 */     a(paramaab, apa.af.cz, bool, 10, 0, 13, paramaek);
/* 204 */     a(paramaab, apa.af.cz, b, 10, 0, 10, paramaek);
/*     */ 
/*     */     
/* 207 */     for (n = 0; n <= this.a - 1; n += this.a - 1) {
/* 208 */       a(paramaab, apa.U.cz, 2, n, 2, 1, paramaek);
/* 209 */       a(paramaab, apa.af.cz, bool, n, 2, 2, paramaek);
/* 210 */       a(paramaab, apa.U.cz, 2, n, 2, 3, paramaek);
/* 211 */       a(paramaab, apa.U.cz, 2, n, 3, 1, paramaek);
/* 212 */       a(paramaab, apa.af.cz, bool, n, 3, 2, paramaek);
/* 213 */       a(paramaab, apa.U.cz, 2, n, 3, 3, paramaek);
/* 214 */       a(paramaab, apa.af.cz, bool, n, 4, 1, paramaek);
/* 215 */       a(paramaab, apa.U.cz, 1, n, 4, 2, paramaek);
/* 216 */       a(paramaab, apa.af.cz, bool, n, 4, 3, paramaek);
/* 217 */       a(paramaab, apa.U.cz, 2, n, 5, 1, paramaek);
/* 218 */       a(paramaab, apa.af.cz, bool, n, 5, 2, paramaek);
/* 219 */       a(paramaab, apa.U.cz, 2, n, 5, 3, paramaek);
/* 220 */       a(paramaab, apa.af.cz, bool, n, 6, 1, paramaek);
/* 221 */       a(paramaab, apa.U.cz, 1, n, 6, 2, paramaek);
/* 222 */       a(paramaab, apa.af.cz, bool, n, 6, 3, paramaek);
/* 223 */       a(paramaab, apa.af.cz, bool, n, 7, 1, paramaek);
/* 224 */       a(paramaab, apa.af.cz, bool, n, 7, 2, paramaek);
/* 225 */       a(paramaab, apa.af.cz, bool, n, 7, 3, paramaek);
/* 226 */       a(paramaab, apa.U.cz, 2, n, 8, 1, paramaek);
/* 227 */       a(paramaab, apa.U.cz, 2, n, 8, 2, paramaek);
/* 228 */       a(paramaab, apa.U.cz, 2, n, 8, 3, paramaek);
/*     */     } 
/* 230 */     for (n = 2; n <= this.a - 3; n += this.a - 3 - 2) {
/* 231 */       a(paramaab, apa.U.cz, 2, n - 1, 2, 0, paramaek);
/* 232 */       a(paramaab, apa.af.cz, bool, n, 2, 0, paramaek);
/* 233 */       a(paramaab, apa.U.cz, 2, n + 1, 2, 0, paramaek);
/* 234 */       a(paramaab, apa.U.cz, 2, n - 1, 3, 0, paramaek);
/* 235 */       a(paramaab, apa.af.cz, bool, n, 3, 0, paramaek);
/* 236 */       a(paramaab, apa.U.cz, 2, n + 1, 3, 0, paramaek);
/* 237 */       a(paramaab, apa.af.cz, bool, n - 1, 4, 0, paramaek);
/* 238 */       a(paramaab, apa.U.cz, 1, n, 4, 0, paramaek);
/* 239 */       a(paramaab, apa.af.cz, bool, n + 1, 4, 0, paramaek);
/* 240 */       a(paramaab, apa.U.cz, 2, n - 1, 5, 0, paramaek);
/* 241 */       a(paramaab, apa.af.cz, bool, n, 5, 0, paramaek);
/* 242 */       a(paramaab, apa.U.cz, 2, n + 1, 5, 0, paramaek);
/* 243 */       a(paramaab, apa.af.cz, bool, n - 1, 6, 0, paramaek);
/* 244 */       a(paramaab, apa.U.cz, 1, n, 6, 0, paramaek);
/* 245 */       a(paramaab, apa.af.cz, bool, n + 1, 6, 0, paramaek);
/* 246 */       a(paramaab, apa.af.cz, bool, n - 1, 7, 0, paramaek);
/* 247 */       a(paramaab, apa.af.cz, bool, n, 7, 0, paramaek);
/* 248 */       a(paramaab, apa.af.cz, bool, n + 1, 7, 0, paramaek);
/* 249 */       a(paramaab, apa.U.cz, 2, n - 1, 8, 0, paramaek);
/* 250 */       a(paramaab, apa.U.cz, 2, n, 8, 0, paramaek);
/* 251 */       a(paramaab, apa.U.cz, 2, n + 1, 8, 0, paramaek);
/*     */     } 
/* 253 */     a(paramaab, paramaek, 8, 4, 0, 12, 6, 0, apa.U.cz, 2, apa.U.cz, 2, false);
/* 254 */     a(paramaab, 0, 0, 8, 6, 0, paramaek);
/* 255 */     a(paramaab, 0, 0, 12, 6, 0, paramaek);
/* 256 */     a(paramaab, apa.af.cz, bool, 9, 5, 0, paramaek);
/* 257 */     a(paramaab, apa.U.cz, 1, 10, 5, 0, paramaek);
/* 258 */     a(paramaab, apa.af.cz, bool, 11, 5, 0, paramaek);
/*     */ 
/*     */     
/* 261 */     a(paramaab, paramaek, 8, -14, 8, 12, -11, 12, apa.U.cz, 2, apa.U.cz, 2, false);
/* 262 */     a(paramaab, paramaek, 8, -10, 8, 12, -10, 12, apa.U.cz, 1, apa.U.cz, 1, false);
/* 263 */     a(paramaab, paramaek, 8, -9, 8, 12, -9, 12, apa.U.cz, 2, apa.U.cz, 2, false);
/* 264 */     a(paramaab, paramaek, 8, -8, 8, 12, -1, 12, apa.U.cz, apa.U.cz, false);
/* 265 */     a(paramaab, paramaek, 9, -11, 9, 11, -1, 11, 0, 0, false);
/* 266 */     a(paramaab, apa.aO.cz, 0, 10, -11, 10, paramaek);
/* 267 */     a(paramaab, paramaek, 9, -13, 9, 11, -13, 11, apa.aq.cz, 0, false);
/* 268 */     a(paramaab, 0, 0, 8, -11, 10, paramaek);
/* 269 */     a(paramaab, 0, 0, 8, -10, 10, paramaek);
/* 270 */     a(paramaab, apa.U.cz, 1, 7, -10, 10, paramaek);
/* 271 */     a(paramaab, apa.U.cz, 2, 7, -11, 10, paramaek);
/* 272 */     a(paramaab, 0, 0, 12, -11, 10, paramaek);
/* 273 */     a(paramaab, 0, 0, 12, -10, 10, paramaek);
/* 274 */     a(paramaab, apa.U.cz, 1, 13, -10, 10, paramaek);
/* 275 */     a(paramaab, apa.U.cz, 2, 13, -11, 10, paramaek);
/* 276 */     a(paramaab, 0, 0, 10, -11, 8, paramaek);
/* 277 */     a(paramaab, 0, 0, 10, -10, 8, paramaek);
/* 278 */     a(paramaab, apa.U.cz, 1, 10, -10, 7, paramaek);
/* 279 */     a(paramaab, apa.U.cz, 2, 10, -11, 7, paramaek);
/* 280 */     a(paramaab, 0, 0, 10, -11, 12, paramaek);
/* 281 */     a(paramaab, 0, 0, 10, -10, 12, paramaek);
/* 282 */     a(paramaab, apa.U.cz, 1, 10, -10, 13, paramaek);
/* 283 */     a(paramaab, apa.U.cz, 2, 10, -11, 13, paramaek);
/*     */ 
/*     */     
/* 286 */     for (n = 0; n < 4; n++) {
/* 287 */       if (!this.h[n]) {
/* 288 */         int i1 = r.a[n] * 2;
/* 289 */         int i2 = r.b[n] * 2;
/* 290 */         this.h[n] = a(paramaab, paramaek, paramRandom, 10 + i1, -11, 10 + i2, lp.a(i, new lp[] { wk.bX.b(paramRandom) }), 2 + paramRandom.nextInt(5));
/*     */       } 
/*     */     } 
/*     */     
/* 294 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */