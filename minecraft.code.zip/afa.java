/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class afa
/*     */   extends afh
/*     */ {
/*     */   public afa(int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 753 */     super(paramInt1);
/*     */     
/* 755 */     this.f = paramInt2;
/* 756 */     this.e = paramaek;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/* 763 */     a((afl)paramagw, paramList, paramRandom, 5, 3, true);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public static afa a(List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 769 */     aek aek = aek.a(paramInt1, paramInt2, paramInt3, -5, -3, 0, 13, 14, 13, paramInt4);
/*     */     
/* 771 */     if (!a(aek) || agw.a(paramList, aek) != null) {
/* 772 */       return null;
/*     */     }
/*     */     
/* 775 */     return new afa(paramInt5, paramRandom, aek, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 782 */     a(paramaab, paramaek, 0, 3, 0, 12, 4, 12, apa.bE.cz, apa.bE.cz, false);
/*     */     
/* 784 */     a(paramaab, paramaek, 0, 5, 0, 12, 13, 12, 0, 0, false);
/*     */ 
/*     */     
/* 787 */     a(paramaab, paramaek, 0, 5, 0, 1, 12, 12, apa.bE.cz, apa.bE.cz, false);
/* 788 */     a(paramaab, paramaek, 11, 5, 0, 12, 12, 12, apa.bE.cz, apa.bE.cz, false);
/* 789 */     a(paramaab, paramaek, 2, 5, 11, 4, 12, 12, apa.bE.cz, apa.bE.cz, false);
/* 790 */     a(paramaab, paramaek, 8, 5, 11, 10, 12, 12, apa.bE.cz, apa.bE.cz, false);
/* 791 */     a(paramaab, paramaek, 5, 9, 11, 7, 12, 12, apa.bE.cz, apa.bE.cz, false);
/* 792 */     a(paramaab, paramaek, 2, 5, 0, 4, 12, 1, apa.bE.cz, apa.bE.cz, false);
/* 793 */     a(paramaab, paramaek, 8, 5, 0, 10, 12, 1, apa.bE.cz, apa.bE.cz, false);
/* 794 */     a(paramaab, paramaek, 5, 9, 0, 7, 12, 1, apa.bE.cz, apa.bE.cz, false);
/*     */ 
/*     */     
/* 797 */     a(paramaab, paramaek, 2, 11, 2, 10, 12, 10, apa.bE.cz, apa.bE.cz, false);
/*     */ 
/*     */     
/* 800 */     a(paramaab, paramaek, 5, 8, 0, 7, 8, 0, apa.bF.cz, apa.bF.cz, false);
/*     */     
/*     */     int i;
/* 803 */     for (i = 1; i <= 11; i += 2) {
/* 804 */       a(paramaab, paramaek, i, 10, 0, i, 11, 0, apa.bF.cz, apa.bF.cz, false);
/* 805 */       a(paramaab, paramaek, i, 10, 12, i, 11, 12, apa.bF.cz, apa.bF.cz, false);
/* 806 */       a(paramaab, paramaek, 0, 10, i, 0, 11, i, apa.bF.cz, apa.bF.cz, false);
/* 807 */       a(paramaab, paramaek, 12, 10, i, 12, 11, i, apa.bF.cz, apa.bF.cz, false);
/* 808 */       a(paramaab, apa.bE.cz, 0, i, 13, 0, paramaek);
/* 809 */       a(paramaab, apa.bE.cz, 0, i, 13, 12, paramaek);
/* 810 */       a(paramaab, apa.bE.cz, 0, 0, 13, i, paramaek);
/* 811 */       a(paramaab, apa.bE.cz, 0, 12, 13, i, paramaek);
/* 812 */       a(paramaab, apa.bF.cz, 0, i + 1, 13, 0, paramaek);
/* 813 */       a(paramaab, apa.bF.cz, 0, i + 1, 13, 12, paramaek);
/* 814 */       a(paramaab, apa.bF.cz, 0, 0, 13, i + 1, paramaek);
/* 815 */       a(paramaab, apa.bF.cz, 0, 12, 13, i + 1, paramaek);
/*     */     } 
/* 817 */     a(paramaab, apa.bF.cz, 0, 0, 13, 0, paramaek);
/* 818 */     a(paramaab, apa.bF.cz, 0, 0, 13, 12, paramaek);
/* 819 */     a(paramaab, apa.bF.cz, 0, 0, 13, 0, paramaek);
/* 820 */     a(paramaab, apa.bF.cz, 0, 12, 13, 0, paramaek);
/*     */ 
/*     */     
/* 823 */     for (i = 3; i <= 9; i += 2) {
/* 824 */       a(paramaab, paramaek, 1, 7, i, 1, 8, i, apa.bF.cz, apa.bF.cz, false);
/* 825 */       a(paramaab, paramaek, 11, 7, i, 11, 8, i, apa.bF.cz, apa.bF.cz, false);
/*     */     } 
/*     */ 
/*     */     
/* 829 */     a(paramaab, paramaek, 4, 2, 0, 8, 2, 12, apa.bE.cz, apa.bE.cz, false);
/* 830 */     a(paramaab, paramaek, 0, 2, 4, 12, 2, 8, apa.bE.cz, apa.bE.cz, false);
/*     */     
/* 832 */     a(paramaab, paramaek, 4, 0, 0, 8, 1, 3, apa.bE.cz, apa.bE.cz, false);
/* 833 */     a(paramaab, paramaek, 4, 0, 9, 8, 1, 12, apa.bE.cz, apa.bE.cz, false);
/* 834 */     a(paramaab, paramaek, 0, 0, 4, 3, 1, 8, apa.bE.cz, apa.bE.cz, false);
/* 835 */     a(paramaab, paramaek, 9, 0, 4, 12, 1, 8, apa.bE.cz, apa.bE.cz, false);
/*     */     
/* 837 */     for (i = 4; i <= 8; i++) {
/* 838 */       for (byte b = 0; b <= 2; b++) {
/* 839 */         b(paramaab, apa.bE.cz, 0, i, -1, b, paramaek);
/* 840 */         b(paramaab, apa.bE.cz, 0, i, -1, 12 - b, paramaek);
/*     */       } 
/*     */     } 
/* 843 */     for (i = 0; i <= 2; i++) {
/* 844 */       for (byte b = 4; b <= 8; b++) {
/* 845 */         b(paramaab, apa.bE.cz, 0, i, -1, b, paramaek);
/* 846 */         b(paramaab, apa.bE.cz, 0, 12 - i, -1, b, paramaek);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 851 */     a(paramaab, paramaek, 5, 5, 5, 7, 5, 7, apa.bE.cz, apa.bE.cz, false);
/* 852 */     a(paramaab, paramaek, 6, 1, 6, 6, 4, 6, 0, 0, false);
/* 853 */     a(paramaab, apa.bE.cz, 0, 6, 0, 6, paramaek);
/* 854 */     a(paramaab, apa.G.cz, 0, 6, 5, 6, paramaek);
/*     */     
/* 856 */     i = a(6, 6);
/* 857 */     int j = a(5);
/* 858 */     int k = b(6, 6);
/* 859 */     if (paramaek.b(i, j, k)) {
/* 860 */       paramaab.d = true;
/* 861 */       apa.r[apa.G.cz].a(paramaab, i, j, k, paramRandom);
/* 862 */       paramaab.d = false;
/*     */     } 
/*     */     
/* 865 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afa.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */