/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apm
/*     */   extends apa
/*     */ {
/*     */   public apm(int paramInt) {
/*  20 */     super(paramInt, aif.q);
/*  21 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.15625F, 1.0F);
/*  22 */     b(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  27 */     return 10;
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  32 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  41 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  46 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int n() {
/*  51 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  56 */     return 30;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  61 */     return wk.L.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  66 */     return wk.L.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  71 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  72 */     boolean bool1 = ((i & 0x2) == 2) ? true : false;
/*  73 */     boolean bool2 = !paramaab.w(paramInt1, paramInt2 - 1, paramInt3) ? true : false;
/*     */     
/*  75 */     if (bool1 != bool2) {
/*  76 */       c(paramaab, paramInt1, paramInt2, paramInt3, i, 0);
/*  77 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  83 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*  84 */     boolean bool1 = ((i & 0x4) == 4) ? true : false;
/*  85 */     boolean bool2 = ((i & 0x2) == 2) ? true : false;
/*     */     
/*  87 */     if (!bool2) {
/*  88 */       a(0.0F, 0.0F, 0.0F, 1.0F, 0.09375F, 1.0F);
/*  89 */     } else if (!bool1) {
/*  90 */       a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
/*     */     } else {
/*  92 */       a(0.0F, 0.0625F, 0.0F, 1.0F, 0.15625F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  98 */     boolean bool = paramaab.w(paramInt1, paramInt2 - 1, paramInt3) ? false : true;
/*  99 */     paramaab.b(paramInt1, paramInt2, paramInt3, bool, 3);
/* 100 */     d(paramaab, paramInt1, paramInt2, paramInt3, bool);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 105 */     d(paramaab, paramInt1, paramInt2, paramInt3, paramInt5 | 0x1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, sq paramsq) {
/* 110 */     if (paramaab.I)
/*     */       return; 
/* 112 */     if (paramsq.cd() != null && (paramsq.cd()).c == wk.bf.cp) {
/* 113 */       paramaab.b(paramInt1, paramInt2, paramInt3, paramInt4 | 0x8, 4);
/*     */     }
/*     */   }
/*     */   
/*     */   private void d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 118 */     for (byte b = 0; b < 2; b++) {
/* 119 */       for (byte b1 = 1; b1 < 42; b1++) {
/* 120 */         int i = paramInt1 + r.a[b] * b1;
/* 121 */         int j = paramInt3 + r.b[b] * b1;
/* 122 */         int k = paramaab.a(i, paramInt2, j);
/*     */         
/* 124 */         if (k == apa.bX.cz) {
/* 125 */           int m = paramaab.h(i, paramInt2, j) & 0x3;
/*     */           
/* 127 */           if (m == r.f[b]) {
/* 128 */             apa.bX.a(paramaab, i, paramInt2, j, k, paramaab.h(i, paramInt2, j), true, b1, paramInt4);
/*     */           }
/*     */           break;
/*     */         } 
/* 132 */         if (k != apa.bY.cz) {
/*     */           break;
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/* 141 */     if (paramaab.I)
/*     */       return; 
/* 143 */     if ((paramaab.h(paramInt1, paramInt2, paramInt3) & 0x1) == 1) {
/*     */       return;
/*     */     }
/*     */     
/* 147 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 152 */     if (paramaab.I)
/*     */       return; 
/* 154 */     if ((paramaab.h(paramInt1, paramInt2, paramInt3) & 0x1) != 1) {
/*     */       return;
/*     */     }
/*     */     
/* 158 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 162 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 163 */     boolean bool1 = ((i & 0x1) == 1) ? true : false;
/* 164 */     boolean bool2 = false;
/*     */     
/* 166 */     List list = paramaab.b((mp)null, aqx.a().a(paramInt1 + this.cG, paramInt2 + this.cH, paramInt3 + this.cI, paramInt1 + this.cJ, paramInt2 + this.cK, paramInt3 + this.cL));
/* 167 */     if (!list.isEmpty()) {
/* 168 */       for (mp mp : list) {
/* 169 */         if (!mp.at()) {
/* 170 */           bool2 = true;
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     }
/* 176 */     if (bool2 && !bool1) {
/* 177 */       i |= 0x1;
/*     */     }
/*     */     
/* 180 */     if (!bool2 && bool1) {
/* 181 */       i &= 0xFFFFFFFE;
/*     */     }
/*     */     
/* 184 */     if (bool2 != bool1) {
/* 185 */       paramaab.b(paramInt1, paramInt2, paramInt3, i, 3);
/* 186 */       d(paramaab, paramInt1, paramInt2, paramInt3, i);
/*     */     } 
/*     */     
/* 189 */     if (bool2) {
/* 190 */       paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */     }
/*     */   }
/*     */   
/*     */   public static boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 195 */     int i = paramInt1 + r.a[paramInt5];
/* 196 */     int j = paramInt2;
/* 197 */     int k = paramInt3 + r.b[paramInt5];
/* 198 */     int m = paramaak.a(i, j, k);
/* 199 */     boolean bool = ((paramInt4 & 0x2) == 2) ? true : false;
/*     */     
/* 201 */     if (m == apa.bX.cz) {
/* 202 */       int n = paramaak.h(i, j, k);
/* 203 */       int i1 = n & 0x3;
/*     */       
/* 205 */       return (i1 == r.f[paramInt5]);
/*     */     } 
/*     */     
/* 208 */     if (m == apa.bY.cz) {
/* 209 */       int n = paramaak.h(i, j, k);
/* 210 */       boolean bool1 = ((n & 0x2) == 2) ? true : false;
/* 211 */       return (bool == bool1);
/*     */     } 
/*     */     
/* 214 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */