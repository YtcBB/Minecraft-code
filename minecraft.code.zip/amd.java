/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class amd
/*    */   extends amb
/*    */ {
/* 17 */   private final bd cR = new bb();
/*    */   
/*    */   protected amd(int paramInt) {
/* 20 */     super(paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 25 */     this.cQ = paramly.a("furnace_side");
/* 26 */     this.c = paramly.a("furnace_top");
/* 27 */     this.d = paramly.a("dropper_front");
/* 28 */     this.e = paramly.a("dropper_front_vertical");
/*    */   }
/*    */ 
/*    */   
/*    */   protected bd a(wm paramwm) {
/* 33 */     return this.cR;
/*    */   }
/*    */   
/*    */   public aqp b(aab paramaab) {
/* 37 */     return new aqd();
/*    */   }
/*    */ 
/*    */   
/*    */   protected void j_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 42 */     ba ba = new ba(paramaab, paramInt1, paramInt2, paramInt3);
/* 43 */     aqc aqc = (aqc)ba.j();
/* 44 */     if (aqc == null)
/*    */       return; 
/* 46 */     int i = aqc.j();
/* 47 */     if (i < 0) {
/* 48 */       paramaab.e(1001, paramInt1, paramInt2, paramInt3, 0);
/*    */     } else {
/* 50 */       wm wm2, wm1 = aqc.a(i);
/* 51 */       int j = paramaab.h(paramInt1, paramInt2, paramInt3) & 0x7;
/* 52 */       lt lt = aqi.b(paramaab, (paramInt1 + s.b[j]), (paramInt2 + s.c[j]), (paramInt3 + s.d[j]));
/*    */ 
/*    */       
/* 55 */       if (lt != null) {
/* 56 */         wm2 = aqi.a(lt, wm1.m().a(1), s.a[j]);
/*    */         
/* 58 */         if (wm2 == null) {
/* 59 */           wm2 = wm1.m();
/* 60 */           if (--wm2.a == 0) wm2 = null;
/*    */         
/*    */         } else {
/*    */           
/* 64 */           wm2 = wm1.m();
/*    */         } 
/*    */       } else {
/* 67 */         wm2 = this.cR.a(ba, wm1);
/* 68 */         if (wm2 != null && wm2.a == 0) wm2 = null;
/*    */       
/*    */       } 
/* 71 */       aqc.a(i, wm2);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */