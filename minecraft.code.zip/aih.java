/*    */ 
/*    */ public class aih
/*    */ {
/*  4 */   public static final aih[] a = new aih[16];
/*    */   
/*  6 */   public static final aih b = new aih(0, 0);
/*  7 */   public static final aih c = new aih(1, 8368696);
/*  8 */   public static final aih d = new aih(2, 16247203);
/*  9 */   public static final aih e = new aih(3, 10987431);
/* 10 */   public static final aih f = new aih(4, 16711680);
/* 11 */   public static final aih g = new aih(5, 10526975);
/* 12 */   public static final aih h = new aih(6, 10987431);
/* 13 */   public static final aih i = new aih(7, 31744);
/* 14 */   public static final aih j = new aih(8, 16777215);
/* 15 */   public static final aih k = new aih(9, 10791096);
/* 16 */   public static final aih l = new aih(10, 12020271);
/* 17 */   public static final aih m = new aih(11, 7368816);
/* 18 */   public static final aih n = new aih(12, 4210943);
/* 19 */   public static final aih o = new aih(13, 6837042);
/*    */   
/*    */   public final int p;
/*    */   public final int q;
/*    */   
/*    */   private aih(int paramInt1, int paramInt2) {
/* 25 */     this.q = paramInt1;
/* 26 */     this.p = paramInt2;
/* 27 */     a[paramInt1] = this;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aih.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */