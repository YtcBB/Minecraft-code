/*    */ import java.util.List;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class alp
/*    */   extends apa
/*    */ {
/*    */   private lx[] a;
/*    */   
/*    */   public alp() {
/* 14 */     super(35, aif.n);
/* 15 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 20 */     return this.a[paramInt2 % this.a.length];
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt) {
/* 25 */     return paramInt;
/*    */   }
/*    */   
/*    */   public static int g_(int paramInt) {
/* 29 */     return (paramInt ^ 0xFFFFFFFF) & 0xF;
/*    */   }
/*    */   
/*    */   public static int c(int paramInt) {
/* 33 */     return (paramInt ^ 0xFFFFFFFF) & 0xF;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 38 */     for (byte b = 0; b < 16; b++) {
/* 39 */       paramList.add(new wm(paramInt, 1, b));
/*    */     }
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 45 */     this.a = new lx[16];
/*    */     
/* 47 */     for (byte b = 0; b < this.a.length; b++)
/* 48 */       this.a[b] = paramly.a("cloth_" + b); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */