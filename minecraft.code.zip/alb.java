/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class alb
/*     */   extends apa
/*     */ {
/*     */   protected final boolean a;
/*     */   
/*     */   public static final boolean d_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 260 */     return d_(paramaab.a(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   public static final boolean d_(int paramInt) {
/* 264 */     return (paramInt == apa.aK.cz || paramInt == apa.X.cz || paramInt == apa.Y.cz || paramInt == apa.cx.cz);
/*     */   }
/*     */   
/*     */   protected alb(int paramInt, boolean paramBoolean) {
/* 268 */     super(paramInt, aif.q);
/* 269 */     this.a = paramBoolean;
/* 270 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
/* 271 */     a(ve.e);
/*     */   }
/*     */   
/*     */   public boolean e() {
/* 275 */     return this.a;
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 280 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/* 289 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public ara a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, arc paramarc1, arc paramarc2) {
/* 294 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/* 295 */     return super.a(paramaab, paramInt1, paramInt2, paramInt3, paramarc1, paramarc2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 300 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 301 */     if (i >= 2 && i <= 5) {
/* 302 */       a(0.0F, 0.0F, 0.0F, 1.0F, 0.625F, 1.0F);
/*     */     } else {
/* 304 */       a(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/* 310 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 315 */     return 9;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 320 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 325 */     if (paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) {
/* 326 */       return true;
/*     */     }
/* 328 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 333 */     if (!paramaab.I) {
/* 334 */       a(paramaab, paramInt1, paramInt2, paramInt3, true);
/*     */       
/* 336 */       if (this.a) {
/* 337 */         a(paramaab, paramInt1, paramInt2, paramInt3, this.cz);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 346 */     if (paramaab.I)
/*     */       return; 
/* 348 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 349 */     int j = i;
/* 350 */     if (this.a) {
/* 351 */       j &= 0x7;
/*     */     }
/* 353 */     boolean bool = false;
/*     */     
/* 355 */     if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) bool = true; 
/* 356 */     if (j == 2 && !paramaab.w(paramInt1 + 1, paramInt2, paramInt3)) bool = true; 
/* 357 */     if (j == 3 && !paramaab.w(paramInt1 - 1, paramInt2, paramInt3)) bool = true; 
/* 358 */     if (j == 4 && !paramaab.w(paramInt1, paramInt2, paramInt3 - 1)) bool = true; 
/* 359 */     if (j == 5 && !paramaab.w(paramInt1, paramInt2, paramInt3 + 1)) bool = true;
/*     */     
/* 361 */     if (bool) {
/* 362 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 363 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } else {
/* 365 */       a(paramaab, paramInt1, paramInt2, paramInt3, i, j, paramInt4);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {}
/*     */   
/*     */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/* 373 */     if (paramaab.I)
/* 374 */       return;  (new alc(this, paramaab, paramInt1, paramInt2, paramInt3)).a(paramaab.C(paramInt1, paramInt2, paramInt3), paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int h() {
/* 380 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 385 */     int i = paramInt5;
/* 386 */     if (this.a) {
/* 387 */       i &= 0x7;
/*     */     }
/*     */     
/* 390 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */     
/* 392 */     if (i == 2 || i == 3 || i == 4 || i == 5) {
/* 393 */       paramaab.f(paramInt1, paramInt2 + 1, paramInt3, paramInt4);
/*     */     }
/* 395 */     if (this.a) {
/* 396 */       paramaab.f(paramInt1, paramInt2, paramInt3, paramInt4);
/* 397 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, paramInt4);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */