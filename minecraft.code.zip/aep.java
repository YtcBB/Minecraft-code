/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aep
/*     */   extends agw
/*     */ {
/*  63 */   private List a = new LinkedList();
/*     */   
/*     */   public aep(int paramInt1, Random paramRandom, int paramInt2, int paramInt3) {
/*  66 */     super(paramInt1);
/*     */     
/*  68 */     this.e = new aek(paramInt2, 50, paramInt3, paramInt2 + 7 + paramRandom.nextInt(6), 54 + paramRandom.nextInt(6), paramInt3 + 7 + paramRandom.nextInt(6));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/*  74 */     int i = c();
/*     */ 
/*     */ 
/*     */     
/*  78 */     int k = this.e.c() - 3 - 1;
/*  79 */     if (k <= 0) {
/*  80 */       k = 1;
/*     */     }
/*     */ 
/*     */     
/*  84 */     int j = 0;
/*  85 */     while (j < this.e.b()) {
/*  86 */       j += paramRandom.nextInt(this.e.b());
/*  87 */       if (j + 3 > this.e.b()) {
/*     */         break;
/*     */       }
/*  90 */       agw agw1 = aem.a(paramagw, paramList, paramRandom, this.e.a + j, this.e.b + paramRandom.nextInt(k) + 1, this.e.c - 1, 2, i);
/*     */       
/*  92 */       if (agw1 != null) {
/*  93 */         aek aek = agw1.b();
/*  94 */         this.a.add(new aek(aek.a, aek.b, this.e.c, aek.d, aek.e, this.e.c + 1));
/*     */       } 
/*  96 */       j += 4;
/*     */     } 
/*     */     
/*  99 */     j = 0;
/* 100 */     while (j < this.e.b()) {
/* 101 */       j += paramRandom.nextInt(this.e.b());
/* 102 */       if (j + 3 > this.e.b()) {
/*     */         break;
/*     */       }
/* 105 */       agw agw1 = aem.a(paramagw, paramList, paramRandom, this.e.a + j, this.e.b + paramRandom.nextInt(k) + 1, this.e.f + 1, 0, i);
/*     */       
/* 107 */       if (agw1 != null) {
/* 108 */         aek aek = agw1.b();
/* 109 */         this.a.add(new aek(aek.a, aek.b, this.e.f - 1, aek.d, aek.e, this.e.f));
/*     */       } 
/* 111 */       j += 4;
/*     */     } 
/*     */     
/* 114 */     j = 0;
/* 115 */     while (j < this.e.d()) {
/* 116 */       j += paramRandom.nextInt(this.e.d());
/* 117 */       if (j + 3 > this.e.d()) {
/*     */         break;
/*     */       }
/* 120 */       agw agw1 = aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b + paramRandom.nextInt(k) + 1, this.e.c + j, 1, i);
/*     */       
/* 122 */       if (agw1 != null) {
/* 123 */         aek aek = agw1.b();
/* 124 */         this.a.add(new aek(this.e.a, aek.b, aek.c, this.e.a + 1, aek.e, aek.f));
/*     */       } 
/* 126 */       j += 4;
/*     */     } 
/*     */     
/* 129 */     j = 0;
/* 130 */     while (j < this.e.d()) {
/* 131 */       j += paramRandom.nextInt(this.e.d());
/* 132 */       if (j + 3 > this.e.d()) {
/*     */         break;
/*     */       }
/* 135 */       agw agw1 = aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b + paramRandom.nextInt(k) + 1, this.e.c + j, 3, i);
/*     */       
/* 137 */       if (agw1 != null) {
/* 138 */         aek aek = agw1.b();
/* 139 */         this.a.add(new aek(this.e.d - 1, aek.b, aek.c, this.e.d, aek.e, aek.f));
/*     */       } 
/* 141 */       j += 4;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 148 */     if (a(paramaab, paramaek)) {
/* 149 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 153 */     a(paramaab, paramaek, this.e.a, this.e.b, this.e.c, this.e.d, this.e.b, this.e.f, apa.z.cz, 0, true);
/*     */ 
/*     */     
/* 156 */     a(paramaab, paramaek, this.e.a, this.e.b + 1, this.e.c, this.e.d, Math.min(this.e.b + 3, this.e.e), this.e.f, 0, 0, false);
/* 157 */     for (aek aek1 : this.a) {
/* 158 */       a(paramaab, paramaek, aek1.a, aek1.e - 2, aek1.c, aek1.d, aek1.e, aek1.f, 0, 0, false);
/*     */     }
/* 160 */     a(paramaab, paramaek, this.e.a, this.e.b + 4, this.e.c, this.e.d, this.e.e, this.e.f, 0, false);
/*     */     
/* 162 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aep.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */