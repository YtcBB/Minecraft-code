/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class all
/*    */   extends alu
/*    */ {
/*    */   private lx[] a;
/*    */   
/*    */   public all(int paramInt) {
/* 11 */     super(paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 16 */     if (paramInt2 < 7) {
/* 17 */       if (paramInt2 == 6) {
/* 18 */         paramInt2 = 5;
/*    */       }
/* 20 */       return this.a[paramInt2 >> 1];
/*    */     } 
/* 22 */     return this.a[3];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected int j() {
/* 28 */     return wk.bL.cp;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int k() {
/* 33 */     return wk.bL.cp;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 38 */     this.a = new lx[4];
/*    */     
/* 40 */     for (byte b = 0; b < this.a.length; b++)
/* 41 */       this.a[b] = paramly.a("carrots_" + b); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\all.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */