/*   */ 
/*   */ 
/*   */ 
/*   */ public class amv
/*   */   extends apa
/*   */ {
/*   */   public amv(int paramInt) {
/* 8 */     super(paramInt, aif.e);
/* 9 */     a(ve.b);
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */