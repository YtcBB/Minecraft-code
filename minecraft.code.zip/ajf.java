/*    */ public class ajf
/*    */   extends ait
/*    */ {
/*    */   public ajf(long paramLong, ait paramait) {
/*  5 */     super(paramLong);
/*  6 */     this.a = paramait;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 11 */     int i = paramInt1 >> 1;
/* 12 */     int j = paramInt2 >> 1;
/* 13 */     int k = (paramInt3 >> 1) + 3;
/* 14 */     int m = (paramInt4 >> 1) + 3;
/* 15 */     int[] arrayOfInt1 = this.a.a(i, j, k, m);
/*    */     
/* 17 */     int[] arrayOfInt2 = air.a(k * 2 * m * 2);
/* 18 */     int n = k << 1;
/* 19 */     for (byte b1 = 0; b1 < m - 1; b1++) {
/* 20 */       int i1 = b1 << 1;
/* 21 */       int i2 = i1 * n;
/* 22 */       int i3 = arrayOfInt1[0 + (b1 + 0) * k];
/* 23 */       int i4 = arrayOfInt1[0 + (b1 + 1) * k];
/* 24 */       for (byte b = 0; b < k - 1; b++) {
/* 25 */         a((b + i << 1), (b1 + j << 1));
/* 26 */         int i5 = arrayOfInt1[b + 1 + (b1 + 0) * k];
/* 27 */         int i6 = arrayOfInt1[b + 1 + (b1 + 1) * k];
/*    */         
/* 29 */         arrayOfInt2[i2] = i3;
/* 30 */         arrayOfInt2[i2++ + n] = a(i3, i4);
/* 31 */         arrayOfInt2[i2] = a(i3, i5);
/* 32 */         arrayOfInt2[i2++ + n] = b(i3, i5, i4, i6);
/*    */         
/* 34 */         i3 = i5;
/* 35 */         i4 = i6;
/*    */       } 
/*    */     } 
/* 38 */     int[] arrayOfInt3 = air.a(paramInt3 * paramInt4);
/* 39 */     for (byte b2 = 0; b2 < paramInt4; b2++) {
/* 40 */       System.arraycopy(arrayOfInt2, (b2 + (paramInt2 & 0x1)) * (k << 1) + (paramInt1 & 0x1), arrayOfInt3, b2 * paramInt3, paramInt3);
/*    */     }
/* 42 */     return arrayOfInt3;
/*    */   }
/*    */   
/*    */   protected int a(int paramInt1, int paramInt2) {
/* 46 */     return (a(2) == 0) ? paramInt1 : paramInt2;
/*    */   }
/*    */   
/*    */   protected int b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 50 */     if (paramInt2 == paramInt3 && paramInt3 == paramInt4) return paramInt2; 
/* 51 */     if (paramInt1 == paramInt2 && paramInt1 == paramInt3) return paramInt1; 
/* 52 */     if (paramInt1 == paramInt2 && paramInt1 == paramInt4) return paramInt1; 
/* 53 */     if (paramInt1 == paramInt3 && paramInt1 == paramInt4) return paramInt1;
/*    */     
/* 55 */     if (paramInt1 == paramInt2 && paramInt3 != paramInt4) return paramInt1; 
/* 56 */     if (paramInt1 == paramInt3 && paramInt2 != paramInt4) return paramInt1; 
/* 57 */     if (paramInt1 == paramInt4 && paramInt2 != paramInt3) return paramInt1;
/*    */     
/* 59 */     if (paramInt2 == paramInt1 && paramInt3 != paramInt4) return paramInt2; 
/* 60 */     if (paramInt2 == paramInt3 && paramInt1 != paramInt4) return paramInt2; 
/* 61 */     if (paramInt2 == paramInt4 && paramInt1 != paramInt3) return paramInt2;
/*    */     
/* 63 */     if (paramInt3 == paramInt1 && paramInt2 != paramInt4) return paramInt3; 
/* 64 */     if (paramInt3 == paramInt2 && paramInt1 != paramInt4) return paramInt3; 
/* 65 */     if (paramInt3 == paramInt4 && paramInt1 != paramInt2) return paramInt3;
/*    */     
/* 67 */     if (paramInt4 == paramInt1 && paramInt2 != paramInt3) return paramInt3; 
/* 68 */     if (paramInt4 == paramInt2 && paramInt1 != paramInt3) return paramInt3; 
/* 69 */     if (paramInt4 == paramInt3 && paramInt1 != paramInt2) return paramInt3;
/*    */     
/* 71 */     int i = a(4);
/* 72 */     if (i == 0) return paramInt1; 
/* 73 */     if (i == 1) return paramInt2; 
/* 74 */     if (i == 2) return paramInt3; 
/* 75 */     return paramInt4;
/*    */   }
/*    */   
/*    */   public static ait a(long paramLong, ait paramait, int paramInt) {
/* 79 */     ait ait1 = paramait;
/* 80 */     for (byte b = 0; b < paramInt; b++) {
/* 81 */       ait1 = new ajf(paramLong + b, ait1);
/*    */     }
/* 83 */     return ait1;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */