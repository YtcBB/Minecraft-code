/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aqi
/*     */   extends aqp
/*     */   implements aqh
/*     */ {
/*  25 */   private wm[] a = new wm[5];
/*     */   private String b;
/*  27 */   private int c = -1;
/*     */ 
/*     */   
/*     */   public void a(bs parambs) {
/*  31 */     super.a(parambs);
/*     */     
/*  33 */     ca ca = parambs.m("Items");
/*  34 */     this.a = new wm[j_()];
/*  35 */     if (parambs.b("CustomName")) this.b = parambs.i("CustomName"); 
/*  36 */     this.c = parambs.e("TransferCooldown");
/*  37 */     for (byte b = 0; b < ca.c(); b++) {
/*  38 */       bs bs1 = (bs)ca.b(b);
/*  39 */       byte b1 = bs1.c("Slot");
/*  40 */       if (b1 >= 0 && b1 < this.a.length) this.a[b1] = wm.a(bs1);
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public void b(bs parambs) {
/*  46 */     super.b(parambs);
/*  47 */     ca ca = new ca();
/*     */     
/*  49 */     for (byte b = 0; b < this.a.length; b++) {
/*  50 */       if (this.a[b] != null) {
/*  51 */         bs bs1 = new bs();
/*  52 */         bs1.a("Slot", (byte)b);
/*  53 */         this.a[b].b(bs1);
/*  54 */         ca.a(bs1);
/*     */       } 
/*     */     } 
/*  57 */     parambs.a("Items", ca);
/*  58 */     parambs.a("TransferCooldown", this.c);
/*  59 */     if (c()) parambs.a("CustomName", this.b);
/*     */   
/*     */   }
/*     */   
/*     */   public void k_() {
/*  64 */     super.k_();
/*     */   }
/*     */   
/*     */   public int j_() {
/*  68 */     return this.a.length;
/*     */   }
/*     */   
/*     */   public wm a(int paramInt) {
/*  72 */     return this.a[paramInt];
/*     */   }
/*     */   
/*     */   public wm a(int paramInt1, int paramInt2) {
/*  76 */     if (this.a[paramInt1] != null) {
/*  77 */       if ((this.a[paramInt1]).a <= paramInt2) {
/*  78 */         wm wm2 = this.a[paramInt1];
/*  79 */         this.a[paramInt1] = null;
/*  80 */         return wm2;
/*     */       } 
/*  82 */       wm wm1 = this.a[paramInt1].a(paramInt2);
/*  83 */       if ((this.a[paramInt1]).a == 0) this.a[paramInt1] = null; 
/*  84 */       return wm1;
/*     */     } 
/*     */     
/*  87 */     return null;
/*     */   }
/*     */   
/*     */   public wm b(int paramInt) {
/*  91 */     if (this.a[paramInt] != null) {
/*  92 */       wm wm1 = this.a[paramInt];
/*  93 */       this.a[paramInt] = null;
/*  94 */       return wm1;
/*     */     } 
/*  96 */     return null;
/*     */   }
/*     */   
/*     */   public void a(int paramInt, wm paramwm) {
/* 100 */     this.a[paramInt] = paramwm;
/* 101 */     if (paramwm != null && paramwm.a > d()) paramwm.a = d(); 
/*     */   }
/*     */   
/*     */   public String b() {
/* 105 */     return c() ? this.b : "container.hopper";
/*     */   }
/*     */   
/*     */   public boolean c() {
/* 109 */     return (this.b != null && this.b.length() > 0);
/*     */   }
/*     */   
/*     */   public void a(String paramString) {
/* 113 */     this.b = paramString;
/*     */   }
/*     */   
/*     */   public int d() {
/* 117 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean a(sq paramsq) {
/* 121 */     if (this.k.r(this.l, this.m, this.n) != this) return false; 
/* 122 */     if (paramsq.e(this.l + 0.5D, this.m + 0.5D, this.n + 0.5D) > 64.0D) return false; 
/* 123 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void f() {}
/*     */ 
/*     */   
/*     */   public void g() {}
/*     */   
/*     */   public boolean b(int paramInt, wm paramwm) {
/* 133 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void h() {
/* 138 */     if (this.k == null || this.k.I)
/*     */       return; 
/* 140 */     this.c--;
/*     */     
/* 142 */     if (!l()) {
/* 143 */       c(0);
/* 144 */       j();
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean j() {
/* 149 */     if (this.k == null || this.k.I) return false;
/*     */     
/* 151 */     if (!l() && amw.d(p())) {
/*     */       
/* 153 */       int i = u() | a(this);
/*     */       
/* 155 */       if (i != 0) {
/* 156 */         c(8);
/* 157 */         k_();
/* 158 */         return true;
/*     */       } 
/*     */     } 
/*     */     
/* 162 */     return false;
/*     */   }
/*     */   
/*     */   private boolean u() {
/* 166 */     lt lt = v();
/* 167 */     if (lt == null) {
/* 168 */       return false;
/*     */     }
/*     */     
/* 171 */     for (byte b = 0; b < j_(); b++) {
/* 172 */       if (a(b) != null) {
/*     */         
/* 174 */         wm wm1 = a(b).m();
/* 175 */         wm wm2 = a(lt, a(b, 1), s.a[amw.c(p())]);
/*     */         
/* 177 */         if (wm2 == null || wm2.a == 0) {
/* 178 */           lt.k_();
/* 179 */           return true;
/*     */         } 
/* 181 */         a(b, wm1);
/*     */       } 
/*     */     } 
/*     */     
/* 185 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean a(aqh paramaqh) {
/* 189 */     lt lt = b(paramaqh);
/*     */     
/* 191 */     if (lt != null) {
/* 192 */       byte b = 0;
/*     */       
/* 194 */       if (lt instanceof md && b > -1) {
/* 195 */         md md = (md)lt;
/* 196 */         int[] arrayOfInt = md.c(b);
/*     */         
/* 198 */         for (byte b1 = 0; b1 < arrayOfInt.length; b1++) {
/* 199 */           if (a(paramaqh, lt, arrayOfInt[b1], b)) return true; 
/*     */         } 
/*     */       } else {
/* 202 */         int i = lt.j_();
/* 203 */         for (byte b1 = 0; b1 < i; b1++) {
/* 204 */           if (a(paramaqh, lt, b1, b)) return true; 
/*     */         } 
/*     */       } 
/*     */     } else {
/* 208 */       rh rh = a(paramaqh.az(), paramaqh.aA(), paramaqh.aB() + 1.0D, paramaqh.aC());
/*     */       
/* 210 */       if (rh != null) {
/* 211 */         return a(paramaqh, rh);
/*     */       }
/*     */     } 
/*     */     
/* 215 */     return false;
/*     */   }
/*     */   
/*     */   private static boolean a(aqh paramaqh, lt paramlt, int paramInt1, int paramInt2) {
/* 219 */     wm wm1 = paramlt.a(paramInt1);
/*     */     
/* 221 */     if (wm1 != null && b(paramlt, wm1, paramInt1, paramInt2)) {
/* 222 */       wm wm2 = wm1.m();
/* 223 */       wm wm3 = a(paramaqh, paramlt.a(paramInt1, 1), -1);
/*     */       
/* 225 */       if (wm3 == null || wm3.a == 0) {
/* 226 */         paramlt.k_();
/* 227 */         return true;
/*     */       } 
/* 229 */       paramlt.a(paramInt1, wm2);
/*     */     } 
/*     */ 
/*     */     
/* 233 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean a(lt paramlt, rh paramrh) {
/* 237 */     boolean bool = false;
/* 238 */     if (paramrh == null) return false;
/*     */     
/* 240 */     wm wm1 = paramrh.d().m();
/* 241 */     wm wm2 = a(paramlt, wm1, -1);
/*     */     
/* 243 */     if (wm2 == null || wm2.a == 0) {
/* 244 */       bool = true;
/*     */       
/* 246 */       paramrh.w();
/*     */     } else {
/* 248 */       paramrh.a(wm2);
/*     */     } 
/*     */     
/* 251 */     return bool;
/*     */   }
/*     */   
/*     */   public static wm a(lt paramlt, wm paramwm, int paramInt) {
/* 255 */     if (paramlt instanceof md && paramInt > -1) {
/* 256 */       md md = (md)paramlt;
/* 257 */       int[] arrayOfInt = md.c(paramInt);
/*     */       
/* 259 */       for (byte b = 0; b < arrayOfInt.length && paramwm != null && paramwm.a > 0; b++) {
/* 260 */         paramwm = c(paramlt, paramwm, arrayOfInt[b], paramInt);
/*     */       }
/*     */     } else {
/* 263 */       int i = paramlt.j_();
/* 264 */       for (byte b = 0; b < i && paramwm != null && paramwm.a > 0; b++) {
/* 265 */         paramwm = c(paramlt, paramwm, b, paramInt);
/*     */       }
/*     */     } 
/*     */     
/* 269 */     if (paramwm != null && paramwm.a == 0) {
/* 270 */       paramwm = null;
/*     */     }
/*     */     
/* 273 */     return paramwm;
/*     */   }
/*     */   
/*     */   private static boolean a(lt paramlt, wm paramwm, int paramInt1, int paramInt2) {
/* 277 */     if (!paramlt.b(paramInt1, paramwm)) return false; 
/* 278 */     if (paramlt instanceof md && !((md)paramlt).a(paramInt1, paramwm, paramInt2)) return false; 
/* 279 */     return true;
/*     */   }
/*     */   
/*     */   private static boolean b(lt paramlt, wm paramwm, int paramInt1, int paramInt2) {
/* 283 */     if (paramlt instanceof md && !((md)paramlt).b(paramInt1, paramwm, paramInt2)) return false; 
/* 284 */     return true;
/*     */   }
/*     */   
/*     */   private static wm c(lt paramlt, wm paramwm, int paramInt1, int paramInt2) {
/* 288 */     wm wm1 = paramlt.a(paramInt1);
/*     */     
/* 290 */     if (a(paramlt, paramwm, paramInt1, paramInt2)) {
/* 291 */       boolean bool = false;
/* 292 */       if (wm1 == null) {
/* 293 */         paramlt.a(paramInt1, paramwm);
/* 294 */         paramwm = null;
/* 295 */         bool = true;
/* 296 */       } else if (a(wm1, paramwm)) {
/* 297 */         int i = paramwm.e() - wm1.a;
/* 298 */         int j = Math.min(paramwm.a, i);
/*     */         
/* 300 */         paramwm.a -= j;
/* 301 */         wm1.a += j;
/* 302 */         bool = (j > 0) ? true : false;
/*     */       } 
/* 304 */       if (bool) {
/* 305 */         if (paramlt instanceof aqi) {
/* 306 */           ((aqi)paramlt).c(8);
/*     */         }
/* 308 */         paramlt.k_();
/*     */       } 
/*     */     } 
/* 311 */     return paramwm;
/*     */   }
/*     */   
/*     */   private lt v() {
/* 315 */     int i = amw.c(p());
/* 316 */     return b(az(), (this.l + s.b[i]), (this.m + s.c[i]), (this.n + s.d[i]));
/*     */   }
/*     */   
/*     */   public static lt b(aqh paramaqh) {
/* 320 */     return b(paramaqh.az(), paramaqh.aA(), paramaqh.aB() + 1.0D, paramaqh.aC());
/*     */   }
/*     */   
/*     */   public static rh a(aab paramaab, double paramDouble1, double paramDouble2, double paramDouble3) {
/* 324 */     List<rh> list = paramaab.a(rh.class, aqx.a().a(paramDouble1, paramDouble2, paramDouble3, paramDouble1 + 1.0D, paramDouble2 + 1.0D, paramDouble3 + 1.0D), my.a);
/*     */     
/* 326 */     if (list.size() > 0) {
/* 327 */       return list.get(0);
/*     */     }
/* 329 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public static lt b(aab paramaab, double paramDouble1, double paramDouble2, double paramDouble3) {
/* 334 */     lt lt = null;
/* 335 */     int i = kx.c(paramDouble1);
/* 336 */     int j = kx.c(paramDouble2);
/* 337 */     int k = kx.c(paramDouble3);
/*     */     
/* 339 */     aqp aqp1 = paramaab.r(i, j, k);
/*     */     
/* 341 */     if (aqp1 != null && aqp1 instanceof lt) {
/* 342 */       lt = (lt)aqp1;
/*     */       
/* 344 */       if (lt instanceof apy) {
/* 345 */         int m = paramaab.a(i, j, k);
/* 346 */         apa apa = apa.r[m];
/*     */         
/* 348 */         if (apa instanceof aln) {
/* 349 */           lt = ((aln)apa).g_(paramaab, i, j, k);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 354 */     if (lt == null) {
/* 355 */       List<lt> list = paramaab.a((mp)null, aqx.a().a(paramDouble1, paramDouble2, paramDouble3, paramDouble1 + 1.0D, paramDouble2 + 1.0D, paramDouble3 + 1.0D), my.b);
/*     */       
/* 357 */       if (list != null && list.size() > 0) {
/* 358 */         lt = list.get(paramaab.s.nextInt(list.size()));
/*     */       }
/*     */     } 
/*     */     
/* 362 */     return lt;
/*     */   }
/*     */   
/*     */   private static boolean a(wm paramwm1, wm paramwm2) {
/* 366 */     if (paramwm1.c != paramwm2.c) return false; 
/* 367 */     if (paramwm1.k() != paramwm2.k()) return false; 
/* 368 */     if (paramwm1.a > paramwm1.e()) return false; 
/* 369 */     if (!wm.a(paramwm1, paramwm2)) return false; 
/* 370 */     return true;
/*     */   }
/*     */   
/*     */   public double aA() {
/* 374 */     return this.l;
/*     */   }
/*     */   
/*     */   public double aB() {
/* 378 */     return this.m;
/*     */   }
/*     */   
/*     */   public double aC() {
/* 382 */     return this.n;
/*     */   }
/*     */   
/*     */   public void c(int paramInt) {
/* 386 */     this.c = paramInt;
/*     */   }
/*     */   
/*     */   public boolean l() {
/* 390 */     return (this.c > 0);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqi.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */