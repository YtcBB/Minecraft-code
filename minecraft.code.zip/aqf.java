/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aqf
/*    */   extends aqp
/*    */ {
/*    */   public float a;
/*    */   public float b;
/*    */   public int c;
/*    */   private int d;
/*    */   
/*    */   public void h() {
/* 17 */     super.h();
/*    */     
/* 19 */     if (++this.d % 20 * 4 == 0) {
/* 20 */       this.k.d(this.l, this.m, this.n, apa.bW.cz, 1, this.c);
/*    */     }
/*    */     
/* 23 */     this.b = this.a;
/*    */     
/* 25 */     float f = 0.1F;
/* 26 */     if (this.c > 0 && this.a == 0.0F) {
/* 27 */       double d1 = this.l + 0.5D;
/* 28 */       double d2 = this.n + 0.5D;
/*    */       
/* 30 */       this.k.a(d1, this.m + 0.5D, d2, "random.chestopen", 0.5F, this.k.s.nextFloat() * 0.1F + 0.9F);
/*    */     } 
/* 32 */     if ((this.c == 0 && this.a > 0.0F) || (this.c > 0 && this.a < 1.0F)) {
/* 33 */       float f1 = this.a;
/* 34 */       if (this.c > 0) { this.a += f; }
/* 35 */       else { this.a -= f; }
/* 36 */        if (this.a > 1.0F) {
/* 37 */         this.a = 1.0F;
/*    */       }
/* 39 */       float f2 = 0.5F;
/* 40 */       if (this.a < f2 && f1 >= f2) {
/* 41 */         double d1 = this.l + 0.5D;
/* 42 */         double d2 = this.n + 0.5D;
/*    */         
/* 44 */         this.k.a(d1, this.m + 0.5D, d2, "random.chestclosed", 0.5F, this.k.s.nextFloat() * 0.1F + 0.9F);
/*    */       } 
/* 46 */       if (this.a < 0.0F) {
/* 47 */         this.a = 0.0F;
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b(int paramInt1, int paramInt2) {
/* 54 */     if (paramInt1 == 1) {
/* 55 */       this.c = paramInt2;
/* 56 */       return true;
/*    */     } 
/* 58 */     return super.b(paramInt1, paramInt2);
/*    */   }
/*    */ 
/*    */   
/*    */   public void w_() {
/* 63 */     i();
/* 64 */     super.w_();
/*    */   }
/*    */   
/*    */   public void a() {
/* 68 */     this.c++;
/* 69 */     this.k.d(this.l, this.m, this.n, apa.bW.cz, 1, this.c);
/*    */   }
/*    */   
/*    */   public void b() {
/* 73 */     this.c--;
/* 74 */     this.k.d(this.l, this.m, this.n, apa.bW.cz, 1, this.c);
/*    */   }
/*    */   
/*    */   public boolean a(sq paramsq) {
/* 78 */     if (this.k.r(this.l, this.m, this.n) != this) return false; 
/* 79 */     if (paramsq.e(this.l + 0.5D, this.m + 0.5D, this.n + 0.5D) > 64.0D) return false;
/*    */     
/* 81 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */