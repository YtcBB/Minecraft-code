public interface acb {
  abw a(aab paramaab, int paramInt1, int paramInt2);
  
  void a(aab paramaab, abw paramabw);
  
  void b(aab paramaab, abw paramabw);
  
  void a();
  
  void b();
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */