/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.List;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class acj
/*     */   implements acb, akw
/*     */ {
/*  25 */   private List a = new ArrayList();
/*  26 */   private Set b = new HashSet();
/*  27 */   private Object c = new Object();
/*     */   
/*     */   private final File d;
/*     */   
/*     */   public acj(File paramFile) {
/*  32 */     this.d = paramFile;
/*     */   }
/*     */ 
/*     */   
/*     */   public abw a(aab paramaab, int paramInt1, int paramInt2) {
/*  37 */     bs bs = null;
/*  38 */     zu zu = new zu(paramInt1, paramInt2);
/*     */     
/*  40 */     synchronized (this.c) {
/*  41 */       if (this.b.contains(zu)) {
/*  42 */         for (byte b = 0; b < this.a.size(); b++) {
/*  43 */           if (((ack)this.a.get(b)).a.equals(zu)) {
/*  44 */             bs = ((ack)this.a.get(b)).b;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*  51 */     if (bs == null) {
/*  52 */       DataInputStream dataInputStream = aci.c(this.d, paramInt1, paramInt2);
/*  53 */       if (dataInputStream != null) {
/*  54 */         bs = cc.a(dataInputStream);
/*     */       } else {
/*  56 */         return null;
/*     */       } 
/*     */     } 
/*     */     
/*  60 */     return a(paramaab, paramInt1, paramInt2, bs);
/*     */   }
/*     */   
/*     */   protected abw a(aab paramaab, int paramInt1, int paramInt2, bs parambs) {
/*  64 */     if (!parambs.b("Level")) {
/*  65 */       paramaab.X().c("Chunk file at " + paramInt1 + "," + paramInt2 + " is missing level data, skipping");
/*  66 */       return null;
/*     */     } 
/*  68 */     if (!parambs.l("Level").b("Sections")) {
/*  69 */       paramaab.X().c("Chunk file at " + paramInt1 + "," + paramInt2 + " is missing block data, skipping");
/*  70 */       return null;
/*     */     } 
/*  72 */     abw abw = a(paramaab, parambs.l("Level"));
/*  73 */     if (!abw.a(paramInt1, paramInt2)) {
/*  74 */       paramaab.X().c("Chunk file at " + paramInt1 + "," + paramInt2 + " is in the wrong location; relocating. (Expected " + paramInt1 + ", " + paramInt2 + ", got " + abw.g + ", " + abw.h + ")");
/*  75 */       parambs.a("xPos", paramInt1);
/*  76 */       parambs.a("zPos", paramInt2);
/*  77 */       abw = a(paramaab, parambs.l("Level"));
/*     */     } 
/*  79 */     return abw;
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, abw paramabw) {
/*  83 */     paramaab.F();
/*     */     
/*     */     try {
/*  86 */       bs bs1 = new bs();
/*  87 */       bs bs2 = new bs();
/*  88 */       bs1.a("Level", bs2);
/*  89 */       a(paramabw, paramaab, bs2);
/*  90 */       a(paramabw.l(), bs1);
/*  91 */     } catch (Exception exception) {
/*  92 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void a(zu paramzu, bs parambs) {
/*  97 */     synchronized (this.c) {
/*  98 */       if (this.b.contains(paramzu)) {
/*  99 */         for (byte b = 0; b < this.a.size(); b++) {
/* 100 */           if (((ack)this.a.get(b)).a.equals(paramzu)) {
/* 101 */             this.a.set(b, new ack(paramzu, parambs));
/*     */             return;
/*     */           } 
/*     */         } 
/*     */       }
/* 106 */       this.a.add(new ack(paramzu, parambs));
/* 107 */       this.b.add(paramzu);
/* 108 */       akv.a.a(this);
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean c() {
/* 113 */     ack ack = null;
/*     */     
/* 115 */     synchronized (this.c) {
/* 116 */       if (!this.a.isEmpty()) {
/* 117 */         ack = this.a.remove(0);
/* 118 */         this.b.remove(ack.a);
/*     */       } else {
/* 120 */         return false;
/*     */       } 
/*     */     } 
/* 123 */     if (ack != null) {
/*     */       try {
/* 125 */         a(ack);
/* 126 */       } catch (Exception exception) {
/* 127 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/* 131 */     return true;
/*     */   }
/*     */   
/*     */   private void a(ack paramack) {
/* 135 */     DataOutputStream dataOutputStream = aci.d(this.d, paramack.a.a, paramack.a.b);
/* 136 */     cc.a(paramack.b, dataOutputStream);
/* 137 */     dataOutputStream.close();
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, abw paramabw) {}
/*     */ 
/*     */   
/*     */   public void a() {}
/*     */   
/*     */   public void b() {
/* 147 */     while (c());
/*     */   }
/*     */ 
/*     */   
/*     */   private void a(abw paramabw, aab paramaab, bs parambs) {
/* 152 */     parambs.a("xPos", paramabw.g);
/* 153 */     parambs.a("zPos", paramabw.h);
/* 154 */     parambs.a("LastUpdate", paramaab.H());
/* 155 */     parambs.a("HeightMap", paramabw.f);
/* 156 */     parambs.a("TerrainPopulated", paramabw.k);
/*     */     
/* 158 */     abx[] arrayOfAbx = paramabw.i();
/* 159 */     ca ca1 = new ca("Sections");
/*     */     
/* 161 */     boolean bool = !paramaab.t.f ? true : false;
/*     */     
/* 163 */     for (abx abx : arrayOfAbx) {
/*     */       
/* 165 */       if (abx != null) {
/*     */ 
/*     */         
/* 168 */         bs bs1 = new bs();
/*     */         
/* 170 */         bs1.a("Y", (byte)(abx.d() >> 4 & 0xFF));
/* 171 */         bs1.a("Blocks", abx.g());
/* 172 */         if (abx.i() != null) {
/* 173 */           bs1.a("Add", (abx.i()).a);
/*     */         }
/* 175 */         bs1.a("Data", (abx.j()).a);
/* 176 */         bs1.a("BlockLight", (abx.k()).a);
/* 177 */         if (bool) {
/* 178 */           bs1.a("SkyLight", (abx.l()).a);
/*     */         }
/*     */         else {
/*     */           
/* 182 */           bs1.a("SkyLight", new byte[(abx.k()).a.length]);
/*     */         } 
/*     */         
/* 185 */         ca1.a(bs1);
/*     */       } 
/* 187 */     }  parambs.a("Sections", ca1);
/* 188 */     parambs.a("Biomes", paramabw.m());
/*     */     
/* 190 */     paramabw.m = false;
/* 191 */     ca ca2 = new ca();
/* 192 */     for (byte b = 0; b < paramabw.j.length; b++) {
/* 193 */       for (mp mp : paramabw.j[b]) {
/* 194 */         bs bs1 = new bs();
/* 195 */         if (mp.d(bs1)) {
/* 196 */           paramabw.m = true;
/* 197 */           ca2.a(bs1);
/*     */         } 
/*     */       } 
/*     */     } 
/* 201 */     parambs.a("Entities", ca2);
/*     */     
/* 203 */     ca ca3 = new ca();
/* 204 */     for (aqp aqp : paramabw.i.values()) {
/* 205 */       bs bs1 = new bs();
/* 206 */       aqp.b(bs1);
/* 207 */       ca3.a(bs1);
/*     */     } 
/* 209 */     parambs.a("TileEntities", ca3);
/*     */     
/* 211 */     List list = paramaab.a(paramabw, false);
/* 212 */     if (list != null) {
/* 213 */       long l = paramaab.H();
/*     */       
/* 215 */       ca ca = new ca();
/* 216 */       for (aar aar : list) {
/* 217 */         bs bs1 = new bs();
/* 218 */         bs1.a("i", aar.d);
/* 219 */         bs1.a("x", aar.a);
/* 220 */         bs1.a("y", aar.b);
/* 221 */         bs1.a("z", aar.c);
/* 222 */         bs1.a("t", (int)(aar.e - l));
/* 223 */         bs1.a("p", aar.f);
/*     */         
/* 225 */         ca.a(bs1);
/*     */       } 
/*     */       
/* 228 */       parambs.a("TileTicks", ca);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private abw a(aab paramaab, bs parambs) {
/* 234 */     int i = parambs.e("xPos");
/* 235 */     int j = parambs.e("zPos");
/*     */     
/* 237 */     abw abw = new abw(paramaab, i, j);
/* 238 */     abw.f = parambs.k("HeightMap");
/* 239 */     abw.k = parambs.n("TerrainPopulated");
/*     */     
/* 241 */     ca ca1 = parambs.m("Sections");
/* 242 */     byte b1 = 16;
/* 243 */     abx[] arrayOfAbx = new abx[b1];
/*     */     
/* 245 */     boolean bool = !paramaab.t.f ? true : false;
/*     */     
/* 247 */     for (byte b2 = 0; b2 < ca1.c(); b2++) {
/* 248 */       bs bs1 = (bs)ca1.b(b2);
/*     */       
/* 250 */       byte b = bs1.c("Y");
/* 251 */       abx abx = new abx(b << 4, bool);
/* 252 */       abx.a(bs1.j("Blocks"));
/* 253 */       if (bs1.b("Add")) {
/* 254 */         abx.a(new abu(bs1.j("Add"), 4));
/*     */       }
/* 256 */       abx.b(new abu(bs1.j("Data"), 4));
/* 257 */       abx.c(new abu(bs1.j("BlockLight"), 4));
/* 258 */       if (bool) {
/* 259 */         abx.d(new abu(bs1.j("SkyLight"), 4));
/*     */       }
/* 261 */       abx.e();
/*     */       
/* 263 */       arrayOfAbx[b] = abx;
/*     */     } 
/* 265 */     abw.a(arrayOfAbx);
/* 266 */     if (parambs.b("Biomes")) {
/* 267 */       abw.a(parambs.j("Biomes"));
/*     */     }
/*     */     
/* 270 */     ca ca2 = parambs.m("Entities");
/* 271 */     if (ca2 != null) {
/* 272 */       for (byte b = 0; b < ca2.c(); b++) {
/* 273 */         bs bs1 = (bs)ca2.b(b);
/* 274 */         mp mp = mv.a(bs1, paramaab);
/* 275 */         abw.m = true;
/* 276 */         if (mp != null) {
/* 277 */           abw.a(mp);
/*     */ 
/*     */           
/* 280 */           mp mp1 = mp;
/* 281 */           bs bs2 = bs1;
/* 282 */           while (bs2.b("Riding")) {
/* 283 */             mp mp2 = mv.a(bs2.l("Riding"), paramaab);
/* 284 */             if (mp2 != null) {
/* 285 */               abw.a(mp2);
/* 286 */               mp1.a(mp2);
/*     */             } 
/* 288 */             mp1 = mp2;
/* 289 */             bs2 = bs2.l("Riding");
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     }
/*     */     
/* 295 */     ca ca3 = parambs.m("TileEntities");
/* 296 */     if (ca3 != null) {
/* 297 */       for (byte b = 0; b < ca3.c(); b++) {
/* 298 */         bs bs1 = (bs)ca3.b(b);
/* 299 */         aqp aqp = aqp.c(bs1);
/* 300 */         if (aqp != null) {
/* 301 */           abw.a(aqp);
/*     */         }
/*     */       } 
/*     */     }
/*     */     
/* 306 */     if (parambs.b("TileTicks")) {
/* 307 */       ca ca = parambs.m("TileTicks");
/*     */       
/* 309 */       if (ca != null)
/*     */       {
/* 311 */         for (byte b = 0; b < ca.c(); b++) {
/* 312 */           bs bs1 = (bs)ca.b(b);
/*     */           
/* 314 */           paramaab.b(bs1.e("x"), bs1.e("y"), bs1.e("z"), bs1.e("i"), bs1.e("t"), bs1.e("p"));
/*     */         } 
/*     */       }
/*     */     } 
/* 318 */     return abw;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\acj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */