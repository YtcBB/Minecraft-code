/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class anu
/*    */   extends alu
/*    */ {
/*    */   private lx[] a;
/*    */   
/*    */   public anu(int paramInt) {
/* 12 */     super(paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 17 */     if (paramInt2 < 7) {
/* 18 */       if (paramInt2 == 6) {
/* 19 */         paramInt2 = 5;
/*    */       }
/* 21 */       return this.a[paramInt2 >> 1];
/*    */     } 
/* 23 */     return this.a[3];
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected int j() {
/* 29 */     return wk.bM.cp;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int k() {
/* 34 */     return wk.bM.cp;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 39 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, paramInt5);
/*    */     
/* 41 */     if (paramaab.I) {
/*    */       return;
/*    */     }
/* 44 */     if (paramInt4 >= 7 && 
/* 45 */       paramaab.s.nextInt(50) == 0) {
/* 46 */       b(paramaab, paramInt1, paramInt2, paramInt3, new wm(wk.bO));
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 53 */     this.a = new lx[4];
/*    */     
/* 55 */     for (byte b = 0; b < this.a.length; b++)
/* 56 */       this.a[b] = paramly.a("potatoes_" + b); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */