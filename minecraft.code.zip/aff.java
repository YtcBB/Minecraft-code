/*      */ import java.util.List;
/*      */ import java.util.Random;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class aff
/*      */   extends afh
/*      */ {
/*      */   public aff(int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/*  877 */     super(paramInt1);
/*      */     
/*  879 */     this.f = paramInt2;
/*  880 */     this.e = paramaek;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void a(agw paramagw, List paramList, Random paramRandom) {
/*  887 */     a((afl)paramagw, paramList, paramRandom, 5, 3, true);
/*  888 */     a((afl)paramagw, paramList, paramRandom, 5, 11, true);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public static aff a(List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  894 */     aek aek = aek.a(paramInt1, paramInt2, paramInt3, -5, -3, 0, 13, 14, 13, paramInt4);
/*      */     
/*  896 */     if (!a(aek) || agw.a(paramList, aek) != null) {
/*  897 */       return null;
/*      */     }
/*      */     
/*  900 */     return new aff(paramInt5, paramRandom, aek, paramInt4);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/*  907 */     a(paramaab, paramaek, 0, 3, 0, 12, 4, 12, apa.bE.cz, apa.bE.cz, false);
/*      */     
/*  909 */     a(paramaab, paramaek, 0, 5, 0, 12, 13, 12, 0, 0, false);
/*      */ 
/*      */     
/*  912 */     a(paramaab, paramaek, 0, 5, 0, 1, 12, 12, apa.bE.cz, apa.bE.cz, false);
/*  913 */     a(paramaab, paramaek, 11, 5, 0, 12, 12, 12, apa.bE.cz, apa.bE.cz, false);
/*  914 */     a(paramaab, paramaek, 2, 5, 11, 4, 12, 12, apa.bE.cz, apa.bE.cz, false);
/*  915 */     a(paramaab, paramaek, 8, 5, 11, 10, 12, 12, apa.bE.cz, apa.bE.cz, false);
/*  916 */     a(paramaab, paramaek, 5, 9, 11, 7, 12, 12, apa.bE.cz, apa.bE.cz, false);
/*  917 */     a(paramaab, paramaek, 2, 5, 0, 4, 12, 1, apa.bE.cz, apa.bE.cz, false);
/*  918 */     a(paramaab, paramaek, 8, 5, 0, 10, 12, 1, apa.bE.cz, apa.bE.cz, false);
/*  919 */     a(paramaab, paramaek, 5, 9, 0, 7, 12, 1, apa.bE.cz, apa.bE.cz, false);
/*      */ 
/*      */     
/*  922 */     a(paramaab, paramaek, 2, 11, 2, 10, 12, 10, apa.bE.cz, apa.bE.cz, false);
/*      */     
/*      */     int i;
/*  925 */     for (i = 1; i <= 11; i += 2) {
/*  926 */       a(paramaab, paramaek, i, 10, 0, i, 11, 0, apa.bF.cz, apa.bF.cz, false);
/*  927 */       a(paramaab, paramaek, i, 10, 12, i, 11, 12, apa.bF.cz, apa.bF.cz, false);
/*  928 */       a(paramaab, paramaek, 0, 10, i, 0, 11, i, apa.bF.cz, apa.bF.cz, false);
/*  929 */       a(paramaab, paramaek, 12, 10, i, 12, 11, i, apa.bF.cz, apa.bF.cz, false);
/*  930 */       a(paramaab, apa.bE.cz, 0, i, 13, 0, paramaek);
/*  931 */       a(paramaab, apa.bE.cz, 0, i, 13, 12, paramaek);
/*  932 */       a(paramaab, apa.bE.cz, 0, 0, 13, i, paramaek);
/*  933 */       a(paramaab, apa.bE.cz, 0, 12, 13, i, paramaek);
/*  934 */       a(paramaab, apa.bF.cz, 0, i + 1, 13, 0, paramaek);
/*  935 */       a(paramaab, apa.bF.cz, 0, i + 1, 13, 12, paramaek);
/*  936 */       a(paramaab, apa.bF.cz, 0, 0, 13, i + 1, paramaek);
/*  937 */       a(paramaab, apa.bF.cz, 0, 12, 13, i + 1, paramaek);
/*      */     } 
/*  939 */     a(paramaab, apa.bF.cz, 0, 0, 13, 0, paramaek);
/*  940 */     a(paramaab, apa.bF.cz, 0, 0, 13, 12, paramaek);
/*  941 */     a(paramaab, apa.bF.cz, 0, 0, 13, 0, paramaek);
/*  942 */     a(paramaab, apa.bF.cz, 0, 12, 13, 0, paramaek);
/*      */ 
/*      */     
/*  945 */     for (i = 3; i <= 9; i += 2) {
/*  946 */       a(paramaab, paramaek, 1, 7, i, 1, 8, i, apa.bF.cz, apa.bF.cz, false);
/*  947 */       a(paramaab, paramaek, 11, 7, i, 11, 8, i, apa.bF.cz, apa.bF.cz, false);
/*      */     } 
/*      */ 
/*      */     
/*  951 */     i = c(apa.bG.cz, 3); int j;
/*  952 */     for (j = 0; j <= 6; j++) {
/*  953 */       int m = j + 4;
/*  954 */       for (byte b1 = 5; b1 <= 7; b1++) {
/*  955 */         a(paramaab, apa.bG.cz, i, b1, 5 + j, m, paramaek);
/*      */       }
/*  957 */       if (m >= 5 && m <= 8) {
/*  958 */         a(paramaab, paramaek, 5, 5, m, 7, j + 4, m, apa.bE.cz, apa.bE.cz, false);
/*  959 */       } else if (m >= 9 && m <= 10) {
/*  960 */         a(paramaab, paramaek, 5, 8, m, 7, j + 4, m, apa.bE.cz, apa.bE.cz, false);
/*      */       } 
/*  962 */       if (j >= 1) {
/*  963 */         a(paramaab, paramaek, 5, 6 + j, m, 7, 9 + j, m, 0, 0, false);
/*      */       }
/*      */     } 
/*  966 */     for (j = 5; j <= 7; j++) {
/*  967 */       a(paramaab, apa.bG.cz, i, j, 12, 11, paramaek);
/*      */     }
/*  969 */     a(paramaab, paramaek, 5, 6, 7, 5, 7, 7, apa.bF.cz, apa.bF.cz, false);
/*  970 */     a(paramaab, paramaek, 7, 6, 7, 7, 7, 7, apa.bF.cz, apa.bF.cz, false);
/*  971 */     a(paramaab, paramaek, 5, 13, 12, 7, 13, 12, 0, 0, false);
/*      */ 
/*      */     
/*  974 */     a(paramaab, paramaek, 2, 5, 2, 3, 5, 3, apa.bE.cz, apa.bE.cz, false);
/*  975 */     a(paramaab, paramaek, 2, 5, 9, 3, 5, 10, apa.bE.cz, apa.bE.cz, false);
/*  976 */     a(paramaab, paramaek, 2, 5, 4, 2, 5, 8, apa.bE.cz, apa.bE.cz, false);
/*  977 */     a(paramaab, paramaek, 9, 5, 2, 10, 5, 3, apa.bE.cz, apa.bE.cz, false);
/*  978 */     a(paramaab, paramaek, 9, 5, 9, 10, 5, 10, apa.bE.cz, apa.bE.cz, false);
/*  979 */     a(paramaab, paramaek, 10, 5, 4, 10, 5, 8, apa.bE.cz, apa.bE.cz, false);
/*  980 */     j = c(apa.bG.cz, 0);
/*  981 */     int k = c(apa.bG.cz, 1);
/*  982 */     a(paramaab, apa.bG.cz, k, 4, 5, 2, paramaek);
/*  983 */     a(paramaab, apa.bG.cz, k, 4, 5, 3, paramaek);
/*  984 */     a(paramaab, apa.bG.cz, k, 4, 5, 9, paramaek);
/*  985 */     a(paramaab, apa.bG.cz, k, 4, 5, 10, paramaek);
/*  986 */     a(paramaab, apa.bG.cz, j, 8, 5, 2, paramaek);
/*  987 */     a(paramaab, apa.bG.cz, j, 8, 5, 3, paramaek);
/*  988 */     a(paramaab, apa.bG.cz, j, 8, 5, 9, paramaek);
/*  989 */     a(paramaab, apa.bG.cz, j, 8, 5, 10, paramaek);
/*      */ 
/*      */     
/*  992 */     a(paramaab, paramaek, 3, 4, 4, 4, 4, 8, apa.bg.cz, apa.bg.cz, false);
/*  993 */     a(paramaab, paramaek, 8, 4, 4, 9, 4, 8, apa.bg.cz, apa.bg.cz, false);
/*  994 */     a(paramaab, paramaek, 3, 5, 4, 4, 5, 8, apa.bH.cz, apa.bH.cz, false);
/*  995 */     a(paramaab, paramaek, 8, 5, 4, 9, 5, 8, apa.bH.cz, apa.bH.cz, false);
/*      */ 
/*      */     
/*  998 */     a(paramaab, paramaek, 4, 2, 0, 8, 2, 12, apa.bE.cz, apa.bE.cz, false);
/*  999 */     a(paramaab, paramaek, 0, 2, 4, 12, 2, 8, apa.bE.cz, apa.bE.cz, false);
/*      */     
/* 1001 */     a(paramaab, paramaek, 4, 0, 0, 8, 1, 3, apa.bE.cz, apa.bE.cz, false);
/* 1002 */     a(paramaab, paramaek, 4, 0, 9, 8, 1, 12, apa.bE.cz, apa.bE.cz, false);
/* 1003 */     a(paramaab, paramaek, 0, 0, 4, 3, 1, 8, apa.bE.cz, apa.bE.cz, false);
/* 1004 */     a(paramaab, paramaek, 9, 0, 4, 12, 1, 8, apa.bE.cz, apa.bE.cz, false);
/*      */     byte b;
/* 1006 */     for (b = 4; b <= 8; b++) {
/* 1007 */       for (byte b1 = 0; b1 <= 2; b1++) {
/* 1008 */         b(paramaab, apa.bE.cz, 0, b, -1, b1, paramaek);
/* 1009 */         b(paramaab, apa.bE.cz, 0, b, -1, 12 - b1, paramaek);
/*      */       } 
/*      */     } 
/* 1012 */     for (b = 0; b <= 2; b++) {
/* 1013 */       for (byte b1 = 4; b1 <= 8; b1++) {
/* 1014 */         b(paramaab, apa.bE.cz, 0, b, -1, b1, paramaek);
/* 1015 */         b(paramaab, apa.bE.cz, 0, 12 - b, -1, b1, paramaek);
/*      */       } 
/*      */     } 
/*      */     
/* 1019 */     return true;
/*      */   }
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aff.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */