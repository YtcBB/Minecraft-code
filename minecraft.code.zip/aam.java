/*    */ 
/*    */ public enum aam
/*    */ {
/*  4 */   a(15),
/*  5 */   b(0);
/*    */   
/*    */   public final int c;
/*    */   
/*    */   aam(int paramInt1) {
/* 10 */     this.c = paramInt1;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aam.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */