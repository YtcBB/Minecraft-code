public interface aag {
  void a(int paramInt1, int paramInt2, int paramInt3);
  
  void b(int paramInt1, int paramInt2, int paramInt3);
  
  void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6);
  
  void a(String paramString, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2);
  
  void a(sq paramsq, String paramString, double paramDouble1, double paramDouble2, double paramDouble3, float paramFloat1, float paramFloat2);
  
  void a(String paramString, double paramDouble1, double paramDouble2, double paramDouble3, double paramDouble4, double paramDouble5, double paramDouble6);
  
  void a(mp parammp);
  
  void b(mp parammp);
  
  void a(String paramString, int paramInt1, int paramInt2, int paramInt3);
  
  void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  void a(sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
  
  void b(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5);
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aag.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */