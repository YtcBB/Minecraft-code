/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ahr
/*     */   extends ahp
/*     */ {
/*     */   private final boolean a;
/* 367 */   private int b = -1;
/*     */   
/*     */   public ahr(ahm paramahm, int paramInt1, Random paramRandom, int paramInt2, int paramInt3) {
/* 370 */     super(paramahm, paramInt1);
/*     */     
/* 372 */     this.a = true;
/* 373 */     this.f = paramRandom.nextInt(4);
/*     */     
/* 375 */     switch (this.f) {
/*     */       case 0:
/*     */       case 2:
/* 378 */         this.e = new aek(paramInt2, 64, paramInt3, paramInt2 + 6 - 1, 78, paramInt3 + 6 - 1);
/*     */         return;
/*     */     } 
/* 381 */     this.e = new aek(paramInt2, 64, paramInt3, paramInt2 + 6 - 1, 78, paramInt3 + 6 - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/* 397 */     ahb.b((ahm)paramagw, paramList, paramRandom, this.e.a - 1, this.e.e - 4, this.e.c + 1, 1, c());
/* 398 */     ahb.b((ahm)paramagw, paramList, paramRandom, this.e.d + 1, this.e.e - 4, this.e.c + 1, 3, c());
/* 399 */     ahb.b((ahm)paramagw, paramList, paramRandom, this.e.a + 1, this.e.e - 4, this.e.c - 1, 2, c());
/* 400 */     ahb.b((ahm)paramagw, paramList, paramRandom, this.e.a + 1, this.e.e - 4, this.e.f + 1, 0, c());
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 418 */     if (this.b < 0) {
/* 419 */       this.b = b(paramaab, paramaek);
/* 420 */       if (this.b < 0) {
/* 421 */         return true;
/*     */       }
/* 423 */       this.e.a(0, this.b - this.e.e + 3, 0);
/*     */     } 
/*     */     
/* 426 */     a(paramaab, paramaek, 1, 0, 1, 4, 12, 4, apa.A.cz, apa.E.cz, false);
/* 427 */     a(paramaab, 0, 0, 2, 12, 2, paramaek);
/* 428 */     a(paramaab, 0, 0, 3, 12, 2, paramaek);
/* 429 */     a(paramaab, 0, 0, 2, 12, 3, paramaek);
/* 430 */     a(paramaab, 0, 0, 3, 12, 3, paramaek);
/*     */     
/* 432 */     a(paramaab, apa.bd.cz, 0, 1, 13, 1, paramaek);
/* 433 */     a(paramaab, apa.bd.cz, 0, 1, 14, 1, paramaek);
/* 434 */     a(paramaab, apa.bd.cz, 0, 4, 13, 1, paramaek);
/* 435 */     a(paramaab, apa.bd.cz, 0, 4, 14, 1, paramaek);
/* 436 */     a(paramaab, apa.bd.cz, 0, 1, 13, 4, paramaek);
/* 437 */     a(paramaab, apa.bd.cz, 0, 1, 14, 4, paramaek);
/* 438 */     a(paramaab, apa.bd.cz, 0, 4, 13, 4, paramaek);
/* 439 */     a(paramaab, apa.bd.cz, 0, 4, 14, 4, paramaek);
/* 440 */     a(paramaab, paramaek, 1, 15, 1, 4, 15, 4, apa.A.cz, apa.A.cz, false);
/*     */     
/* 442 */     for (byte b = 0; b <= 5; b++) {
/* 443 */       for (byte b1 = 0; b1 <= 5; b1++) {
/*     */         
/* 445 */         if (b1 == 0 || b1 == 5 || b == 0 || b == 5) {
/*     */ 
/*     */           
/* 448 */           a(paramaab, apa.J.cz, 0, b1, 11, b, paramaek);
/* 449 */           b(paramaab, b1, 12, b, paramaek);
/*     */         } 
/*     */       } 
/*     */     } 
/* 453 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ahr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */