/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class anm
/*    */   extends akz
/*    */ {
/*    */   public anm(int paramInt) {
/* 11 */     super(paramInt, aif.d);
/* 12 */     a(ve.d);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 18 */     boolean bool = paramaab.C(paramInt1, paramInt2, paramInt3);
/* 19 */     aql aql = (aql)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 20 */     if (aql != null && aql.b != bool) {
/* 21 */       if (bool) {
/* 22 */         aql.a(paramaab, paramInt1, paramInt2, paramInt3);
/*    */       }
/* 24 */       aql.b = bool;
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 31 */     if (paramaab.I) return true; 
/* 32 */     aql aql = (aql)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 33 */     if (aql != null) {
/* 34 */       aql.a();
/* 35 */       aql.a(paramaab, paramInt1, paramInt2, paramInt3);
/*    */     } 
/* 37 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {
/* 42 */     if (paramaab.I)
/* 43 */       return;  aql aql = (aql)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 44 */     if (aql != null) aql.a(paramaab, paramInt1, paramInt2, paramInt3); 
/*    */   }
/*    */   
/*    */   public aqp b(aab paramaab) {
/* 48 */     return new aql();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 53 */     float f = (float)Math.pow(2.0D, (paramInt5 - 12) / 12.0D);
/*    */     
/* 55 */     String str = "harp";
/* 56 */     if (paramInt4 == 1) str = "bd"; 
/* 57 */     if (paramInt4 == 2) str = "snare"; 
/* 58 */     if (paramInt4 == 3) str = "hat"; 
/* 59 */     if (paramInt4 == 4) str = "bassattack";
/*    */     
/* 61 */     paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "note." + str, 3.0F, f);
/* 62 */     paramaab.a("note", paramInt1 + 0.5D, paramInt2 + 1.2D, paramInt3 + 0.5D, paramInt5 / 24.0D, 0.0D, 0.0D);
/* 63 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */