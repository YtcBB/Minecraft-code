/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aec
/*    */   extends adj
/*    */ {
/*    */   public aec(boolean paramBoolean) {
/* 11 */     super(paramBoolean);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 18 */     int i = paramRandom.nextInt(4) + 6;
/* 19 */     int j = 1 + paramRandom.nextInt(2);
/* 20 */     int k = i - j;
/* 21 */     int m = 2 + paramRandom.nextInt(2);
/*    */     
/* 23 */     boolean bool1 = true;
/*    */     
/* 25 */     if (paramInt2 < 1 || paramInt2 + i + 1 > 256) {
/* 26 */       return false;
/*    */     }
/*    */     
/*    */     int n;
/* 30 */     for (n = paramInt2; n <= paramInt2 + 1 + i && bool1; n++) {
/*    */       
/* 32 */       int i4 = 1;
/* 33 */       if (n - paramInt2 < j) {
/* 34 */         i4 = 0;
/*    */       } else {
/* 36 */         i4 = m;
/*    */       } 
/* 38 */       for (int i5 = paramInt1 - i4; i5 <= paramInt1 + i4 && bool1; i5++) {
/* 39 */         for (int i6 = paramInt3 - i4; i6 <= paramInt3 + i4 && bool1; i6++) {
/* 40 */           if (n >= 0 && n < 256) {
/* 41 */             int i7 = paramaab.a(i5, n, i6);
/* 42 */             if (i7 != 0 && i7 != apa.O.cz) bool1 = false; 
/*    */           } else {
/* 44 */             bool1 = false;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 50 */     if (!bool1) return false;
/*    */ 
/*    */     
/* 53 */     n = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/* 54 */     if ((n != apa.y.cz && n != apa.z.cz) || paramInt2 >= 256 - i - 1) {
/* 55 */       return false;
/*    */     }
/* 57 */     a(paramaab, paramInt1, paramInt2 - 1, paramInt3, apa.z.cz);
/*    */ 
/*    */     
/* 60 */     int i1 = paramRandom.nextInt(2);
/* 61 */     int i2 = 1;
/* 62 */     boolean bool2 = false; int i3;
/* 63 */     for (i3 = 0; i3 <= k; i3++) {
/*    */       
/* 65 */       int i4 = paramInt2 + i - i3;
/*    */       
/* 67 */       for (int i5 = paramInt1 - i1; i5 <= paramInt1 + i1; i5++) {
/* 68 */         int i6 = i5 - paramInt1;
/* 69 */         for (int i7 = paramInt3 - i1; i7 <= paramInt3 + i1; i7++) {
/* 70 */           int i8 = i7 - paramInt3;
/* 71 */           if ((Math.abs(i6) != i1 || Math.abs(i8) != i1 || i1 <= 0) && 
/* 72 */             !apa.s[paramaab.a(i5, i4, i7)]) {
/* 73 */             a(paramaab, i5, i4, i7, apa.O.cz, 1);
/*    */           }
/*    */         } 
/*    */       } 
/* 77 */       if (i1 >= i2) {
/* 78 */         i1 = bool2;
/* 79 */         bool2 = true;
/* 80 */         i2++;
/* 81 */         if (i2 > m) {
/* 82 */           i2 = m;
/*    */         }
/*    */       } else {
/* 85 */         i1++;
/*    */       } 
/*    */     } 
/* 88 */     i3 = paramRandom.nextInt(3);
/* 89 */     for (byte b = 0; b < i - i3; b++) {
/* 90 */       int i4 = paramaab.a(paramInt1, paramInt2 + b, paramInt3);
/* 91 */       if (i4 == 0 || i4 == apa.O.cz) a(paramaab, paramInt1, paramInt2 + b, paramInt3, apa.N.cz, 1); 
/*    */     } 
/* 93 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aec.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */