/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class add
/*    */   extends adj
/*    */ {
/*    */   private final lp[] a;
/*    */   private final int b;
/*    */   
/*    */   public add(lp[] paramArrayOflp, int paramInt) {
/* 16 */     this.a = paramArrayOflp;
/* 17 */     this.b = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 22 */     int i = 0;
/* 23 */     while (((i = paramaab.a(paramInt1, paramInt2, paramInt3)) == 0 || i == apa.O.cz) && paramInt2 > 1) {
/* 24 */       paramInt2--;
/*    */     }
/* 26 */     if (paramInt2 < 1) {
/* 27 */       return false;
/*    */     }
/* 29 */     paramInt2++;
/*    */     
/* 31 */     for (byte b = 0; b < 4; b++) {
/* 32 */       int j = paramInt1 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 33 */       int k = paramInt2 + paramRandom.nextInt(3) - paramRandom.nextInt(3);
/* 34 */       int m = paramInt3 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 35 */       if (paramaab.c(j, k, m) && paramaab.w(j, k - 1, m)) {
/* 36 */         paramaab.f(j, k, m, apa.ay.cz, 0, 2);
/* 37 */         apy apy = (apy)paramaab.r(j, k, m);
/* 38 */         if (apy != null && 
/* 39 */           apy != null) lp.a(paramRandom, this.a, apy, this.b);
/*    */         
/* 41 */         if (paramaab.c(j - 1, k, m) && paramaab.w(j - 1, k - 1, m)) {
/* 42 */           paramaab.f(j - 1, k, m, apa.au.cz, 0, 2);
/*    */         }
/* 44 */         if (paramaab.c(j + 1, k, m) && paramaab.w(j - 1, k - 1, m)) {
/* 45 */           paramaab.f(j + 1, k, m, apa.au.cz, 0, 2);
/*    */         }
/* 47 */         if (paramaab.c(j, k, m - 1) && paramaab.w(j - 1, k - 1, m)) {
/* 48 */           paramaab.f(j, k, m - 1, apa.au.cz, 0, 2);
/*    */         }
/* 50 */         if (paramaab.c(j, k, m + 1) && paramaab.w(j - 1, k - 1, m)) {
/* 51 */           paramaab.f(j, k, m + 1, apa.au.cz, 0, 2);
/*    */         }
/* 53 */         return true;
/*    */       } 
/*    */     } 
/*    */     
/* 57 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\add.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */