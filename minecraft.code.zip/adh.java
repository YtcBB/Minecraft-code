/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adh
/*    */   extends adj
/*    */ {
/*    */   private int a;
/*    */   
/*    */   public adh(int paramInt) {
/* 12 */     this.a = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 17 */     int i = 0;
/* 18 */     while (((i = paramaab.a(paramInt1, paramInt2, paramInt3)) == 0 || i == apa.O.cz) && paramInt2 > 0) {
/* 19 */       paramInt2--;
/*    */     }
/* 21 */     for (byte b = 0; b < 4; b++) {
/* 22 */       int j = paramInt1 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 23 */       int k = paramInt2 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 24 */       int m = paramInt3 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 25 */       if (paramaab.c(j, k, m) && 
/* 26 */         apa.r[this.a].f(paramaab, j, k, m)) {
/* 27 */         paramaab.f(j, k, m, this.a, 0, 2);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 32 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */