/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aef
/*     */   extends adj
/*     */ {
/*     */   private final int a;
/*     */   private final boolean b;
/*     */   private final int c;
/*     */   private final int d;
/*     */   
/*     */   public aef(boolean paramBoolean) {
/*  17 */     this(paramBoolean, 4, 0, 0, false);
/*     */   }
/*     */   
/*     */   public aef(boolean paramBoolean1, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean2) {
/*  21 */     super(paramBoolean1);
/*  22 */     this.a = paramInt1;
/*  23 */     this.c = paramInt2;
/*  24 */     this.d = paramInt3;
/*  25 */     this.b = paramBoolean2;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/*  31 */     int i = paramRandom.nextInt(3) + this.a;
/*     */     
/*  33 */     boolean bool = true;
/*  34 */     if (paramInt2 < 1 || paramInt2 + i + 1 > 256) return false; 
/*     */     int j;
/*  36 */     for (j = paramInt2; j <= paramInt2 + 1 + i; j++) {
/*  37 */       byte b = 1;
/*  38 */       if (j == paramInt2) b = 0; 
/*  39 */       if (j >= paramInt2 + 1 + i - 2) b = 2; 
/*  40 */       for (int m = paramInt1 - b; m <= paramInt1 + b && bool; m++) {
/*  41 */         for (int n = paramInt3 - b; n <= paramInt3 + b && bool; n++) {
/*  42 */           if (j >= 0 && j < 256) {
/*  43 */             int i1 = paramaab.a(m, j, n);
/*  44 */             if (i1 != 0 && i1 != apa.O.cz && i1 != apa.y.cz && i1 != apa.z.cz && i1 != apa.N.cz) bool = false; 
/*     */           } else {
/*  46 */             bool = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  52 */     if (!bool) return false;
/*     */     
/*  54 */     j = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/*  55 */     if ((j != apa.y.cz && j != apa.z.cz) || paramInt2 >= 256 - i - 1) return false;
/*     */     
/*  57 */     a(paramaab, paramInt1, paramInt2 - 1, paramInt3, apa.z.cz);
/*     */     
/*  59 */     byte b1 = 3;
/*  60 */     byte b2 = 0; int k;
/*  61 */     for (k = paramInt2 - b1 + i; k <= paramInt2 + i; k++) {
/*  62 */       int m = k - paramInt2 + i;
/*  63 */       int n = b2 + 1 - m / 2;
/*  64 */       for (int i1 = paramInt1 - n; i1 <= paramInt1 + n; i1++) {
/*  65 */         int i2 = i1 - paramInt1;
/*  66 */         for (int i3 = paramInt3 - n; i3 <= paramInt3 + n; i3++) {
/*  67 */           int i4 = i3 - paramInt3;
/*  68 */           if (Math.abs(i2) != n || Math.abs(i4) != n || (paramRandom.nextInt(2) != 0 && m != 0)) {
/*  69 */             int i5 = paramaab.a(i1, k, i3);
/*  70 */             if (i5 == 0 || i5 == apa.O.cz) a(paramaab, i1, k, i3, apa.O.cz, this.d); 
/*     */           } 
/*     */         } 
/*     */       } 
/*  74 */     }  for (k = 0; k < i; k++) {
/*  75 */       int m = paramaab.a(paramInt1, paramInt2 + k, paramInt3);
/*  76 */       if (m == 0 || m == apa.O.cz) {
/*  77 */         a(paramaab, paramInt1, paramInt2 + k, paramInt3, apa.N.cz, this.c);
/*  78 */         if (this.b && k > 0) {
/*  79 */           if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1 - 1, paramInt2 + k, paramInt3)) {
/*  80 */             a(paramaab, paramInt1 - 1, paramInt2 + k, paramInt3, apa.by.cz, 8);
/*     */           }
/*  82 */           if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1 + 1, paramInt2 + k, paramInt3)) {
/*  83 */             a(paramaab, paramInt1 + 1, paramInt2 + k, paramInt3, apa.by.cz, 2);
/*     */           }
/*  85 */           if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1, paramInt2 + k, paramInt3 - 1)) {
/*  86 */             a(paramaab, paramInt1, paramInt2 + k, paramInt3 - 1, apa.by.cz, 1);
/*     */           }
/*  88 */           if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1, paramInt2 + k, paramInt3 + 1)) {
/*  89 */             a(paramaab, paramInt1, paramInt2 + k, paramInt3 + 1, apa.by.cz, 4);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  95 */     if (this.b) {
/*  96 */       for (k = paramInt2 - 3 + i; k <= paramInt2 + i; k++) {
/*  97 */         int m = k - paramInt2 + i;
/*  98 */         int n = 2 - m / 2;
/*  99 */         for (int i1 = paramInt1 - n; i1 <= paramInt1 + n; i1++) {
/* 100 */           for (int i2 = paramInt3 - n; i2 <= paramInt3 + n; i2++) {
/* 101 */             if (paramaab.a(i1, k, i2) == apa.O.cz) {
/* 102 */               if (paramRandom.nextInt(4) == 0 && paramaab.a(i1 - 1, k, i2) == 0) {
/* 103 */                 b(paramaab, i1 - 1, k, i2, 8);
/*     */               }
/* 105 */               if (paramRandom.nextInt(4) == 0 && paramaab.a(i1 + 1, k, i2) == 0) {
/* 106 */                 b(paramaab, i1 + 1, k, i2, 2);
/*     */               }
/* 108 */               if (paramRandom.nextInt(4) == 0 && paramaab.a(i1, k, i2 - 1) == 0) {
/* 109 */                 b(paramaab, i1, k, i2 - 1, 1);
/*     */               }
/* 111 */               if (paramRandom.nextInt(4) == 0 && paramaab.a(i1, k, i2 + 1) == 0) {
/* 112 */                 b(paramaab, i1, k, i2 + 1, 4);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 120 */       if (paramRandom.nextInt(5) == 0 && i > 5) {
/* 121 */         for (k = 0; k < 2; k++) {
/* 122 */           for (byte b = 0; b < 4; b++) {
/* 123 */             if (paramRandom.nextInt(4 - k) == 0) {
/* 124 */               int m = paramRandom.nextInt(3);
/* 125 */               a(paramaab, paramInt1 + r.a[r.f[b]], paramInt2 + i - 5 + k, paramInt3 + r.b[r.f[b]], apa.bT.cz, m << 2 | b);
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }
/*     */     } 
/*     */     
/* 132 */     return true;
/*     */   }
/*     */   
/*     */   private void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 136 */     a(paramaab, paramInt1, paramInt2, paramInt3, apa.by.cz, paramInt4);
/* 137 */     byte b = 4;
/* 138 */     while (paramaab.a(paramInt1, --paramInt2, paramInt3) == 0 && b > 0) {
/* 139 */       a(paramaab, paramInt1, paramInt2, paramInt3, apa.by.cz, paramInt4);
/* 140 */       b--;
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aef.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */