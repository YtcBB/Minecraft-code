/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class alq
/*     */   extends alz
/*     */ {
/*  16 */   public static final String[] a = new String[] { "cocoa_0", "cocoa_1", "cocoa_2" };
/*     */ 
/*     */   
/*     */   private lx[] b;
/*     */ 
/*     */   
/*     */   public alq(int paramInt) {
/*  23 */     super(paramInt, aif.k);
/*  24 */     b(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  29 */     return this.b[2];
/*     */   }
/*     */   
/*     */   public lx h_(int paramInt) {
/*  33 */     if (paramInt < 0 || paramInt >= this.b.length) {
/*  34 */       paramInt = this.b.length - 1;
/*     */     }
/*  36 */     return this.b[paramInt];
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  42 */     if (!f(paramaab, paramInt1, paramInt2, paramInt3)) {
/*  43 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/*  44 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*  45 */     } else if (paramaab.s.nextInt(5) == 0) {
/*  46 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  47 */       int j = c(i);
/*  48 */       if (j < 2) {
/*  49 */         j++;
/*  50 */         paramaab.b(paramInt1, paramInt2, paramInt3, j << 2 | j(i), 2);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  56 */     int i = j(paramaab.h(paramInt1, paramInt2, paramInt3));
/*     */     
/*  58 */     paramInt1 += r.a[i];
/*  59 */     paramInt3 += r.b[i];
/*  60 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3);
/*     */     
/*  62 */     return (j == apa.N.cz && apk.d(paramaab.h(paramInt1, paramInt2, paramInt3)) == 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  67 */     return 28;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  72 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  77 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  82 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  83 */     return super.b(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  88 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  89 */     return super.c_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  94 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*  95 */     int j = j(i);
/*  96 */     int k = c(i);
/*     */     
/*  98 */     int m = 4 + k * 2;
/*  99 */     int n = 5 + k * 2;
/*     */     
/* 101 */     float f = m / 2.0F;
/*     */     
/* 103 */     switch (j) {
/*     */       case 0:
/* 105 */         a((8.0F - f) / 16.0F, (12.0F - n) / 16.0F, (15.0F - m) / 16.0F, (8.0F + f) / 16.0F, 0.75F, 0.9375F);
/*     */         break;
/*     */       case 2:
/* 108 */         a((8.0F - f) / 16.0F, (12.0F - n) / 16.0F, 0.0625F, (8.0F + f) / 16.0F, 0.75F, (1.0F + m) / 16.0F);
/*     */         break;
/*     */       case 1:
/* 111 */         a(0.0625F, (12.0F - n) / 16.0F, (8.0F - f) / 16.0F, (1.0F + m) / 16.0F, 0.75F, (8.0F + f) / 16.0F);
/*     */         break;
/*     */       case 3:
/* 114 */         a((15.0F - m) / 16.0F, (12.0F - n) / 16.0F, (8.0F - f) / 16.0F, 0.9375F, 0.75F, (8.0F + f) / 16.0F);
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 121 */     int i = ((kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3) + 0) % 4;
/* 122 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/* 127 */     if (paramInt4 == 1 || paramInt4 == 0) {
/* 128 */       paramInt4 = 2;
/*     */     }
/* 130 */     return r.f[r.e[paramInt4]];
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 135 */     if (!f(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 136 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 137 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static int c(int paramInt) {
/* 142 */     return (paramInt & 0xC) >> 2;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 147 */     int i = c(paramInt4);
/* 148 */     byte b1 = 1;
/* 149 */     if (i >= 2) {
/* 150 */       b1 = 3;
/*     */     }
/* 152 */     for (byte b2 = 0; b2 < b1; b2++) {
/* 153 */       b(paramaab, paramInt1, paramInt2, paramInt3, new wm(wk.aX, 1, 3));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 159 */     return wk.aX.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int h(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 164 */     return 3;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 169 */     this.b = new lx[a.length];
/*     */     
/* 171 */     for (byte b = 0; b < this.b.length; b++)
/* 172 */       this.b[b] = paramly.a(a[b]); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */