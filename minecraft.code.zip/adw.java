/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adw
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 14 */     int i = paramRandom.nextInt(5) + 7;
/* 15 */     int j = i - paramRandom.nextInt(2) - 3;
/* 16 */     int k = i - j;
/* 17 */     int m = 1 + paramRandom.nextInt(k + 1);
/*    */     
/* 19 */     boolean bool = true;
/*    */     
/* 21 */     if (paramInt2 < 1 || paramInt2 + i + 1 > 128) {
/* 22 */       return false;
/*    */     }
/*    */     
/*    */     int n;
/* 26 */     for (n = paramInt2; n <= paramInt2 + 1 + i && bool; n++) {
/*    */       
/* 28 */       int i2 = 1;
/* 29 */       if (n - paramInt2 < j) {
/* 30 */         i2 = 0;
/*    */       } else {
/* 32 */         i2 = m;
/*    */       } 
/* 34 */       for (int i3 = paramInt1 - i2; i3 <= paramInt1 + i2 && bool; i3++) {
/* 35 */         for (int i4 = paramInt3 - i2; i4 <= paramInt3 + i2 && bool; i4++) {
/* 36 */           if (n >= 0 && n < 128) {
/* 37 */             int i5 = paramaab.a(i3, n, i4);
/* 38 */             if (i5 != 0 && i5 != apa.O.cz) bool = false; 
/*    */           } else {
/* 40 */             bool = false;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 46 */     if (!bool) return false;
/*    */ 
/*    */     
/* 49 */     n = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/* 50 */     if ((n != apa.y.cz && n != apa.z.cz) || paramInt2 >= 128 - i - 1) {
/* 51 */       return false;
/*    */     }
/* 53 */     a(paramaab, paramInt1, paramInt2 - 1, paramInt3, apa.z.cz);
/*    */ 
/*    */     
/* 56 */     byte b = 0; int i1;
/* 57 */     for (i1 = paramInt2 + i; i1 >= paramInt2 + j; i1--) {
/*    */       
/* 59 */       for (int i2 = paramInt1 - b; i2 <= paramInt1 + b; i2++) {
/* 60 */         int i3 = i2 - paramInt1;
/* 61 */         for (int i4 = paramInt3 - b; i4 <= paramInt3 + b; i4++) {
/* 62 */           int i5 = i4 - paramInt3;
/* 63 */           if ((Math.abs(i3) != b || Math.abs(i5) != b || b <= 0) && 
/* 64 */             !apa.s[paramaab.a(i2, i1, i4)]) {
/* 65 */             a(paramaab, i2, i1, i4, apa.O.cz, 1);
/*    */           }
/*    */         } 
/*    */       } 
/* 69 */       if (b >= 1 && i1 == paramInt2 + j + 1) {
/* 70 */         b--;
/* 71 */       } else if (b < m) {
/* 72 */         b++;
/*    */       } 
/*    */     } 
/* 75 */     for (i1 = 0; i1 < i - 1; i1++) {
/* 76 */       int i2 = paramaab.a(paramInt1, paramInt2 + i1, paramInt3);
/* 77 */       if (i2 == 0 || i2 == apa.O.cz) a(paramaab, paramInt1, paramInt2 + i1, paramInt3, apa.N.cz, 1); 
/*    */     } 
/* 79 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */