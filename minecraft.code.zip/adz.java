/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adz
/*    */   extends adj
/*    */ {
/*    */   private int a;
/*    */   private int b;
/*    */   
/*    */   public adz(int paramInt1, int paramInt2) {
/* 14 */     this.a = paramInt2;
/* 15 */     this.b = paramInt1;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 20 */     if (paramaab.g(paramInt1, paramInt2, paramInt3) != aif.h) return false; 
/* 21 */     int i = paramRandom.nextInt(this.b - 2) + 2;
/* 22 */     byte b = 2;
/* 23 */     for (int j = paramInt1 - i; j <= paramInt1 + i; j++) {
/* 24 */       for (int k = paramInt3 - i; k <= paramInt3 + i; k++) {
/* 25 */         int m = j - paramInt1;
/* 26 */         int n = k - paramInt3;
/* 27 */         if (m * m + n * n <= i * i) {
/* 28 */           for (int i1 = paramInt2 - b; i1 <= paramInt2 + b; i1++) {
/* 29 */             int i2 = paramaab.a(j, i1, k);
/* 30 */             if (i2 == apa.z.cz || i2 == apa.y.cz) {
/* 31 */               paramaab.f(j, i1, k, this.a, 0, 2);
/*    */             }
/*    */           } 
/*    */         }
/*    */       } 
/*    */     } 
/* 37 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */