/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class amo
/*    */   extends ams
/*    */ {
/*    */   public amo(int paramInt, aif paramaif, boolean paramBoolean) {
/* 11 */     super(paramInt, "glass", paramaif, paramBoolean);
/* 12 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 17 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public int n() {
/* 22 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 27 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b() {
/* 32 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean r_() {
/* 37 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */