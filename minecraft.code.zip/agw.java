/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class agw
/*     */ {
/*     */   protected aek e;
/*     */   protected int f;
/*     */   protected int g;
/*     */   
/*     */   protected agw(int paramInt) {
/*  46 */     this.g = paramInt;
/*  47 */     this.f = -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {}
/*     */ 
/*     */   
/*     */   public abstract boolean a(aab paramaab, Random paramRandom, aek paramaek);
/*     */   
/*     */   public aek b() {
/*  57 */     return this.e;
/*     */   }
/*     */   
/*     */   public int c() {
/*  61 */     return this.g;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static agw a(List paramList, aek paramaek) {
/*  72 */     for (agw agw1 : paramList) {
/*  73 */       if (agw1.b() != null && agw1.b().a(paramaek)) {
/*  74 */         return agw1;
/*     */       }
/*     */     } 
/*  77 */     return null;
/*     */   }
/*     */   
/*     */   public aat a() {
/*  81 */     return new aat(this.e.e(), this.e.f(), this.e.g());
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean a(aab paramaab, aek paramaek) {
/*  86 */     int i = Math.max(this.e.a - 1, paramaek.a);
/*  87 */     int j = Math.max(this.e.b - 1, paramaek.b);
/*  88 */     int k = Math.max(this.e.c - 1, paramaek.c);
/*  89 */     int m = Math.min(this.e.d + 1, paramaek.d);
/*  90 */     int n = Math.min(this.e.e + 1, paramaek.e);
/*  91 */     int i1 = Math.min(this.e.f + 1, paramaek.f);
/*     */     
/*     */     int i2;
/*  94 */     for (i2 = i; i2 <= m; i2++) {
/*  95 */       for (int i3 = k; i3 <= i1; i3++) {
/*  96 */         int i4 = paramaab.a(i2, j, i3);
/*  97 */         if (i4 > 0 && (apa.r[i4]).cO.d()) {
/*  98 */           return true;
/*     */         }
/* 100 */         i4 = paramaab.a(i2, n, i3);
/* 101 */         if (i4 > 0 && (apa.r[i4]).cO.d()) {
/* 102 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 107 */     for (i2 = i; i2 <= m; i2++) {
/* 108 */       for (int i3 = j; i3 <= n; i3++) {
/* 109 */         int i4 = paramaab.a(i2, i3, k);
/* 110 */         if (i4 > 0 && (apa.r[i4]).cO.d()) {
/* 111 */           return true;
/*     */         }
/* 113 */         i4 = paramaab.a(i2, i3, i1);
/* 114 */         if (i4 > 0 && (apa.r[i4]).cO.d()) {
/* 115 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 120 */     for (i2 = k; i2 <= i1; i2++) {
/* 121 */       for (int i3 = j; i3 <= n; i3++) {
/* 122 */         int i4 = paramaab.a(i, i3, i2);
/* 123 */         if (i4 > 0 && (apa.r[i4]).cO.d()) {
/* 124 */           return true;
/*     */         }
/* 126 */         i4 = paramaab.a(m, i3, i2);
/* 127 */         if (i4 > 0 && (apa.r[i4]).cO.d()) {
/* 128 */           return true;
/*     */         }
/*     */       } 
/*     */     } 
/* 132 */     return false;
/*     */   }
/*     */   
/*     */   protected int a(int paramInt1, int paramInt2) {
/* 136 */     switch (this.f) {
/*     */       case 0:
/*     */       case 2:
/* 139 */         return this.e.a + paramInt1;
/*     */       case 1:
/* 141 */         return this.e.d - paramInt2;
/*     */       case 3:
/* 143 */         return this.e.a + paramInt2;
/*     */     } 
/* 145 */     return paramInt1;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int a(int paramInt) {
/* 150 */     if (this.f == -1) {
/* 151 */       return paramInt;
/*     */     }
/* 153 */     return paramInt + this.e.b;
/*     */   }
/*     */   
/*     */   protected int b(int paramInt1, int paramInt2) {
/* 157 */     switch (this.f) {
/*     */       case 2:
/* 159 */         return this.e.f - paramInt2;
/*     */       case 0:
/* 161 */         return this.e.c + paramInt2;
/*     */       case 1:
/*     */       case 3:
/* 164 */         return this.e.c + paramInt1;
/*     */     } 
/* 166 */     return paramInt2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected int c(int paramInt1, int paramInt2) {
/* 171 */     if (paramInt1 == apa.aK.cz) {
/* 172 */       if (this.f == 1 || this.f == 3) {
/* 173 */         if (paramInt2 == 1) {
/* 174 */           return 0;
/*     */         }
/* 176 */         return 1;
/*     */       }
/*     */     
/* 179 */     } else if (paramInt1 == apa.aI.cz || paramInt1 == apa.aP.cz) {
/* 180 */       if (this.f == 0) {
/* 181 */         if (paramInt2 == 0) {
/* 182 */           return 2;
/*     */         }
/* 184 */         if (paramInt2 == 2)
/* 185 */           return 0; 
/*     */       } else {
/* 187 */         if (this.f == 1)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 192 */           return paramInt2 + 1 & 0x3; } 
/* 193 */         if (this.f == 3)
/*     */         {
/*     */ 
/*     */ 
/*     */           
/* 198 */           return paramInt2 + 3 & 0x3; } 
/*     */       } 
/* 200 */     } else if (paramInt1 == apa.aL.cz || paramInt1 == apa.ax.cz || paramInt1 == apa.bG.cz || paramInt1 == apa.bB.cz || paramInt1 == apa.bU.cz) {
/* 201 */       if (this.f == 0) {
/* 202 */         if (paramInt2 == 2) {
/* 203 */           return 3;
/*     */         }
/* 205 */         if (paramInt2 == 3) {
/* 206 */           return 2;
/*     */         }
/* 208 */       } else if (this.f == 1) {
/* 209 */         if (paramInt2 == 0) {
/* 210 */           return 2;
/*     */         }
/* 212 */         if (paramInt2 == 1) {
/* 213 */           return 3;
/*     */         }
/* 215 */         if (paramInt2 == 2) {
/* 216 */           return 0;
/*     */         }
/* 218 */         if (paramInt2 == 3) {
/* 219 */           return 1;
/*     */         }
/* 221 */       } else if (this.f == 3) {
/* 222 */         if (paramInt2 == 0) {
/* 223 */           return 2;
/*     */         }
/* 225 */         if (paramInt2 == 1) {
/* 226 */           return 3;
/*     */         }
/* 228 */         if (paramInt2 == 2) {
/* 229 */           return 1;
/*     */         }
/* 231 */         if (paramInt2 == 3) {
/* 232 */           return 0;
/*     */         }
/*     */       } 
/* 235 */     } else if (paramInt1 == apa.aJ.cz) {
/* 236 */       if (this.f == 0) {
/* 237 */         if (paramInt2 == 2) {
/* 238 */           return 3;
/*     */         }
/* 240 */         if (paramInt2 == 3) {
/* 241 */           return 2;
/*     */         }
/* 243 */       } else if (this.f == 1) {
/* 244 */         if (paramInt2 == 2) {
/* 245 */           return 4;
/*     */         }
/* 247 */         if (paramInt2 == 3) {
/* 248 */           return 5;
/*     */         }
/* 250 */         if (paramInt2 == 4) {
/* 251 */           return 2;
/*     */         }
/* 253 */         if (paramInt2 == 5) {
/* 254 */           return 3;
/*     */         }
/* 256 */       } else if (this.f == 3) {
/* 257 */         if (paramInt2 == 2) {
/* 258 */           return 5;
/*     */         }
/* 260 */         if (paramInt2 == 3) {
/* 261 */           return 4;
/*     */         }
/* 263 */         if (paramInt2 == 4) {
/* 264 */           return 2;
/*     */         }
/* 266 */         if (paramInt2 == 5) {
/* 267 */           return 3;
/*     */         }
/*     */       }
/*     */     
/* 271 */     } else if (paramInt1 == apa.aV.cz) {
/* 272 */       if (this.f == 0) {
/* 273 */         if (paramInt2 == 3) {
/* 274 */           return 4;
/*     */         }
/* 276 */         if (paramInt2 == 4) {
/* 277 */           return 3;
/*     */         }
/* 279 */       } else if (this.f == 1) {
/* 280 */         if (paramInt2 == 3) {
/* 281 */           return 1;
/*     */         }
/* 283 */         if (paramInt2 == 4) {
/* 284 */           return 2;
/*     */         }
/* 286 */         if (paramInt2 == 2) {
/* 287 */           return 3;
/*     */         }
/* 289 */         if (paramInt2 == 1) {
/* 290 */           return 4;
/*     */         }
/* 292 */       } else if (this.f == 3) {
/* 293 */         if (paramInt2 == 3) {
/* 294 */           return 2;
/*     */         }
/* 296 */         if (paramInt2 == 4) {
/* 297 */           return 1;
/*     */         }
/* 299 */         if (paramInt2 == 2) {
/* 300 */           return 3;
/*     */         }
/* 302 */         if (paramInt2 == 1) {
/* 303 */           return 4;
/*     */         }
/*     */       } 
/* 306 */     } else if (paramInt1 == apa.bX.cz || (apa.r[paramInt1] != null && apa.r[paramInt1] instanceof alz)) {
/* 307 */       if (this.f == 0) {
/* 308 */         if (paramInt2 == 0 || paramInt2 == 2) {
/* 309 */           return r.f[paramInt2];
/*     */         }
/* 311 */       } else if (this.f == 1) {
/* 312 */         if (paramInt2 == 2) {
/* 313 */           return 1;
/*     */         }
/* 315 */         if (paramInt2 == 0) {
/* 316 */           return 3;
/*     */         }
/* 318 */         if (paramInt2 == 1) {
/* 319 */           return 2;
/*     */         }
/* 321 */         if (paramInt2 == 3) {
/* 322 */           return 0;
/*     */         }
/* 324 */       } else if (this.f == 3) {
/* 325 */         if (paramInt2 == 2) {
/* 326 */           return 3;
/*     */         }
/* 328 */         if (paramInt2 == 0) {
/* 329 */           return 1;
/*     */         }
/* 331 */         if (paramInt2 == 1) {
/* 332 */           return 2;
/*     */         }
/* 334 */         if (paramInt2 == 3) {
/* 335 */           return 0;
/*     */         }
/*     */       } 
/* 338 */     } else if (paramInt1 == apa.ad.cz || paramInt1 == apa.Z.cz || paramInt1 == apa.aN.cz || paramInt1 == apa.T.cz) {
/* 339 */       if (this.f == 0) {
/* 340 */         if (paramInt2 == 2 || paramInt2 == 3) {
/* 341 */           return s.a[paramInt2];
/*     */         }
/* 343 */       } else if (this.f == 1) {
/* 344 */         if (paramInt2 == 2) {
/* 345 */           return 4;
/*     */         }
/* 347 */         if (paramInt2 == 3) {
/* 348 */           return 5;
/*     */         }
/* 350 */         if (paramInt2 == 4) {
/* 351 */           return 2;
/*     */         }
/* 353 */         if (paramInt2 == 5) {
/* 354 */           return 3;
/*     */         }
/* 356 */       } else if (this.f == 3) {
/* 357 */         if (paramInt2 == 2) {
/* 358 */           return 5;
/*     */         }
/* 360 */         if (paramInt2 == 3) {
/* 361 */           return 4;
/*     */         }
/* 363 */         if (paramInt2 == 4) {
/* 364 */           return 2;
/*     */         }
/* 366 */         if (paramInt2 == 5) {
/* 367 */           return 3;
/*     */         }
/*     */       } 
/*     */     } 
/* 371 */     return paramInt2;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, aek paramaek) {
/* 376 */     int i = a(paramInt3, paramInt5);
/* 377 */     int j = a(paramInt4);
/* 378 */     int k = b(paramInt3, paramInt5);
/*     */     
/* 380 */     if (!paramaek.b(i, j, k)) {
/*     */       return;
/*     */     }
/*     */     
/* 384 */     paramaab.f(i, j, k, paramInt1, paramInt2, 2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aek paramaek) {
/* 401 */     int i = a(paramInt1, paramInt3);
/* 402 */     int j = a(paramInt2);
/* 403 */     int k = b(paramInt1, paramInt3);
/*     */     
/* 405 */     if (!paramaek.b(i, j, k)) {
/* 406 */       return 0;
/*     */     }
/*     */     
/* 409 */     return paramaab.a(i, j, k);
/*     */   }
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 413 */     for (int i = paramInt2; i <= paramInt5; i++) {
/* 414 */       for (int j = paramInt1; j <= paramInt4; j++) {
/* 415 */         for (int k = paramInt3; k <= paramInt6; k++) {
/* 416 */           a(paramaab, 0, 0, j, i, k, paramaek);
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
/* 424 */     for (int i = paramInt2; i <= paramInt5; i++) {
/* 425 */       for (int j = paramInt1; j <= paramInt4; j++) {
/* 426 */         for (int k = paramInt3; k <= paramInt6; k++) {
/*     */           
/* 428 */           if (!paramBoolean || a(paramaab, j, i, k, paramaek) != 0)
/*     */           {
/*     */             
/* 431 */             if (i == paramInt2 || i == paramInt5 || j == paramInt1 || j == paramInt4 || k == paramInt3 || k == paramInt6) {
/* 432 */               a(paramaab, paramInt7, 0, j, i, k, paramaek);
/*     */             } else {
/* 434 */               a(paramaab, paramInt8, 0, j, i, k, paramaek);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, int paramInt9, int paramInt10, boolean paramBoolean) {
/* 444 */     for (int i = paramInt2; i <= paramInt5; i++) {
/* 445 */       for (int j = paramInt1; j <= paramInt4; j++) {
/* 446 */         for (int k = paramInt3; k <= paramInt6; k++) {
/*     */           
/* 448 */           if (!paramBoolean || a(paramaab, j, i, k, paramaek) != 0)
/*     */           {
/*     */             
/* 451 */             if (i == paramInt2 || i == paramInt5 || j == paramInt1 || j == paramInt4 || k == paramInt3 || k == paramInt6) {
/* 452 */               a(paramaab, paramInt7, paramInt8, j, i, k, paramaek);
/*     */             } else {
/* 454 */               a(paramaab, paramInt9, paramInt10, j, i, k, paramaek);
/*     */             } 
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, boolean paramBoolean, Random paramRandom, agx paramagx) {
/* 468 */     for (int i = paramInt2; i <= paramInt5; i++) {
/* 469 */       for (int j = paramInt1; j <= paramInt4; j++) {
/* 470 */         for (int k = paramInt3; k <= paramInt6; k++) {
/*     */           
/* 472 */           if (!paramBoolean || a(paramaab, j, i, k, paramaek) != 0) {
/*     */ 
/*     */             
/* 475 */             paramagx.a(paramRandom, j, i, k, (i == paramInt2 || i == paramInt5 || j == paramInt1 || j == paramInt4 || k == paramInt3 || k == paramInt6));
/* 476 */             a(paramaab, paramagx.a(), paramagx.b(), j, i, k, paramaek);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, Random paramRandom, float paramFloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8, boolean paramBoolean) {
/* 489 */     for (int i = paramInt2; i <= paramInt5; i++) {
/* 490 */       for (int j = paramInt1; j <= paramInt4; j++) {
/* 491 */         for (int k = paramInt3; k <= paramInt6; k++) {
/*     */           
/* 493 */           if (paramRandom.nextFloat() <= paramFloat)
/*     */           {
/*     */             
/* 496 */             if (!paramBoolean || a(paramaab, j, i, k, paramaek) != 0)
/*     */             {
/*     */               
/* 499 */               if (i == paramInt2 || i == paramInt5 || j == paramInt1 || j == paramInt4 || k == paramInt3 || k == paramInt6) {
/* 500 */                 a(paramaab, paramInt7, 0, j, i, k, paramaek);
/*     */               } else {
/* 502 */                 a(paramaab, paramInt8, 0, j, i, k, paramaek);
/*     */               } 
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, Random paramRandom, float paramFloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 512 */     if (paramRandom.nextFloat() < paramFloat) {
/* 513 */       a(paramaab, paramInt4, paramInt5, paramInt1, paramInt2, paramInt3, paramaek);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, boolean paramBoolean) {
/* 520 */     float f1 = (paramInt4 - paramInt1 + 1);
/* 521 */     float f2 = (paramInt5 - paramInt2 + 1);
/* 522 */     float f3 = (paramInt6 - paramInt3 + 1);
/* 523 */     float f4 = paramInt1 + f1 / 2.0F;
/* 524 */     float f5 = paramInt3 + f3 / 2.0F;
/*     */     
/* 526 */     for (int i = paramInt2; i <= paramInt5; i++) {
/* 527 */       float f = (i - paramInt2) / f2;
/*     */       
/* 529 */       for (int j = paramInt1; j <= paramInt4; j++) {
/* 530 */         float f6 = (j - f4) / f1 * 0.5F;
/*     */         
/* 532 */         for (int k = paramInt3; k <= paramInt6; k++) {
/* 533 */           float f7 = (k - f5) / f3 * 0.5F;
/*     */           
/* 535 */           if (!paramBoolean || a(paramaab, j, i, k, paramaek) != 0) {
/*     */ 
/*     */ 
/*     */             
/* 539 */             float f8 = f6 * f6 + f * f + f7 * f7;
/*     */             
/* 541 */             if (f8 <= 1.05F) {
/* 542 */               a(paramaab, paramInt7, 0, j, i, k, paramaek);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aek paramaek) {
/* 552 */     int i = a(paramInt1, paramInt3);
/* 553 */     int j = a(paramInt2);
/* 554 */     int k = b(paramInt1, paramInt3);
/*     */     
/* 556 */     if (!paramaek.b(i, j, k)) {
/*     */       return;
/*     */     }
/*     */     
/* 560 */     while (!paramaab.c(i, j, k) && j < 255) {
/* 561 */       paramaab.f(i, j, k, 0, 0, 2);
/* 562 */       j++;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, aek paramaek) {
/* 568 */     int i = a(paramInt3, paramInt5);
/* 569 */     int j = a(paramInt4);
/* 570 */     int k = b(paramInt3, paramInt5);
/*     */     
/* 572 */     if (!paramaek.b(i, j, k)) {
/*     */       return;
/*     */     }
/*     */     
/* 576 */     while ((paramaab.c(i, j, k) || paramaab.g(i, j, k).d()) && j > 1) {
/* 577 */       paramaab.f(i, j, k, paramInt1, paramInt2, 2);
/* 578 */       j--;
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean a(aab paramaab, aek paramaek, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, lp[] paramArrayOflp, int paramInt4) {
/* 584 */     int i = a(paramInt1, paramInt3);
/* 585 */     int j = a(paramInt2);
/* 586 */     int k = b(paramInt1, paramInt3);
/*     */     
/* 588 */     if (paramaek.b(i, j, k) && 
/* 589 */       paramaab.a(i, j, k) != apa.ay.cz) {
/* 590 */       paramaab.f(i, j, k, apa.ay.cz, 0, 2);
/* 591 */       apy apy = (apy)paramaab.r(i, j, k);
/* 592 */       if (apy != null) lp.a(paramRandom, paramArrayOflp, apy, paramInt4); 
/* 593 */       return true;
/*     */     } 
/*     */     
/* 596 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean a(aab paramaab, aek paramaek, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, lp[] paramArrayOflp, int paramInt5) {
/* 601 */     int i = a(paramInt1, paramInt3);
/* 602 */     int j = a(paramInt2);
/* 603 */     int k = b(paramInt1, paramInt3);
/*     */     
/* 605 */     if (paramaek.b(i, j, k) && 
/* 606 */       paramaab.a(i, j, k) != apa.T.cz) {
/* 607 */       paramaab.f(i, j, k, apa.T.cz, c(apa.T.cz, paramInt4), 2);
/* 608 */       aqc aqc = (aqc)paramaab.r(i, j, k);
/* 609 */       if (aqc != null) lp.a(paramRandom, paramArrayOflp, aqc, paramInt5); 
/* 610 */       return true;
/*     */     } 
/*     */     
/* 613 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, aek paramaek, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 618 */     int i = a(paramInt1, paramInt3);
/* 619 */     int j = a(paramInt2);
/* 620 */     int k = b(paramInt1, paramInt3);
/*     */     
/* 622 */     if (paramaek.b(i, j, k))
/* 623 */       vs.a(paramaab, i, j, k, paramInt4, apa.aI); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\agw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */