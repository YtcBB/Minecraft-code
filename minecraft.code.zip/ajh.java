/*    */ 
/*    */ 
/*    */ public class ajh
/*    */ {
/*    */   public final int a;
/*    */   public final int b;
/*    */   public final int c;
/*    */   private final int j;
/*  9 */   int d = -1;
/*    */   
/*    */   float e;
/*    */   float f;
/*    */   
/*    */   public ajh(int paramInt1, int paramInt2, int paramInt3) {
/* 15 */     this.a = paramInt1;
/* 16 */     this.b = paramInt2;
/* 17 */     this.c = paramInt3;
/*    */     
/* 19 */     this.j = a(paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */   float g; ajh h; public boolean i = false;
/*    */   public static int a(int paramInt1, int paramInt2, int paramInt3) {
/* 23 */     return paramInt2 & 0xFF | (paramInt1 & 0x7FFF) << 8 | (paramInt3 & 0x7FFF) << 24 | ((paramInt1 < 0) ? Integer.MIN_VALUE : 0) | ((paramInt3 < 0) ? 32768 : 0);
/*    */   }
/*    */   
/*    */   public float a(ajh paramajh) {
/* 27 */     float f1 = (paramajh.a - this.a);
/* 28 */     float f2 = (paramajh.b - this.b);
/* 29 */     float f3 = (paramajh.c - this.c);
/* 30 */     return kx.c(f1 * f1 + f2 * f2 + f3 * f3);
/*    */   }
/*    */   
/*    */   public float b(ajh paramajh) {
/* 34 */     float f1 = (paramajh.a - this.a);
/* 35 */     float f2 = (paramajh.b - this.b);
/* 36 */     float f3 = (paramajh.c - this.c);
/* 37 */     return f1 * f1 + f2 * f2 + f3 * f3;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 41 */     if (paramObject instanceof ajh) {
/* 42 */       ajh ajh1 = (ajh)paramObject;
/* 43 */       return (this.j == ajh1.j && this.a == ajh1.a && this.b == ajh1.b && this.c == ajh1.c);
/*    */     } 
/* 45 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 49 */     return this.j;
/*    */   }
/*    */   
/*    */   public boolean a() {
/* 53 */     return (this.d >= 0);
/*    */   }
/*    */   
/*    */   public String toString() {
/* 57 */     return this.a + ", " + this.b + ", " + this.c;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */