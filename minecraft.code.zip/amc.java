/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amc
/*     */   extends apa
/*     */ {
/*  25 */   private static final String[] a = new String[] { "doorWood_lower", "doorWood_upper", "doorIron_lower", "doorIron_upper" };
/*     */   
/*     */   private final int b;
/*     */   
/*     */   private lx[] c;
/*     */   
/*     */   protected amc(int paramInt, aif paramaif) {
/*  32 */     super(paramInt, paramaif);
/*     */     
/*  34 */     if (paramaif == aif.f) {
/*  35 */       this.b = 2;
/*     */     } else {
/*  37 */       this.b = 0;
/*     */     } 
/*     */     
/*  40 */     float f1 = 0.5F;
/*  41 */     float f2 = 1.0F;
/*  42 */     a(0.5F - f1, 0.0F, 0.5F - f1, 0.5F + f1, f2, 0.5F + f1);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  47 */     return this.c[this.b];
/*     */   }
/*     */ 
/*     */   
/*     */   public lx b_(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  52 */     if (paramInt4 == 1 || paramInt4 == 0) return this.c[this.b];
/*     */     
/*  54 */     int i = c_(paramaak, paramInt1, paramInt2, paramInt3);
/*  55 */     int j = i & 0x3;
/*  56 */     boolean bool1 = ((i & 0x4) != 0) ? true : false;
/*  57 */     boolean bool2 = false;
/*  58 */     boolean bool3 = ((i & 0x8) != 0) ? true : false;
/*     */     
/*  60 */     if (bool1)
/*  61 */     { if (j == 0 && paramInt4 == 2) { bool2 = !bool2 ? true : false; }
/*  62 */       else if (j == 1 && paramInt4 == 5) { bool2 = !bool2 ? true : false; }
/*  63 */       else if (j == 2 && paramInt4 == 3) { bool2 = !bool2 ? true : false; }
/*  64 */       else if (j == 3 && paramInt4 == 4) { bool2 = !bool2 ? true : false; }
/*     */        }
/*  66 */     else { if (j == 0 && paramInt4 == 5) { bool2 = !bool2 ? true : false; }
/*  67 */       else if (j == 1 && paramInt4 == 3) { bool2 = !bool2 ? true : false; }
/*  68 */       else if (j == 2 && paramInt4 == 4) { bool2 = !bool2 ? true : false; }
/*  69 */       else if (j == 3 && paramInt4 == 2) { bool2 = !bool2 ? true : false; }
/*  70 */        if ((i & 0x10) != 0) bool2 = !bool2 ? true : false;
/*     */        }
/*     */     
/*  73 */     return this.c[this.b + (bool2 ? a.length : 0) + (bool3 ? 1 : 0)];
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  78 */     this.c = new lx[a.length * 2];
/*     */     
/*  80 */     for (byte b = 0; b < a.length; b++) {
/*  81 */       this.c[b] = paramly.a(a[b]);
/*  82 */       this.c[b + a.length] = new lw(this.c[b], true, false);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  97 */     int i = c_(paramaak, paramInt1, paramInt2, paramInt3);
/*  98 */     return ((i & 0x4) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/* 103 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 108 */     return 7;
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 113 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/* 114 */     return super.c_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 119 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/* 120 */     return super.b(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 125 */     d(c_(paramaak, paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   public int d(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 129 */     return c_(paramaak, paramInt1, paramInt2, paramInt3) & 0x3;
/*     */   }
/*     */   
/*     */   public boolean b_(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 133 */     return ((c_(paramaak, paramInt1, paramInt2, paramInt3) & 0x4) != 0);
/*     */   }
/*     */ 
/*     */   
/*     */   private void d(int paramInt) {
/* 138 */     float f = 0.1875F;
/* 139 */     a(0.0F, 0.0F, 0.0F, 1.0F, 2.0F, 1.0F);
/* 140 */     int i = paramInt & 0x3;
/* 141 */     boolean bool1 = ((paramInt & 0x4) != 0) ? true : false;
/* 142 */     boolean bool2 = ((paramInt & 0x10) != 0) ? true : false;
/* 143 */     if (i == 0) {
/* 144 */       if (bool1)
/* 145 */       { if (!bool2) { a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f); }
/* 146 */         else { a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F); }  }
/* 147 */       else { a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F); } 
/* 148 */     } else if (i == 1) {
/* 149 */       if (bool1)
/* 150 */       { if (!bool2) { a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); }
/* 151 */         else { a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F); }  }
/* 152 */       else { a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f); } 
/* 153 */     } else if (i == 2) {
/* 154 */       if (bool1)
/* 155 */       { if (!bool2) { a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F); }
/* 156 */         else { a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, f); }  }
/* 157 */       else { a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); } 
/* 158 */     } else if (i == 3) {
/* 159 */       if (bool1)
/* 160 */       { if (!bool2) { a(0.0F, 0.0F, 0.0F, f, 1.0F, 1.0F); }
/* 161 */         else { a(1.0F - f, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F); }  }
/* 162 */       else { a(0.0F, 0.0F, 1.0F - f, 1.0F, 1.0F, 1.0F); }
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {}
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 173 */     if (this.cO == aif.f) return true;
/*     */     
/* 175 */     int i = c_(paramaab, paramInt1, paramInt2, paramInt3);
/* 176 */     int j = i & 0x7;
/* 177 */     j ^= 0x4;
/* 178 */     if ((i & 0x8) == 0) {
/* 179 */       paramaab.b(paramInt1, paramInt2, paramInt3, j, 2);
/* 180 */       paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     } else {
/* 182 */       paramaab.b(paramInt1, paramInt2 - 1, paramInt3, j, 2);
/* 183 */       paramaab.g(paramInt1, paramInt2 - 1, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/* 186 */     paramaab.a(paramsq, 1003, paramInt1, paramInt2, paramInt3, 0);
/* 187 */     return true;
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, boolean paramBoolean) {
/* 191 */     int i = c_(paramaab, paramInt1, paramInt2, paramInt3);
/* 192 */     boolean bool = ((i & 0x4) != 0);
/* 193 */     if (bool == paramBoolean)
/*     */       return; 
/* 195 */     int j = i & 0x7;
/* 196 */     j ^= 0x4;
/* 197 */     if ((i & 0x8) == 0) {
/* 198 */       paramaab.b(paramInt1, paramInt2, paramInt3, j, 2);
/* 199 */       paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     } else {
/* 201 */       paramaab.b(paramInt1, paramInt2 - 1, paramInt3, j, 2);
/* 202 */       paramaab.g(paramInt1, paramInt2 - 1, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/* 205 */     paramaab.a((sq)null, 1003, paramInt1, paramInt2, paramInt3, 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 210 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 211 */     if ((i & 0x8) == 0) {
/* 212 */       boolean bool = false;
/* 213 */       if (paramaab.a(paramInt1, paramInt2 + 1, paramInt3) != this.cz) {
/* 214 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/* 215 */         bool = true;
/*     */       } 
/* 217 */       if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) {
/* 218 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/* 219 */         bool = true;
/* 220 */         if (paramaab.a(paramInt1, paramInt2 + 1, paramInt3) == this.cz) {
/* 221 */           paramaab.i(paramInt1, paramInt2 + 1, paramInt3);
/*     */         }
/*     */       } 
/* 224 */       if (bool) {
/* 225 */         if (!paramaab.I) {
/* 226 */           c(paramaab, paramInt1, paramInt2, paramInt3, i, 0);
/*     */         }
/*     */       } else {
/* 229 */         boolean bool1 = (paramaab.C(paramInt1, paramInt2, paramInt3) || paramaab.C(paramInt1, paramInt2 + 1, paramInt3)) ? true : false;
/* 230 */         if ((bool1 || (paramInt4 > 0 && apa.r[paramInt4].f())) && paramInt4 != this.cz) {
/* 231 */           a(paramaab, paramInt1, paramInt2, paramInt3, bool1);
/*     */         }
/*     */       } 
/*     */     } else {
/* 235 */       if (paramaab.a(paramInt1, paramInt2 - 1, paramInt3) != this.cz) {
/* 236 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       }
/* 238 */       if (paramInt4 > 0 && paramInt4 != this.cz) {
/* 239 */         a(paramaab, paramInt1, paramInt2 - 1, paramInt3, paramInt4);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 246 */     if ((paramInt1 & 0x8) != 0) return 0; 
/* 247 */     if (this.cO == aif.f) return wk.aC.cp; 
/* 248 */     return wk.aw.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public ara a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, arc paramarc1, arc paramarc2) {
/* 253 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/* 254 */     return super.a(paramaab, paramInt1, paramInt2, paramInt3, paramarc1, paramarc2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 259 */     if (paramInt2 >= 255) return false;
/*     */     
/* 261 */     return (paramaab.w(paramInt1, paramInt2 - 1, paramInt3) && super.c(paramaab, paramInt1, paramInt2, paramInt3) && super.c(paramaab, paramInt1, paramInt2 + 1, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public int h() {
/* 266 */     return 1;
/*     */   }
/*     */   
/*     */   public int c_(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 270 */     int j, k, i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 271 */     boolean bool1 = ((i & 0x8) != 0) ? true : false;
/*     */ 
/*     */     
/* 274 */     if (bool1) {
/* 275 */       j = paramaak.h(paramInt1, paramInt2 - 1, paramInt3);
/* 276 */       k = i;
/*     */     } else {
/* 278 */       j = i;
/* 279 */       k = paramaak.h(paramInt1, paramInt2 + 1, paramInt3);
/*     */     } 
/*     */ 
/*     */     
/* 283 */     boolean bool2 = ((k & 0x1) != 0) ? true : false;
/* 284 */     return j & 0x7 | (bool1 ? 8 : 0) | (bool2 ? 16 : 0);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 289 */     return (this.cO == aif.f) ? wk.aC.cp : wk.aw.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, sq paramsq) {
/* 294 */     if (paramsq.ce.d && (
/* 295 */       paramInt4 & 0x8) != 0 && 
/* 296 */       paramaab.a(paramInt1, paramInt2 - 1, paramInt3) == this.cz)
/* 297 */       paramaab.i(paramInt1, paramInt2 - 1, paramInt3); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */