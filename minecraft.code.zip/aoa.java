/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aoa
/*     */   extends apa
/*     */ {
/*  18 */   public static final String[] a = new String[] { "default", "chiseled", "lines" };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  26 */   private static final String[] b = new String[] { "quartzblock_side", "quartzblock_chiseled", "quartzblock_lines", null, null };
/*     */   
/*     */   private lx[] c;
/*     */   
/*     */   private lx d;
/*     */   
/*     */   private lx e;
/*     */   private lx cR;
/*     */   private lx cS;
/*     */   
/*     */   public aoa(int paramInt) {
/*  37 */     super(paramInt, aif.e);
/*  38 */     a(ve.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  43 */     if (paramInt2 == 2 || paramInt2 == 3 || paramInt2 == 4) {
/*  44 */       if (paramInt2 == 2 && (paramInt1 == 1 || paramInt1 == 0))
/*  45 */         return this.e; 
/*  46 */       if (paramInt2 == 3 && (paramInt1 == 5 || paramInt1 == 4))
/*  47 */         return this.e; 
/*  48 */       if (paramInt2 == 4 && (paramInt1 == 2 || paramInt1 == 3)) {
/*  49 */         return this.e;
/*     */       }
/*     */       
/*  52 */       return this.c[paramInt2];
/*     */     } 
/*     */     
/*  55 */     if (paramInt1 == 1 || (paramInt1 == 0 && paramInt2 == 1)) {
/*  56 */       if (paramInt2 == 1) {
/*  57 */         return this.d;
/*     */       }
/*  59 */       return this.cR;
/*     */     } 
/*  61 */     if (paramInt1 == 0) {
/*  62 */       return this.cS;
/*     */     }
/*  64 */     if (paramInt2 < 0 || paramInt2 >= this.c.length) paramInt2 = 0; 
/*  65 */     return this.c[paramInt2];
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  70 */     if (paramInt5 == 2) {
/*  71 */       switch (paramInt4) {
/*     */         case 2:
/*     */         case 3:
/*  74 */           paramInt5 = 4;
/*     */           break;
/*     */         case 4:
/*     */         case 5:
/*  78 */           paramInt5 = 3;
/*     */           break;
/*     */         case 0:
/*     */         case 1:
/*  82 */           paramInt5 = 2;
/*     */           break;
/*     */       } 
/*     */     
/*     */     }
/*  87 */     return paramInt5;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/*  92 */     if (paramInt == 3 || paramInt == 4) return 2;
/*     */     
/*  94 */     return paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   protected wm c_(int paramInt) {
/*  99 */     if (paramInt == 3 || paramInt == 4) return new wm(this.cz, 1, 2); 
/* 100 */     return super.c_(paramInt);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 105 */     return 39;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 110 */     paramList.add(new wm(paramInt, 1, 0));
/* 111 */     paramList.add(new wm(paramInt, 1, 1));
/* 112 */     paramList.add(new wm(paramInt, 1, 2));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 117 */     this.c = new lx[b.length];
/*     */     
/* 119 */     for (byte b = 0; b < this.c.length; b++) {
/* 120 */       if (b[b] == null) {
/* 121 */         this.c[b] = this.c[b - 1];
/*     */       } else {
/* 123 */         this.c[b] = paramly.a(b[b]);
/*     */       } 
/*     */     } 
/*     */     
/* 127 */     this.cR = paramly.a("quartzblock_top");
/* 128 */     this.d = paramly.a("quartzblock_chiseled_top");
/* 129 */     this.e = paramly.a("quartzblock_lines_top");
/* 130 */     this.cS = paramly.a("quartzblock_bottom");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoa.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */