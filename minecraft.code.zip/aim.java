/*    */ 
/*    */ 
/*    */ 
/*    */ public class aim
/*    */   extends ait
/*    */ {
/*  7 */   private aav[] b = new aav[] { aav.d, aav.f, aav.e, aav.h, aav.c, aav.g, aav.w };
/*    */ 
/*    */ 
/*    */   
/*    */   public aim(long paramLong, ait paramait, aal paramaal) {
/* 12 */     super(paramLong);
/* 13 */     this.a = paramait;
/*    */     
/* 15 */     if (paramaal == aal.e) {
/* 16 */       this.b = new aav[] { aav.d, aav.f, aav.e, aav.h, aav.c, aav.g };
/*    */     }
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 24 */     int[] arrayOfInt1 = this.a.a(paramInt1, paramInt2, paramInt3, paramInt4);
/*    */     
/* 26 */     int[] arrayOfInt2 = air.a(paramInt3 * paramInt4);
/* 27 */     for (byte b = 0; b < paramInt4; b++) {
/* 28 */       for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 29 */         a((b1 + paramInt1), (b + paramInt2));
/* 30 */         int i = arrayOfInt1[b1 + b * paramInt3];
/* 31 */         if (i == 0) {
/* 32 */           arrayOfInt2[b1 + b * paramInt3] = 0;
/* 33 */         } else if (i == aav.p.N) {
/* 34 */           arrayOfInt2[b1 + b * paramInt3] = i;
/* 35 */         } else if (i == 1) {
/* 36 */           arrayOfInt2[b1 + b * paramInt3] = (this.b[a(this.b.length)]).N;
/*    */         } else {
/* 38 */           int j = (this.b[a(this.b.length)]).N;
/* 39 */           if (j == aav.g.N) {
/* 40 */             arrayOfInt2[b1 + b * paramInt3] = j;
/*    */           } else {
/* 42 */             arrayOfInt2[b1 + b * paramInt3] = aav.n.N;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 48 */     return arrayOfInt2;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aim.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */