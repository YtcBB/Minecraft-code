/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class aqk
/*    */   extends zs
/*    */ {
/*    */   aqk(aqj paramaqj) {}
/*    */   
/*    */   public void a(int paramInt) {
/* 14 */     this.a.k.d(this.a.l, this.a.m, this.a.n, apa.aw.cz, paramInt, 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public aab a() {
/* 19 */     return this.a.k;
/*    */   }
/*    */ 
/*    */   
/*    */   public int b() {
/* 24 */     return this.a.l;
/*    */   }
/*    */ 
/*    */   
/*    */   public int c() {
/* 29 */     return this.a.m;
/*    */   }
/*    */ 
/*    */   
/*    */   public int d() {
/* 34 */     return this.a.n;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(zt paramzt) {
/* 39 */     super.a(paramzt);
/* 40 */     if (a() != null) a().j(this.a.l, this.a.m, this.a.n); 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */