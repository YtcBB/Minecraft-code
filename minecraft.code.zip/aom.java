/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aom
/*     */   extends akz
/*     */ {
/*     */   protected aom(int paramInt) {
/*  26 */     super(paramInt, aif.q);
/*  27 */     a(0.25F, 0.0F, 0.25F, 0.75F, 0.5F, 0.75F);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  32 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  37 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  42 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  47 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3) & 0x7;
/*     */     
/*  49 */     switch (i) {
/*     */       
/*     */       default:
/*  52 */         a(0.25F, 0.0F, 0.25F, 0.75F, 0.5F, 0.75F);
/*     */         return;
/*     */       case 2:
/*  55 */         a(0.25F, 0.25F, 0.5F, 0.75F, 0.75F, 1.0F);
/*     */         return;
/*     */       case 3:
/*  58 */         a(0.25F, 0.25F, 0.0F, 0.75F, 0.75F, 0.5F);
/*     */         return;
/*     */       case 4:
/*  61 */         a(0.5F, 0.25F, 0.25F, 1.0F, 0.75F, 0.75F); return;
/*     */       case 5:
/*     */         break;
/*  64 */     }  a(0.0F, 0.25F, 0.25F, 0.5F, 0.75F, 0.75F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  71 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*  72 */     return super.b(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/*  77 */     int i = kx.c((paramng.A * 4.0F / 360.0F) + 2.5D) & 0x3;
/*  78 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/*  82 */     return new aqn();
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  87 */     return wk.bR.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int h(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  92 */     aqp aqp = paramaab.r(paramInt1, paramInt2, paramInt3);
/*  93 */     if (aqp != null && aqp instanceof aqn) {
/*  94 */       return ((aqn)aqp).a();
/*     */     }
/*  96 */     return super.h(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/* 101 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, sq paramsq) {
/* 112 */     if (paramsq.ce.d) {
/*     */       
/* 114 */       paramInt4 |= 0x8;
/* 115 */       paramaab.b(paramInt1, paramInt2, paramInt3, paramInt4, 4);
/*     */     } 
/* 117 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramsq);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 122 */     if (paramaab.I)
/* 123 */       return;  if ((paramInt5 & 0x8) == 0) {
/* 124 */       wm wm = new wm(wk.bR.cp, 1, h(paramaab, paramInt1, paramInt2, paramInt3));
/* 125 */       aqn aqn = (aqn)paramaab.r(paramInt1, paramInt2, paramInt3);
/*     */       
/* 127 */       if (aqn.a() == 3 && aqn.c() != null && aqn.c().length() > 0) {
/* 128 */         wm.d(new bs());
/* 129 */         wm.q().a("SkullOwner", aqn.c());
/*     */       } 
/*     */       
/* 132 */       b(paramaab, paramInt1, paramInt2, paramInt3, wm);
/*     */     } 
/* 134 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 139 */     return wk.bR.cp;
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqn paramaqn) {
/* 143 */     if (paramaqn.a() == 1 && paramInt2 >= 2 && paramaab.r > 0 && !paramaab.I) {
/*     */ 
/*     */ 
/*     */       
/* 147 */       int i = apa.bg.cz;
/*     */       
/*     */       byte b;
/* 150 */       for (b = -2; b <= 0; b++) {
/* 151 */         if (paramaab.a(paramInt1, paramInt2 - 1, paramInt3 + b) == i && paramaab.a(paramInt1, paramInt2 - 1, paramInt3 + b + 1) == i && paramaab.a(paramInt1, paramInt2 - 2, paramInt3 + b + 1) == i && paramaab.a(paramInt1, paramInt2 - 1, paramInt3 + b + 2) == i && d(paramaab, paramInt1, paramInt2, paramInt3 + b, 1) && d(paramaab, paramInt1, paramInt2, paramInt3 + b + 1, 1) && d(paramaab, paramInt1, paramInt2, paramInt3 + b + 2, 1)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 160 */           paramaab.b(paramInt1, paramInt2, paramInt3 + b, 8, 2);
/* 161 */           paramaab.b(paramInt1, paramInt2, paramInt3 + b + 1, 8, 2);
/* 162 */           paramaab.b(paramInt1, paramInt2, paramInt3 + b + 2, 8, 2);
/* 163 */           paramaab.f(paramInt1, paramInt2, paramInt3 + b, 0, 0, 2);
/* 164 */           paramaab.f(paramInt1, paramInt2, paramInt3 + b + 1, 0, 0, 2);
/* 165 */           paramaab.f(paramInt1, paramInt2, paramInt3 + b + 2, 0, 0, 2);
/* 166 */           paramaab.f(paramInt1, paramInt2 - 1, paramInt3 + b, 0, 0, 2);
/* 167 */           paramaab.f(paramInt1, paramInt2 - 1, paramInt3 + b + 1, 0, 0, 2);
/* 168 */           paramaab.f(paramInt1, paramInt2 - 1, paramInt3 + b + 2, 0, 0, 2);
/* 169 */           paramaab.f(paramInt1, paramInt2 - 2, paramInt3 + b + 1, 0, 0, 2);
/*     */           
/* 171 */           if (!paramaab.I) {
/* 172 */             rb rb = new rb(paramaab);
/* 173 */             rb.b(paramInt1 + 0.5D, paramInt2 - 1.45D, (paramInt3 + b) + 1.5D, 90.0F, 0.0F);
/* 174 */             rb.ay = 90.0F;
/* 175 */             rb.m();
/* 176 */             paramaab.d(rb);
/*     */           } 
/*     */           
/* 179 */           for (byte b1 = 0; b1 < 120; b1++) {
/* 180 */             paramaab.a("snowballpoof", paramInt1 + paramaab.s.nextDouble(), (paramInt2 - 2) + paramaab.s.nextDouble() * 3.9D, (paramInt3 + b + 1) + paramaab.s.nextDouble(), 0.0D, 0.0D, 0.0D);
/*     */           }
/*     */           
/* 183 */           paramaab.d(paramInt1, paramInt2, paramInt3 + b, 0);
/* 184 */           paramaab.d(paramInt1, paramInt2, paramInt3 + b + 1, 0);
/* 185 */           paramaab.d(paramInt1, paramInt2, paramInt3 + b + 2, 0);
/* 186 */           paramaab.d(paramInt1, paramInt2 - 1, paramInt3 + b, 0);
/* 187 */           paramaab.d(paramInt1, paramInt2 - 1, paramInt3 + b + 1, 0);
/* 188 */           paramaab.d(paramInt1, paramInt2 - 1, paramInt3 + b + 2, 0);
/* 189 */           paramaab.d(paramInt1, paramInt2 - 2, paramInt3 + b + 1, 0);
/*     */           
/*     */           return;
/*     */         } 
/*     */       } 
/*     */       
/* 195 */       for (b = -2; b <= 0; b++) {
/* 196 */         if (paramaab.a(paramInt1 + b, paramInt2 - 1, paramInt3) == i && paramaab.a(paramInt1 + b + 1, paramInt2 - 1, paramInt3) == i && paramaab.a(paramInt1 + b + 1, paramInt2 - 2, paramInt3) == i && paramaab.a(paramInt1 + b + 2, paramInt2 - 1, paramInt3) == i && d(paramaab, paramInt1 + b, paramInt2, paramInt3, 1) && d(paramaab, paramInt1 + b + 1, paramInt2, paramInt3, 1) && d(paramaab, paramInt1 + b + 2, paramInt2, paramInt3, 1)) {
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */           
/* 205 */           paramaab.b(paramInt1 + b, paramInt2, paramInt3, 8, 2);
/* 206 */           paramaab.b(paramInt1 + b + 1, paramInt2, paramInt3, 8, 2);
/* 207 */           paramaab.b(paramInt1 + b + 2, paramInt2, paramInt3, 8, 2);
/* 208 */           paramaab.f(paramInt1 + b, paramInt2, paramInt3, 0, 0, 2);
/* 209 */           paramaab.f(paramInt1 + b + 1, paramInt2, paramInt3, 0, 0, 2);
/* 210 */           paramaab.f(paramInt1 + b + 2, paramInt2, paramInt3, 0, 0, 2);
/* 211 */           paramaab.f(paramInt1 + b, paramInt2 - 1, paramInt3, 0, 0, 2);
/* 212 */           paramaab.f(paramInt1 + b + 1, paramInt2 - 1, paramInt3, 0, 0, 2);
/* 213 */           paramaab.f(paramInt1 + b + 2, paramInt2 - 1, paramInt3, 0, 0, 2);
/* 214 */           paramaab.f(paramInt1 + b + 1, paramInt2 - 2, paramInt3, 0, 0, 2);
/*     */           
/* 216 */           if (!paramaab.I) {
/* 217 */             rb rb = new rb(paramaab);
/* 218 */             rb.b((paramInt1 + b) + 1.5D, paramInt2 - 1.45D, paramInt3 + 0.5D, 0.0F, 0.0F);
/* 219 */             rb.m();
/* 220 */             paramaab.d(rb);
/*     */           } 
/*     */           
/* 223 */           for (byte b1 = 0; b1 < 120; b1++) {
/* 224 */             paramaab.a("snowballpoof", (paramInt1 + b + 1) + paramaab.s.nextDouble(), (paramInt2 - 2) + paramaab.s.nextDouble() * 3.9D, paramInt3 + paramaab.s.nextDouble(), 0.0D, 0.0D, 0.0D);
/*     */           }
/*     */           
/* 227 */           paramaab.d(paramInt1 + b, paramInt2, paramInt3, 0);
/* 228 */           paramaab.d(paramInt1 + b + 1, paramInt2, paramInt3, 0);
/* 229 */           paramaab.d(paramInt1 + b + 2, paramInt2, paramInt3, 0);
/* 230 */           paramaab.d(paramInt1 + b, paramInt2 - 1, paramInt3, 0);
/* 231 */           paramaab.d(paramInt1 + b + 1, paramInt2 - 1, paramInt3, 0);
/* 232 */           paramaab.d(paramInt1 + b + 2, paramInt2 - 1, paramInt3, 0);
/* 233 */           paramaab.d(paramInt1 + b + 1, paramInt2 - 2, paramInt3, 0);
/*     */           return;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 242 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) != this.cz) {
/* 243 */       return false;
/*     */     }
/* 245 */     aqp aqp = paramaab.r(paramInt1, paramInt2, paramInt3);
/* 246 */     if (aqp == null || !(aqp instanceof aqn)) {
/* 247 */       return false;
/*     */     }
/* 249 */     return (((aqn)aqp).a() == paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/* 259 */     return apa.bg.m(paramInt1);
/*     */   }
/*     */ 
/*     */   
/*     */   public String u_() {
/* 264 */     return xi.a[0];
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aom.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */