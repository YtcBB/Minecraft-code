/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ang
/*    */   extends ane
/*    */ {
/*    */   protected ang(int paramInt, aif paramaif) {
/* 10 */     super(paramInt, paramaif);
/*    */     
/* 12 */     b(false);
/* 13 */     if (paramaif == aif.i) b(true);
/*    */   
/*    */   }
/*    */   
/*    */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 18 */     return (this.cO != aif.i);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 23 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/* 24 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) == this.cz) {
/* 25 */       k(paramaab, paramInt1, paramInt2, paramInt3);
/*    */     }
/*    */   }
/*    */   
/*    */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 30 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 31 */     paramaab.f(paramInt1, paramInt2, paramInt3, this.cz - 1, i, 2);
/* 32 */     paramaab.a(paramInt1, paramInt2, paramInt3, this.cz - 1, a(paramaab));
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 37 */     if (this.cO == aif.i) {
/* 38 */       int i = paramRandom.nextInt(3); int j;
/* 39 */       for (j = 0; j < i; j++) {
/* 40 */         paramInt1 += paramRandom.nextInt(3) - 1;
/* 41 */         paramInt2++;
/* 42 */         paramInt3 += paramRandom.nextInt(3) - 1;
/* 43 */         int k = paramaab.a(paramInt1, paramInt2, paramInt3);
/* 44 */         if (k == 0) {
/* 45 */           if (m(paramaab, paramInt1 - 1, paramInt2, paramInt3) || m(paramaab, paramInt1 + 1, paramInt2, paramInt3) || m(paramaab, paramInt1, paramInt2, paramInt3 - 1) || m(paramaab, paramInt1, paramInt2, paramInt3 + 1) || m(paramaab, paramInt1, paramInt2 - 1, paramInt3) || m(paramaab, paramInt1, paramInt2 + 1, paramInt3)) {
/*    */             
/* 47 */             paramaab.c(paramInt1, paramInt2, paramInt3, apa.av.cz);
/*    */             return;
/*    */           } 
/* 50 */         } else if ((apa.r[k]).cO.c()) {
/*    */           return;
/*    */         } 
/*    */       } 
/* 54 */       if (i == 0) {
/* 55 */         j = paramInt1;
/* 56 */         int k = paramInt3;
/* 57 */         for (byte b = 0; b < 3; b++) {
/* 58 */           paramInt1 = j + paramRandom.nextInt(3) - 1;
/* 59 */           paramInt3 = k + paramRandom.nextInt(3) - 1;
/* 60 */           if (paramaab.c(paramInt1, paramInt2 + 1, paramInt3) && m(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 61 */             paramaab.c(paramInt1, paramInt2 + 1, paramInt3, apa.av.cz);
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */   }
/*    */   
/*    */   private boolean m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 69 */     return paramaab.g(paramInt1, paramInt2, paramInt3).h();
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ang.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */