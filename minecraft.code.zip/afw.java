/*     */ import java.util.ArrayList;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ class afw
/*     */   extends agy
/*     */ {
/*     */   public afw(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 112 */     afx.a();
/*     */     
/* 114 */     agn agn = new agn(0, paramRandom, (paramInt1 << 4) + 2, (paramInt2 << 4) + 2);
/* 115 */     this.a.add(agn);
/* 116 */     agn.a(agn, this.a, paramRandom);
/*     */     
/* 118 */     ArrayList<agw> arrayList = agn.c;
/* 119 */     while (!arrayList.isEmpty()) {
/* 120 */       int i = paramRandom.nextInt(arrayList.size());
/* 121 */       agw agw = arrayList.remove(i);
/* 122 */       agw.a(agn, this.a, paramRandom);
/*     */     } 
/*     */     
/* 125 */     c();
/* 126 */     a(paramaab, paramRandom, 10);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afw.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */