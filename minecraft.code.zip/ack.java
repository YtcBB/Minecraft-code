/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ class ack
/*    */ {
/*    */   public final zu a;
/*    */   public final bs b;
/*    */   
/*    */   public ack(zu paramzu, bs parambs) {
/* 20 */     this.a = paramzu;
/* 21 */     this.b = parambs;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ack.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */