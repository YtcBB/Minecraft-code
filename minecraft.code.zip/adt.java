/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class adt
/*     */   extends adj
/*     */ {
/*     */   private final int a;
/*     */   private final int b;
/*     */   private final int c;
/*     */   
/*     */   public adt(boolean paramBoolean, int paramInt1, int paramInt2, int paramInt3) {
/*  16 */     super(paramBoolean);
/*  17 */     this.a = paramInt1;
/*  18 */     this.b = paramInt2;
/*  19 */     this.c = paramInt3;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/*  24 */     int i = paramRandom.nextInt(3) + this.a;
/*     */     
/*  26 */     boolean bool = true;
/*  27 */     if (paramInt2 < 1 || paramInt2 + i + 1 > 256) return false; 
/*     */     int j;
/*  29 */     for (j = paramInt2; j <= paramInt2 + 1 + i; j++) {
/*  30 */       byte b1 = 2;
/*  31 */       if (j == paramInt2) b1 = 1; 
/*  32 */       if (j >= paramInt2 + 1 + i - 2) b1 = 2; 
/*  33 */       for (int m = paramInt1 - b1; m <= paramInt1 + b1 && bool; m++) {
/*  34 */         for (int n = paramInt3 - b1; n <= paramInt3 + b1 && bool; n++) {
/*  35 */           if (j >= 0 && j < 256) {
/*  36 */             int i1 = paramaab.a(m, j, n);
/*  37 */             if (i1 != 0 && i1 != apa.O.cz && i1 != apa.y.cz && i1 != apa.z.cz && i1 != apa.N.cz && i1 != apa.C.cz) bool = false; 
/*     */           } else {
/*  39 */             bool = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  45 */     if (!bool) return false;
/*     */     
/*  47 */     j = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/*  48 */     if ((j != apa.y.cz && j != apa.z.cz) || paramInt2 >= 256 - i - 1) return false;
/*     */     
/*  50 */     paramaab.f(paramInt1, paramInt2 - 1, paramInt3, apa.z.cz, 0, 2);
/*  51 */     paramaab.f(paramInt1 + 1, paramInt2 - 1, paramInt3, apa.z.cz, 0, 2);
/*  52 */     paramaab.f(paramInt1, paramInt2 - 1, paramInt3 + 1, apa.z.cz, 0, 2);
/*  53 */     paramaab.f(paramInt1 + 1, paramInt2 - 1, paramInt3 + 1, apa.z.cz, 0, 2);
/*     */     
/*  55 */     a(paramaab, paramInt1, paramInt3, paramInt2 + i, 2, paramRandom);
/*     */     
/*  57 */     int k = paramInt2 + i - 2 - paramRandom.nextInt(4);
/*  58 */     while (k > paramInt2 + i / 2) {
/*  59 */       float f = paramRandom.nextFloat() * 3.1415927F * 2.0F;
/*  60 */       int m = paramInt1 + (int)(0.5F + kx.b(f) * 4.0F);
/*  61 */       int n = paramInt3 + (int)(0.5F + kx.a(f) * 4.0F);
/*  62 */       a(paramaab, m, n, k, 0, paramRandom);
/*     */       
/*  64 */       for (byte b1 = 0; b1 < 5; b1++) {
/*  65 */         m = paramInt1 + (int)(1.5F + kx.b(f) * b1);
/*  66 */         n = paramInt3 + (int)(1.5F + kx.a(f) * b1);
/*  67 */         a(paramaab, m, k - 3 + b1 / 2, n, apa.N.cz, this.b);
/*     */       } 
/*     */       
/*  70 */       k -= 2 + paramRandom.nextInt(4);
/*     */     } 
/*     */     
/*  73 */     for (byte b = 0; b < i; b++) {
/*  74 */       int m = paramaab.a(paramInt1, paramInt2 + b, paramInt3);
/*  75 */       if (m == 0 || m == apa.O.cz) {
/*  76 */         a(paramaab, paramInt1, paramInt2 + b, paramInt3, apa.N.cz, this.b);
/*  77 */         if (b > 0) {
/*  78 */           if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1 - 1, paramInt2 + b, paramInt3)) {
/*  79 */             a(paramaab, paramInt1 - 1, paramInt2 + b, paramInt3, apa.by.cz, 8);
/*     */           }
/*  81 */           if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1, paramInt2 + b, paramInt3 - 1)) {
/*  82 */             a(paramaab, paramInt1, paramInt2 + b, paramInt3 - 1, apa.by.cz, 1);
/*     */           }
/*     */         } 
/*     */       } 
/*  86 */       if (b < i - 1) {
/*  87 */         m = paramaab.a(paramInt1 + 1, paramInt2 + b, paramInt3);
/*  88 */         if (m == 0 || m == apa.O.cz) {
/*  89 */           a(paramaab, paramInt1 + 1, paramInt2 + b, paramInt3, apa.N.cz, this.b);
/*  90 */           if (b > 0) {
/*  91 */             if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1 + 2, paramInt2 + b, paramInt3)) {
/*  92 */               a(paramaab, paramInt1 + 2, paramInt2 + b, paramInt3, apa.by.cz, 2);
/*     */             }
/*  94 */             if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1 + 1, paramInt2 + b, paramInt3 - 1)) {
/*  95 */               a(paramaab, paramInt1 + 1, paramInt2 + b, paramInt3 - 1, apa.by.cz, 1);
/*     */             }
/*     */           } 
/*     */         } 
/*  99 */         m = paramaab.a(paramInt1 + 1, paramInt2 + b, paramInt3 + 1);
/* 100 */         if (m == 0 || m == apa.O.cz) {
/* 101 */           a(paramaab, paramInt1 + 1, paramInt2 + b, paramInt3 + 1, apa.N.cz, this.b);
/* 102 */           if (b > 0) {
/* 103 */             if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1 + 2, paramInt2 + b, paramInt3 + 1)) {
/* 104 */               a(paramaab, paramInt1 + 2, paramInt2 + b, paramInt3 + 1, apa.by.cz, 2);
/*     */             }
/* 106 */             if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1 + 1, paramInt2 + b, paramInt3 + 2)) {
/* 107 */               a(paramaab, paramInt1 + 1, paramInt2 + b, paramInt3 + 2, apa.by.cz, 4);
/*     */             }
/*     */           } 
/*     */         } 
/* 111 */         m = paramaab.a(paramInt1, paramInt2 + b, paramInt3 + 1);
/* 112 */         if (m == 0 || m == apa.O.cz) {
/* 113 */           a(paramaab, paramInt1, paramInt2 + b, paramInt3 + 1, apa.N.cz, this.b);
/* 114 */           if (b > 0) {
/* 115 */             if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1 - 1, paramInt2 + b, paramInt3 + 1)) {
/* 116 */               a(paramaab, paramInt1 - 1, paramInt2 + b, paramInt3 + 1, apa.by.cz, 8);
/*     */             }
/* 118 */             if (paramRandom.nextInt(3) > 0 && paramaab.c(paramInt1, paramInt2 + b, paramInt3 + 2)) {
/* 119 */               a(paramaab, paramInt1, paramInt2 + b, paramInt3 + 2, apa.by.cz, 4);
/*     */             }
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 126 */     return true;
/*     */   }
/*     */   
/*     */   private void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, Random paramRandom) {
/* 130 */     byte b = 2;
/* 131 */     for (int i = paramInt3 - b; i <= paramInt3; i++) {
/* 132 */       int j = i - paramInt3;
/* 133 */       int k = paramInt4 + 1 - j;
/* 134 */       for (int m = paramInt1 - k; m <= paramInt1 + k + 1; m++) {
/* 135 */         int n = m - paramInt1;
/* 136 */         for (int i1 = paramInt2 - k; i1 <= paramInt2 + k + 1; i1++) {
/* 137 */           int i2 = i1 - paramInt2;
/* 138 */           if (n >= 0 || i2 >= 0 || n * n + i2 * i2 <= k * k)
/*     */           {
/*     */             
/* 141 */             if ((n <= 0 && i2 <= 0) || n * n + i2 * i2 <= (k + 1) * (k + 1))
/*     */             {
/*     */               
/* 144 */               if (paramRandom.nextInt(4) != 0 || n * n + i2 * i2 <= (k - 1) * (k - 1)) {
/*     */ 
/*     */                 
/* 147 */                 int i3 = paramaab.a(m, i, i1);
/* 148 */                 if (i3 == 0 || i3 == apa.O.cz) a(paramaab, m, i, i1, apa.O.cz, this.c); 
/*     */               } 
/*     */             }
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */