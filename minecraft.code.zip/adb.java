/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class adb
/*     */   extends adj
/*     */ {
/*  29 */   static final byte[] a = new byte[] { 2, 0, 0, 1, 2, 1 };
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  34 */   Random b = new Random();
/*     */ 
/*     */   
/*     */   aab c;
/*     */ 
/*     */   
/*  40 */   int[] d = new int[] { 0, 0, 0 };
/*     */ 
/*     */ 
/*     */   
/*  44 */   int e = 0;
/*     */   
/*     */   int f;
/*  47 */   double g = 0.618D;
/*  48 */   double h = 1.0D;
/*  49 */   double i = 0.381D;
/*  50 */   double j = 1.0D;
/*  51 */   double k = 1.0D;
/*  52 */   int l = 1;
/*  53 */   int m = 12;
/*  54 */   int n = 4;
/*     */   
/*     */   int[][] o;
/*     */   
/*     */   public adb(boolean paramBoolean) {
/*  59 */     super(paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void a() {
/*  67 */     this.f = (int)(this.e * this.g);
/*  68 */     if (this.f >= this.e) this.f = this.e - 1; 
/*  69 */     int i = (int)(1.382D + Math.pow(this.k * this.e / 13.0D, 2.0D));
/*  70 */     if (i < 1) i = 1;
/*     */ 
/*     */     
/*  73 */     int[][] arrayOfInt = new int[i * this.e][4];
/*  74 */     int j = this.d[1] + this.e - this.n;
/*  75 */     byte b = 1;
/*  76 */     int k = this.d[1] + this.f;
/*  77 */     int m = j - this.d[1];
/*  78 */     arrayOfInt[0][0] = this.d[0];
/*  79 */     arrayOfInt[0][1] = j;
/*  80 */     arrayOfInt[0][2] = this.d[2];
/*  81 */     arrayOfInt[0][3] = k;
/*  82 */     j--;
/*     */     
/*  84 */     while (m >= 0) {
/*  85 */       byte b1 = 0;
/*     */       
/*  87 */       float f = a(m);
/*  88 */       if (f < 0.0F) {
/*  89 */         j--;
/*  90 */         m--;
/*     */         
/*     */         continue;
/*     */       } 
/*     */       
/*  95 */       double d = 0.5D;
/*  96 */       while (b1 < i) {
/*  97 */         double d1 = this.j * f * (this.b.nextFloat() + 0.328D);
/*  98 */         double d2 = this.b.nextFloat() * 2.0D * 3.14159D;
/*  99 */         int n = kx.c(d1 * Math.sin(d2) + this.d[0] + d);
/* 100 */         int i1 = kx.c(d1 * Math.cos(d2) + this.d[2] + d);
/* 101 */         int[] arrayOfInt1 = { n, j, i1 };
/*     */ 
/*     */         
/* 104 */         int[] arrayOfInt2 = { n, j + this.n, i1 };
/*     */ 
/*     */ 
/*     */         
/* 108 */         if (a(arrayOfInt1, arrayOfInt2) == -1) {
/*     */ 
/*     */           
/* 111 */           int[] arrayOfInt3 = { this.d[0], this.d[1], this.d[2] };
/*     */ 
/*     */           
/* 114 */           double d3 = Math.sqrt(Math.pow(Math.abs(this.d[0] - arrayOfInt1[0]), 2.0D) + Math.pow(Math.abs(this.d[2] - arrayOfInt1[2]), 2.0D));
/* 115 */           double d4 = d3 * this.i;
/* 116 */           if (arrayOfInt1[1] - d4 > k) {
/* 117 */             arrayOfInt3[1] = k;
/*     */           } else {
/*     */             
/* 120 */             arrayOfInt3[1] = (int)(arrayOfInt1[1] - d4);
/*     */           } 
/*     */           
/* 123 */           if (a(arrayOfInt3, arrayOfInt1) == -1) {
/*     */ 
/*     */             
/* 126 */             arrayOfInt[b][0] = n;
/* 127 */             arrayOfInt[b][1] = j;
/* 128 */             arrayOfInt[b][2] = i1;
/* 129 */             arrayOfInt[b][3] = arrayOfInt3[1];
/* 130 */             b++;
/*     */           } 
/*     */         } 
/* 133 */         b1++;
/*     */       } 
/* 135 */       j--;
/* 136 */       m--;
/*     */     } 
/* 138 */     this.o = new int[b][4];
/* 139 */     System.arraycopy(arrayOfInt, 0, this.o, 0, b);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void a(int paramInt1, int paramInt2, int paramInt3, float paramFloat, byte paramByte, int paramInt4) {
/* 154 */     int i = (int)(paramFloat + 0.618D);
/* 155 */     byte b1 = a[paramByte];
/* 156 */     byte b2 = a[paramByte + 3];
/* 157 */     int[] arrayOfInt1 = { paramInt1, paramInt2, paramInt3 };
/*     */ 
/*     */     
/* 160 */     int[] arrayOfInt2 = { 0, 0, 0 };
/*     */ 
/*     */     
/* 163 */     int j = -i;
/* 164 */     int k = -i;
/*     */     
/* 166 */     arrayOfInt2[paramByte] = arrayOfInt1[paramByte];
/* 167 */     while (j <= i) {
/* 168 */       arrayOfInt2[b1] = arrayOfInt1[b1] + j;
/* 169 */       k = -i;
/* 170 */       while (k <= i) {
/* 171 */         double d = Math.pow(Math.abs(j) + 0.5D, 2.0D) + Math.pow(Math.abs(k) + 0.5D, 2.0D);
/* 172 */         if (d > (paramFloat * paramFloat)) {
/* 173 */           k++;
/*     */           continue;
/*     */         } 
/* 176 */         arrayOfInt2[b2] = arrayOfInt1[b2] + k;
/* 177 */         int m = this.c.a(arrayOfInt2[0], arrayOfInt2[1], arrayOfInt2[2]);
/* 178 */         if (m != 0 && m != apa.O.cz) {
/*     */ 
/*     */           
/* 181 */           k++;
/*     */           continue;
/*     */         } 
/* 184 */         a(this.c, arrayOfInt2[0], arrayOfInt2[1], arrayOfInt2[2], paramInt4, 0);
/* 185 */         k++;
/*     */       } 
/* 187 */       j++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float a(int paramInt) {
/*     */     float f3;
/* 199 */     if (paramInt < this.e * 0.3D) return -1.618F; 
/* 200 */     float f1 = this.e / 2.0F;
/* 201 */     float f2 = this.e / 2.0F - paramInt;
/*     */     
/* 203 */     if (f2 == 0.0F) { f3 = f1; }
/* 204 */     else if (Math.abs(f2) >= f1) { f3 = 0.0F; }
/* 205 */     else { f3 = (float)Math.sqrt(Math.pow(Math.abs(f1), 2.0D) - Math.pow(Math.abs(f2), 2.0D)); }
/*     */     
/* 207 */     f3 *= 0.5F;
/* 208 */     return f3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   float b(int paramInt) {
/* 217 */     if (paramInt < 0 || paramInt >= this.n) return -1.0F; 
/* 218 */     if (paramInt == 0 || paramInt == this.n - 1) return 2.0F; 
/* 219 */     return 3.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void a(int paramInt1, int paramInt2, int paramInt3) {
/* 226 */     int i = paramInt2;
/* 227 */     int j = paramInt2 + this.n;
/*     */     
/* 229 */     while (i < j) {
/* 230 */       float f = b(i - paramInt2);
/* 231 */       a(paramInt1, i, paramInt3, f, (byte)1, apa.O.cz);
/* 232 */       i++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void a(int[] paramArrayOfint1, int[] paramArrayOfint2, int paramInt) {
/*     */     byte b5;
/* 243 */     int[] arrayOfInt1 = { 0, 0, 0 };
/*     */ 
/*     */     
/* 246 */     byte b1 = 0;
/* 247 */     byte b2 = 0;
/* 248 */     while (b1 < 3) {
/* 249 */       arrayOfInt1[b1] = paramArrayOfint2[b1] - paramArrayOfint1[b1];
/* 250 */       if (Math.abs(arrayOfInt1[b1]) > Math.abs(arrayOfInt1[b2])) {
/* 251 */         b2 = b1;
/*     */       }
/* 253 */       b1 = (byte)(b1 + 1);
/*     */     } 
/*     */     
/* 256 */     if (arrayOfInt1[b2] == 0)
/*     */       return; 
/* 258 */     byte b3 = a[b2];
/* 259 */     byte b4 = a[b2 + 3];
/*     */ 
/*     */ 
/*     */     
/* 263 */     if (arrayOfInt1[b2] > 0) { b5 = 1; }
/* 264 */     else { b5 = -1; }
/*     */     
/* 266 */     double d1 = arrayOfInt1[b3] / arrayOfInt1[b2];
/* 267 */     double d2 = arrayOfInt1[b4] / arrayOfInt1[b2];
/*     */     
/* 269 */     int[] arrayOfInt2 = { 0, 0, 0 };
/*     */ 
/*     */ 
/*     */     
/* 273 */     int i = 0;
/* 274 */     int j = arrayOfInt1[b2] + b5;
/* 275 */     while (i != j) {
/* 276 */       arrayOfInt2[b2] = kx.c((paramArrayOfint1[b2] + i) + 0.5D);
/* 277 */       arrayOfInt2[b3] = kx.c(paramArrayOfint1[b3] + i * d1 + 0.5D);
/* 278 */       arrayOfInt2[b4] = kx.c(paramArrayOfint1[b4] + i * d2 + 0.5D);
/*     */       
/* 280 */       byte b = 0;
/* 281 */       int k = Math.abs(arrayOfInt2[0] - paramArrayOfint1[0]);
/* 282 */       int m = Math.abs(arrayOfInt2[2] - paramArrayOfint1[2]);
/* 283 */       int n = Math.max(k, m);
/*     */       
/* 285 */       if (n > 0) {
/* 286 */         if (k == n) {
/* 287 */           b = 4;
/* 288 */         } else if (m == n) {
/* 289 */           b = 8;
/*     */         } 
/*     */       }
/*     */       
/* 293 */       a(this.c, arrayOfInt2[0], arrayOfInt2[1], arrayOfInt2[2], paramInt, b);
/* 294 */       i += b5;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void b() {
/* 302 */     byte b = 0;
/* 303 */     int i = this.o.length;
/* 304 */     while (b < i) {
/* 305 */       int j = this.o[b][0];
/* 306 */       int k = this.o[b][1];
/* 307 */       int m = this.o[b][2];
/* 308 */       a(j, k, m);
/* 309 */       b++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean c(int paramInt) {
/* 321 */     if (paramInt < this.e * 0.2D) return false; 
/* 322 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   void c() {
/* 327 */     int i = this.d[0];
/* 328 */     int j = this.d[1];
/* 329 */     int k = this.d[1] + this.f;
/* 330 */     int m = this.d[2];
/* 331 */     int[] arrayOfInt1 = { i, j, m };
/*     */ 
/*     */     
/* 334 */     int[] arrayOfInt2 = { i, k, m };
/*     */ 
/*     */     
/* 337 */     a(arrayOfInt1, arrayOfInt2, apa.N.cz);
/* 338 */     if (this.l == 2) {
/* 339 */       arrayOfInt1[0] = arrayOfInt1[0] + 1;
/* 340 */       arrayOfInt2[0] = arrayOfInt2[0] + 1;
/* 341 */       a(arrayOfInt1, arrayOfInt2, apa.N.cz);
/* 342 */       arrayOfInt1[2] = arrayOfInt1[2] + 1;
/* 343 */       arrayOfInt2[2] = arrayOfInt2[2] + 1;
/* 344 */       a(arrayOfInt1, arrayOfInt2, apa.N.cz);
/* 345 */       arrayOfInt1[0] = arrayOfInt1[0] + -1;
/* 346 */       arrayOfInt2[0] = arrayOfInt2[0] + -1;
/* 347 */       a(arrayOfInt1, arrayOfInt2, apa.N.cz);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   void d() {
/* 355 */     byte b = 0;
/* 356 */     int i = this.o.length;
/* 357 */     int[] arrayOfInt = { this.d[0], this.d[1], this.d[2] };
/*     */ 
/*     */     
/* 360 */     while (b < i) {
/* 361 */       int[] arrayOfInt1 = this.o[b];
/* 362 */       int[] arrayOfInt2 = { arrayOfInt1[0], arrayOfInt1[1], arrayOfInt1[2] };
/*     */ 
/*     */       
/* 365 */       arrayOfInt[1] = arrayOfInt1[3];
/* 366 */       int j = arrayOfInt[1] - this.d[1];
/* 367 */       if (c(j)) {
/* 368 */         a(arrayOfInt, arrayOfInt2, (byte)apa.N.cz);
/*     */       }
/* 370 */       b++;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   int a(int[] paramArrayOfint1, int[] paramArrayOfint2) {
/*     */     byte b5;
/* 383 */     int[] arrayOfInt1 = { 0, 0, 0 };
/*     */ 
/*     */     
/* 386 */     byte b1 = 0;
/* 387 */     byte b2 = 0;
/* 388 */     while (b1 < 3) {
/* 389 */       arrayOfInt1[b1] = paramArrayOfint2[b1] - paramArrayOfint1[b1];
/* 390 */       if (Math.abs(arrayOfInt1[b1]) > Math.abs(arrayOfInt1[b2])) {
/* 391 */         b2 = b1;
/*     */       }
/* 393 */       b1 = (byte)(b1 + 1);
/*     */     } 
/*     */     
/* 396 */     if (arrayOfInt1[b2] == 0) return -1;
/*     */     
/* 398 */     byte b3 = a[b2];
/* 399 */     byte b4 = a[b2 + 3];
/*     */ 
/*     */ 
/*     */     
/* 403 */     if (arrayOfInt1[b2] > 0) { b5 = 1; }
/* 404 */     else { b5 = -1; }
/*     */     
/* 406 */     double d1 = arrayOfInt1[b3] / arrayOfInt1[b2];
/* 407 */     double d2 = arrayOfInt1[b4] / arrayOfInt1[b2];
/*     */     
/* 409 */     int[] arrayOfInt2 = { 0, 0, 0 };
/*     */ 
/*     */ 
/*     */     
/* 413 */     int i = 0;
/* 414 */     int j = arrayOfInt1[b2] + b5;
/*     */     
/* 416 */     while (i != j) {
/* 417 */       arrayOfInt2[b2] = paramArrayOfint1[b2] + i;
/* 418 */       arrayOfInt2[b3] = kx.c(paramArrayOfint1[b3] + i * d1);
/* 419 */       arrayOfInt2[b4] = kx.c(paramArrayOfint1[b4] + i * d2);
/* 420 */       int k = this.c.a(arrayOfInt2[0], arrayOfInt2[1], arrayOfInt2[2]);
/* 421 */       if (k != 0 && k != apa.O.cz) {
/*     */         break;
/*     */       }
/*     */ 
/*     */       
/* 426 */       i += b5;
/*     */     } 
/*     */     
/* 429 */     if (i == j) {
/* 430 */       return -1;
/*     */     }
/*     */ 
/*     */     
/* 434 */     return Math.abs(i);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   boolean e() {
/* 447 */     int[] arrayOfInt1 = { this.d[0], this.d[1], this.d[2] };
/*     */ 
/*     */     
/* 450 */     int[] arrayOfInt2 = { this.d[0], this.d[1] + this.e - 1, this.d[2] };
/*     */ 
/*     */ 
/*     */     
/* 454 */     int i = this.c.a(this.d[0], this.d[1] - 1, this.d[2]);
/* 455 */     if (i != 2 && i != 3) {
/* 456 */       return false;
/*     */     }
/* 458 */     int j = a(arrayOfInt1, arrayOfInt2);
/*     */     
/* 460 */     if (j == -1) {
/* 461 */       return true;
/*     */     }
/*     */     
/* 464 */     if (j < 6) {
/* 465 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 470 */     this.e = j;
/* 471 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(double paramDouble1, double paramDouble2, double paramDouble3) {
/* 485 */     this.m = (int)(paramDouble1 * 12.0D);
/* 486 */     if (paramDouble1 > 0.5D) this.n = 5; 
/* 487 */     this.j = paramDouble2;
/* 488 */     this.k = paramDouble3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 502 */     this.c = paramaab;
/* 503 */     long l = paramRandom.nextLong();
/* 504 */     this.b.setSeed(l);
/*     */     
/* 506 */     this.d[0] = paramInt1;
/* 507 */     this.d[1] = paramInt2;
/* 508 */     this.d[2] = paramInt3;
/*     */     
/* 510 */     if (this.e == 0) {
/* 511 */       this.e = 5 + this.b.nextInt(this.m);
/*     */     }
/* 513 */     if (!e()) {
/* 514 */       return false;
/*     */     }
/* 516 */     a();
/* 517 */     b();
/* 518 */     c();
/* 519 */     d();
/* 520 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */