/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adm
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 11 */     for (byte b = 0; b < 64; b++) {
/* 12 */       int i = paramInt1 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 13 */       int j = paramInt2 + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 14 */       int k = paramInt3 + paramRandom.nextInt(8) - paramRandom.nextInt(8);
/* 15 */       if (paramaab.c(i, j, k) && 
/* 16 */         paramaab.a(i, j - 1, k) == apa.bf.cz) {
/* 17 */         paramaab.f(i, j, k, apa.av.cz, 0, 2);
/*    */       }
/*    */     } 
/* 20 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */