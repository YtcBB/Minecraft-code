/*    */ 
/*    */ public class aaa
/*    */ {
/*  4 */   private static int[] a = new int[65536];
/*    */   
/*    */   public static void a(int[] paramArrayOfint) {
/*  7 */     a = paramArrayOfint;
/*    */   }
/*    */   
/*    */   public static int a(double paramDouble1, double paramDouble2) {
/* 11 */     paramDouble2 *= paramDouble1;
/* 12 */     int i = (int)((1.0D - paramDouble1) * 255.0D);
/* 13 */     int j = (int)((1.0D - paramDouble2) * 255.0D);
/* 14 */     return a[j << 8 | i];
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aaa.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */