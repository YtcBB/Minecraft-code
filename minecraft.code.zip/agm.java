/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class agm
/*     */   extends agq
/*     */ {
/*     */   private final boolean a;
/*     */   private final agr b;
/*     */   
/*     */   public agm(int paramInt1, Random paramRandom, int paramInt2, int paramInt3) {
/* 401 */     super(paramInt1);
/*     */     
/* 403 */     this.a = true;
/* 404 */     this.f = paramRandom.nextInt(4);
/* 405 */     this.b = agr.a;
/*     */     
/* 407 */     switch (this.f) {
/*     */       case 0:
/*     */       case 2:
/* 410 */         this.e = new aek(paramInt2, 64, paramInt3, paramInt2 + 5 - 1, 74, paramInt3 + 5 - 1);
/*     */         return;
/*     */     } 
/* 413 */     this.e = new aek(paramInt2, 64, paramInt3, paramInt2 + 5 - 1, 74, paramInt3 + 5 - 1);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public agm(int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 419 */     super(paramInt1);
/*     */     
/* 421 */     this.a = false;
/* 422 */     this.f = paramInt2;
/* 423 */     this.b = a(paramRandom);
/* 424 */     this.e = paramaek;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/* 430 */     if (this.a)
/*     */     {
/* 432 */       afx.a(agd.class);
/*     */     }
/* 434 */     a((agn)paramagw, paramList, paramRandom, 1, 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public static agm a(List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 439 */     aek aek = aek.a(paramInt1, paramInt2, paramInt3, -1, -7, 0, 5, 11, 5, paramInt4);
/*     */     
/* 441 */     if (!a(aek) || agw.a(paramList, aek) != null) {
/* 442 */       return null;
/*     */     }
/*     */     
/* 445 */     return new agm(paramInt5, paramRandom, aek, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 450 */     if (a(paramaab, paramaek)) {
/* 451 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 455 */     a(paramaab, paramaek, 0, 0, 0, 4, 10, 4, true, paramRandom, afx.b());
/*     */     
/* 457 */     a(paramaab, paramRandom, paramaek, this.b, 1, 7, 0);
/*     */     
/* 459 */     a(paramaab, paramRandom, paramaek, agr.a, 1, 1, 4);
/*     */ 
/*     */     
/* 462 */     a(paramaab, apa.bq.cz, 0, 2, 6, 1, paramaek);
/* 463 */     a(paramaab, apa.bq.cz, 0, 1, 5, 1, paramaek);
/* 464 */     a(paramaab, apa.ao.cz, 0, 1, 6, 1, paramaek);
/* 465 */     a(paramaab, apa.bq.cz, 0, 1, 5, 2, paramaek);
/* 466 */     a(paramaab, apa.bq.cz, 0, 1, 4, 3, paramaek);
/* 467 */     a(paramaab, apa.ao.cz, 0, 1, 5, 3, paramaek);
/* 468 */     a(paramaab, apa.bq.cz, 0, 2, 4, 3, paramaek);
/* 469 */     a(paramaab, apa.bq.cz, 0, 3, 3, 3, paramaek);
/* 470 */     a(paramaab, apa.ao.cz, 0, 3, 4, 3, paramaek);
/* 471 */     a(paramaab, apa.bq.cz, 0, 3, 3, 2, paramaek);
/* 472 */     a(paramaab, apa.bq.cz, 0, 3, 2, 1, paramaek);
/* 473 */     a(paramaab, apa.ao.cz, 0, 3, 3, 1, paramaek);
/* 474 */     a(paramaab, apa.bq.cz, 0, 2, 2, 1, paramaek);
/* 475 */     a(paramaab, apa.bq.cz, 0, 1, 1, 1, paramaek);
/* 476 */     a(paramaab, apa.ao.cz, 0, 1, 2, 1, paramaek);
/* 477 */     a(paramaab, apa.bq.cz, 0, 1, 1, 2, paramaek);
/* 478 */     a(paramaab, apa.ao.cz, 0, 1, 1, 3, paramaek);
/*     */     
/* 480 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\agm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */