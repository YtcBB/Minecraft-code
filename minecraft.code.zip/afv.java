/*     */ import java.util.ArrayList;
/*     */ import java.util.Collections;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class afv
/*     */   extends ags
/*     */ {
/*  16 */   private aav[] e = new aav[] { aav.d, aav.f, aav.e, aav.h, aav.g, aav.n, aav.o, aav.s, aav.t, aav.v, aav.w, aav.x };
/*     */ 
/*     */   
/*     */   private boolean f;
/*     */ 
/*     */   
/*  22 */   private zu[] g = new zu[3];
/*  23 */   private double h = 32.0D;
/*  24 */   private int i = 3;
/*     */   
/*     */   public afv() {}
/*     */   
/*     */   public afv(Map paramMap) {
/*  29 */     for (Map.Entry entry : paramMap.entrySet()) {
/*  30 */       if (((String)entry.getKey()).equals("distance")) {
/*  31 */         this.h = kx.a((String)entry.getValue(), this.h, 1.0D); continue;
/*  32 */       }  if (((String)entry.getKey()).equals("count")) {
/*  33 */         this.g = new zu[kx.a((String)entry.getValue(), this.g.length, 1)]; continue;
/*  34 */       }  if (((String)entry.getKey()).equals("spread")) {
/*  35 */         this.i = kx.a((String)entry.getValue(), this.i, 1);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   protected boolean a(int paramInt1, int paramInt2) {
/*  42 */     if (!this.f) {
/*  43 */       Random random = new Random();
/*     */       
/*  45 */       random.setSeed(this.c.G());
/*     */       
/*  47 */       double d = random.nextDouble() * Math.PI * 2.0D;
/*  48 */       int i = 1;
/*     */       
/*  50 */       for (byte b = 0; b < this.g.length; b++) {
/*  51 */         double d1 = (1.25D * i + random.nextDouble()) * this.h * i;
/*  52 */         int j = (int)Math.round(Math.cos(d) * d1);
/*  53 */         int k = (int)Math.round(Math.sin(d) * d1);
/*     */         
/*  55 */         ArrayList<? super aav> arrayList = new ArrayList();
/*  56 */         Collections.addAll(arrayList, this.e);
/*     */         
/*  58 */         aat aat = this.c.u().a((j << 4) + 8, (k << 4) + 8, 112, arrayList, random);
/*  59 */         if (aat != null) {
/*  60 */           j = aat.a >> 4;
/*  61 */           k = aat.c >> 4;
/*     */         } 
/*     */         
/*  64 */         this.g[b] = new zu(j, k);
/*     */         
/*  66 */         d += 6.283185307179586D * i / this.i;
/*     */         
/*  68 */         if (b == this.i) {
/*  69 */           i += 2 + random.nextInt(5);
/*  70 */           this.i += 1 + random.nextInt(2);
/*     */         } 
/*     */       } 
/*     */       
/*  74 */       this.f = true;
/*     */     } 
/*  76 */     for (zu zu1 : this.g) {
/*  77 */       if (paramInt1 == zu1.a && paramInt2 == zu1.b) {
/*  78 */         return true;
/*     */       }
/*     */     } 
/*  81 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   protected List p_() {
/*  86 */     ArrayList<aat> arrayList = new ArrayList();
/*  87 */     for (zu zu1 : this.g) {
/*  88 */       if (zu1 != null) {
/*  89 */         arrayList.add(zu1.a(64));
/*     */       }
/*     */     } 
/*  92 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   protected agy b(int paramInt1, int paramInt2) {
/*  97 */     afw afw = new afw(this.c, this.b, paramInt1, paramInt2);
/*     */     
/*  99 */     while (afw.b().isEmpty() || ((agn)afw.b().get(0)).b == null)
/*     */     {
/* 101 */       afw = new afw(this.c, this.b, paramInt1, paramInt2);
/*     */     }
/*     */     
/* 104 */     return afw;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\afv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */