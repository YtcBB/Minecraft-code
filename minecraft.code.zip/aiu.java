/*    */ 
/*    */ 
/*    */ public class aiu
/*    */   extends ait
/*    */ {
/*    */   public aiu(long paramLong, ait paramait) {
/*  7 */     super(paramLong);
/*  8 */     this.a = paramait;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 13 */     int[] arrayOfInt1 = this.a.a(paramInt1 - 1, paramInt2 - 1, paramInt3 + 2, paramInt4 + 2);
/*    */     
/* 15 */     int[] arrayOfInt2 = air.a(paramInt3 * paramInt4);
/* 16 */     for (byte b = 0; b < paramInt4; b++) {
/* 17 */       for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 18 */         a((b1 + paramInt1), (b + paramInt2));
/* 19 */         int i = arrayOfInt1[b1 + 1 + (b + 1) * (paramInt3 + 2)];
/* 20 */         if (a(3) == 0) {
/* 21 */           int j = i;
/* 22 */           if (i == aav.d.N) {
/* 23 */             j = aav.s.N;
/* 24 */           } else if (i == aav.f.N) {
/* 25 */             j = aav.t.N;
/* 26 */           } else if (i == aav.g.N) {
/* 27 */             j = aav.u.N;
/* 28 */           } else if (i == aav.c.N) {
/* 29 */             j = aav.f.N;
/* 30 */           } else if (i == aav.n.N) {
/* 31 */             j = aav.o.N;
/* 32 */           } else if (i == aav.w.N) {
/* 33 */             j = aav.x.N;
/*    */           } 
/* 35 */           if (j == i) {
/* 36 */             arrayOfInt2[b1 + b * paramInt3] = i;
/*    */           } else {
/* 38 */             int k = arrayOfInt1[b1 + 1 + (b + 1 - 1) * (paramInt3 + 2)];
/* 39 */             int m = arrayOfInt1[b1 + 1 + 1 + (b + 1) * (paramInt3 + 2)];
/* 40 */             int n = arrayOfInt1[b1 + 1 - 1 + (b + 1) * (paramInt3 + 2)];
/* 41 */             int i1 = arrayOfInt1[b1 + 1 + (b + 1 + 1) * (paramInt3 + 2)];
/* 42 */             if (k == i && m == i && n == i && i1 == i) {
/* 43 */               arrayOfInt2[b1 + b * paramInt3] = j;
/*    */             } else {
/* 45 */               arrayOfInt2[b1 + b * paramInt3] = i;
/*    */             } 
/*    */           } 
/*    */         } else {
/* 49 */           arrayOfInt2[b1 + b * paramInt3] = i;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 54 */     return arrayOfInt2;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aiu.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */