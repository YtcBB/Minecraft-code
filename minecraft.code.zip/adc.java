/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class adc
/*    */   extends adj
/*    */ {
/*    */   public adc(boolean paramBoolean) {
/* 14 */     super(paramBoolean);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 19 */     int i = paramRandom.nextInt(3) + 5;
/*    */     
/* 21 */     boolean bool = true;
/* 22 */     if (paramInt2 < 1 || paramInt2 + i + 1 > 256) return false; 
/*    */     int j;
/* 24 */     for (j = paramInt2; j <= paramInt2 + 1 + i; j++) {
/* 25 */       byte b = 1;
/* 26 */       if (j == paramInt2) b = 0; 
/* 27 */       if (j >= paramInt2 + 1 + i - 2) b = 2; 
/* 28 */       for (int m = paramInt1 - b; m <= paramInt1 + b && bool; m++) {
/* 29 */         for (int n = paramInt3 - b; n <= paramInt3 + b && bool; n++) {
/* 30 */           if (j >= 0 && j < 256) {
/* 31 */             int i1 = paramaab.a(m, j, n);
/* 32 */             if (i1 != 0 && i1 != apa.O.cz) bool = false; 
/*    */           } else {
/* 34 */             bool = false;
/*    */           } 
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 40 */     if (!bool) return false;
/*    */     
/* 42 */     j = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/* 43 */     if ((j != apa.y.cz && j != apa.z.cz) || paramInt2 >= 256 - i - 1) return false;
/*    */     
/* 45 */     a(paramaab, paramInt1, paramInt2 - 1, paramInt3, apa.z.cz);
/*    */     int k;
/* 47 */     for (k = paramInt2 - 3 + i; k <= paramInt2 + i; k++) {
/* 48 */       int m = k - paramInt2 + i;
/* 49 */       int n = 1 - m / 2;
/* 50 */       for (int i1 = paramInt1 - n; i1 <= paramInt1 + n; i1++) {
/* 51 */         int i2 = i1 - paramInt1;
/* 52 */         for (int i3 = paramInt3 - n; i3 <= paramInt3 + n; i3++) {
/* 53 */           int i4 = i3 - paramInt3;
/* 54 */           if (Math.abs(i2) != n || Math.abs(i4) != n || (paramRandom.nextInt(2) != 0 && m != 0)) {
/* 55 */             int i5 = paramaab.a(i1, k, i3);
/* 56 */             if (i5 == 0 || i5 == apa.O.cz) a(paramaab, i1, k, i3, apa.O.cz, 2); 
/*    */           } 
/*    */         } 
/*    */       } 
/* 60 */     }  for (k = 0; k < i; k++) {
/* 61 */       int m = paramaab.a(paramInt1, paramInt2 + k, paramInt3);
/* 62 */       if (m == 0 || m == apa.O.cz) a(paramaab, paramInt1, paramInt2 + k, paramInt3, apa.N.cz, 2); 
/*    */     } 
/* 64 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */