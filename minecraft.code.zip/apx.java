/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apx
/*     */   extends aqp
/*     */   implements md
/*     */ {
/*  18 */   private static final int[] a = new int[] { 3 };
/*  19 */   private static final int[] b = new int[] { 0, 1, 2 };
/*     */   
/*  21 */   private wm[] c = new wm[4];
/*     */   
/*     */   private int d;
/*     */   private int e;
/*     */   private int f;
/*     */   private String g;
/*     */   
/*     */   public String b() {
/*  29 */     return c() ? this.g : "container.brewing";
/*     */   }
/*     */   
/*     */   public boolean c() {
/*  33 */     return (this.g != null && this.g.length() > 0);
/*     */   }
/*     */   
/*     */   public void a(String paramString) {
/*  37 */     this.g = paramString;
/*     */   }
/*     */   
/*     */   public int j_() {
/*  41 */     return this.c.length;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void h() {
/*  47 */     if (this.d > 0) {
/*  48 */       this.d--;
/*     */       
/*  50 */       if (this.d == 0) {
/*     */         
/*  52 */         u();
/*  53 */         k_();
/*  54 */       } else if (!l()) {
/*  55 */         this.d = 0;
/*  56 */         k_();
/*  57 */       } else if (this.f != (this.c[3]).c) {
/*  58 */         this.d = 0;
/*  59 */         k_();
/*     */       } 
/*  61 */     } else if (l()) {
/*  62 */       this.d = 400;
/*  63 */       this.f = (this.c[3]).c;
/*     */     } 
/*     */     
/*  66 */     int i = j();
/*  67 */     if (i != this.e) {
/*  68 */       this.e = i;
/*  69 */       this.k.b(this.l, this.m, this.n, i, 2);
/*     */     } 
/*     */     
/*  72 */     super.h();
/*     */   }
/*     */   
/*     */   public int x_() {
/*  76 */     return this.d;
/*     */   }
/*     */   
/*     */   private boolean l() {
/*  80 */     if (this.c[3] == null || (this.c[3]).a <= 0) {
/*  81 */       return false;
/*     */     }
/*  83 */     wm wm1 = this.c[3];
/*     */ 
/*     */     
/*  86 */     if (!wk.f[wm1.c].w()) {
/*  87 */       return false;
/*     */     }
/*     */     
/*  90 */     boolean bool = false;
/*  91 */     for (byte b = 0; b < 3; b++) {
/*  92 */       if (this.c[b] != null && (this.c[b]).c == wk.bt.cp) {
/*  93 */         int i = this.c[b].k();
/*  94 */         int j = c(i, wm1);
/*     */         
/*  96 */         if (!ww.f(i) && ww.f(j)) {
/*  97 */           bool = true;
/*     */           
/*     */           break;
/*     */         } 
/* 101 */         List list1 = wk.bt.c(i);
/* 102 */         List list2 = wk.bt.c(j);
/*     */         
/* 104 */         if ((i <= 0 || list1 != list2) && (list1 == null || (!list1.equals(list2) && list2 != null)) && 
/* 105 */           i != j) {
/* 106 */           bool = true;
/*     */           break;
/*     */         } 
/*     */       } 
/*     */     } 
/* 111 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void u() {
/* 139 */     if (!l()) {
/*     */       return;
/*     */     }
/*     */     
/* 143 */     wm wm1 = this.c[3];
/*     */ 
/*     */ 
/*     */     
/* 147 */     for (byte b = 0; b < 3; b++) {
/* 148 */       if (this.c[b] != null && (this.c[b]).c == wk.bt.cp) {
/* 149 */         int i = this.c[b].k();
/* 150 */         int j = c(i, wm1);
/*     */         
/* 152 */         List list1 = wk.bt.c(i);
/* 153 */         List list2 = wk.bt.c(j);
/*     */         
/* 155 */         if ((i > 0 && list1 == list2) || (list1 != null && (list1.equals(list2) || list2 == null))) {
/*     */           
/* 157 */           if (!ww.f(i) && ww.f(j)) {
/* 158 */             this.c[b].b(j);
/*     */           }
/*     */         }
/* 161 */         else if (i != j) {
/* 162 */           this.c[b].b(j);
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 183 */     if (wk.f[wm1.c].t()) {
/* 184 */       this.c[3] = new wm(wk.f[wm1.c].s());
/*     */     } else {
/* 186 */       (this.c[3]).a--;
/* 187 */       if ((this.c[3]).a <= 0) {
/* 188 */         this.c[3] = null;
/*     */       }
/*     */     } 
/*     */   }
/*     */   
/*     */   private int c(int paramInt, wm paramwm) {
/* 194 */     if (paramwm == null) {
/* 195 */       return paramInt;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 205 */     if (wk.f[paramwm.c].w()) {
/* 206 */       return xu.a(paramInt, wk.f[paramwm.c].v());
/*     */     }
/* 208 */     return paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(bs parambs) {
/* 214 */     super.a(parambs);
/*     */     
/* 216 */     ca ca = parambs.m("Items");
/* 217 */     this.c = new wm[j_()];
/* 218 */     for (byte b = 0; b < ca.c(); b++) {
/* 219 */       bs bs1 = (bs)ca.b(b);
/* 220 */       byte b1 = bs1.c("Slot");
/* 221 */       if (b1 >= 0 && b1 < this.c.length) this.c[b1] = wm.a(bs1);
/*     */     
/*     */     } 
/* 224 */     this.d = parambs.d("BrewTime");
/* 225 */     if (parambs.b("CustomName")) this.g = parambs.i("CustomName");
/*     */   
/*     */   }
/*     */   
/*     */   public void b(bs parambs) {
/* 230 */     super.b(parambs);
/*     */     
/* 232 */     parambs.a("BrewTime", (short)this.d);
/* 233 */     ca ca = new ca();
/*     */     
/* 235 */     for (byte b = 0; b < this.c.length; b++) {
/* 236 */       if (this.c[b] != null) {
/* 237 */         bs bs1 = new bs();
/* 238 */         bs1.a("Slot", (byte)b);
/* 239 */         this.c[b].b(bs1);
/* 240 */         ca.a(bs1);
/*     */       } 
/*     */     } 
/* 243 */     parambs.a("Items", ca);
/* 244 */     if (c()) parambs.a("CustomName", this.g); 
/*     */   }
/*     */   
/*     */   public wm a(int paramInt) {
/* 248 */     if (paramInt >= 0 && paramInt < this.c.length) {
/* 249 */       return this.c[paramInt];
/*     */     }
/* 251 */     return null;
/*     */   }
/*     */   
/*     */   public wm a(int paramInt1, int paramInt2) {
/* 255 */     if (paramInt1 >= 0 && paramInt1 < this.c.length) {
/* 256 */       wm wm1 = this.c[paramInt1];
/* 257 */       this.c[paramInt1] = null;
/* 258 */       return wm1;
/*     */     } 
/* 260 */     return null;
/*     */   }
/*     */   
/*     */   public wm b(int paramInt) {
/* 264 */     if (paramInt >= 0 && paramInt < this.c.length) {
/* 265 */       wm wm1 = this.c[paramInt];
/* 266 */       this.c[paramInt] = null;
/* 267 */       return wm1;
/*     */     } 
/* 269 */     return null;
/*     */   }
/*     */   
/*     */   public void a(int paramInt, wm paramwm) {
/* 273 */     if (paramInt >= 0 && paramInt < this.c.length) {
/* 274 */       this.c[paramInt] = paramwm;
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 280 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean a(sq paramsq) {
/* 284 */     if (this.k.r(this.l, this.m, this.n) != this) return false; 
/* 285 */     if (paramsq.e(this.l + 0.5D, this.m + 0.5D, this.n + 0.5D) > 64.0D) return false; 
/* 286 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void f() {}
/*     */ 
/*     */   
/*     */   public void g() {}
/*     */   
/*     */   public boolean b(int paramInt, wm paramwm) {
/* 296 */     if (paramInt == 3)
/*     */     {
/* 298 */       return wk.f[paramwm.c].w();
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 304 */     return (paramwm.c == wk.bt.cp || paramwm.c == wk.bu.cp);
/*     */   }
/*     */   
/*     */   public void d(int paramInt) {
/* 308 */     this.d = paramInt;
/*     */   }
/*     */   
/*     */   public int j() {
/* 312 */     int i = 0;
/* 313 */     for (byte b = 0; b < 3; b++) {
/* 314 */       if (this.c[b] != null) {
/* 315 */         i |= 1 << b;
/*     */       }
/*     */     } 
/* 318 */     return i;
/*     */   }
/*     */   
/*     */   public int[] c(int paramInt) {
/* 322 */     if (paramInt == 1) {
/* 323 */       return a;
/*     */     }
/*     */     
/* 326 */     return b;
/*     */   }
/*     */   
/*     */   public boolean a(int paramInt1, wm paramwm, int paramInt2) {
/* 330 */     return b(paramInt1, paramwm);
/*     */   }
/*     */   
/*     */   public boolean b(int paramInt1, wm paramwm, int paramInt2) {
/* 334 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apx.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */