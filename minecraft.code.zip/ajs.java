/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ajs
/*     */   extends ajv
/*     */ {
/*     */   private final ajv a;
/*     */   
/*     */   public ajs(ajv paramajv) {
/*  21 */     this.a = paramajv;
/*     */   }
/*     */ 
/*     */   
/*     */   public bs a() {
/*  26 */     return this.a.a();
/*     */   }
/*     */ 
/*     */   
/*     */   public bs a(bs parambs) {
/*  31 */     return this.a.a(parambs);
/*     */   }
/*     */ 
/*     */   
/*     */   public long b() {
/*  36 */     return this.a.b();
/*     */   }
/*     */ 
/*     */   
/*     */   public int c() {
/*  41 */     return this.a.c();
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  46 */     return this.a.d();
/*     */   }
/*     */ 
/*     */   
/*     */   public int e() {
/*  51 */     return this.a.e();
/*     */   }
/*     */ 
/*     */   
/*     */   public long f() {
/*  56 */     return this.a.f();
/*     */   }
/*     */ 
/*     */   
/*     */   public long g() {
/*  61 */     return this.a.g();
/*     */   }
/*     */ 
/*     */   
/*     */   public long h() {
/*  66 */     return this.a.h();
/*     */   }
/*     */ 
/*     */   
/*     */   public bs i() {
/*  71 */     return this.a.i();
/*     */   }
/*     */ 
/*     */   
/*     */   public int j() {
/*  76 */     return this.a.j();
/*     */   }
/*     */ 
/*     */   
/*     */   public String k() {
/*  81 */     return this.a.k();
/*     */   }
/*     */ 
/*     */   
/*     */   public int l() {
/*  86 */     return this.a.l();
/*     */   }
/*     */ 
/*     */   
/*     */   public long m() {
/*  91 */     return this.a.m();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean n() {
/*  96 */     return this.a.n();
/*     */   }
/*     */ 
/*     */   
/*     */   public int o() {
/* 101 */     return this.a.o();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean p() {
/* 106 */     return this.a.p();
/*     */   }
/*     */ 
/*     */   
/*     */   public int q() {
/* 111 */     return this.a.q();
/*     */   }
/*     */ 
/*     */   
/*     */   public aaj r() {
/* 116 */     return this.a.r();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void b(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void c(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void b(long paramLong) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void c(long paramLong) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(int paramInt1, int paramInt2, int paramInt3) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(String paramString) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void e(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(boolean paramBoolean) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void f(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void b(boolean paramBoolean) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void g(int paramInt) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean s() {
/* 170 */     return this.a.s();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean t() {
/* 177 */     return this.a.t();
/*     */   }
/*     */   
/*     */   public aal u() {
/* 181 */     return this.a.u();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aal paramaal) {}
/*     */   
/*     */   public boolean v() {
/* 188 */     return this.a.v();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean w() {
/* 195 */     return this.a.w();
/*     */   }
/*     */ 
/*     */   
/*     */   public void d(boolean paramBoolean) {}
/*     */ 
/*     */   
/*     */   public zy x() {
/* 203 */     return this.a.x();
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajs.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */