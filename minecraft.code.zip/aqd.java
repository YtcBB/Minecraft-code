/*   */ public class aqd
/*   */   extends aqc
/*   */ {
/*   */   public String b() {
/* 5 */     return c() ? this.a : "container.dropper";
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */