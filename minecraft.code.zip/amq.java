/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ public class amq
/*    */   extends amt
/*    */ {
/*    */   public amq(int paramInt) {
/*  9 */     super(paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 14 */     if (paramInt2 > 3) paramInt2 = 3; 
/* 15 */     if (paramRandom.nextInt(10 - paramInt2 * 3) == 0) return wk.aq.cp; 
/* 16 */     return this.cz;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */