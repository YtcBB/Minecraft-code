import java.util.List;
import java.util.Map;

public interface aa {
  int a(ab paramab, String paramString);
  
  List b(ab paramab, String paramString);
  
  List a(ab paramab);
  
  Map a();
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aa.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */