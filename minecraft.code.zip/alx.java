/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class alx
/*     */   extends alb
/*     */ {
/*     */   private lx[] b;
/*     */   
/*     */   public alx(int paramInt) {
/*  22 */     super(paramInt, true);
/*     */     
/*  24 */     b(true);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  29 */     return 20;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f() {
/*  34 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/*  39 */     if (paramaab.I) {
/*     */       return;
/*     */     }
/*     */     
/*  43 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  44 */     if ((i & 0x8) != 0) {
/*     */       return;
/*     */     }
/*     */     
/*  48 */     d(paramaab, paramInt1, paramInt2, paramInt3, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  53 */     if (paramaab.I)
/*     */       return; 
/*  55 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  56 */     if ((i & 0x8) == 0) {
/*     */       return;
/*     */     }
/*     */     
/*  60 */     d(paramaab, paramInt1, paramInt2, paramInt3, i);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  65 */     return ((paramaak.h(paramInt1, paramInt2, paramInt3) & 0x8) != 0) ? 15 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  70 */     if ((paramaak.h(paramInt1, paramInt2, paramInt3) & 0x8) == 0) return 0; 
/*  71 */     return (paramInt4 == 1) ? 15 : 0;
/*     */   }
/*     */   
/*     */   private void d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  75 */     boolean bool1 = ((paramInt4 & 0x8) != 0) ? true : false;
/*  76 */     boolean bool2 = false;
/*     */     
/*  78 */     float f = 0.125F;
/*  79 */     List list = paramaab.a(ri.class, aqx.a().a((paramInt1 + f), paramInt2, (paramInt3 + f), ((paramInt1 + 1) - f), ((paramInt2 + 1) - f), ((paramInt3 + 1) - f)));
/*  80 */     if (!list.isEmpty()) {
/*  81 */       bool2 = true;
/*     */     }
/*     */     
/*  84 */     if (bool2 && !bool1) {
/*  85 */       paramaab.b(paramInt1, paramInt2, paramInt3, paramInt4 | 0x8, 3);
/*  86 */       paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/*  87 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/*  88 */       paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/*  91 */     if (!bool2 && bool1) {
/*  92 */       paramaab.b(paramInt1, paramInt2, paramInt3, paramInt4 & 0x7, 3);
/*  93 */       paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/*  94 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/*  95 */       paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/*  98 */     if (bool2) {
/*  99 */       paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */     }
/*     */     
/* 102 */     paramaab.m(paramInt1, paramInt2, paramInt3, this.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 107 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/* 108 */     d(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean q_() {
/* 113 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 118 */     if ((paramaab.h(paramInt1, paramInt2, paramInt3) & 0x8) > 0) {
/* 119 */       float f = 0.125F;
/* 120 */       List<lt> list = paramaab.a(ri.class, aqx.a().a((paramInt1 + f), paramInt2, (paramInt3 + f), ((paramInt1 + 1) - f), ((paramInt2 + 1) - f), ((paramInt3 + 1) - f)), my.b);
/*     */       
/* 122 */       if (list.size() > 0) {
/* 123 */         return tj.b(list.get(0));
/*     */       }
/*     */     } 
/*     */     
/* 127 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 132 */     this.b = new lx[2];
/* 133 */     this.b[0] = paramly.a("detectorRail");
/* 134 */     this.b[1] = paramly.a("detectorRail_on");
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/* 139 */     if ((paramInt2 & 0x8) != 0) {
/* 140 */       return this.b[1];
/*     */     }
/* 142 */     return this.b[0];
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alx.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */