/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amm
/*     */   extends apa
/*     */ {
/*     */   public amm(int paramInt) {
/*  24 */     super(paramInt, aif.q);
/*  25 */     g();
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  30 */     float f1 = 0.375F;
/*  31 */     float f2 = f1 / 2.0F;
/*  32 */     a(0.5F - f2, 0.0F, 0.5F - f2, 0.5F + f2, f1, 0.5F + f2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  37 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  42 */     return 33;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  47 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  52 */     wm wm = paramsq.bK.h();
/*  53 */     if (wm == null) return false; 
/*  54 */     if (paramaab.h(paramInt1, paramInt2, paramInt3) != 0) return false; 
/*  55 */     int i = a(wm);
/*     */     
/*  57 */     if (i > 0) {
/*  58 */       paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*     */       
/*  60 */       if (!paramsq.ce.d && 
/*  61 */         --wm.a <= 0) {
/*  62 */         paramsq.bK.a(paramsq.bK.c, (wm)null);
/*     */       }
/*     */ 
/*     */       
/*  66 */       return true;
/*     */     } 
/*     */     
/*  69 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  74 */     wm wm = n_(paramaab.h(paramInt1, paramInt2, paramInt3));
/*     */     
/*  76 */     if (wm == null) {
/*  77 */       return wk.bK.cp;
/*     */     }
/*  79 */     return wm.c;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int h(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  85 */     wm wm = n_(paramaab.h(paramInt1, paramInt2, paramInt3));
/*     */     
/*  87 */     if (wm == null) {
/*  88 */       return wk.bK.cp;
/*     */     }
/*  90 */     return wm.k();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean t_() {
/*  96 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 101 */     return (super.c(paramaab, paramInt1, paramInt2, paramInt3) && paramaab.w(paramInt1, paramInt2 - 1, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 106 */     if (!paramaab.w(paramInt1, paramInt2 - 1, paramInt3)) {
/* 107 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/*     */       
/* 109 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 115 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramFloat, paramInt5);
/*     */     
/* 117 */     if (paramInt4 > 0) {
/* 118 */       wm wm = n_(paramInt4);
/* 119 */       if (wm != null) b(paramaab, paramInt1, paramInt2, paramInt3, wm);
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 125 */     return wk.bK.cp;
/*     */   }
/*     */   
/*     */   public static wm n_(int paramInt) {
/* 129 */     switch (paramInt) {
/*     */       case 1:
/* 131 */         return new wm(apa.ai);
/*     */       case 2:
/* 133 */         return new wm(apa.ah);
/*     */       case 9:
/* 135 */         return new wm(apa.aZ);
/*     */       case 8:
/* 137 */         return new wm(apa.aj);
/*     */       case 7:
/* 139 */         return new wm(apa.ak);
/*     */       case 10:
/* 141 */         return new wm(apa.ac);
/*     */       case 3:
/* 143 */         return new wm(apa.C, 1, 0);
/*     */       case 5:
/* 145 */         return new wm(apa.C, 1, 2);
/*     */       case 4:
/* 147 */         return new wm(apa.C, 1, 1);
/*     */       case 6:
/* 149 */         return new wm(apa.C, 1, 3);
/*     */       case 11:
/* 151 */         return new wm(apa.ab, 1, 2);
/*     */     } 
/*     */     
/* 154 */     return null;
/*     */   }
/*     */   
/*     */   public static int a(wm paramwm) {
/* 158 */     int i = (paramwm.b()).cp;
/*     */     
/* 160 */     if (i == apa.ai.cz) return 1; 
/* 161 */     if (i == apa.ah.cz) return 2; 
/* 162 */     if (i == apa.aZ.cz) return 9; 
/* 163 */     if (i == apa.aj.cz) return 8; 
/* 164 */     if (i == apa.ak.cz) return 7; 
/* 165 */     if (i == apa.ac.cz) return 10;
/*     */     
/* 167 */     if (i == apa.C.cz) {
/* 168 */       switch (paramwm.k()) {
/*     */         case 0:
/* 170 */           return 3;
/*     */         case 2:
/* 172 */           return 5;
/*     */         case 1:
/* 174 */           return 4;
/*     */         case 3:
/* 176 */           return 6;
/*     */       } 
/*     */     
/*     */     }
/* 180 */     if (i == apa.ab.cz) {
/* 181 */       switch (paramwm.k()) {
/*     */         case 2:
/* 183 */           return 11;
/*     */       } 
/*     */     
/*     */     }
/* 187 */     return 0;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */