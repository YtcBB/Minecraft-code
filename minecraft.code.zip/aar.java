/*    */ 
/*    */ 
/*    */ public class aar
/*    */   implements Comparable
/*    */ {
/*  6 */   private static long g = 0L;
/*    */   public int a;
/*    */   public int b;
/*    */   public int c;
/* 10 */   private long h = g++; public int d; public long e; public int f;
/*    */   
/*    */   public aar(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 13 */     this.a = paramInt1;
/* 14 */     this.b = paramInt2;
/* 15 */     this.c = paramInt3;
/* 16 */     this.d = paramInt4;
/*    */   }
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 20 */     if (paramObject instanceof aar) {
/* 21 */       aar aar1 = (aar)paramObject;
/* 22 */       return (this.a == aar1.a && this.b == aar1.b && this.c == aar1.c && apa.b(this.d, aar1.d));
/*    */     } 
/* 24 */     return false;
/*    */   }
/*    */   
/*    */   public int hashCode() {
/* 28 */     return (this.a * 1024 * 1024 + this.c * 1024 + this.b) * 256;
/*    */   }
/*    */   
/*    */   public aar a(long paramLong) {
/* 32 */     this.e = paramLong;
/* 33 */     return this;
/*    */   }
/*    */   
/*    */   public void a(int paramInt) {
/* 37 */     this.f = paramInt;
/*    */   }
/*    */   
/*    */   public int a(aar paramaar) {
/* 41 */     if (this.e < paramaar.e) return -1; 
/* 42 */     if (this.e > paramaar.e) return 1; 
/* 43 */     if (this.f != paramaar.f) return this.f - paramaar.f; 
/* 44 */     if (this.h < paramaar.h) return -1; 
/* 45 */     if (this.h > paramaar.h) return 1; 
/* 46 */     return 0;
/*    */   }
/*    */   
/*    */   public String toString() {
/* 50 */     return this.d + ": (" + this.a + ", " + this.b + ", " + this.c + "), " + this.e + ", " + this.f + ", " + this.h;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aar.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */