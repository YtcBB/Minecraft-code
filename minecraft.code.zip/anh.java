/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class anh
/*    */   extends apa
/*    */ {
/*    */   protected anh(int paramInt) {
/* 11 */     super(paramInt, aif.d);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 16 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 21 */     paramaab.i(paramInt1, paramInt2, paramInt3);
/*    */   }
/*    */   
/*    */   public void a(ly paramly) {}
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anh.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */