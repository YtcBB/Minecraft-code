/*    */ import java.util.List;
/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ai
/*    */   extends x
/*    */ {
/*    */   public String c() {
/* 15 */     return "gamemode";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 20 */     return 2;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public String a(ab paramab) {
/* 26 */     return paramab.a("commands.gamemode.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 30 */     if (paramArrayOfString.length > 0) {
/* 31 */       aaj aaj = e(paramab, paramArrayOfString[0]);
/* 32 */       jc jc = (paramArrayOfString.length >= 2) ? c(paramab, paramArrayOfString[1]) : c(paramab);
/*    */       
/* 34 */       jc.a(aaj);
/* 35 */       jc.T = 0.0F;
/*    */       
/* 37 */       String str = bo.a("gameMode." + aaj.b());
/*    */       
/* 39 */       if (jc != paramab) {
/* 40 */         a(paramab, 1, "commands.gamemode.success.other", new Object[] { jc.am(), str });
/*    */       } else {
/* 42 */         a(paramab, 1, "commands.gamemode.success.self", new Object[] { str });
/*    */       } 
/*    */       
/*    */       return;
/*    */     } 
/*    */     
/* 48 */     throw new ax("commands.gamemode.usage", new Object[0]);
/*    */   }
/*    */   
/*    */   protected aaj e(ab paramab, String paramString) {
/* 52 */     if (paramString.equalsIgnoreCase(aaj.b.b()) || paramString.equalsIgnoreCase("s"))
/* 53 */       return aaj.b; 
/* 54 */     if (paramString.equalsIgnoreCase(aaj.c.b()) || paramString.equalsIgnoreCase("c"))
/* 55 */       return aaj.c; 
/* 56 */     if (paramString.equalsIgnoreCase(aaj.d.b()) || paramString.equalsIgnoreCase("a")) {
/* 57 */       return aaj.d;
/*    */     }
/* 59 */     return aai.a(a(paramab, paramString, 0, (aaj.values()).length - 2));
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public List a(ab paramab, String[] paramArrayOfString) {
/* 65 */     if (paramArrayOfString.length == 1)
/* 66 */       return a(paramArrayOfString, new String[] { "survival", "creative", "adventure" }); 
/* 67 */     if (paramArrayOfString.length == 2) {
/* 68 */       return a(paramArrayOfString, d());
/*    */     }
/*    */     
/* 71 */     return null;
/*    */   }
/*    */   
/*    */   protected String[] d() {
/* 75 */     return MinecraftServer.D().A();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(String[] paramArrayOfString, int paramInt) {
/* 80 */     return (paramInt == 1);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ai.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */