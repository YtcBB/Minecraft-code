/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apn
/*     */   extends apa
/*     */ {
/*     */   public apn(int paramInt) {
/*  21 */     super(paramInt, aif.l);
/*  22 */     b(true);
/*  23 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  28 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  33 */     return 20;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  38 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  43 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  51 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  53 */     float f1 = 1.0F;
/*  54 */     float f2 = 1.0F;
/*  55 */     float f3 = 1.0F;
/*  56 */     float f4 = 0.0F;
/*  57 */     float f5 = 0.0F;
/*  58 */     float f6 = 0.0F;
/*  59 */     boolean bool = (i > 0) ? true : false;
/*     */     
/*  61 */     if ((i & 0x2) != 0) {
/*  62 */       f4 = Math.max(f4, 0.0625F);
/*  63 */       f1 = 0.0F;
/*  64 */       f2 = 0.0F;
/*  65 */       f5 = 1.0F;
/*  66 */       f3 = 0.0F;
/*  67 */       f6 = 1.0F;
/*  68 */       bool = true;
/*     */     } 
/*  70 */     if ((i & 0x8) != 0) {
/*  71 */       f1 = Math.min(f1, 0.9375F);
/*  72 */       f4 = 1.0F;
/*  73 */       f2 = 0.0F;
/*  74 */       f5 = 1.0F;
/*  75 */       f3 = 0.0F;
/*  76 */       f6 = 1.0F;
/*  77 */       bool = true;
/*     */     } 
/*  79 */     if ((i & 0x4) != 0) {
/*  80 */       f6 = Math.max(f6, 0.0625F);
/*  81 */       f3 = 0.0F;
/*  82 */       f1 = 0.0F;
/*  83 */       f4 = 1.0F;
/*  84 */       f2 = 0.0F;
/*  85 */       f5 = 1.0F;
/*  86 */       bool = true;
/*     */     } 
/*  88 */     if ((i & 0x1) != 0) {
/*  89 */       f3 = Math.min(f3, 0.9375F);
/*  90 */       f6 = 1.0F;
/*  91 */       f1 = 0.0F;
/*  92 */       f4 = 1.0F;
/*  93 */       f2 = 0.0F;
/*  94 */       f5 = 1.0F;
/*  95 */       bool = true;
/*     */     } 
/*  97 */     if (!bool && d(paramaak.a(paramInt1, paramInt2 + 1, paramInt3))) {
/*  98 */       f2 = Math.min(f2, 0.9375F);
/*  99 */       f5 = 1.0F;
/* 100 */       f1 = 0.0F;
/* 101 */       f4 = 1.0F;
/* 102 */       f3 = 0.0F;
/* 103 */       f6 = 1.0F;
/*     */     } 
/* 105 */     a(f1, f2, f3, f4, f5, f6);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 110 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 115 */     switch (paramInt4)
/*     */     { default:
/* 117 */         return false;
/*     */       case 1:
/* 119 */         return d(paramaab.a(paramInt1, paramInt2 + 1, paramInt3));
/*     */       case 2:
/* 121 */         return d(paramaab.a(paramInt1, paramInt2, paramInt3 + 1));
/*     */       case 3:
/* 123 */         return d(paramaab.a(paramInt1, paramInt2, paramInt3 - 1));
/*     */       case 5:
/* 125 */         return d(paramaab.a(paramInt1 - 1, paramInt2, paramInt3));
/*     */       case 4:
/* 127 */         break; }  return d(paramaab.a(paramInt1 + 1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean d(int paramInt) {
/* 132 */     if (paramInt == 0) return false; 
/* 133 */     apa apa1 = apa.r[paramInt];
/* 134 */     if (apa1.b() && apa1.cO.c()) return true; 
/* 135 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   private boolean k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 140 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 141 */     int j = i;
/*     */     
/* 143 */     if (j > 0) {
/* 144 */       for (byte b = 0; b <= 3; b++) {
/* 145 */         int k = 1 << b;
/* 146 */         if ((i & k) != 0 && 
/* 147 */           !d(paramaab.a(paramInt1 + r.a[b], paramInt2, paramInt3 + r.b[b])))
/*     */         {
/*     */           
/* 150 */           if (paramaab.a(paramInt1, paramInt2 + 1, paramInt3) != this.cz || (paramaab.h(paramInt1, paramInt2 + 1, paramInt3) & k) == 0) {
/* 151 */             j &= k ^ 0xFFFFFFFF;
/*     */           }
/*     */         }
/*     */       } 
/*     */     }
/*     */ 
/*     */     
/* 158 */     if (j == 0)
/*     */     {
/* 160 */       if (!d(paramaab.a(paramInt1, paramInt2 + 1, paramInt3))) {
/* 161 */         return false;
/*     */       }
/*     */     }
/* 164 */     if (j != i) {
/* 165 */       paramaab.b(paramInt1, paramInt2, paramInt3, j, 2);
/*     */     }
/* 167 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int o() {
/* 173 */     return zx.c();
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(int paramInt) {
/* 178 */     return zx.c();
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 183 */     return paramaak.a(paramInt1, paramInt3).l();
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 188 */     if (!paramaab.I && !k(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 189 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 190 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 196 */     if (!paramaab.I && 
/* 197 */       paramaab.s.nextInt(4) == 0) {
/* 198 */       byte b1 = 4;
/* 199 */       byte b2 = 5;
/* 200 */       boolean bool = false; int i;
/* 201 */       label86: for (i = paramInt1 - b1; i <= paramInt1 + b1; i++) {
/* 202 */         for (int m = paramInt3 - b1; m <= paramInt3 + b1; m++) {
/* 203 */           for (int n = paramInt2 - 1; n <= paramInt2 + 1; n++) {
/* 204 */             if (paramaab.a(i, n, m) == this.cz && --b2 <= 0) {
/* 205 */               bool = true; break label86;
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       } 
/* 210 */       i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 211 */       int j = paramaab.s.nextInt(6);
/* 212 */       int k = r.e[j];
/*     */       
/* 214 */       if (j == 1 && paramInt2 < 255 && paramaab.c(paramInt1, paramInt2 + 1, paramInt3)) {
/* 215 */         if (bool)
/*     */           return; 
/* 217 */         int m = paramaab.s.nextInt(16) & i;
/* 218 */         if (m > 0) {
/* 219 */           for (byte b = 0; b <= 3; b++) {
/* 220 */             if (!d(paramaab.a(paramInt1 + r.a[b], paramInt2 + 1, paramInt3 + r.b[b]))) {
/* 221 */               m &= 1 << b ^ 0xFFFFFFFF;
/*     */             }
/*     */           } 
/* 224 */           if (m > 0) {
/* 225 */             paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz, m, 2);
/*     */           }
/*     */         } 
/* 228 */       } else if (j >= 2 && j <= 5 && (i & 1 << k) == 0) {
/* 229 */         if (bool)
/*     */           return; 
/* 231 */         int m = paramaab.a(paramInt1 + r.a[k], paramInt2, paramInt3 + r.b[k]);
/*     */         
/* 233 */         if (m == 0 || apa.r[m] == null) {
/*     */ 
/*     */           
/* 236 */           int n = k + 1 & 0x3;
/* 237 */           int i1 = k + 3 & 0x3;
/*     */ 
/*     */           
/* 240 */           if ((i & 1 << n) != 0 && d(paramaab.a(paramInt1 + r.a[k] + r.a[n], paramInt2, paramInt3 + r.b[k] + r.b[n]))) {
/*     */             
/* 242 */             paramaab.f(paramInt1 + r.a[k], paramInt2, paramInt3 + r.b[k], this.cz, 1 << n, 2);
/* 243 */           } else if ((i & 1 << i1) != 0 && d(paramaab.a(paramInt1 + r.a[k] + r.a[i1], paramInt2, paramInt3 + r.b[k] + r.b[i1]))) {
/*     */             
/* 245 */             paramaab.f(paramInt1 + r.a[k], paramInt2, paramInt3 + r.b[k], this.cz, 1 << i1, 2);
/*     */ 
/*     */           
/*     */           }
/* 249 */           else if ((i & 1 << n) != 0 && paramaab.c(paramInt1 + r.a[k] + r.a[n], paramInt2, paramInt3 + r.b[k] + r.b[n]) && d(paramaab.a(paramInt1 + r.a[n], paramInt2, paramInt3 + r.b[n]))) {
/*     */ 
/*     */             
/* 252 */             paramaab.f(paramInt1 + r.a[k] + r.a[n], paramInt2, paramInt3 + r.b[k] + r.b[n], this.cz, 1 << (k + 2 & 0x3), 2);
/*     */           }
/* 254 */           else if ((i & 1 << i1) != 0 && paramaab.c(paramInt1 + r.a[k] + r.a[i1], paramInt2, paramInt3 + r.b[k] + r.b[i1]) && d(paramaab.a(paramInt1 + r.a[i1], paramInt2, paramInt3 + r.b[i1]))) {
/*     */ 
/*     */             
/* 257 */             paramaab.f(paramInt1 + r.a[k] + r.a[i1], paramInt2, paramInt3 + r.b[k] + r.b[i1], this.cz, 1 << (k + 2 & 0x3), 2);
/*     */ 
/*     */           
/*     */           }
/* 261 */           else if (d(paramaab.a(paramInt1 + r.a[k], paramInt2 + 1, paramInt3 + r.b[k]))) {
/* 262 */             paramaab.f(paramInt1 + r.a[k], paramInt2, paramInt3 + r.b[k], this.cz, 0, 2);
/*     */           }
/*     */         
/* 265 */         } else if ((apa.r[m]).cO.k() && apa.r[m].b()) {
/*     */           
/* 267 */           paramaab.b(paramInt1, paramInt2, paramInt3, i | 1 << k, 2);
/*     */         
/*     */         }
/*     */       
/*     */       }
/* 272 */       else if (paramInt2 > 1) {
/* 273 */         int m = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/*     */         
/* 275 */         if (m == 0) {
/* 276 */           int n = paramaab.s.nextInt(16) & i;
/* 277 */           if (n > 0) {
/* 278 */             paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz, n, 2);
/*     */           }
/* 280 */         } else if (m == this.cz) {
/* 281 */           int n = paramaab.s.nextInt(16) & i;
/* 282 */           int i1 = paramaab.h(paramInt1, paramInt2 - 1, paramInt3);
/* 283 */           if (i1 != (i1 | n)) {
/* 284 */             paramaab.b(paramInt1, paramInt2 - 1, paramInt3, i1 | n, 2);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/* 295 */     byte b = 0;
/* 296 */     switch (paramInt4) {
/*     */       case 2:
/* 298 */         b = 1;
/*     */         break;
/*     */       case 3:
/* 301 */         b = 4;
/*     */         break;
/*     */       case 4:
/* 304 */         b = 8;
/*     */         break;
/*     */       case 5:
/* 307 */         b = 2;
/*     */         break;
/*     */     } 
/* 310 */     if (b != 0) {
/* 311 */       return b;
/*     */     }
/* 313 */     return paramInt5;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 319 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/* 324 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 329 */     if (!paramaab.I && paramsq.cd() != null && (paramsq.cd()).c == wk.bf.cp) {
/* 330 */       paramsq.a(kf.C[this.cz], 1);
/*     */ 
/*     */       
/* 333 */       b(paramaab, paramInt1, paramInt2, paramInt3, new wm(apa.by, 1, 0));
/*     */     } else {
/* 335 */       super.a(paramaab, paramsq, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apn.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */