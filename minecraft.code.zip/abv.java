/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class abv
/*     */   extends abw
/*     */ {
/*     */   public abv(aab paramaab, int paramInt1, int paramInt2) {
/*  13 */     super(paramaab, paramInt1, paramInt2);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2) {
/*  18 */     return (paramInt1 == this.g && paramInt2 == this.h);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(int paramInt1, int paramInt2) {
/*  23 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void b() {}
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, int paramInt2, int paramInt3) {
/*  36 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(int paramInt1, int paramInt2, int paramInt3) {
/*  41 */     return 255;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  46 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int c(int paramInt1, int paramInt2, int paramInt3) {
/*  56 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  61 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aam paramaam, int paramInt1, int paramInt2, int paramInt3) {
/*  66 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aam paramaam, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */ 
/*     */   
/*     */   public int c(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  75 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(mp parammp) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void b(mp parammp) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(mp parammp, int paramInt) {}
/*     */ 
/*     */   
/*     */   public boolean d(int paramInt1, int paramInt2, int paramInt3) {
/*  92 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public aqp e(int paramInt1, int paramInt2, int paramInt3) {
/*  97 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aqp paramaqp) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(int paramInt1, int paramInt2, int paramInt3, aqp paramaqp) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void f(int paramInt1, int paramInt2, int paramInt3) {}
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void c() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void d() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void e() {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(mp parammp, aqx paramaqx, List paramList, my parammy) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(Class paramClass, aqx paramaqx, List paramList, my parammy) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(boolean paramBoolean) {
/* 139 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Random a(long paramLong) {
/* 165 */     return new Random(this.e.G() + (this.g * this.g * 4987142) + (this.g * 5947611) + (this.h * this.h) * 4392871L + (this.h * 389711) ^ paramLong);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean g() {
/* 170 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(int paramInt1, int paramInt2) {
/* 175 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */