/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ajm
/*     */ {
/*     */   public final sq a;
/*  32 */   public int[] b = new int[128];
/*  33 */   public int[] c = new int[128];
/*  34 */   private int f = 0;
/*  35 */   private int g = 0;
/*     */   private byte[] h;
/*     */   public int d;
/*     */   private boolean i = false;
/*     */   
/*     */   public ajm(ajl paramajl, sq paramsq) {
/*  41 */     this.a = paramsq;
/*  42 */     for (byte b = 0; b < this.b.length; b++) {
/*  43 */       this.b[b] = 0;
/*  44 */       this.c[b] = 127;
/*     */     } 
/*     */   }
/*     */   
/*     */   public byte[] a(wm paramwm) {
/*  49 */     if (!this.i) {
/*  50 */       byte[] arrayOfByte = new byte[2];
/*  51 */       arrayOfByte[0] = 2;
/*  52 */       arrayOfByte[1] = this.e.d;
/*     */       
/*  54 */       this.i = true;
/*  55 */       return arrayOfByte;
/*     */     } 
/*     */     
/*  58 */     if (--this.g < 0) {
/*  59 */       this.g = 4;
/*     */       
/*  61 */       byte[] arrayOfByte = new byte[this.e.g.size() * 3 + 1];
/*  62 */       arrayOfByte[0] = 1;
/*  63 */       byte b1 = 0;
/*  64 */       for (ajn ajn : this.e.g.values()) {
/*  65 */         arrayOfByte[b1 * 3 + 1] = (byte)(ajn.a << 4 | ajn.d & 0xF);
/*  66 */         arrayOfByte[b1 * 3 + 2] = ajn.b;
/*  67 */         arrayOfByte[b1 * 3 + 3] = ajn.c;
/*  68 */         b1++;
/*     */       } 
/*  70 */       boolean bool = !paramwm.z() ? true : false;
/*  71 */       if (this.h == null || this.h.length != arrayOfByte.length) {
/*  72 */         bool = false;
/*     */       } else {
/*  74 */         for (byte b2 = 0; b2 < arrayOfByte.length; b2++) {
/*  75 */           if (arrayOfByte[b2] != this.h[b2]) {
/*  76 */             bool = false;
/*     */             
/*     */             break;
/*     */           } 
/*     */         } 
/*     */       } 
/*  82 */       if (!bool) {
/*  83 */         this.h = arrayOfByte;
/*  84 */         return arrayOfByte;
/*     */       } 
/*     */     } 
/*  87 */     for (byte b = 0; b < 1; b++) {
/*  88 */       int i = this.f++ * 11 % 128;
/*     */       
/*  90 */       if (this.b[i] >= 0) {
/*  91 */         int j = this.c[i] - this.b[i] + 1;
/*  92 */         int k = this.b[i];
/*     */         
/*  94 */         byte[] arrayOfByte = new byte[j + 3];
/*  95 */         arrayOfByte[0] = 0;
/*  96 */         arrayOfByte[1] = (byte)i;
/*  97 */         arrayOfByte[2] = (byte)k;
/*  98 */         for (byte b1 = 0; b1 < arrayOfByte.length - 3; b1++) {
/*  99 */           arrayOfByte[b1 + 3] = this.e.e[(b1 + k) * 128 + i];
/*     */         }
/* 101 */         this.c[i] = -1;
/* 102 */         this.b[i] = -1;
/* 103 */         return arrayOfByte;
/*     */       } 
/*     */     } 
/* 106 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */