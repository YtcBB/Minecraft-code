/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class apt
/*    */   extends amr
/*    */ {
/* 11 */   public static final String[] b = new String[] { "oak", "spruce", "birch", "jungle" };
/*    */ 
/*    */ 
/*    */   
/*    */   public apt(int paramInt, boolean paramBoolean) {
/* 16 */     super(paramInt, paramBoolean, aif.d);
/* 17 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 22 */     return apa.B.a(paramInt1, paramInt2 & 0x7);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 27 */     return apa.bS.cz;
/*    */   }
/*    */ 
/*    */   
/*    */   protected wm c_(int paramInt) {
/* 32 */     return new wm(apa.bS.cz, 2, paramInt & 0x7);
/*    */   }
/*    */ 
/*    */   
/*    */   public String c(int paramInt) {
/* 37 */     if (paramInt < 0 || paramInt >= b.length) {
/* 38 */       paramInt = 0;
/*    */     }
/* 40 */     return a() + "." + b[paramInt];
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 45 */     if (paramInt == apa.bR.cz)
/*    */       return; 
/* 47 */     for (byte b = 0; b < 4; b++)
/* 48 */       paramList.add(new wm(paramInt, 1, b)); 
/*    */   }
/*    */   
/*    */   public void a(ly paramly) {}
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */