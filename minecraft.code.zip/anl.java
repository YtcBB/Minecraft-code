/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class anl
/*    */   extends alh
/*    */ {
/*    */   private final String a;
/*    */   
/*    */   protected anl(int paramInt, String paramString) {
/* 13 */     super(paramInt);
/* 14 */     this.a = paramString;
/* 15 */     float f = 0.2F;
/* 16 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, f * 2.0F, 0.5F + f);
/* 17 */     b(true);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 22 */     if (paramRandom.nextInt(25) == 0) {
/* 23 */       byte b1 = 4;
/* 24 */       byte b2 = 5; int i;
/* 25 */       for (i = paramInt1 - b1; i <= paramInt1 + b1; i++) {
/* 26 */         for (int m = paramInt3 - b1; m <= paramInt3 + b1; m++) {
/* 27 */           for (int n = paramInt2 - 1; n <= paramInt2 + 1; n++)
/* 28 */           { if (paramaab.a(i, n, m) == this.cz && --b2 <= 0)
/*    */               return;  } 
/*    */         } 
/* 31 */       }  i = paramInt1 + paramRandom.nextInt(3) - 1;
/* 32 */       int j = paramInt2 + paramRandom.nextInt(2) - paramRandom.nextInt(2);
/* 33 */       int k = paramInt3 + paramRandom.nextInt(3) - 1;
/* 34 */       for (byte b3 = 0; b3 < 4; b3++) {
/* 35 */         if (paramaab.c(i, j, k) && f(paramaab, i, j, k)) {
/* 36 */           paramInt1 = i;
/* 37 */           paramInt2 = j;
/* 38 */           paramInt3 = k;
/*    */         } 
/* 40 */         i = paramInt1 + paramRandom.nextInt(3) - 1;
/* 41 */         j = paramInt2 + paramRandom.nextInt(2) - paramRandom.nextInt(2);
/* 42 */         k = paramInt3 + paramRandom.nextInt(3) - 1;
/*    */       } 
/*    */       
/* 45 */       if (paramaab.c(i, j, k) && f(paramaab, i, j, k)) {
/* 46 */         paramaab.c(i, j, k, this.cz);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 53 */     return (super.c(paramaab, paramInt1, paramInt2, paramInt3) && f(paramaab, paramInt1, paramInt2, paramInt3));
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean f_(int paramInt) {
/* 58 */     return apa.s[paramInt];
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 63 */     if (paramInt2 < 0 || paramInt2 >= 256) return false;
/*    */     
/* 65 */     int i = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/*    */     
/* 67 */     return (i == apa.bC.cz || (paramaab.m(paramInt1, paramInt2, paramInt3) < 13 && f_(i)));
/*    */   }
/*    */   
/*    */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 71 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*    */     
/* 73 */     paramaab.i(paramInt1, paramInt2, paramInt3);
/* 74 */     adq adq = null;
/*    */     
/* 76 */     if (this.cz == apa.aj.cz) {
/* 77 */       adq = new adq(0);
/* 78 */     } else if (this.cz == apa.ak.cz) {
/* 79 */       adq = new adq(1);
/*    */     } 
/*    */     
/* 82 */     if (adq == null || !adq.a(paramaab, paramRandom, paramInt1, paramInt2, paramInt3)) {
/* 83 */       paramaab.f(paramInt1, paramInt2, paramInt3, this.cz, i, 3);
/* 84 */       return false;
/*    */     } 
/* 86 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 91 */     this.cQ = paramly.a(this.a);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anl.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */