/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aea
/*    */   extends adj
/*    */ {
/*    */   private int a;
/*    */   
/*    */   public aea(int paramInt) {
/* 14 */     this.a = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 19 */     if (!paramaab.c(paramInt1, paramInt2, paramInt3) || paramaab.a(paramInt1, paramInt2 - 1, paramInt3) != this.a) {
/* 20 */       return false;
/*    */     }
/* 22 */     int i = paramRandom.nextInt(32) + 6;
/* 23 */     int j = paramRandom.nextInt(4) + 1; int k;
/* 24 */     for (k = paramInt1 - j; k <= paramInt1 + j; k++) {
/* 25 */       for (int m = paramInt3 - j; m <= paramInt3 + j; m++) {
/* 26 */         int n = k - paramInt1;
/* 27 */         int i1 = m - paramInt3;
/* 28 */         if (n * n + i1 * i1 <= j * j + 1 && 
/* 29 */           paramaab.a(k, paramInt2 - 1, m) != this.a) return false; 
/*    */       } 
/*    */     } 
/* 32 */     for (k = paramInt2; k < paramInt2 + i && 
/* 33 */       k < 128; k++) {
/* 34 */       for (int m = paramInt1 - j; m <= paramInt1 + j; m++) {
/* 35 */         for (int n = paramInt3 - j; n <= paramInt3 + j; n++) {
/* 36 */           int i1 = m - paramInt1;
/* 37 */           int i2 = n - paramInt3;
/* 38 */           if (i1 * i1 + i2 * i2 <= j * j + 1) {
/* 39 */             paramaab.f(m, k, n, apa.at.cz, 0, 2);
/*    */           }
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 45 */     qy qy = new qy(paramaab);
/* 46 */     qy.b((paramInt1 + 0.5F), (paramInt2 + i), (paramInt3 + 0.5F), paramRandom.nextFloat() * 360.0F, 0.0F);
/* 47 */     paramaab.d(qy);
/* 48 */     paramaab.f(paramInt1, paramInt2 + i, paramInt3, apa.D.cz, 0, 2);
/*    */     
/* 50 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aea.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */