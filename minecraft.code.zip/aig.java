/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class aig
/*    */   extends aif
/*    */ {
/*    */   aig(aih paramaih) {
/* 34 */     super(paramaih);
/*    */   }
/*    */   public boolean c() {
/* 37 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */