/*    */ 
/*    */ 
/*    */ 
/*    */ public class abq
/*    */   extends aaz
/*    */ {
/*    */   protected adj L;
/*    */   
/*    */   public abq(aav paramaav) {
/* 10 */     super(paramaav);
/*    */ 
/*    */     
/* 13 */     this.L = new aea(apa.bN.cz);
/*    */   }
/*    */   
/*    */   protected void a() {
/* 17 */     b();
/*    */     
/* 19 */     if (this.b.nextInt(5) == 0) {
/* 20 */       int i = this.c + this.b.nextInt(16) + 8;
/* 21 */       int j = this.d + this.b.nextInt(16) + 8;
/* 22 */       int k = this.a.i(i, j);
/* 23 */       if (k > 0);
/*    */       
/* 25 */       this.L.a(this.a, this.b, i, k, j);
/*    */     } 
/*    */     
/* 28 */     if (this.c == 0 && this.d == 0) {
/* 29 */       qz qz = new qz(this.a);
/* 30 */       qz.b(0.0D, 128.0D, 0.0D, this.b.nextFloat() * 360.0F, 0.0F);
/* 31 */       this.a.d(qz);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */