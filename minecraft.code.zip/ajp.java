/*    */ import java.io.File;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ajp
/*    */   extends ajt
/*    */ {
/*    */   public ajp(File paramFile, String paramString, boolean paramBoolean) {
/* 16 */     super(paramFile, paramString, paramBoolean);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public acb a(acn paramacn) {
/* 22 */     File file = b();
/*    */     
/* 24 */     if (paramacn instanceof aco) {
/* 25 */       File file1 = new File(file, "DIM-1");
/* 26 */       file1.mkdirs();
/* 27 */       return new acj(file1);
/*    */     } 
/* 29 */     if (paramacn instanceof acq) {
/* 30 */       File file1 = new File(file, "DIM1");
/* 31 */       file1.mkdirs();
/* 32 */       return new acj(file1);
/*    */     } 
/*    */     
/* 35 */     return new acj(file);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ajv paramajv, bs parambs) {
/* 40 */     paramajv.e(19133);
/* 41 */     super.a(paramajv, parambs);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a() {
/*    */     try {
/* 47 */       akv.a.a();
/* 48 */     } catch (InterruptedException interruptedException) {
/* 49 */       interruptedException.printStackTrace();
/*    */     } 
/*    */     
/* 52 */     aci.a();
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajp.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */