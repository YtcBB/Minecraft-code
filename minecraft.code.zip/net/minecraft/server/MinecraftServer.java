/*      */ package net.minecraft.server;
/*      */ import aa;
/*      */ import aab;
/*      */ import aaf;
/*      */ import aag;
/*      */ import aai;
/*      */ import aaj;
/*      */ import aal;
/*      */ import ab;
/*      */ import ajv;
/*      */ import akf;
/*      */ import aki;
/*      */ import aqx;
/*      */ import b;
/*      */ import ei;
/*      */ import fh;
/*      */ import gu;
/*      */ import hs;
/*      */ import iq;
/*      */ import is;
/*      */ import iv;
/*      */ import iz;
/*      */ import java.awt.GraphicsEnvironment;
/*      */ import java.io.File;
/*      */ import java.security.KeyPair;
/*      */ import java.util.ArrayList;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Callable;
/*      */ import jk;
/*      */ import jn;
/*      */ import kx;
/*      */ import la;
/*      */ import ma;
/*      */ import mc;
/*      */ import t;
/*      */ import u;
/*      */ 
/*      */ public abstract class MinecraftServer implements ab, Runnable, mc {
/*   39 */   private static MinecraftServer k = null;
/*      */   
/*      */   private final aki l;
/*      */   
/*   43 */   private final ma m = new ma("server", this);
/*      */   
/*      */   private final File n;
/*   46 */   private final List o = new ArrayList();
/*      */   private final aa p;
/*   48 */   public final la a = new la();
/*      */   
/*      */   private String q;
/*   51 */   private int r = -1;
/*      */   public iz[] b;
/*      */   private gu s;
/*      */   private boolean t = true;
/*      */   private boolean u = false;
/*   56 */   private int v = 0;
/*      */   
/*      */   public String c;
/*      */   
/*      */   public int d;
/*      */   private boolean w;
/*      */   private boolean x;
/*      */   private boolean y;
/*      */   private boolean z;
/*      */   private boolean A;
/*      */   private String B;
/*      */   private int C;
/*      */   private long D;
/*      */   private long E;
/*      */   private long F;
/*      */   private long G;
/*   72 */   public final long[] e = new long[100];
/*   73 */   public final long[] f = new long[100];
/*   74 */   public final long[] g = new long[100];
/*   75 */   public final long[] h = new long[100];
/*   76 */   public final long[] i = new long[100];
/*      */   
/*      */   public long[][] j;
/*      */   private KeyPair H;
/*      */   private String I;
/*      */   private String J;
/*      */   private String K;
/*      */   private boolean L;
/*      */   private boolean M;
/*      */   private boolean N;
/*   86 */   private String O = "";
/*      */   private boolean P = false;
/*      */   private long Q;
/*      */   private String R;
/*      */   private boolean S;
/*      */   private boolean T = false;
/*      */   
/*      */   public MinecraftServer(File paramFile) {
/*   94 */     k = this;
/*   95 */     this.n = paramFile;
/*   96 */     this.p = (aa)new hs();
/*   97 */     this.l = (aki)new ajq(paramFile);
/*      */     
/*   99 */     an();
/*      */   }
/*      */   
/*      */   private void an() {
/*  103 */     fx.a();
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   protected void b(String paramString) {
/*  109 */     if (N().b(paramString)) {
/*  110 */       al().a("Converting map!");
/*  111 */       c("menu.convertingLevel");
/*  112 */       N().a(paramString, (lc)new gn(this));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected synchronized void c(String paramString) {
/*  138 */     this.R = paramString;
/*      */   }
/*      */   
/*      */   public synchronized String d() {
/*  142 */     return this.R;
/*      */   }
/*      */   protected void a(String paramString1, String paramString2, long paramLong, aal paramaal, String paramString3) {
/*      */     aai aai;
/*  146 */     b(paramString1);
/*  147 */     c("menu.loadingLevel");
/*      */     
/*  149 */     this.b = new iz[3];
/*  150 */     this.j = new long[this.b.length][100];
/*      */     
/*  152 */     akf akf = this.l.a(paramString1, true);
/*      */ 
/*      */     
/*  155 */     ajv ajv = akf.d();
/*  156 */     if (ajv == null) {
/*  157 */       aai = new aai(paramLong, g(), f(), i(), paramaal);
/*  158 */       aai.a(paramString3);
/*      */     } else {
/*  160 */       aai = new aai(ajv);
/*      */     } 
/*  162 */     if (this.M) {
/*  163 */       aai.a();
/*      */     }
/*      */     
/*  166 */     for (byte b = 0; b < this.b.length; b++) {
/*      */ 
/*      */       
/*  169 */       byte b1 = 0;
/*  170 */       if (b == 1) b1 = -1; 
/*  171 */       if (b == 2) b1 = 1;
/*      */       
/*  173 */       if (b == 0) {
/*  174 */         if (M()) {
/*  175 */           this.b[b] = (iz)new iq(this, akf, paramString2, b1, this.a, al());
/*      */         } else {
/*  177 */           this.b[b] = new iz(this, akf, paramString2, b1, aai, this.a, al());
/*      */         } 
/*      */       } else {
/*  180 */         this.b[b] = (iz)new is(this, akf, paramString2, b1, aai, this.b[0], this.a, al());
/*      */       } 
/*      */       
/*  183 */       this.b[b].a((aag)new iv(this, this.b[b]));
/*      */       
/*  185 */       if (!I()) {
/*  186 */         this.b[b].M().a(g());
/*      */       }
/*      */       
/*  189 */       this.s.a(this.b);
/*      */     } 
/*      */     
/*  192 */     c(h());
/*      */     
/*  194 */     e();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void e() {
/*  204 */     byte b = 0;
/*      */     
/*  206 */     c("menu.generatingTerrain");
/*      */     
/*  208 */     boolean bool = false;
/*  209 */     al().a("Preparing start region for level " + bool);
/*  210 */     iz iz1 = this.b[bool];
/*  211 */     t t = iz1.J();
/*      */     
/*  213 */     long l = System.currentTimeMillis();
/*  214 */     for (short s = -192; s <= 192 && m(); s += 16) {
/*  215 */       for (short s1 = -192; s1 <= 192 && m(); s1 += 16) {
/*      */         
/*  217 */         long l1 = System.currentTimeMillis();
/*  218 */         if (l1 - l > 1000L) {
/*  219 */           a_("Preparing spawn area", b * 100 / 625);
/*  220 */           l = l1;
/*      */         } 
/*  222 */         b++;
/*      */         
/*  224 */         iz1.b.c(t.a + s >> 4, t.c + s1 >> 4);
/*      */       } 
/*      */     } 
/*      */     
/*  228 */     j();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void a_(String paramString, int paramInt) {
/*  240 */     this.c = paramString;
/*  241 */     this.d = paramInt;
/*  242 */     al().a(paramString + ": " + paramInt + "%");
/*      */   }
/*      */   
/*      */   protected void j() {
/*  246 */     this.c = null;
/*  247 */     this.d = 0;
/*      */   }
/*      */   
/*      */   protected void a(boolean paramBoolean) {
/*  251 */     if (this.N)
/*  252 */       return;  for (iz iz1 : this.b) {
/*  253 */       if (iz1 != null) {
/*  254 */         if (!paramBoolean) al().a("Saving chunks for level '" + iz1.M().k() + "'/" + iz1.t.l()); 
/*      */         try {
/*  256 */           iz1.a(true, null);
/*  257 */         } catch (aaf aaf) {
/*  258 */           al().b(aaf.getMessage());
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   public void k() {
/*  265 */     if (this.N)
/*  266 */       return;  al().a("Stopping server");
/*  267 */     if (ae() != null) {
/*  268 */       ae().a();
/*      */     }
/*  270 */     if (this.s != null) {
/*  271 */       al().a("Saving players");
/*  272 */       this.s.g();
/*  273 */       this.s.r();
/*      */     } 
/*  275 */     al().a("Saving worlds");
/*  276 */     a(false);
/*  277 */     for (byte b = 0; b < this.b.length; b++) {
/*  278 */       iz iz1 = this.b[b];
/*  279 */       iz1.n();
/*      */     } 
/*      */ 
/*      */     
/*  283 */     if (this.m != null && this.m.d()) {
/*  284 */       this.m.e();
/*      */     }
/*      */   }
/*      */   
/*      */   public String l() {
/*  289 */     return this.q;
/*      */   }
/*      */   
/*      */   public void d(String paramString) {
/*  293 */     this.q = paramString;
/*      */   }
/*      */   
/*      */   public boolean m() {
/*  297 */     return this.t;
/*      */   }
/*      */   
/*      */   public void n() {
/*  301 */     this.t = false;
/*      */   }
/*      */   
/*      */   public void run() {
/*      */     try {
/*  306 */       if (c()) {
/*  307 */         long l1 = System.currentTimeMillis();
/*  308 */         long l2 = 0L;
/*      */         
/*  310 */         while (this.t) {
/*  311 */           long l3 = System.currentTimeMillis();
/*  312 */           long l4 = l3 - l1;
/*  313 */           if (l4 > 2000L && l1 - this.Q >= 15000L) {
/*  314 */             al().b("Can't keep up! Did the system time change, or is the server overloaded?");
/*  315 */             l4 = 2000L;
/*  316 */             this.Q = l1;
/*      */           } 
/*  318 */           if (l4 < 0L) {
/*  319 */             al().b("Time ran backwards! Did the system time change?");
/*  320 */             l4 = 0L;
/*      */           } 
/*  322 */           l2 += l4;
/*  323 */           l1 = l3;
/*      */           
/*  325 */           if (this.b[0].e()) {
/*  326 */             q();
/*  327 */             l2 = 0L;
/*      */           } else {
/*  329 */             while (l2 > 50L) {
/*  330 */               l2 -= 50L;
/*  331 */               q();
/*      */             } 
/*      */           } 
/*      */           
/*  335 */           Thread.sleep(1L);
/*  336 */           this.P = true;
/*      */         } 
/*      */       } else {
/*  339 */         a((b)null);
/*      */       } 
/*  341 */     } catch (Throwable throwable) {
/*  342 */       throwable.printStackTrace();
/*  343 */       al().c("Encountered an unexpected exception " + throwable.getClass().getSimpleName(), throwable);
/*      */       
/*  345 */       b b = null;
/*      */       
/*  347 */       if (throwable instanceof u) {
/*  348 */         b = b(((u)throwable).a());
/*      */       } else {
/*  350 */         b = b(new b("Exception in server tick loop", throwable));
/*      */       } 
/*      */       
/*  353 */       File file = new File(new File(o(), "crash-reports"), "crash-" + (new SimpleDateFormat("yyyy-MM-dd_HH.mm.ss")).format(new Date()) + "-server.txt");
/*      */       
/*  355 */       if (b.a(file, al())) {
/*  356 */         al().c("This crash report has been saved to: " + file.getAbsolutePath());
/*      */       } else {
/*  358 */         al().c("We were unable to save this crash report to disk.");
/*      */       } 
/*      */       
/*  361 */       a(b);
/*      */     } finally {
/*      */       try {
/*  364 */         k();
/*  365 */         this.u = true;
/*  366 */       } catch (Throwable throwable) {
/*  367 */         throwable.printStackTrace();
/*      */       } finally {
/*  369 */         p();
/*      */       } 
/*      */     } 
/*      */   }
/*      */   
/*      */   protected File o() {
/*  375 */     return new File(".");
/*      */   }
/*      */ 
/*      */   
/*      */   protected void a(b paramb) {}
/*      */ 
/*      */   
/*      */   protected void p() {}
/*      */   
/*      */   public void q() {
/*  385 */     long l = System.nanoTime();
/*      */     
/*  387 */     aqx.a().a();
/*  388 */     this.v++;
/*      */     
/*  390 */     if (this.S) {
/*  391 */       this.S = false;
/*  392 */       this.a.a = true;
/*  393 */       this.a.a();
/*      */     } 
/*      */     
/*  396 */     this.a.a("root");
/*  397 */     r();
/*      */     
/*  399 */     if (this.v % 900 == 0) {
/*  400 */       this.a.a("save");
/*  401 */       this.s.g();
/*  402 */       a(true);
/*  403 */       this.a.b();
/*      */     } 
/*      */     
/*  406 */     this.a.a("tallying");
/*  407 */     this.i[this.v % 100] = System.nanoTime() - l;
/*      */     
/*  409 */     this.e[this.v % 100] = ei.q - this.D;
/*  410 */     this.D = ei.q;
/*  411 */     this.f[this.v % 100] = ei.r - this.E;
/*  412 */     this.E = ei.r;
/*  413 */     this.g[this.v % 100] = ei.o - this.F;
/*  414 */     this.F = ei.o;
/*  415 */     this.h[this.v % 100] = ei.p - this.G;
/*  416 */     this.G = ei.p;
/*  417 */     this.a.b();
/*      */     
/*  419 */     this.a.a("snooper");
/*  420 */     if (!this.m.d() && this.v > 100) {
/*  421 */       this.m.a();
/*      */     }
/*      */     
/*  424 */     if (this.v % 6000 == 0) {
/*  425 */       this.m.b();
/*      */     }
/*  427 */     this.a.b();
/*      */     
/*  429 */     this.a.b();
/*      */   }
/*      */   
/*      */   public void r() {
/*  433 */     this.a.a("levels");
/*      */     byte b;
/*  435 */     for (b = 0; b < this.b.length; b++) {
/*  436 */       long l = System.nanoTime();
/*      */       
/*  438 */       if (b == 0 || s()) {
/*  439 */         iz iz1 = this.b[b];
/*  440 */         this.a.a(iz1.M().k());
/*      */         
/*  442 */         this.a.a("pools");
/*  443 */         iz1.U().a();
/*  444 */         this.a.b();
/*      */         
/*  446 */         if (this.v % 20 == 0) {
/*  447 */           this.a.a("timeSync");
/*  448 */           this.s.a((ei)new fh(iz1.H(), iz1.I()), iz1.t.h);
/*  449 */           this.a.b();
/*      */         } 
/*      */         
/*  452 */         this.a.a("tick");
/*      */         try {
/*  454 */           iz1.b();
/*  455 */         } catch (Throwable throwable) {
/*  456 */           b b1 = b.a(throwable, "Exception ticking world");
/*  457 */           iz1.a(b1);
/*  458 */           throw new u(b1);
/*      */         } 
/*      */         
/*      */         try {
/*  462 */           iz1.h();
/*  463 */         } catch (Throwable throwable) {
/*  464 */           b b1 = b.a(throwable, "Exception ticking world entities");
/*  465 */           iz1.a(b1);
/*  466 */           throw new u(b1);
/*      */         } 
/*  468 */         this.a.b();
/*  469 */         this.a.a("tracker");
/*  470 */         iz1.q().a();
/*  471 */         this.a.b();
/*      */         
/*  473 */         this.a.b();
/*      */       } 
/*      */       
/*  476 */       this.j[b][this.v % 100] = System.nanoTime() - l;
/*      */     } 
/*      */     
/*  479 */     this.a.c("connection");
/*  480 */     ae().b();
/*  481 */     this.a.c("players");
/*  482 */     this.s.b();
/*      */     
/*  484 */     this.a.c("tickables");
/*  485 */     for (b = 0; b < this.o.size(); b++) {
/*  486 */       ((gy)this.o.get(b)).a();
/*      */     }
/*  488 */     this.a.b();
/*      */   }
/*      */   
/*      */   public boolean s() {
/*  492 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void t() {
/*  570 */     (new gp(this, "Server thread")).start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public File e(String paramString) {
/*  579 */     return new File(o(), paramString);
/*      */   }
/*      */   
/*      */   public void f(String paramString) {
/*  583 */     al().a(paramString);
/*      */   }
/*      */   
/*      */   public void g(String paramString) {
/*  587 */     al().b(paramString);
/*      */   }
/*      */   
/*      */   public iz a(int paramInt) {
/*  591 */     if (paramInt == -1) return this.b[1]; 
/*  592 */     if (paramInt == 1) return this.b[2]; 
/*  593 */     return this.b[0];
/*      */   }
/*      */   
/*      */   public String u() {
/*  597 */     return this.q;
/*      */   }
/*      */   
/*      */   public int v() {
/*  601 */     return this.r;
/*      */   }
/*      */   
/*      */   public String w() {
/*  605 */     return this.B;
/*      */   }
/*      */   
/*      */   public String x() {
/*  609 */     return "1.5.2";
/*      */   }
/*      */   
/*      */   public int y() {
/*  613 */     return this.s.k();
/*      */   }
/*      */   
/*      */   public int z() {
/*  617 */     return this.s.l();
/*      */   }
/*      */   
/*      */   public String[] A() {
/*  621 */     return this.s.d();
/*      */   }
/*      */   
/*      */   public String B() {
/*  625 */     return "";
/*      */   }
/*      */   
/*      */   public String h(String paramString) {
/*  629 */     jn.a.c();
/*  630 */     this.p.a((ab)jn.a, paramString);
/*  631 */     return jn.a.d();
/*      */   }
/*      */   
/*      */   public boolean C() {
/*  635 */     return false;
/*      */   }
/*      */   
/*      */   public void i(String paramString) {
/*  639 */     al().c(paramString);
/*      */   }
/*      */   
/*      */   public void j(String paramString) {
/*  643 */     if (C()) {
/*  644 */       al().a(paramString);
/*      */     }
/*      */   }
/*      */   
/*      */   public String getServerModName() {
/*  649 */     return "vanilla";
/*      */   }
/*      */   
/*      */   public b b(b paramb) {
/*  653 */     paramb.g().a("Profiler Position", (Callable)new gq(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  659 */     if (this.b != null && this.b.length > 0 && this.b[0] != null) {
/*  660 */       paramb.g().a("Vec3 Pool Size", (Callable)new gr(this));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  674 */     if (this.s != null) {
/*  675 */       paramb.g().a("Player Count", (Callable)new gs(this));
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  682 */     return paramb;
/*      */   }
/*      */   
/*      */   public List a(ab paramab, String paramString) {
/*  686 */     ArrayList<String> arrayList = new ArrayList();
/*      */     
/*  688 */     if (paramString.startsWith("/")) {
/*  689 */       paramString = paramString.substring(1);
/*  690 */       boolean bool = !paramString.contains(" ") ? true : false;
/*      */       
/*  692 */       List list = this.p.b(paramab, paramString);
/*      */       
/*  694 */       if (list != null) {
/*  695 */         for (String str1 : list) {
/*  696 */           if (bool) {
/*  697 */             arrayList.add("/" + str1); continue;
/*      */           } 
/*  699 */           arrayList.add(str1);
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  704 */       return arrayList;
/*      */     } 
/*  706 */     String[] arrayOfString = paramString.split(" ", -1);
/*  707 */     String str = arrayOfString[arrayOfString.length - 1];
/*      */     
/*  709 */     for (String str1 : this.s.d()) {
/*  710 */       if (x.a(str, str1)) {
/*  711 */         arrayList.add(str1);
/*      */       }
/*      */     } 
/*      */ 
/*      */     
/*  716 */     return arrayList;
/*      */   }
/*      */   
/*      */   public static MinecraftServer D() {
/*  720 */     return k;
/*      */   }
/*      */   
/*      */   public String c_() {
/*  724 */     return "Server";
/*      */   }
/*      */   
/*      */   public void a(String paramString) {
/*  728 */     al().a(lf.a(paramString));
/*      */   }
/*      */   
/*      */   public boolean a(int paramInt, String paramString) {
/*  732 */     return true;
/*      */   }
/*      */   
/*      */   public String a(String paramString, Object... paramVarArgs) {
/*  736 */     return bp.a().a(paramString, paramVarArgs);
/*      */   }
/*      */   
/*      */   public aa E() {
/*  740 */     return this.p;
/*      */   }
/*      */   
/*      */   public KeyPair F() {
/*  744 */     return this.H;
/*      */   }
/*      */   
/*      */   public int G() {
/*  748 */     return this.r;
/*      */   }
/*      */   
/*      */   public void b(int paramInt) {
/*  752 */     this.r = paramInt;
/*      */   }
/*      */   
/*      */   public String H() {
/*  756 */     return this.I;
/*      */   }
/*      */   
/*      */   public void k(String paramString) {
/*  760 */     this.I = paramString;
/*      */   }
/*      */   
/*      */   public boolean I() {
/*  764 */     return (this.I != null);
/*      */   }
/*      */   
/*      */   public String J() {
/*  768 */     return this.J;
/*      */   }
/*      */   
/*      */   public void l(String paramString) {
/*  772 */     this.J = paramString;
/*      */   }
/*      */   
/*      */   public void m(String paramString) {
/*  776 */     this.K = paramString;
/*      */   }
/*      */   
/*      */   public String K() {
/*  780 */     return this.K;
/*      */   }
/*      */   
/*      */   public void a(KeyPair paramKeyPair) {
/*  784 */     this.H = paramKeyPair;
/*      */   }
/*      */   
/*      */   public void c(int paramInt) {
/*  788 */     for (byte b = 0; b < this.b.length; b++) {
/*  789 */       iz iz1 = this.b[b];
/*      */       
/*  791 */       if (iz1 != null) {
/*  792 */         if (iz1.M().t()) {
/*  793 */           ((aab)iz1).r = 3;
/*  794 */           iz1.a(true, true);
/*  795 */         } else if (I()) {
/*  796 */           ((aab)iz1).r = paramInt;
/*  797 */           iz1.a((((aab)iz1).r > 0), true);
/*      */         } else {
/*  799 */           ((aab)iz1).r = paramInt;
/*  800 */           iz1.a(L(), this.x);
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */   
/*      */   protected boolean L() {
/*  807 */     return true;
/*      */   }
/*      */   
/*      */   public boolean M() {
/*  811 */     return this.L;
/*      */   }
/*      */   
/*      */   public void b(boolean paramBoolean) {
/*  815 */     this.L = paramBoolean;
/*      */   }
/*      */   
/*      */   public void c(boolean paramBoolean) {
/*  819 */     this.M = paramBoolean;
/*      */   }
/*      */   
/*      */   public aki N() {
/*  823 */     return this.l;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void P() {
/*  831 */     this.N = true;
/*      */     
/*  833 */     N().d();
/*      */     
/*  835 */     for (byte b = 0; b < this.b.length; b++) {
/*  836 */       iz iz1 = this.b[b];
/*      */       
/*  838 */       if (iz1 != null) {
/*  839 */         iz1.n();
/*      */       }
/*      */     } 
/*      */     
/*  843 */     N().e(this.b[0].L().g());
/*  844 */     n();
/*      */   }
/*      */   
/*      */   public String Q() {
/*  848 */     return this.O;
/*      */   }
/*      */   
/*      */   public void n(String paramString) {
/*  852 */     this.O = paramString;
/*      */   }
/*      */   
/*      */   public void a(ma paramma) {
/*  856 */     paramma.a("whitelist_enabled", Boolean.valueOf(false));
/*  857 */     paramma.a("whitelist_count", Integer.valueOf(0));
/*  858 */     paramma.a("players_current", Integer.valueOf(y()));
/*  859 */     paramma.a("players_max", Integer.valueOf(z()));
/*  860 */     paramma.a("players_seen", Integer.valueOf((this.s.m()).length));
/*  861 */     paramma.a("uses_auth", Boolean.valueOf(this.w));
/*  862 */     paramma.a("gui_state", ag() ? "enabled" : "disabled");
/*      */     
/*  864 */     paramma.a("avg_tick_ms", Integer.valueOf((int)(kx.a(this.i) * 1.0E-6D)));
/*  865 */     paramma.a("avg_sent_packet_count", Integer.valueOf((int)kx.a(this.e)));
/*  866 */     paramma.a("avg_sent_packet_size", Integer.valueOf((int)kx.a(this.f)));
/*  867 */     paramma.a("avg_rec_packet_count", Integer.valueOf((int)kx.a(this.g)));
/*  868 */     paramma.a("avg_rec_packet_size", Integer.valueOf((int)kx.a(this.h)));
/*      */     
/*  870 */     byte b1 = 0;
/*  871 */     for (byte b2 = 0; b2 < this.b.length; b2++) {
/*  872 */       if (this.b[b2] != null) {
/*  873 */         iz iz1 = this.b[b2];
/*  874 */         ajv ajv = iz1.M();
/*      */         
/*  876 */         paramma.a("world[" + b1 + "][dimension]", Integer.valueOf(iz1.t.h));
/*  877 */         paramma.a("world[" + b1 + "][mode]", ajv.r());
/*  878 */         paramma.a("world[" + b1 + "][difficulty]", Integer.valueOf(iz1.r));
/*  879 */         paramma.a("world[" + b1 + "][hardcore]", Boolean.valueOf(ajv.t()));
/*  880 */         paramma.a("world[" + b1 + "][generator_name]", ajv.u().a());
/*  881 */         paramma.a("world[" + b1 + "][generator_version]", Integer.valueOf(ajv.u().c()));
/*  882 */         paramma.a("world[" + b1 + "][height]", Integer.valueOf(this.C));
/*  883 */         paramma.a("world[" + b1 + "][chunks_loaded]", Integer.valueOf(iz1.K().f()));
/*      */         
/*  885 */         b1++;
/*      */       } 
/*      */     } 
/*      */     
/*  889 */     paramma.a("worlds", Integer.valueOf(b1));
/*      */   }
/*      */   
/*      */   public void b(ma paramma) {
/*  893 */     paramma.a("singleplayer", Boolean.valueOf(I()));
/*  894 */     paramma.a("server_brand", getServerModName());
/*  895 */     paramma.a("gui_supported", GraphicsEnvironment.isHeadless() ? "headless" : "supported");
/*  896 */     paramma.a("dedicated", Boolean.valueOf(T()));
/*      */   }
/*      */   
/*      */   public boolean R() {
/*  900 */     return true;
/*      */   }
/*      */   
/*      */   public int S() {
/*  904 */     return 16;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean U() {
/*  910 */     return this.w;
/*      */   }
/*      */   
/*      */   public void d(boolean paramBoolean) {
/*  914 */     this.w = paramBoolean;
/*      */   }
/*      */   
/*      */   public boolean V() {
/*  918 */     return this.x;
/*      */   }
/*      */   
/*      */   public void e(boolean paramBoolean) {
/*  922 */     this.x = paramBoolean;
/*      */   }
/*      */   
/*      */   public boolean W() {
/*  926 */     return this.y;
/*      */   }
/*      */   
/*      */   public void f(boolean paramBoolean) {
/*  930 */     this.y = paramBoolean;
/*      */   }
/*      */   
/*      */   public boolean X() {
/*  934 */     return this.z;
/*      */   }
/*      */   
/*      */   public void g(boolean paramBoolean) {
/*  938 */     this.z = paramBoolean;
/*      */   }
/*      */   
/*      */   public boolean Y() {
/*  942 */     return this.A;
/*      */   }
/*      */   
/*      */   public void h(boolean paramBoolean) {
/*  946 */     this.A = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public String aa() {
/*  952 */     return this.B;
/*      */   }
/*      */   
/*      */   public void o(String paramString) {
/*  956 */     this.B = paramString;
/*      */   }
/*      */   
/*      */   public int ab() {
/*  960 */     return this.C;
/*      */   }
/*      */   
/*      */   public void d(int paramInt) {
/*  964 */     this.C = paramInt;
/*      */   }
/*      */   
/*      */   public boolean ac() {
/*  968 */     return this.u;
/*      */   }
/*      */   
/*      */   public gu ad() {
/*  972 */     return this.s;
/*      */   }
/*      */   
/*      */   public void a(gu paramgu) {
/*  976 */     this.s = paramgu;
/*      */   }
/*      */   
/*      */   public void a(aaj paramaaj) {
/*  980 */     for (byte b = 0; b < this.b.length; b++) {
/*  981 */       (D()).b[b].M().a(paramaaj);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean af() {
/*  988 */     return this.P;
/*      */   }
/*      */   
/*      */   public boolean ag() {
/*  992 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public int ah() {
/*  998 */     return this.v;
/*      */   }
/*      */   
/*      */   public void ai() {
/* 1002 */     this.S = true;
/*      */   }
/*      */   
/*      */   public ma aj() {
/* 1006 */     return this.m;
/*      */   }
/*      */   
/*      */   public t b() {
/* 1010 */     return new t(0, 0, 0);
/*      */   }
/*      */   
/*      */   public int ak() {
/* 1014 */     return 16;
/*      */   }
/*      */   
/*      */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {
/* 1018 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void i(boolean paramBoolean) {
/* 1024 */     this.T = paramBoolean;
/*      */   }
/*      */   
/*      */   public boolean am() {
/* 1028 */     return this.T;
/*      */   }
/*      */   
/*      */   protected abstract boolean c();
/*      */   
/*      */   public abstract boolean f();
/*      */   
/*      */   public abstract aaj g();
/*      */   
/*      */   public abstract int h();
/*      */   
/*      */   public abstract boolean i();
/*      */   
/*      */   public abstract boolean T();
/*      */   
/*      */   public abstract boolean Z();
/*      */   
/*      */   public abstract jk ae();
/*      */   
/*      */   public abstract String a(aaj paramaaj, boolean paramBoolean);
/*      */   
/*      */   public abstract ku al();
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\net\minecraft\server\MinecraftServer.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */