/*   */ package net.minecraft.client;
/*   */ 
/*   */ 
/*   */ 
/*   */ 
/*   */ public class ClientBrandRetriever
/*   */ {
/*   */   public static String getClientModName() {
/* 9 */     return "vanilla";
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\net\minecraft\client\ClientBrandRetriever.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */