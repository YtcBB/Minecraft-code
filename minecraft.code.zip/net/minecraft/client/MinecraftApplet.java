/*     */ package net.minecraft.client;
/*     */ 
/*     */ import avu;
/*     */ import avv;
/*     */ import awf;
/*     */ import java.applet.Applet;
/*     */ import java.awt.BorderLayout;
/*     */ import java.awt.Canvas;
/*     */ 
/*     */ 
/*     */ public class MinecraftApplet
/*     */   extends Applet
/*     */ {
/*     */   private Canvas a;
/*     */   private Minecraft b;
/*  16 */   private Thread c = null;
/*     */ 
/*     */   
/*     */   public void init() {
/*  20 */     this.a = (Canvas)new avu(this);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  36 */     boolean bool = "true".equalsIgnoreCase(getParameter("fullscreen"));
/*     */     
/*  38 */     this.b = (Minecraft)new avv(this, this.a, this, getWidth(), getHeight(), bool);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     this.b.l = getDocumentBase().getHost();
/*  61 */     if (getDocumentBase().getPort() > 0) {
/*  62 */       this.b.l += ":" + getDocumentBase().getPort();
/*     */     }
/*  64 */     if (getParameter("username") != null && getParameter("sessionid") != null) {
/*  65 */       this.b.k = new awf(getParameter("username"), getParameter("sessionid"));
/*  66 */       this.b.al().a("Setting user: " + this.b.k.a);
/*  67 */       System.out.println("(Session ID is " + this.b.k.b + ")");
/*     */     } else {
/*  69 */       this.b.k = new awf("Player", "");
/*     */     } 
/*  71 */     this.b.a("true".equals(getParameter("demo")));
/*     */     
/*  73 */     if (getParameter("server") != null && getParameter("port") != null) {
/*  74 */       this.b.a(getParameter("server"), Integer.parseInt(getParameter("port")));
/*     */     }
/*     */     
/*  77 */     this.b.n = !"true".equals(getParameter("stand-alone"));
/*     */     
/*  79 */     setLayout(new BorderLayout());
/*  80 */     add(this.a, "Center");
/*  81 */     this.a.setFocusable(true);
/*  82 */     this.a.setFocusTraversalKeysEnabled(false);
/*  83 */     validate();
/*     */   }
/*     */   
/*     */   public void a() {
/*  87 */     if (this.c != null)
/*  88 */       return;  this.c = new Thread(this.b, "Minecraft main thread");
/*  89 */     this.c.start();
/*     */   }
/*     */ 
/*     */   
/*     */   public void start() {
/*  94 */     if (this.b != null) this.b.o = false;
/*     */   
/*     */   }
/*     */   
/*     */   public void stop() {
/*  99 */     if (this.b != null) this.b.o = true;
/*     */   
/*     */   }
/*     */   
/*     */   public void destroy() {
/* 104 */     b();
/*     */   }
/*     */   
/*     */   public void b() {
/* 108 */     if (this.c == null)
/* 109 */       return;  this.b.g();
/*     */     try {
/* 111 */       this.c.join(10000L);
/* 112 */     } catch (InterruptedException interruptedException) {
/*     */       try {
/* 114 */         this.b.e();
/* 115 */       } catch (Exception exception) {
/* 116 */         exception.printStackTrace();
/*     */       } 
/*     */     } 
/* 119 */     this.c = null;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\net\minecraft\client\MinecraftApplet.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */