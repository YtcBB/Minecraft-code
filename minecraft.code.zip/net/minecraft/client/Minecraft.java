/*      */ package net.minecraft.client;
/*      */ import aab;
/*      */ import aai;
/*      */ import ajv;
/*      */ import akf;
/*      */ import aki;
/*      */ import apa;
/*      */ import arb;
/*      */ import ava;
/*      */ import avd;
/*      */ import avk;
/*      */ import avt;
/*      */ import awp;
/*      */ import awv;
/*      */ import axr;
/*      */ import axs;
/*      */ import b;
/*      */ import bdk;
/*      */ import bds;
/*      */ import bdz;
/*      */ import bfq;
/*      */ import bgd;
/*      */ import bjg;
/*      */ import bkc;
/*      */ import bkf;
/*      */ import bp;
/*      */ import java.awt.BorderLayout;
/*      */ import java.awt.Frame;
/*      */ import java.awt.Graphics;
/*      */ import java.io.File;
/*      */ import java.text.DecimalFormat;
/*      */ import java.util.ArrayList;
/*      */ import java.util.HashMap;
/*      */ import java.util.List;
/*      */ import java.util.concurrent.Callable;
/*      */ import javax.swing.JPanel;
/*      */ import kf;
/*      */ import ku;
/*      */ import kx;
/*      */ import lb;
/*      */ import m;
/*      */ import ma;
/*      */ import mp;
/*      */ import nf;
/*      */ import ng;
/*      */ import org.lwjgl.Sys;
/*      */ import org.lwjgl.input.Keyboard;
/*      */ import org.lwjgl.input.Mouse;
/*      */ import org.lwjgl.opengl.ContextCapabilities;
/*      */ import org.lwjgl.opengl.Display;
/*      */ import org.lwjgl.opengl.GL11;
/*      */ import ri;
/*      */ import sq;
/*      */ import u;
/*      */ import wk;
/*      */ import wm;
/*      */ 
/*      */ public abstract class Minecraft implements Runnable, mc {
/*   59 */   public static byte[] a = new byte[10485760];
/*      */   
/*      */   private final ku P;
/*      */   
/*      */   private bdz Q;
/*      */   
/*      */   private static Minecraft R;
/*      */   
/*      */   public bdr b;
/*      */   
/*      */   private boolean S = false;
/*      */   
/*      */   private boolean T = false;
/*      */   
/*      */   private b U;
/*      */   public int c;
/*      */   public int d;
/*   76 */   private awe V = new awe(20.0F);
/*   77 */   private ma W = new ma("client", this);
/*      */   
/*      */   public bds e;
/*      */   public bfy f;
/*      */   public bdv g;
/*      */   public ng h;
/*      */   public ng i;
/*      */   public beu j;
/*   85 */   public awf k = null;
/*      */   
/*      */   public String l;
/*      */   public Canvas m;
/*      */   public boolean n = false;
/*      */   public volatile boolean o = false;
/*      */   public bge p;
/*      */   public awv q;
/*      */   public awv r;
/*   94 */   public axr s = null;
/*      */   public awb t;
/*      */   public bfq u;
/*      */   private aus X;
/*   98 */   private int Y = 0;
/*      */   
/*      */   private int Z;
/*      */   
/*      */   private int aa;
/*      */   
/*      */   private bjg ab;
/*      */   public ayc v;
/*      */   public aww w;
/*      */   public boolean x = false;
/*  108 */   public ara y = null;
/*      */   public avy z;
/*      */   protected MinecraftApplet A;
/*  111 */   public bkc B = new bkc();
/*      */   
/*      */   public avw C;
/*      */   
/*      */   public bju D;
/*      */   
/*      */   public File E;
/*      */   private aki ac;
/*      */   private static int ad;
/*  120 */   private int ae = 0;
/*      */   
/*      */   private boolean af;
/*      */   
/*      */   public bki F;
/*      */   
/*      */   private String ag;
/*      */   
/*      */   private int ah;
/*      */   
/*      */   boolean G = false;
/*      */   public boolean H = false;
/*  132 */   long I = G();
/*  133 */   private int ai = 0;
/*      */   
/*      */   private boolean aj;
/*      */   private cg ak;
/*      */   private boolean al;
/*  138 */   public final la J = new la();
/*  139 */   private long am = -1L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void I() {
/*  168 */     avd avd = new avd(this, "Timer hack thread");
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  179 */     avd.setDaemon(true);
/*  180 */     avd.start();
/*      */   }
/*      */   
/*      */   public void a(b paramb) {
/*  184 */     this.T = true;
/*  185 */     this.U = paramb;
/*      */   }
/*      */   
/*      */   public void c(b paramb) {
/*  189 */     this.T = true;
/*  190 */     d(paramb);
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void a(String paramString, int paramInt) {
/*  196 */     this.ag = paramString;
/*  197 */     this.ah = paramInt;
/*      */   }
/*      */   
/*      */   public void a() {
/*  201 */     if (this.m != null) {
/*  202 */       Graphics graphics = this.m.getGraphics();
/*  203 */       if (graphics != null) {
/*  204 */         graphics.setColor(Color.BLACK);
/*  205 */         graphics.fillRect(0, 0, this.c, this.d);
/*  206 */         graphics.dispose();
/*      */       } 
/*  208 */       Display.setParent(this.m);
/*      */     }
/*  210 */     else if (this.S) {
/*  211 */       Display.setFullscreen(true);
/*  212 */       this.c = Display.getDisplayMode().getWidth();
/*  213 */       this.d = Display.getDisplayMode().getHeight();
/*  214 */       if (this.c <= 0) this.c = 1; 
/*  215 */       if (this.d <= 0) this.d = 1; 
/*      */     } else {
/*  217 */       Display.setDisplayMode(new DisplayMode(this.c, this.d));
/*      */     } 
/*      */ 
/*      */     
/*  221 */     Display.setTitle("Minecraft Minecraft 1.5.2");
/*      */     
/*  223 */     al().a("LWJGL Version: " + Sys.getVersion());
/*      */     
/*      */     try {
/*  226 */       Display.create((new PixelFormat()).withDepthBits(24));
/*  227 */     } catch (LWJGLException lWJGLException) {
/*      */ 
/*      */       
/*  230 */       lWJGLException.printStackTrace();
/*      */       try {
/*  232 */         Thread.sleep(1000L);
/*  233 */       } catch (InterruptedException interruptedException) {}
/*      */       
/*  235 */       Display.create();
/*      */     } 
/*      */     
/*  238 */     bkn.a();
/*      */     
/*  240 */     this.E = b();
/*  241 */     this.ac = (aki)new ajq(new File(this.E, "saves"));
/*      */     
/*  243 */     this.z = new avy(this, this.E);
/*  244 */     this.D = new bju(this.E, this);
/*  245 */     this.p = new bge(this.D, this.z);
/*  246 */     J();
/*      */     
/*  248 */     this.q = new awv(this.z, "/font/default.png", this.p, false);
/*  249 */     this.r = new awv(this.z, "/font/alternate.png", this.p, false);
/*      */     
/*  251 */     if (this.z.an != null) {
/*  252 */       bp.a().a(this.z.an, false);
/*  253 */       this.q.a(bp.a().d());
/*  254 */       this.q.b(bp.e(this.z.an));
/*      */     } 
/*      */     
/*  257 */     aaa.a(this.p.a("/misc/grasscolor.png"));
/*  258 */     zx.a(this.p.a("/misc/foliagecolor.png"));
/*      */     
/*  260 */     this.u = new bfq(this);
/*  261 */     bgy.a.f = new bfx(this);
/*  262 */     this.F = new bki(this.k, this.E);
/*      */     
/*  264 */     jv.f.a((jw)new avl(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  274 */     J();
/*      */     
/*  276 */     Mouse.create();
/*  277 */     this.C = new avw(this.m, this.z);
/*      */     
/*  279 */     d("Pre startup");
/*      */     
/*  281 */     GL11.glEnable(3553);
/*  282 */     GL11.glShadeModel(7425);
/*  283 */     GL11.glClearDepth(1.0D);
/*  284 */     GL11.glEnable(2929);
/*  285 */     GL11.glDepthFunc(515);
/*  286 */     GL11.glEnable(3008);
/*  287 */     GL11.glAlphaFunc(516, 0.1F);
/*  288 */     GL11.glCullFace(1029);
/*      */     
/*  290 */     GL11.glMatrixMode(5889);
/*  291 */     GL11.glLoadIdentity();
/*  292 */     GL11.glMatrixMode(5888);
/*  293 */     d("Startup");
/*      */     
/*  295 */     this.B.a(this.z);
/*      */     
/*  297 */     this.f = new bfy(this, this.p);
/*  298 */     this.p.d();
/*      */     
/*  300 */     GL11.glViewport(0, 0, this.c, this.d);
/*      */     
/*  302 */     this.j = new beu((aab)this.e, this.p);
/*      */     try {
/*  304 */       this.X = new aus(this.E, this);
/*  305 */       this.X.start();
/*  306 */     } catch (Exception exception) {}
/*      */ 
/*      */     
/*  309 */     d("Post startup");
/*  310 */     this.w = new aww(this);
/*      */     
/*  312 */     if (this.ag != null) {
/*  313 */       a((axr)new bdn((axr)new bkf(), this, this.ag, this.ah));
/*      */     } else {
/*  315 */       a((axr)new bkf());
/*      */     } 
/*  317 */     this.t = new awb(this);
/*      */     
/*  319 */     if (this.z.u && !this.S) k(); 
/*      */   }
/*      */   
/*      */   private void J() {
/*  323 */     axs axs = new axs(this.z, this.c, this.d);
/*      */     
/*  325 */     GL11.glClear(16640);
/*  326 */     GL11.glMatrixMode(5889);
/*  327 */     GL11.glLoadIdentity();
/*  328 */     GL11.glOrtho(0.0D, axs.c(), axs.d(), 0.0D, 1000.0D, 3000.0D);
/*  329 */     GL11.glMatrixMode(5888);
/*  330 */     GL11.glLoadIdentity();
/*  331 */     GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*  332 */     GL11.glViewport(0, 0, this.c, this.d);
/*  333 */     GL11.glClearColor(0.0F, 0.0F, 0.0F, 0.0F);
/*      */     
/*  335 */     GL11.glDisable(2896);
/*  336 */     GL11.glEnable(3553);
/*  337 */     GL11.glDisable(2912);
/*      */     
/*  339 */     bgd bgd = bgd.a;
/*  340 */     this.p.b("/title/mojang.png");
/*  341 */     bgd.b();
/*  342 */     bgd.d(16777215);
/*  343 */     bgd.a(0.0D, this.d, 0.0D, 0.0D, 0.0D);
/*  344 */     bgd.a(this.c, this.d, 0.0D, 0.0D, 0.0D);
/*  345 */     bgd.a(this.c, 0.0D, 0.0D, 0.0D, 0.0D);
/*  346 */     bgd.a(0.0D, 0.0D, 0.0D, 0.0D, 0.0D);
/*  347 */     bgd.a();
/*      */     
/*  349 */     GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
/*  350 */     bgd.d(16777215);
/*      */     
/*  352 */     char c1 = 'Ā';
/*  353 */     char c2 = 'Ā';
/*  354 */     a((axs.a() - c1) / 2, (axs.b() - c2) / 2, 0, 0, c1, c2);
/*      */     
/*  356 */     GL11.glDisable(2896);
/*  357 */     GL11.glDisable(2912);
/*      */     
/*  359 */     GL11.glEnable(3008);
/*  360 */     GL11.glAlphaFunc(516, 0.1F);
/*      */     
/*  362 */     Display.swapBuffers();
/*      */   }
/*      */   
/*      */   public void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  366 */     float f1 = 0.00390625F;
/*  367 */     float f2 = 0.00390625F;
/*  368 */     bgd bgd = bgd.a;
/*  369 */     bgd.b();
/*  370 */     bgd.a((paramInt1 + 0), (paramInt2 + paramInt6), 0.0D, ((paramInt3 + 0) * f1), ((paramInt4 + paramInt6) * f2));
/*  371 */     bgd.a((paramInt1 + paramInt5), (paramInt2 + paramInt6), 0.0D, ((paramInt3 + paramInt5) * f1), ((paramInt4 + paramInt6) * f2));
/*  372 */     bgd.a((paramInt1 + paramInt5), (paramInt2 + 0), 0.0D, ((paramInt3 + paramInt5) * f1), ((paramInt4 + 0) * f2));
/*  373 */     bgd.a((paramInt1 + 0), (paramInt2 + 0), 0.0D, ((paramInt3 + 0) * f1), ((paramInt4 + 0) * f2));
/*  374 */     bgd.a();
/*      */   }
/*      */   
/*  377 */   private static File an = null; public volatile boolean K; public String L; long M; int N; long O; private String ao;
/*      */   
/*      */   public static File b() {
/*  380 */     if (an == null) an = a("minecraft"); 
/*  381 */     return an;
/*      */   }
/*      */   public static File a(String paramString) {
/*      */     File file;
/*  385 */     String str2, str1 = System.getProperty("user.home", ".");
/*      */     
/*  387 */     switch (avj.a[c().ordinal()]) {
/*      */       case 1:
/*      */       case 2:
/*  390 */         file = new File(str1, '.' + paramString + '/');
/*      */         break;
/*      */       case 3:
/*  393 */         str2 = System.getenv("APPDATA");
/*  394 */         if (str2 != null) { file = new File(str2, "." + paramString + '/'); break; }
/*  395 */          file = new File(str1, '.' + paramString + '/');
/*      */         break;
/*      */       case 4:
/*  398 */         file = new File(str1, "Library/Application Support/" + paramString);
/*      */         break;
/*      */       default:
/*  401 */         file = new File(str1, paramString + '/'); break;
/*      */     } 
/*  403 */     if (!file.exists() && !file.mkdirs()) throw new RuntimeException("The working directory could not be created: " + file); 
/*  404 */     return file;
/*      */   }
/*      */   
/*      */   public static avt c() {
/*  408 */     String str = System.getProperty("os.name").toLowerCase();
/*  409 */     if (str.contains("win")) return avt.c; 
/*  410 */     if (str.contains("mac")) return avt.d; 
/*  411 */     if (str.contains("solaris")) return avt.b; 
/*  412 */     if (str.contains("sunos")) return avt.b; 
/*  413 */     if (str.contains("linux")) return avt.a; 
/*  414 */     if (str.contains("unix")) return avt.a; 
/*  415 */     return avt.e;
/*      */   }
/*      */   
/*      */   public aki d() {
/*  419 */     return this.ac;
/*      */   }
/*      */   public void a(axr paramaxr) {
/*      */     bkf bkf;
/*      */     awp awp;
/*  424 */     if (this.s != null) {
/*  425 */       this.s.b();
/*      */     }
/*      */     
/*  428 */     this.F.d();
/*      */     
/*  430 */     if (paramaxr == null && this.e == null) {
/*  431 */       bkf = new bkf();
/*  432 */     } else if (bkf == null && this.g.aX() <= 0) {
/*  433 */       awp = new awp();
/*      */     } 
/*      */     
/*  436 */     if (awp instanceof bkf) {
/*  437 */       this.z.ab = false;
/*  438 */       this.w.b().a();
/*      */     } 
/*      */     
/*  441 */     this.s = (axr)awp;
/*      */     
/*  443 */     if (awp != null) {
/*  444 */       i();
/*  445 */       axs axs = new axs(this.z, this.c, this.d);
/*  446 */       int i = axs.a();
/*  447 */       int j = axs.b();
/*  448 */       awp.a(this, i, j);
/*  449 */       this.x = false;
/*      */     } else {
/*  451 */       h();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void d(String paramString) {
/*  456 */     int i = GL11.glGetError();
/*  457 */     if (i != 0) {
/*  458 */       String str = GLU.gluErrorString(i);
/*  459 */       al().c("########## GL ERROR ##########");
/*  460 */       al().c("@ " + paramString);
/*  461 */       al().c(i + ": " + str);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void e() {
/*      */     try {
/*  467 */       this.F.d();
/*      */ 
/*      */       
/*      */       try {
/*  471 */         if (this.X != null) {
/*  472 */           this.X.b();
/*      */         }
/*  474 */       } catch (Exception exception) {}
/*      */ 
/*      */       
/*  477 */       al().a("Stopping!");
/*      */       try {
/*  479 */         a((bds)null);
/*  480 */       } catch (Throwable throwable) {}
/*      */ 
/*      */       
/*      */       try {
/*  484 */         avc.c();
/*  485 */       } catch (Throwable throwable) {}
/*      */ 
/*      */       
/*  488 */       this.B.b();
/*  489 */       Mouse.destroy();
/*  490 */       Keyboard.destroy();
/*      */     } finally {
/*  492 */       Display.destroy();
/*  493 */       if (!this.T) System.exit(0); 
/*      */     } 
/*  495 */     System.gc();
/*      */   }
/*      */   
/*  498 */   public Minecraft(Canvas paramCanvas, MinecraftApplet paramMinecraftApplet, int paramInt1, int paramInt2, boolean paramBoolean) { this.K = true;
/*  499 */     this.L = "";
/*      */     
/*  501 */     this.M = G();
/*  502 */     this.N = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  775 */     this.O = -1L;
/*      */     
/*  777 */     this.ao = "root"; this.P = (ku)new kh("Minecraft-Client", " [CLIENT]", (new File(b(), "output-client.log")).getAbsolutePath()); kf.a(); this.aa = paramInt2; this.S = paramBoolean; this.A = paramMinecraftApplet; cw.a = 32767; I(); this.m = paramCanvas; this.c = paramInt1; this.d = paramInt2; this.S = paramBoolean; R = this; biq.a(); this.v = new ayc(this); }
/*      */   public void run() { this.K = true; try { a(); } catch (Exception exception) { exception.printStackTrace(); c(b(new b("Failed to start game", exception))); return; }  try { while (this.K) { if (this.T && this.U != null) { c(this.U); return; }  if (this.af) { this.af = false; this.p.c(); }  try { K(); } catch (OutOfMemoryError outOfMemoryError) { f(); a((axr)new axk()); System.gc(); }  }  } catch (awd awd) {  } catch (u u) { b(u.a()); f(); u.printStackTrace(); c(u.a()); } catch (Throwable throwable) { b b1 = b(new b("Unexpected error", throwable)); f(); throwable.printStackTrace(); c(b1); } finally { e(); }  }
/*      */   private void K() { if (this.A != null && !this.A.isActive()) { this.K = false; return; }  aqx.a().a(); if (this.e != null) this.e.U().a();  this.J.a("root"); if (this.m == null && Display.isCloseRequested()) g();  if (this.o && this.e != null) { float f = this.V.c; this.V.a(); this.V.c = f; } else { this.V.a(); }  long l1 = System.nanoTime(); this.J.a("tick"); for (byte b1 = 0; b1 < this.V.b; b1++) l();  this.J.c("preRenderErrors"); long l2 = System.nanoTime() - l1; d("Pre render"); bgf.b = this.z.j; this.J.c("sound"); this.B.a((ng)this.g, this.V.c); if (!this.o) this.B.g();  this.J.b(); this.J.a("render"); this.J.a("display"); GL11.glEnable(3553); if (!Keyboard.isKeyDown(65)) Display.update();  if (this.g != null && this.g.S()) this.z.aa = 0;  this.J.b(); if (!this.x) { this.J.c("gameRenderer"); this.u.b(this.V.c); this.J.b(); }  GL11.glFlush(); this.J.b(); if (!Display.isActive() && this.S) k();  if (this.z.ab && this.z.ac) { if (!this.J.a) this.J.a();  this.J.a = true; a(l2); } else { this.J.a = false; this.O = System.nanoTime(); }  this.v.a(); this.J.a("root"); Thread.yield(); if (Keyboard.isKeyDown(65)) Display.update();  M(); if (this.m != null && !this.S && (this.m.getWidth() != this.c || this.m.getHeight() != this.d)) { this.c = this.m.getWidth(); this.d = this.m.getHeight(); if (this.c <= 0) this.c = 1;  if (this.d <= 0) this.d = 1;  a(this.c, this.d); }  d("Post render"); this.N++; boolean bool = this.o; this.o = (C() && this.s != null && this.s.f() && !this.ab.an()); if (B() && this.g != null && this.g.a != null && this.o != bool) ((ch)this.g.a.f()).a(this.o);  while (G() >= this.M + 1000L) { ad = this.N; this.L = ad + " fps, " + bfm.b + " chunk updates"; bfm.b = 0; this.M += 1000L; this.N = 0; this.W.b(); if (!this.W.d()) this.W.a();  }  this.J.b(); if (L() > 0)
/*  780 */       Display.sync(bfq.a(L()));  } private void b(int paramInt) { List<lb> list = this.J.b(this.ao);
/*  781 */     if (list == null || list.isEmpty())
/*      */       return; 
/*  783 */     lb lb = list.remove(0);
/*  784 */     if (paramInt == 0)
/*  785 */     { if (lb.c.length() > 0) {
/*  786 */         int i = this.ao.lastIndexOf(".");
/*  787 */         if (i >= 0) this.ao = this.ao.substring(0, i); 
/*      */       }  }
/*      */     else
/*  790 */     { paramInt--;
/*  791 */       if (paramInt < list.size() && !((lb)list.get(paramInt)).c.equals("unspecified"))
/*  792 */       { if (this.ao.length() > 0) this.ao += "."; 
/*  793 */         this.ao += ((lb)list.get(paramInt)).c; }  }  }
/*      */   private int L() { if (this.s != null && this.s instanceof bkf)
/*      */       return 2;  return this.z.i; }
/*      */   public void f() { try { a = new byte[0]; this.f.f(); } catch (Throwable throwable) {} try { System.gc(); aqx.a().b(); this.e.U().b(); } catch (Throwable throwable) {} try { System.gc(); a((bds)null); } catch (Throwable throwable) {} System.gc(); }
/*      */   private void M() { if (Keyboard.isKeyDown(60)) { if (!this.G) { this.G = true; this.w.b().a(awc.a(an, this.c, this.d)); }  }
/*      */     else { this.G = false; }
/*  799 */      } private void a(long paramLong) { if (!this.J.a)
/*  800 */       return;  List<lb> list = this.J.b(this.ao);
/*  801 */     lb lb = list.remove(0);
/*      */     
/*  803 */     GL11.glClear(256);
/*  804 */     GL11.glMatrixMode(5889);
/*  805 */     GL11.glEnable(2903);
/*  806 */     GL11.glLoadIdentity();
/*  807 */     GL11.glOrtho(0.0D, this.c, this.d, 0.0D, 1000.0D, 3000.0D);
/*  808 */     GL11.glMatrixMode(5888);
/*  809 */     GL11.glLoadIdentity();
/*  810 */     GL11.glTranslatef(0.0F, 0.0F, -2000.0F);
/*      */     
/*  812 */     GL11.glLineWidth(1.0F);
/*  813 */     GL11.glDisable(3553);
/*  814 */     bgd bgd = bgd.a;
/*      */     
/*  816 */     char c = ' ';
/*  817 */     int i = this.c - c - 10;
/*  818 */     int j = this.d - c * 2;
/*  819 */     GL11.glEnable(3042);
/*  820 */     bgd.b();
/*  821 */     bgd.a(0, 200);
/*  822 */     bgd.a((i - c * 1.1F), (j - c * 0.6F - 16.0F), 0.0D);
/*  823 */     bgd.a((i - c * 1.1F), (j + c * 2), 0.0D);
/*  824 */     bgd.a((i + c * 1.1F), (j + c * 2), 0.0D);
/*  825 */     bgd.a((i + c * 1.1F), (j - c * 0.6F - 16.0F), 0.0D);
/*  826 */     bgd.a();
/*  827 */     GL11.glDisable(3042);
/*      */     
/*  829 */     double d = 0.0D;
/*  830 */     for (byte b1 = 0; b1 < list.size(); b1++) {
/*  831 */       lb lb1 = list.get(b1);
/*      */       
/*  833 */       int m = kx.c(lb1.a / 4.0D) + 1;
/*      */       
/*  835 */       bgd.b(6);
/*  836 */       bgd.d(lb1.a());
/*  837 */       bgd.a(i, j, 0.0D); int n;
/*  838 */       for (n = m; n >= 0; n--) {
/*  839 */         float f1 = (float)((d + lb1.a * n / m) * 3.1415927410125732D * 2.0D / 100.0D);
/*  840 */         float f2 = kx.a(f1) * c;
/*  841 */         float f3 = kx.b(f1) * c * 0.5F;
/*  842 */         bgd.a((i + f2), (j - f3), 0.0D);
/*      */       } 
/*  844 */       bgd.a();
/*  845 */       bgd.b(5);
/*  846 */       bgd.d((lb1.a() & 0xFEFEFE) >> 1);
/*  847 */       for (n = m; n >= 0; n--) {
/*  848 */         float f1 = (float)((d + lb1.a * n / m) * 3.1415927410125732D * 2.0D / 100.0D);
/*  849 */         float f2 = kx.a(f1) * c;
/*  850 */         float f3 = kx.b(f1) * c * 0.5F;
/*  851 */         bgd.a((i + f2), (j - f3), 0.0D);
/*  852 */         bgd.a((i + f2), (j - f3 + 10.0F), 0.0D);
/*      */       } 
/*  854 */       bgd.a();
/*      */       
/*  856 */       d += lb1.a;
/*      */     } 
/*  858 */     DecimalFormat decimalFormat = new DecimalFormat("##0.00");
/*      */     
/*  860 */     GL11.glEnable(3553);
/*      */ 
/*      */     
/*  863 */     String str = "";
/*  864 */     if (!lb.c.equals("unspecified")) {
/*  865 */       str = str + "[0] ";
/*      */     }
/*  867 */     if (lb.c.length() == 0) {
/*  868 */       str = str + "ROOT ";
/*      */     } else {
/*  870 */       str = str + lb.c + " ";
/*      */     } 
/*  872 */     int k = 16777215;
/*  873 */     this.q.a(str, i - c, j - c / 2 - 16, k);
/*  874 */     this.q.a(str = decimalFormat.format(lb.b) + "%", i + c - this.q.a(str), j - c / 2 - 16, k);
/*      */ 
/*      */     
/*  877 */     for (byte b2 = 0; b2 < list.size(); b2++) {
/*  878 */       lb lb1 = list.get(b2);
/*  879 */       String str1 = "";
/*  880 */       if (lb1.c.equals("unspecified")) {
/*  881 */         str1 = str1 + "[?] ";
/*      */       } else {
/*  883 */         str1 = str1 + "[" + (b2 + 1) + "] ";
/*      */       } 
/*      */       
/*  886 */       str1 = str1 + lb1.c;
/*  887 */       this.q.a(str1, i - c, j + c / 2 + b2 * 8 + 20, lb1.a());
/*  888 */       this.q.a(str1 = decimalFormat.format(lb1.a) + "%", i + c - 50 - this.q.a(str1), j + c / 2 + b2 * 8 + 20, lb1.a());
/*  889 */       this.q.a(str1 = decimalFormat.format(lb1.b) + "%", i + c - this.q.a(str1), j + c / 2 + b2 * 8 + 20, lb1.a());
/*      */     }  }
/*      */ 
/*      */   
/*      */   public void g() {
/*  894 */     this.K = false;
/*      */   }
/*      */   
/*      */   public void h() {
/*  898 */     if (!Display.isActive())
/*  899 */       return;  if (this.H)
/*  900 */       return;  this.H = true;
/*  901 */     this.C.a();
/*  902 */     a((axr)null);
/*  903 */     this.Y = 10000;
/*      */   }
/*      */   
/*      */   public void i() {
/*  907 */     if (!this.H)
/*  908 */       return;  ava.a();
/*  909 */     this.H = false;
/*  910 */     this.C.b();
/*      */   }
/*      */   
/*      */   public void j() {
/*  914 */     if (this.s != null)
/*      */       return; 
/*  916 */     a((axr)new axl());
/*  917 */     if (C() && !this.ab.an()) {
/*  918 */       this.B.e();
/*      */     }
/*      */   }
/*      */   
/*      */   private void a(int paramInt, boolean paramBoolean) {
/*  923 */     if (!paramBoolean) this.Y = 0; 
/*  924 */     if (paramInt == 0 && this.Y > 0)
/*      */       return; 
/*  926 */     if (paramBoolean && this.y != null && this.y.a == arb.a && paramInt == 0) {
/*  927 */       int i = this.y.b;
/*  928 */       int j = this.y.c;
/*  929 */       int k = this.y.d;
/*      */       
/*  931 */       this.b.c(i, j, k, this.y.e);
/*  932 */       if (this.g.e(i, j, k)) {
/*  933 */         this.j.a(i, j, k, this.y.e);
/*  934 */         this.g.bK();
/*      */       } 
/*      */     } else {
/*  937 */       this.b.c();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void c(int paramInt) {
/*  942 */     if (paramInt == 0 && this.Y > 0)
/*  943 */       return;  if (paramInt == 0) {
/*  944 */       this.g.bK();
/*      */     }
/*      */     
/*  947 */     if (paramInt == 1) this.ae = 4;
/*      */     
/*  949 */     boolean bool = true;
/*      */     
/*  951 */     wm wm = this.g.bK.h();
/*      */     
/*  953 */     if (this.y == null) {
/*  954 */       if (paramInt == 0 && this.b.g()) this.Y = 10; 
/*  955 */     } else if (this.y.a == arb.b) {
/*  956 */       if (paramInt == 0) {
/*  957 */         this.b.a((sq)this.g, this.y.g);
/*      */       }
/*  959 */       if (paramInt == 1 && 
/*  960 */         this.b.b((sq)this.g, this.y.g)) {
/*  961 */         bool = false;
/*      */       }
/*      */     }
/*  964 */     else if (this.y.a == arb.a) {
/*  965 */       int i = this.y.b;
/*  966 */       int j = this.y.c;
/*  967 */       int k = this.y.d;
/*  968 */       int m = this.y.e;
/*      */       
/*  970 */       if (paramInt == 0) {
/*  971 */         this.b.b(i, j, k, this.y.e);
/*      */       } else {
/*  973 */         boolean bool1 = (wm != null) ? wm.a : false;
/*  974 */         if (this.b.a((sq)this.g, (aab)this.e, wm, i, j, k, m, this.y.f)) {
/*  975 */           bool = false;
/*  976 */           this.g.bK();
/*      */         } 
/*  978 */         if (wm == null) {
/*      */           return;
/*      */         }
/*      */         
/*  982 */         if (wm.a == 0) {
/*  983 */           this.g.bK.a[this.g.bK.c] = null;
/*  984 */         } else if (wm.a != bool1 || this.b.h()) {
/*  985 */           this.u.c.b();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*  990 */     if (bool && paramInt == 1) {
/*  991 */       wm wm1 = this.g.bK.h();
/*  992 */       if (wm1 != null && 
/*  993 */         this.b.a((sq)this.g, (aab)this.e, wm1)) {
/*  994 */         this.u.c.c();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */   
/*      */   public void k() {
/*      */     try {
/* 1003 */       this.S = !this.S;
/* 1004 */       if (this.S) {
/* 1005 */         Display.setDisplayMode(Display.getDesktopDisplayMode());
/* 1006 */         this.c = Display.getDisplayMode().getWidth();
/* 1007 */         this.d = Display.getDisplayMode().getHeight();
/* 1008 */         if (this.c <= 0) this.c = 1; 
/* 1009 */         if (this.d <= 0) this.d = 1; 
/*      */       } else {
/* 1011 */         if (this.m != null) {
/* 1012 */           this.c = this.m.getWidth();
/* 1013 */           this.d = this.m.getHeight();
/*      */         }
/*      */         else {
/*      */           
/* 1017 */           this.c = this.Z;
/* 1018 */           this.d = this.aa;
/*      */         } 
/* 1020 */         if (this.c <= 0) this.c = 1; 
/* 1021 */         if (this.d <= 0) this.d = 1; 
/*      */       } 
/* 1023 */       if (this.s != null) {
/* 1024 */         a(this.c, this.d);
/*      */       }
/* 1026 */       Display.setFullscreen(this.S);
/* 1027 */       Display.setVSyncEnabled(this.z.v);
/* 1028 */       Display.update();
/* 1029 */     } catch (Exception exception) {
/* 1030 */       exception.printStackTrace();
/*      */     } 
/*      */   }
/*      */   
/*      */   private void a(int paramInt1, int paramInt2) {
/* 1035 */     this.c = (paramInt1 <= 0) ? 1 : paramInt1;
/* 1036 */     this.d = (paramInt2 <= 0) ? 1 : paramInt2;
/*      */     
/* 1038 */     if (this.s != null) {
/* 1039 */       axs axs = new axs(this.z, paramInt1, paramInt2);
/* 1040 */       int i = axs.a();
/* 1041 */       int j = axs.b();
/* 1042 */       this.s.a(this, i, j);
/*      */     } 
/*      */   }
/*      */   
/*      */   public void l() {
/* 1047 */     if (this.ae > 0) this.ae--;
/*      */     
/* 1049 */     this.J.a("stats");
/* 1050 */     this.F.e();
/* 1051 */     this.J.c("gui");
/* 1052 */     if (!this.o) this.w.a(); 
/* 1053 */     this.J.c("pick");
/* 1054 */     this.u.a(1.0F);
/*      */     
/* 1056 */     this.J.c("gameMode");
/* 1057 */     if (!this.o && this.e != null) this.b.e(); 
/* 1058 */     this.p.b("/terrain.png");
/* 1059 */     this.J.c("textures");
/* 1060 */     if (!this.o) this.p.b();
/*      */     
/* 1062 */     if (this.s == null && this.g != null) {
/* 1063 */       if (this.g.aX() <= 0) {
/* 1064 */         a((axr)null);
/* 1065 */       } else if (this.g.bz() && this.e != null) {
/* 1066 */         a((axr)new awz());
/*      */       } 
/* 1068 */     } else if (this.s != null && this.s instanceof awz && !this.g.bz()) {
/* 1069 */       a((axr)null);
/*      */     } 
/*      */     
/* 1072 */     if (this.s != null) {
/* 1073 */       this.Y = 10000;
/*      */     }
/*      */     
/* 1076 */     if (this.s != null) {
/*      */       try {
/* 1078 */         this.s.m();
/* 1079 */       } catch (Throwable throwable) {
/* 1080 */         b b1 = b.a(throwable, "Updating screen events");
/* 1081 */         m m = b1.a("Affected screen");
/* 1082 */         m.a("Screen name", (Callable)new avm(this));
/*      */ 
/*      */ 
/*      */ 
/*      */         
/* 1087 */         throw new u(b1);
/*      */       } 
/*      */       
/* 1090 */       if (this.s != null) {
/*      */         try {
/* 1092 */           this.s.n.a();
/* 1093 */         } catch (Throwable throwable) {
/* 1094 */           b b1 = b.a(throwable, "Ticking screen particles");
/* 1095 */           m m = b1.a("Affected screen");
/* 1096 */           m.a("Screen name", (Callable)new avn(this));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1101 */           throw new u(b1);
/*      */         } 
/*      */         
/*      */         try {
/* 1105 */           this.s.c();
/* 1106 */         } catch (Throwable throwable) {
/* 1107 */           b b1 = b.a(throwable, "Ticking screen");
/* 1108 */           m m = b1.a("Affected screen");
/* 1109 */           m.a("Screen name", (Callable)new avo(this));
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1114 */           throw new u(b1);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1119 */     if (this.s == null || this.s.l) {
/* 1120 */       this.J.c("mouse");
/*      */       
/* 1122 */       while (Mouse.next()) {
/* 1123 */         ava.a(Mouse.getEventButton() - 100, Mouse.getEventButtonState());
/* 1124 */         if (Mouse.getEventButtonState()) {
/* 1125 */           ava.a(Mouse.getEventButton() - 100);
/*      */         }
/*      */         
/* 1128 */         long l = G() - this.I;
/* 1129 */         if (l > 200L)
/*      */           continue; 
/* 1131 */         int i = Mouse.getEventDWheel();
/* 1132 */         if (i != 0) {
/* 1133 */           this.g.bK.c(i);
/*      */           
/* 1135 */           if (this.z.ae) {
/* 1136 */             if (i > 0) i = 1; 
/* 1137 */             if (i < 0) i = -1;
/*      */             
/* 1139 */             this.z.ah += i * 0.25F;
/*      */           } 
/*      */         } 
/*      */         
/* 1143 */         if (this.s == null) {
/* 1144 */           if (!this.H && Mouse.getEventButtonState())
/* 1145 */             h();  continue;
/*      */         } 
/* 1147 */         if (this.s != null) {
/* 1148 */           this.s.d();
/*      */         }
/*      */       } 
/*      */       
/* 1152 */       if (this.Y > 0) this.Y--;
/*      */       
/* 1154 */       this.J.c("keyboard");
/* 1155 */       while (Keyboard.next()) {
/* 1156 */         ava.a(Keyboard.getEventKey(), Keyboard.getEventKeyState());
/*      */         
/* 1158 */         if (Keyboard.getEventKeyState()) {
/* 1159 */           ava.a(Keyboard.getEventKey());
/*      */         }
/*      */         
/* 1162 */         if (this.am > 0L) {
/* 1163 */           if (G() - this.am >= 6000L) {
/* 1164 */             throw new u(new b("Manually triggered debug crash", new Throwable()));
/*      */           }
/*      */           
/* 1167 */           if (!Keyboard.isKeyDown(46) || !Keyboard.isKeyDown(61)) {
/* 1168 */             this.am = -1L;
/*      */           }
/* 1170 */         } else if (Keyboard.isKeyDown(46) && Keyboard.isKeyDown(61)) {
/* 1171 */           this.am = G();
/*      */         } 
/*      */         
/* 1174 */         if (Keyboard.getEventKeyState()) {
/* 1175 */           if (Keyboard.getEventKey() == 87) {
/* 1176 */             k();
/*      */             
/*      */             continue;
/*      */           } 
/* 1180 */           if (this.s != null) {
/* 1181 */             this.s.n();
/*      */           } else {
/* 1183 */             if (Keyboard.getEventKey() == 1) {
/* 1184 */               j();
/*      */             }
/*      */             
/* 1187 */             if (Keyboard.getEventKey() == 31 && Keyboard.isKeyDown(61)) {
/* 1188 */               N();
/*      */             }
/* 1190 */             if (Keyboard.getEventKey() == 20 && Keyboard.isKeyDown(61)) {
/* 1191 */               this.p.c();
/* 1192 */               this.f.a();
/*      */             } 
/* 1194 */             if (Keyboard.getEventKey() == 33 && Keyboard.isKeyDown(61)) {
/* 1195 */               int i = Keyboard.isKeyDown(42) | Keyboard.isKeyDown(54);
/* 1196 */               this.z.a(awa.g, (i != 0) ? -1 : 1);
/*      */             } 
/* 1198 */             if (Keyboard.getEventKey() == 30 && Keyboard.isKeyDown(61)) {
/* 1199 */               this.f.a();
/*      */             }
/* 1201 */             if (Keyboard.getEventKey() == 35 && Keyboard.isKeyDown(61)) {
/* 1202 */               this.z.x = !this.z.x;
/* 1203 */               this.z.b();
/*      */             } 
/* 1205 */             if (Keyboard.getEventKey() == 48 && Keyboard.isKeyDown(61)) {
/* 1206 */               bgy.p = !bgy.p;
/*      */             }
/* 1208 */             if (Keyboard.getEventKey() == 25 && Keyboard.isKeyDown(61)) {
/* 1209 */               this.z.y = !this.z.y;
/* 1210 */               this.z.b();
/*      */             } 
/* 1212 */             if (Keyboard.getEventKey() == 59) {
/* 1213 */               this.z.Z = !this.z.Z;
/*      */             }
/* 1215 */             if (Keyboard.getEventKey() == 61) {
/* 1216 */               this.z.ab = !this.z.ab;
/* 1217 */               this.z.ac = axr.p();
/*      */             } 
/* 1219 */             if (Keyboard.getEventKey() == 63) {
/* 1220 */               this.z.aa++;
/* 1221 */               if (this.z.aa > 2) {
/* 1222 */                 this.z.aa = 0;
/*      */               }
/*      */             } 
/* 1225 */             if (Keyboard.getEventKey() == 66) {
/* 1226 */               this.z.af = !this.z.af;
/*      */             }
/*      */           } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           byte b1;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/* 1247 */           for (b1 = 0; b1 < 9; b1++) {
/* 1248 */             if (Keyboard.getEventKey() == 2 + b1) this.g.bK.c = b1; 
/*      */           } 
/* 1250 */           if (this.z.ab && this.z.ac) {
/* 1251 */             if (Keyboard.getEventKey() == 11) {
/* 1252 */               b(0);
/*      */             }
/* 1254 */             for (b1 = 0; b1 < 9; b1++) {
/* 1255 */               if (Keyboard.getEventKey() == 2 + b1) {
/* 1256 */                 b(b1 + 1);
/*      */               }
/*      */             } 
/*      */           } 
/*      */         } 
/*      */       } 
/*      */       
/* 1263 */       boolean bool = (this.z.n != 2) ? true : false;
/*      */       
/* 1265 */       while (this.z.N.c())
/* 1266 */         a((axr)new azg((sq)this.g)); 
/* 1267 */       while (this.z.O.c())
/* 1268 */         this.g.a(axr.o()); 
/* 1269 */       while (this.z.P.c() && bool)
/* 1270 */         a((axr)new awj()); 
/* 1271 */       if (this.s == null && this.z.V.c() && bool) a((axr)new awj("/"));
/*      */       
/* 1273 */       if (this.g.bX()) {
/* 1274 */         if (!this.z.S.e) {
/* 1275 */           this.b.c((sq)this.g);
/*      */         }
/*      */         
/* 1278 */         while (this.z.R.c());
/*      */         
/* 1280 */         while (this.z.S.c());
/*      */         
/* 1282 */         while (this.z.U.c());
/*      */       } else {
/*      */         
/* 1285 */         while (this.z.R.c()) {
/* 1286 */           c(0);
/*      */         }
/* 1288 */         while (this.z.S.c()) {
/* 1289 */           c(1);
/*      */         }
/* 1291 */         while (this.z.U.c()) {
/* 1292 */           O();
/*      */         }
/*      */       } 
/*      */       
/* 1296 */       if (this.z.S.e && this.ae == 0 && !this.g.bX()) {
/* 1297 */         c(1);
/*      */       }
/*      */       
/* 1300 */       a(0, (this.s == null && this.z.R.e && this.H));
/*      */     } 
/*      */     
/* 1303 */     if (this.e != null) {
/* 1304 */       if (this.g != null) {
/* 1305 */         this.ai++;
/* 1306 */         if (this.ai == 30) {
/* 1307 */           this.ai = 0;
/* 1308 */           this.e.h((mp)this.g);
/*      */         } 
/*      */       } 
/*      */       
/* 1312 */       this.J.c("gameRenderer");
/* 1313 */       if (!this.o) this.u.a(); 
/* 1314 */       this.J.c("levelRenderer");
/* 1315 */       if (!this.o) this.f.e(); 
/* 1316 */       this.J.c("level");
/* 1317 */       if (!this.o) {
/* 1318 */         if (this.e.q > 0) this.e.q--; 
/* 1319 */         this.e.h();
/*      */       } 
/* 1321 */       if (!this.o) {
/* 1322 */         this.e.a((this.e.r > 0), true);
/*      */         
/*      */         try {
/* 1325 */           this.e.b();
/* 1326 */         } catch (Throwable throwable) {
/* 1327 */           b b1 = b.a(throwable, "Exception in world tick");
/* 1328 */           if (this.e == null) {
/* 1329 */             m m = b1.a("Affected level");
/* 1330 */             m.a("Problem", "Level is null!");
/*      */           } else {
/* 1332 */             this.e.a(b1);
/*      */           } 
/* 1334 */           throw new u(b1);
/*      */         } 
/*      */       } 
/* 1337 */       this.J.c("animateTick");
/* 1338 */       if (!this.o && this.e != null) this.e.I(kx.c(this.g.u), kx.c(this.g.v), kx.c(this.g.w)); 
/* 1339 */       this.J.c("particles");
/* 1340 */       if (!this.o) this.j.a(); 
/* 1341 */     } else if (this.ak != null) {
/* 1342 */       this.J.c("pendingConnection");
/* 1343 */       this.ak.b();
/*      */     } 
/*      */     
/* 1346 */     this.J.b();
/*      */     
/* 1348 */     this.I = G();
/*      */   }
/*      */   
/*      */   private void N() {
/* 1352 */     al().a("FORCING RELOAD!");
/* 1353 */     if (this.B != null) this.B.d(); 
/* 1354 */     this.B = new bkc();
/* 1355 */     this.B.a(this.z);
/* 1356 */     this.X.a();
/*      */   }
/*      */   
/*      */   public void a(String paramString1, String paramString2, aai paramaai) {
/* 1360 */     a((bds)null);
/* 1361 */     System.gc();
/*      */     
/* 1363 */     akf akf = this.ac.a(paramString1, false);
/* 1364 */     ajv ajv = akf.d();
/*      */     
/* 1366 */     if (ajv == null && paramaai != null) {
/* 1367 */       this.F.a(kf.g, 1);
/* 1368 */       ajv = new ajv(paramaai, paramString1);
/* 1369 */       akf.a(ajv);
/*      */     } 
/*      */     
/* 1372 */     if (paramaai == null) {
/* 1373 */       paramaai = new aai(ajv);
/*      */     }
/*      */     
/* 1376 */     this.F.a(kf.f, 1);
/*      */     
/* 1378 */     this.ab = new bjg(this, paramString1, paramString2, paramaai);
/* 1379 */     this.ab.t();
/* 1380 */     this.al = true;
/*      */     
/* 1382 */     this.t.a(bo.a("menu.loadingLevel"));
/* 1383 */     while (!this.ab.af()) {
/* 1384 */       String str = this.ab.d();
/* 1385 */       if (str != null) {
/* 1386 */         this.t.c(bo.a(str));
/*      */       } else {
/* 1388 */         this.t.c("");
/*      */       } 
/*      */       try {
/* 1391 */         Thread.sleep(200L);
/* 1392 */       } catch (InterruptedException interruptedException) {}
/*      */     } 
/*      */     
/* 1395 */     a((axr)null);
/*      */     
/*      */     try {
/* 1398 */       bdk bdk = new bdk(this, this.ab);
/* 1399 */       this.ak = bdk.f();
/* 1400 */     } catch (IOException iOException) {
/* 1401 */       c(b(new b("Connecting to integrated server", iOException)));
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void a(bds parambds) {
/* 1411 */     a(parambds, "");
/*      */   }
/*      */   
/*      */   public void a(bds parambds, String paramString) {
/* 1415 */     this.F.d();
/*      */     
/* 1417 */     if (parambds == null) {
/*      */       
/* 1419 */       bdk bdk = r();
/* 1420 */       if (bdk != null) {
/* 1421 */         bdk.c();
/*      */       }
/* 1423 */       if (this.ak != null) {
/* 1424 */         this.ak.f();
/*      */       }
/*      */       
/* 1427 */       if (this.ab != null) {
/* 1428 */         this.ab.n();
/*      */       }
/* 1430 */       this.ab = null;
/*      */     } 
/*      */     
/* 1433 */     this.h = null;
/* 1434 */     this.ak = null;
/*      */     
/* 1436 */     if (this.t != null) {
/* 1437 */       this.t.b(paramString);
/* 1438 */       this.t.c("");
/*      */     } 
/*      */     
/* 1441 */     if (parambds == null && this.e != null) {
/* 1442 */       if (this.D.a()) {
/* 1443 */         this.D.b();
/*      */       }
/* 1445 */       a((bdz)null);
/* 1446 */       this.al = false;
/*      */     } 
/*      */     
/* 1449 */     this.B.a(null, 0.0F, 0.0F, 0.0F);
/* 1450 */     this.B.d();
/*      */     
/* 1452 */     this.e = parambds;
/*      */     
/* 1454 */     if (parambds != null) {
/* 1455 */       if (this.f != null) this.f.a(parambds); 
/* 1456 */       if (this.j != null) this.j.a((aab)parambds);
/*      */       
/* 1458 */       if (this.g == null) {
/* 1459 */         this.g = this.b.a((aab)parambds);
/* 1460 */         this.b.b((sq)this.g);
/*      */       } 
/*      */       
/* 1463 */       this.g.v();
/* 1464 */       parambds.d((mp)this.g);
/*      */       
/* 1466 */       this.g.b = (bfh)new bfi(this.z);
/*      */       
/* 1468 */       this.b.a((sq)this.g);
/* 1469 */       this.h = (ng)this.g;
/*      */     } else {
/* 1471 */       this.ac.d();
/* 1472 */       this.g = null;
/*      */     } 
/*      */     
/* 1475 */     System.gc();
/* 1476 */     this.I = 0L;
/*      */   }
/*      */   
/*      */   public void a(String paramString, File paramFile) {
/* 1480 */     int i = paramString.indexOf("/");
/* 1481 */     String str = paramString.substring(0, i);
/* 1482 */     paramString = paramString.substring(i + 1);
/*      */     
/* 1484 */     if (str.equalsIgnoreCase("sound3")) {
/* 1485 */       this.B.a(paramString, paramFile);
/* 1486 */     } else if (str.equalsIgnoreCase("streaming")) {
/* 1487 */       this.B.b(paramString, paramFile);
/* 1488 */     } else if (str.equalsIgnoreCase("music") || str.equalsIgnoreCase("newmusic")) {
/* 1489 */       this.B.c(paramString, paramFile);
/* 1490 */     } else if (str.equalsIgnoreCase("lang")) {
/* 1491 */       bp.a().a(paramString, paramFile);
/*      */     } 
/*      */   }
/*      */   
/*      */   public String m() {
/* 1496 */     return this.f.c();
/*      */   }
/*      */   
/*      */   public String n() {
/* 1500 */     return this.f.d();
/*      */   }
/*      */   
/*      */   public String o() {
/* 1504 */     return this.e.y();
/*      */   }
/*      */   
/*      */   public String p() {
/* 1508 */     return "P: " + this.j.b() + ". T: " + this.e.x();
/*      */   }
/*      */   
/*      */   public void a(int paramInt) {
/* 1512 */     this.e.f();
/* 1513 */     this.e.a();
/*      */     
/* 1515 */     int i = 0;
/* 1516 */     if (this.g != null) {
/* 1517 */       i = this.g.k;
/* 1518 */       this.e.e((mp)this.g);
/*      */     } 
/*      */     
/* 1521 */     this.h = null;
/* 1522 */     this.g = this.b.a((aab)this.e);
/* 1523 */     this.g.ar = paramInt;
/* 1524 */     this.h = (ng)this.g;
/* 1525 */     this.g.v();
/* 1526 */     this.e.d((mp)this.g);
/* 1527 */     this.b.b((sq)this.g);
/*      */     
/* 1529 */     this.g.b = (bfh)new bfi(this.z);
/* 1530 */     this.g.k = i;
/* 1531 */     this.b.a((sq)this.g);
/*      */     
/* 1533 */     if (this.s instanceof awp) a((axr)null); 
/*      */   }
/*      */   
/*      */   void a(boolean paramBoolean) {
/* 1537 */     this.aj = paramBoolean;
/*      */   }
/*      */   
/*      */   public final boolean q() {
/* 1541 */     return this.aj;
/*      */   }
/*      */   
/*      */   public bdk r() {
/* 1545 */     if (this.g != null) {
/* 1546 */       return this.g.a;
/*      */     }
/* 1548 */     return null;
/*      */   }
/*      */   
/*      */   public static void main(String[] paramArrayOfString) {
/* 1552 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/*      */ 
/*      */     
/* 1555 */     boolean bool1 = false;
/* 1556 */     boolean bool2 = true;
/* 1557 */     boolean bool3 = false;
/*      */     
/* 1559 */     String str1 = "Player" + (G() % 1000L);
/* 1560 */     String str2 = str1;
/* 1561 */     if (paramArrayOfString.length > 0) str2 = paramArrayOfString[0];
/*      */     
/* 1563 */     String str3 = "-";
/* 1564 */     if (paramArrayOfString.length > 1) str3 = paramArrayOfString[1]; 
/* 1565 */     ArrayList<String> arrayList = new ArrayList();
/*      */     
/* 1567 */     for (byte b1 = 2; b1 < paramArrayOfString.length; b1++) {
/* 1568 */       String str4 = paramArrayOfString[b1];
/* 1569 */       String str5 = (b1 == paramArrayOfString.length - 1) ? null : paramArrayOfString[b1 + 1];
/* 1570 */       boolean bool = false;
/*      */       
/* 1572 */       if (str4.equals("-demo") || str4.equals("--demo")) {
/* 1573 */         bool1 = true;
/* 1574 */       } else if (str4.equals("--applet")) {
/* 1575 */         bool2 = false;
/* 1576 */       } else if (str4.equals("--password") && str5 != null) {
/* 1577 */         String[] arrayOfString = kn.a(null, str2, str5);
/* 1578 */         if (arrayOfString != null) {
/* 1579 */           str2 = arrayOfString[0];
/* 1580 */           str3 = arrayOfString[1];
/* 1581 */           arrayList.add("Logged in insecurely as " + str2);
/*      */         } else {
/* 1583 */           arrayList.add("Could not log in as " + str2 + " with given password");
/*      */         } 
/* 1585 */         bool = true;
/*      */       } 
/*      */       
/* 1588 */       if (bool) {
/* 1589 */         b1++;
/*      */       }
/*      */     } 
/*      */     
/* 1593 */     if (str2.contains("@") && str3.length() <= 1) {
/* 1594 */       str2 = str1;
/*      */     }
/*      */ 
/*      */     
/* 1598 */     hashMap.put("demo", "" + bool1);
/* 1599 */     hashMap.put("stand-alone", "" + bool2);
/* 1600 */     hashMap.put("username", str2);
/* 1601 */     hashMap.put("fullscreen", "" + bool3);
/* 1602 */     hashMap.put("sessionid", str3);
/*      */ 
/*      */     
/* 1605 */     Frame frame = new Frame();
/* 1606 */     frame.setTitle("Minecraft");
/* 1607 */     frame.setBackground(Color.BLACK);
/*      */ 
/*      */ 
/*      */     
/* 1611 */     JPanel jPanel = new JPanel();
/* 1612 */     frame.setLayout(new BorderLayout());
/* 1613 */     jPanel.setPreferredSize(new Dimension(854, 480));
/* 1614 */     frame.add(jPanel, "Center");
/* 1615 */     frame.pack();
/*      */     
/* 1617 */     frame.setLocationRelativeTo((Component)null);
/* 1618 */     frame.setVisible(true);
/*      */     
/* 1620 */     frame.addWindowListener((WindowListener)new avp());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1659 */     avk avk = new avk(hashMap);
/* 1660 */     MinecraftApplet minecraftApplet = new MinecraftApplet();
/* 1661 */     minecraftApplet.setStub((AppletStub)avk);
/*      */     
/* 1663 */     avk.setLayout(new BorderLayout());
/* 1664 */     avk.add(minecraftApplet, "Center");
/* 1665 */     avk.validate();
/*      */     
/* 1667 */     frame.removeAll();
/* 1668 */     frame.setLayout(new BorderLayout());
/* 1669 */     frame.add((Component)avk, "Center");
/* 1670 */     frame.validate();
/*      */     
/* 1672 */     minecraftApplet.init();
/*      */     
/* 1674 */     for (String str : arrayList) {
/* 1675 */       x().al().a(str);
/*      */     }
/*      */     
/* 1678 */     minecraftApplet.start();
/*      */     
/* 1680 */     Runtime.getRuntime().addShutdownHook((Thread)new avq());
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean s() {
/* 1688 */     return (R == null || !R.z.Z);
/*      */   }
/*      */   
/*      */   public static boolean t() {
/* 1692 */     return (R != null && R.z.j);
/*      */   }
/*      */   
/*      */   public static boolean u() {
/* 1696 */     return (R != null && R.z.k != 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean c(String paramString) {
/* 1708 */     if (!paramString.startsWith("/")) {
/* 1709 */       return false;
/*      */     }
/*      */ 
/*      */     
/* 1713 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void O() {
/*      */     int i;
/* 1759 */     if (this.y == null) {
/*      */       return;
/*      */     }
/*      */     
/* 1763 */     boolean bool1 = this.g.ce.d;
/*      */     
/* 1765 */     int j = 0;
/* 1766 */     boolean bool2 = false;
/*      */     
/* 1768 */     if (this.y.a == arb.a) {
/* 1769 */       int k = this.y.b;
/* 1770 */       int m = this.y.c;
/* 1771 */       int n = this.y.d;
/*      */       
/* 1773 */       apa apa = apa.r[this.e.a(k, m, n)];
/* 1774 */       if (apa == null)
/*      */         return; 
/* 1776 */       i = apa.d((aab)this.e, k, m, n);
/* 1777 */       if (i == 0)
/* 1778 */         return;  bool2 = wk.f[i].m();
/*      */       
/* 1780 */       int i1 = (i >= 256 || apa.r[apa.cz].t_()) ? apa.cz : i;
/* 1781 */       j = apa.r[i1].h((aab)this.e, k, m, n);
/* 1782 */     } else if (this.y.a == arb.b && this.y.g != null && bool1) {
/* 1783 */       if (this.y.g instanceof np) {
/* 1784 */         i = wk.at.cp;
/* 1785 */       } else if (this.y.g instanceof nf) {
/* 1786 */         nf nf = (nf)this.y.g;
/* 1787 */         if (nf.i() == null) {
/* 1788 */           i = wk.bJ.cp;
/*      */         } else {
/* 1790 */           i = (nf.i()).c;
/* 1791 */           j = nf.i().k();
/* 1792 */           bool2 = true;
/*      */         } 
/* 1794 */       } else if (this.y.g instanceof ri) {
/* 1795 */         ri ri = (ri)this.y.g;
/*      */         
/* 1797 */         if (ri.l() == 2)
/* 1798 */         { i = wk.aP.cp; }
/* 1799 */         else if (ri.l() == 1)
/* 1800 */         { i = wk.aO.cp; }
/* 1801 */         else if (ri.l() == 3)
/* 1802 */         { i = wk.cb.cp; }
/* 1803 */         else if (ri.l() == 5)
/* 1804 */         { i = wk.cc.cp; }
/* 1805 */         else { i = wk.aA.cp; } 
/* 1806 */       } else if (this.y.g instanceof rf) {
/* 1807 */         i = wk.aF.cp;
/*      */       } else {
/* 1809 */         i = wk.bD.cp;
/* 1810 */         j = mv.a(this.y.g);
/* 1811 */         bool2 = true;
/*      */         
/* 1813 */         if (j <= 0 || !mv.a.containsKey(Integer.valueOf(j)))
/*      */           return; 
/*      */       } 
/*      */     } else {
/*      */       return;
/*      */     } 
/* 1819 */     this.g.bK.a(i, j, bool2, bool1);
/*      */     
/* 1821 */     if (bool1) {
/* 1822 */       int k = this.g.bL.c.size() - 9 + this.g.bK.c;
/* 1823 */       this.b.a(this.g.bK.a(this.g.bK.c), k);
/*      */     } 
/*      */   }
/*      */   
/*      */   public b b(b paramb) {
/* 1828 */     paramb.g().a("LWJGL", (Callable)new avr(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1834 */     paramb.g().a("OpenGL", (Callable)new avs(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1840 */     paramb.g().a("Is Modded", (Callable)new ave(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1849 */     paramb.g().a("Type", (Callable)new avf(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1855 */     paramb.g().a("Texture Pack", (Callable)new avg(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1861 */     paramb.g().a("Profiler Position", (Callable)new avh(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1867 */     paramb.g().a("Vec3 Pool Size", (Callable)new avi(this));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1880 */     if (this.e != null) {
/* 1881 */       this.e.a(paramb);
/*      */     }
/*      */     
/* 1884 */     return paramb;
/*      */   }
/*      */   
/*      */   public static Minecraft x() {
/* 1888 */     return R;
/*      */   }
/*      */   
/*      */   public void y() {
/* 1892 */     this.af = true;
/*      */   }
/*      */   
/*      */   public void a(ma paramma) {
/* 1896 */     paramma.a("fps", Integer.valueOf(ad));
/* 1897 */     paramma.a("texpack_name", this.D.e().c());
/* 1898 */     paramma.a("vsync_enabled", Boolean.valueOf(this.z.v));
/* 1899 */     paramma.a("display_frequency", Integer.valueOf(Display.getDisplayMode().getFrequency()));
/* 1900 */     paramma.a("display_type", this.S ? "fullscreen" : "windowed");
/*      */     
/* 1902 */     if (this.ab != null && this.ab.aj() != null) {
/* 1903 */       paramma.a("snooper_partner", this.ab.aj().f());
/*      */     }
/*      */   }
/*      */   
/*      */   public void b(ma paramma) {
/* 1908 */     paramma.a("opengl_version", GL11.glGetString(7938));
/* 1909 */     paramma.a("opengl_vendor", GL11.glGetString(7936));
/* 1910 */     paramma.a("client_brand", ClientBrandRetriever.getClientModName());
/* 1911 */     paramma.a("applet", Boolean.valueOf(this.n));
/*      */     
/* 1913 */     ContextCapabilities contextCapabilities = GLContext.getCapabilities();
/* 1914 */     paramma.a("gl_caps[ARB_multitexture]", Boolean.valueOf(contextCapabilities.GL_ARB_multitexture));
/* 1915 */     paramma.a("gl_caps[ARB_multisample]", Boolean.valueOf(contextCapabilities.GL_ARB_multisample));
/* 1916 */     paramma.a("gl_caps[ARB_texture_cube_map]", Boolean.valueOf(contextCapabilities.GL_ARB_texture_cube_map));
/* 1917 */     paramma.a("gl_caps[ARB_vertex_blend]", Boolean.valueOf(contextCapabilities.GL_ARB_vertex_blend));
/* 1918 */     paramma.a("gl_caps[ARB_matrix_palette]", Boolean.valueOf(contextCapabilities.GL_ARB_matrix_palette));
/* 1919 */     paramma.a("gl_caps[ARB_vertex_program]", Boolean.valueOf(contextCapabilities.GL_ARB_vertex_program));
/* 1920 */     paramma.a("gl_caps[ARB_vertex_shader]", Boolean.valueOf(contextCapabilities.GL_ARB_vertex_shader));
/* 1921 */     paramma.a("gl_caps[ARB_fragment_program]", Boolean.valueOf(contextCapabilities.GL_ARB_fragment_program));
/* 1922 */     paramma.a("gl_caps[ARB_fragment_shader]", Boolean.valueOf(contextCapabilities.GL_ARB_fragment_shader));
/* 1923 */     paramma.a("gl_caps[ARB_shader_objects]", Boolean.valueOf(contextCapabilities.GL_ARB_shader_objects));
/* 1924 */     paramma.a("gl_caps[ARB_vertex_buffer_object]", Boolean.valueOf(contextCapabilities.GL_ARB_vertex_buffer_object));
/* 1925 */     paramma.a("gl_caps[ARB_framebuffer_object]", Boolean.valueOf(contextCapabilities.GL_ARB_framebuffer_object));
/* 1926 */     paramma.a("gl_caps[ARB_pixel_buffer_object]", Boolean.valueOf(contextCapabilities.GL_ARB_pixel_buffer_object));
/* 1927 */     paramma.a("gl_caps[ARB_uniform_buffer_object]", Boolean.valueOf(contextCapabilities.GL_ARB_uniform_buffer_object));
/* 1928 */     paramma.a("gl_caps[ARB_texture_non_power_of_two]", Boolean.valueOf(contextCapabilities.GL_ARB_texture_non_power_of_two));
/*      */     
/* 1930 */     paramma.a("gl_caps[gl_max_vertex_uniforms]", Integer.valueOf(GL11.glGetInteger(35658)));
/* 1931 */     paramma.a("gl_caps[gl_max_fragment_uniforms]", Integer.valueOf(GL11.glGetInteger(35657)));
/*      */     
/* 1933 */     paramma.a("gl_max_texture_size", Integer.valueOf(z()));
/*      */   }
/*      */   
/*      */   public static int z() {
/* 1937 */     for (int i = 16384; i > 0; i >>= 1) {
/* 1938 */       GL11.glTexImage2D(32868, 0, 6408, i, i, 0, 6408, 5121, (ByteBuffer)null);
/* 1939 */       int j = GL11.glGetTexLevelParameteri(32868, 0, 4096);
/* 1940 */       if (j != 0) {
/* 1941 */         return i;
/*      */       }
/*      */     } 
/* 1944 */     return -1;
/*      */   }
/*      */   
/*      */   public boolean R() {
/* 1948 */     return this.z.t;
/*      */   }
/*      */   
/*      */   public void a(bdz parambdz) {
/* 1952 */     this.Q = parambdz;
/*      */   }
/*      */   
/*      */   public bdz A() {
/* 1956 */     return this.Q;
/*      */   }
/*      */   
/*      */   public boolean B() {
/* 1960 */     return this.al;
/*      */   }
/*      */   
/*      */   public boolean C() {
/* 1964 */     return (this.al && this.ab != null);
/*      */   }
/*      */   
/*      */   public bjg D() {
/* 1968 */     return this.ab;
/*      */   }
/*      */   
/*      */   public static void E() {
/* 1972 */     if (R == null)
/*      */       return; 
/* 1974 */     bjg bjg1 = R.D();
/* 1975 */     if (bjg1 != null) {
/* 1976 */       bjg1.k();
/*      */     }
/*      */   }
/*      */   
/*      */   public ma F() {
/* 1981 */     return this.W;
/*      */   }
/*      */   
/*      */   public static long G() {
/* 1985 */     return Sys.getTime() * 1000L / Sys.getTimerResolution();
/*      */   }
/*      */   
/*      */   public boolean H() {
/* 1989 */     return this.S;
/*      */   }
/*      */   
/*      */   public ku al() {
/* 1993 */     return this.P;
/*      */   }
/*      */   
/*      */   public abstract void d(b paramb);
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\net\minecraft\client\Minecraft.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */