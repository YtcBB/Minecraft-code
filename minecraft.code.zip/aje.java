/*    */ public class aje
/*    */   extends ait
/*    */ {
/*    */   public aje(long paramLong, ait paramait) {
/*  5 */     super(paramLong);
/*  6 */     this.a = paramait;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 11 */     paramInt1 -= 2;
/* 12 */     paramInt2 -= 2;
/* 13 */     byte b1 = 2;
/* 14 */     int i = 1 << b1;
/* 15 */     int j = paramInt1 >> b1;
/* 16 */     int k = paramInt2 >> b1;
/* 17 */     int m = (paramInt3 >> b1) + 3;
/* 18 */     int n = (paramInt4 >> b1) + 3;
/* 19 */     int[] arrayOfInt1 = this.a.a(j, k, m, n);
/*    */     
/* 21 */     int i1 = m << b1;
/* 22 */     int i2 = n << b1;
/* 23 */     int[] arrayOfInt2 = air.a(i1 * i2);
/* 24 */     for (byte b2 = 0; b2 < n - 1; b2++) {
/* 25 */       int i3 = arrayOfInt1[0 + (b2 + 0) * m];
/* 26 */       int i4 = arrayOfInt1[0 + (b2 + 1) * m];
/* 27 */       for (byte b = 0; b < m - 1; b++) {
/* 28 */         double d1 = i * 0.9D;
/* 29 */         a((b + j << b1), (b2 + k << b1));
/* 30 */         double d2 = (a(1024) / 1024.0D - 0.5D) * d1;
/* 31 */         double d3 = (a(1024) / 1024.0D - 0.5D) * d1;
/* 32 */         a((b + j + 1 << b1), (b2 + k << b1));
/* 33 */         double d4 = (a(1024) / 1024.0D - 0.5D) * d1 + i;
/* 34 */         double d5 = (a(1024) / 1024.0D - 0.5D) * d1;
/* 35 */         a((b + j << b1), (b2 + k + 1 << b1));
/* 36 */         double d6 = (a(1024) / 1024.0D - 0.5D) * d1;
/* 37 */         double d7 = (a(1024) / 1024.0D - 0.5D) * d1 + i;
/* 38 */         a((b + j + 1 << b1), (b2 + k + 1 << b1));
/* 39 */         double d8 = (a(1024) / 1024.0D - 0.5D) * d1 + i;
/* 40 */         double d9 = (a(1024) / 1024.0D - 0.5D) * d1 + i;
/*    */         
/* 42 */         int i5 = arrayOfInt1[b + 1 + (b2 + 0) * m];
/* 43 */         int i6 = arrayOfInt1[b + 1 + (b2 + 1) * m];
/*    */         
/* 45 */         for (byte b4 = 0; b4 < i; b4++) {
/* 46 */           int i7 = ((b2 << b1) + b4) * i1 + (b << b1);
/* 47 */           for (byte b5 = 0; b5 < i; b5++) {
/* 48 */             double d10 = (b4 - d3) * (b4 - d3) + (b5 - d2) * (b5 - d2);
/* 49 */             double d11 = (b4 - d5) * (b4 - d5) + (b5 - d4) * (b5 - d4);
/* 50 */             double d12 = (b4 - d7) * (b4 - d7) + (b5 - d6) * (b5 - d6);
/* 51 */             double d13 = (b4 - d9) * (b4 - d9) + (b5 - d8) * (b5 - d8);
/*    */             
/* 53 */             if (d10 < d11 && d10 < d12 && d10 < d13) {
/* 54 */               arrayOfInt2[i7++] = i3;
/* 55 */             } else if (d11 < d10 && d11 < d12 && d11 < d13) {
/* 56 */               arrayOfInt2[i7++] = i5;
/* 57 */             } else if (d12 < d10 && d12 < d11 && d12 < d13) {
/* 58 */               arrayOfInt2[i7++] = i4;
/*    */             } else {
/* 60 */               arrayOfInt2[i7++] = i6;
/*    */             } 
/*    */           } 
/*    */         } 
/*    */         
/* 65 */         i3 = i5;
/* 66 */         i4 = i6;
/*    */       } 
/*    */     } 
/* 69 */     int[] arrayOfInt3 = air.a(paramInt3 * paramInt4);
/* 70 */     for (byte b3 = 0; b3 < paramInt4; b3++) {
/* 71 */       System.arraycopy(arrayOfInt2, (b3 + (paramInt2 & i - 1)) * (m << b1) + (paramInt1 & i - 1), arrayOfInt3, b3 * paramInt3, paramInt3);
/*    */     }
/* 73 */     return arrayOfInt3;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aje.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */