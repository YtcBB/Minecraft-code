/*    */ 
/*    */ 
/*    */ 
/*    */ public abstract class ajo
/*    */ {
/*    */   public final String h;
/*    */   private boolean a;
/*    */   
/*    */   public ajo(String paramString) {
/* 10 */     this.h = paramString;
/*    */   }
/*    */   
/*    */   public abstract void a(bs parambs);
/*    */   
/*    */   public abstract void b(bs parambs);
/*    */   
/*    */   public void c() {
/* 18 */     a(true);
/*    */   }
/*    */   
/*    */   public void a(boolean paramBoolean) {
/* 22 */     this.a = paramBoolean;
/*    */   }
/*    */   
/*    */   public boolean d() {
/* 26 */     return this.a;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */