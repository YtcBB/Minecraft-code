/*    */ public class aas {
/*    */   private int a;
/*    */   private int b;
/*    */   private int c;
/*    */   private int d;
/*    */   private int e;
/*    */   private int f;
/*    */   
/*    */   public aas(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/* 10 */     this.a = paramInt1;
/* 11 */     this.b = paramInt2;
/* 12 */     this.c = paramInt3;
/* 13 */     this.e = paramInt5;
/* 14 */     this.f = paramInt6;
/* 15 */     this.d = paramInt4;
/*    */   }
/*    */   
/*    */   public int a() {
/* 19 */     return this.a;
/*    */   }
/*    */   
/*    */   public int b() {
/* 23 */     return this.b;
/*    */   }
/*    */   
/*    */   public int c() {
/* 27 */     return this.c;
/*    */   }
/*    */   
/*    */   public int d() {
/* 31 */     return this.e;
/*    */   }
/*    */   
/*    */   public int e() {
/* 35 */     return this.f;
/*    */   }
/*    */   
/*    */   public int f() {
/* 39 */     return this.d;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean equals(Object paramObject) {
/* 44 */     if (paramObject instanceof aas) {
/* 45 */       aas aas1 = (aas)paramObject;
/* 46 */       return (this.a == aas1.a && this.b == aas1.b && this.c == aas1.c && this.e == aas1.e && this.f == aas1.f && this.d == aas1.d);
/*    */     } 
/* 48 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public String toString() {
/* 53 */     return "TE(" + this.a + "," + this.b + "," + this.c + ")," + this.e + "," + this.f + "," + this.d;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aas.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */