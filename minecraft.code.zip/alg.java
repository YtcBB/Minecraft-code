/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class alg
/*     */   extends akz
/*     */ {
/*  22 */   private Random a = new Random();
/*     */   private lx b;
/*     */   
/*     */   public alg(int paramInt) {
/*  26 */     super(paramInt, aif.f);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  31 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  36 */     return 25;
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/*  40 */     return new apx();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  45 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/*  50 */     a(0.4375F, 0.0F, 0.4375F, 0.5625F, 0.875F, 0.5625F);
/*  51 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*  52 */     g();
/*  53 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/*  58 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.125F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  63 */     if (paramaab.I) {
/*  64 */       return true;
/*     */     }
/*  66 */     apx apx = (apx)paramaab.r(paramInt1, paramInt2, paramInt3);
/*  67 */     if (apx != null) paramsq.a(apx);
/*     */     
/*  69 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/*  74 */     if (paramwm.t()) {
/*  75 */       ((apx)paramaab.r(paramInt1, paramInt2, paramInt3)).a(paramwm.s());
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  81 */     double d1 = (paramInt1 + 0.4F + paramRandom.nextFloat() * 0.2F);
/*  82 */     double d2 = (paramInt2 + 0.7F + paramRandom.nextFloat() * 0.3F);
/*  83 */     double d3 = (paramInt3 + 0.4F + paramRandom.nextFloat() * 0.2F);
/*     */     
/*  85 */     paramaab.a("smoke", d1, d2, d3, 0.0D, 0.0D, 0.0D);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  90 */     aqp aqp = paramaab.r(paramInt1, paramInt2, paramInt3);
/*  91 */     if (aqp instanceof apx) {
/*  92 */       apx apx = (apx)aqp;
/*  93 */       for (byte b = 0; b < apx.j_(); b++) {
/*  94 */         wm wm = apx.a(b);
/*  95 */         if (wm != null) {
/*  96 */           float f1 = this.a.nextFloat() * 0.8F + 0.1F;
/*  97 */           float f2 = this.a.nextFloat() * 0.8F + 0.1F;
/*  98 */           float f3 = this.a.nextFloat() * 0.8F + 0.1F;
/*     */           
/* 100 */           while (wm.a > 0) {
/* 101 */             int i = this.a.nextInt(21) + 10;
/* 102 */             if (i > wm.a) i = wm.a; 
/* 103 */             wm.a -= i;
/*     */             
/* 105 */             rh rh = new rh(paramaab, (paramInt1 + f1), (paramInt2 + f2), (paramInt3 + f3), new wm(wm.c, i, wm.k()));
/* 106 */             float f = 0.05F;
/* 107 */             rh.x = ((float)this.a.nextGaussian() * f);
/* 108 */             rh.y = ((float)this.a.nextGaussian() * f + 0.2F);
/* 109 */             rh.z = ((float)this.a.nextGaussian() * f);
/* 110 */             paramaab.d(rh);
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/* 115 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 120 */     return wk.bz.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 125 */     return wk.bz.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean q_() {
/* 130 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 135 */     return tj.b((lt)paramaab.r(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   public void a(ly paramly) {
/* 139 */     super.a(paramly);
/* 140 */     this.b = paramly.a("brewingStand_base");
/*     */   }
/*     */   
/*     */   public lx i() {
/* 144 */     return this.b;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */