/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class amk
/*     */   extends apa
/*     */ {
/*     */   private final String a;
/*     */   
/*     */   public amk(int paramInt, String paramString, aif paramaif) {
/*  16 */     super(paramInt, paramaif);
/*  17 */     this.a = paramString;
/*  18 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/*  23 */     boolean bool1 = d(paramaab, paramInt1, paramInt2, paramInt3 - 1);
/*  24 */     boolean bool2 = d(paramaab, paramInt1, paramInt2, paramInt3 + 1);
/*  25 */     boolean bool3 = d(paramaab, paramInt1 - 1, paramInt2, paramInt3);
/*  26 */     boolean bool4 = d(paramaab, paramInt1 + 1, paramInt2, paramInt3);
/*     */     
/*  28 */     float f1 = 0.375F;
/*  29 */     float f2 = 0.625F;
/*  30 */     float f3 = 0.375F;
/*  31 */     float f4 = 0.625F;
/*     */     
/*  33 */     if (bool1) {
/*  34 */       f3 = 0.0F;
/*     */     }
/*  36 */     if (bool2) {
/*  37 */       f4 = 1.0F;
/*     */     }
/*  39 */     if (bool1 || bool2) {
/*  40 */       a(f1, 0.0F, f3, f2, 1.5F, f4);
/*  41 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     } 
/*  43 */     f3 = 0.375F;
/*  44 */     f4 = 0.625F;
/*  45 */     if (bool3) {
/*  46 */       f1 = 0.0F;
/*     */     }
/*  48 */     if (bool4) {
/*  49 */       f2 = 1.0F;
/*     */     }
/*  51 */     if (bool3 || bool4 || (!bool1 && !bool2)) {
/*  52 */       a(f1, 0.0F, f3, f2, 1.5F, f4);
/*  53 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     } 
/*     */     
/*  56 */     if (bool1) {
/*  57 */       f3 = 0.0F;
/*     */     }
/*  59 */     if (bool2) {
/*  60 */       f4 = 1.0F;
/*     */     }
/*     */     
/*  63 */     a(f1, 0.0F, f3, f2, 1.0F, f4);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  68 */     boolean bool1 = d(paramaak, paramInt1, paramInt2, paramInt3 - 1);
/*  69 */     boolean bool2 = d(paramaak, paramInt1, paramInt2, paramInt3 + 1);
/*  70 */     boolean bool3 = d(paramaak, paramInt1 - 1, paramInt2, paramInt3);
/*  71 */     boolean bool4 = d(paramaak, paramInt1 + 1, paramInt2, paramInt3);
/*     */     
/*  73 */     float f1 = 0.375F;
/*  74 */     float f2 = 0.625F;
/*  75 */     float f3 = 0.375F;
/*  76 */     float f4 = 0.625F;
/*     */     
/*  78 */     if (bool1) {
/*  79 */       f3 = 0.0F;
/*     */     }
/*  81 */     if (bool2) {
/*  82 */       f4 = 1.0F;
/*     */     }
/*  84 */     if (bool3) {
/*  85 */       f1 = 0.0F;
/*     */     }
/*  87 */     if (bool4) {
/*  88 */       f2 = 1.0F;
/*     */     }
/*     */     
/*  91 */     a(f1, 0.0F, f3, f2, 1.0F, f4);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  96 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/* 101 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 106 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 111 */     return 11;
/*     */   }
/*     */   
/*     */   public boolean d(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 115 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/* 116 */     if (i == this.cz || i == apa.bz.cz) {
/* 117 */       return true;
/*     */     }
/* 119 */     apa apa1 = apa.r[i];
/* 120 */     if (apa1 != null && 
/* 121 */       apa1.cO.k() && apa1.b()) {
/* 122 */       return (apa1.cO != aif.A);
/*     */     }
/*     */     
/* 125 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean l_(int paramInt) {
/* 129 */     return (paramInt == apa.bd.cz || paramInt == apa.bF.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 134 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 139 */     this.cQ = paramly.a(this.a);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */