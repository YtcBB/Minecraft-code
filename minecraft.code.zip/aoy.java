/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aoy
/*    */   extends apa
/*    */ {
/*    */   private lx a;
/*    */   private lx b;
/*    */   
/*    */   public aoy(int paramInt) {
/* 22 */     super(paramInt, aif.e);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 27 */     if (paramInt1 == 1) {
/* 28 */       return this.a;
/*    */     }
/* 30 */     if (paramInt1 == 0) {
/* 31 */       return apa.bN.m(paramInt1);
/*    */     }
/* 33 */     return this.cQ;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 38 */     this.cQ = paramly.a("endframe_side");
/* 39 */     this.a = paramly.a("endframe_top");
/* 40 */     this.b = paramly.a("endframe_eye");
/*    */   }
/*    */   
/*    */   public lx q() {
/* 44 */     return this.b;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 49 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public int d() {
/* 54 */     return 26;
/*    */   }
/*    */ 
/*    */   
/*    */   public void g() {
/* 59 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.8125F, 1.0F);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/* 64 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.8125F, 1.0F);
/* 65 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*    */     
/* 67 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 68 */     if (d(i)) {
/* 69 */       a(0.3125F, 0.8125F, 0.3125F, 0.6875F, 1.0F, 0.6875F);
/* 70 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*    */     } 
/* 72 */     g();
/*    */   }
/*    */   
/*    */   public static boolean d(int paramInt) {
/* 76 */     return ((paramInt & 0x4) != 0);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 81 */     return 0;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 86 */     int i = ((kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3) + 2) % 4;
/* 87 */     paramaab.b(paramInt1, paramInt2, paramInt3, i, 2);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */