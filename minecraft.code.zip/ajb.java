/*    */ 
/*    */ 
/*    */ public class ajb
/*    */   extends ait
/*    */ {
/*    */   public ajb(long paramLong, ait paramait) {
/*  7 */     super(paramLong);
/*  8 */     this.a = paramait;
/*    */   }
/*    */ 
/*    */   
/*    */   public int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 13 */     int[] arrayOfInt1 = this.a.a(paramInt1 - 1, paramInt2 - 1, paramInt3 + 2, paramInt4 + 2);
/*    */     
/* 15 */     int[] arrayOfInt2 = air.a(paramInt3 * paramInt4);
/* 16 */     for (byte b = 0; b < paramInt4; b++) {
/* 17 */       for (byte b1 = 0; b1 < paramInt3; b1++) {
/* 18 */         a((b1 + paramInt1), (b + paramInt2));
/* 19 */         int i = arrayOfInt1[b1 + 1 + (b + 1) * (paramInt3 + 2)];
/* 20 */         if ((i == aav.h.N && a(6) == 0) || ((i == aav.w.N || i == aav.x.N) && a(8) == 0)) {
/* 21 */           arrayOfInt2[b1 + b * paramInt3] = aav.i.N;
/*    */         } else {
/* 23 */           arrayOfInt2[b1 + b * paramInt3] = i;
/*    */         } 
/*    */       } 
/*    */     } 
/*    */     
/* 28 */     return arrayOfInt2;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */