/*    */ import java.util.ArrayList;
/*    */ import java.util.Collections;
/*    */ import java.util.List;
/*    */ 
/*    */ public class akv implements Runnable {
/*  6 */   public static final akv a = new akv();
/*    */   
/*  8 */   private List b = Collections.synchronizedList(new ArrayList());
/*    */   
/* 10 */   private volatile long c = 0L;
/* 11 */   private volatile long d = 0L;
/*    */   private volatile boolean e = false;
/*    */   
/*    */   private akv() {
/* 15 */     Thread thread = new Thread(this, "File IO Thread");
/* 16 */     thread.setPriority(1);
/* 17 */     thread.start();
/*    */   }
/*    */   
/*    */   public void run() {
/*    */     while (true) {
/* 22 */       b();
/*    */     }
/*    */   }
/*    */   
/*    */   private void b() {
/* 27 */     for (byte b = 0; b < this.b.size(); b++) {
/* 28 */       akw akw = this.b.get(b);
/* 29 */       boolean bool = akw.c();
/* 30 */       if (!bool) {
/* 31 */         this.b.remove(b--);
/* 32 */         this.d++;
/*    */       } 
/*    */       
/*    */       try {
/* 36 */         Thread.sleep(this.e ? 0L : 10L);
/* 37 */       } catch (InterruptedException interruptedException) {
/* 38 */         interruptedException.printStackTrace();
/*    */       } 
/*    */     } 
/* 41 */     if (this.b.isEmpty()) {
/*    */       try {
/* 43 */         Thread.sleep(25L);
/* 44 */       } catch (InterruptedException interruptedException) {
/* 45 */         interruptedException.printStackTrace();
/*    */       } 
/*    */     }
/*    */   }
/*    */   
/*    */   public void a(akw paramakw) {
/* 51 */     if (this.b.contains(paramakw))
/* 52 */       return;  this.c++;
/* 53 */     this.b.add(paramakw);
/*    */   }
/*    */   
/*    */   public void a() {
/* 57 */     this.e = true;
/* 58 */     while (this.c != this.d) {
/* 59 */       Thread.sleep(10L);
/*    */     }
/* 61 */     this.e = false;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\akv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */