/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aoq
/*     */   extends apa
/*     */ {
/*  18 */   private static final int[][] a = new int[][] { { 2, 6 }, { 3, 7 }, { 2, 3 }, { 6, 7 }, { 0, 4 }, { 1, 5 }, { 0, 1 }, { 4, 5 } };
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final apa b;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private final int c;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean d = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  41 */   private int e = 0;
/*     */   
/*     */   protected aoq(int paramInt1, apa paramapa, int paramInt2) {
/*  44 */     super(paramInt1, paramapa.cO);
/*  45 */     this.b = paramapa;
/*  46 */     this.c = paramInt2;
/*  47 */     c(paramapa.cA);
/*  48 */     b(paramapa.cB / 3.0F);
/*  49 */     a(paramapa.cM);
/*  50 */     k(255);
/*  51 */     a(ve.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  56 */     if (this.d) {
/*  57 */       a(0.5F * (this.e % 2), 0.5F * (this.e / 2 % 2), 0.5F * (this.e / 4 % 2), 0.5F + 0.5F * (this.e % 2), 0.5F + 0.5F * (this.e / 2 % 2), 0.5F + 0.5F * (this.e / 4 % 2));
/*     */     } else {
/*  59 */       a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  65 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  70 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  75 */     return 10;
/*     */   }
/*     */   
/*     */   public void d(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  79 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  81 */     if ((i & 0x4) != 0) {
/*  82 */       a(0.0F, 0.5F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */     } else {
/*  84 */       a(0.0F, 0.0F, 0.0F, 1.0F, 0.5F, 1.0F);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean d(int paramInt) {
/*  89 */     return (paramInt > 0 && apa.r[paramInt] instanceof aoq);
/*     */   }
/*     */   
/*     */   private boolean f(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  93 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/*  94 */     if (d(i) && paramaak.h(paramInt1, paramInt2, paramInt3) == paramInt4) {
/*  95 */       return true;
/*     */     }
/*     */     
/*  98 */     return false;
/*     */   }
/*     */   
/*     */   public boolean g(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 102 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 103 */     int j = i & 0x3;
/*     */     
/* 105 */     float f1 = 0.5F;
/* 106 */     float f2 = 1.0F;
/*     */     
/* 108 */     if ((i & 0x4) != 0) {
/* 109 */       f1 = 0.0F;
/* 110 */       f2 = 0.5F;
/*     */     } 
/*     */     
/* 113 */     float f3 = 0.0F;
/* 114 */     float f4 = 1.0F;
/* 115 */     float f5 = 0.0F;
/* 116 */     float f6 = 0.5F;
/*     */     
/* 118 */     boolean bool = true;
/*     */     
/* 120 */     if (j == 0) {
/* 121 */       f3 = 0.5F;
/* 122 */       f6 = 1.0F;
/*     */       
/* 124 */       int k = paramaak.a(paramInt1 + 1, paramInt2, paramInt3);
/* 125 */       int m = paramaak.h(paramInt1 + 1, paramInt2, paramInt3);
/* 126 */       if (d(k) && (i & 0x4) == (m & 0x4)) {
/* 127 */         int n = m & 0x3;
/* 128 */         if (n == 3 && !f(paramaak, paramInt1, paramInt2, paramInt3 + 1, i)) {
/* 129 */           f6 = 0.5F;
/* 130 */           bool = false;
/* 131 */         } else if (n == 2 && !f(paramaak, paramInt1, paramInt2, paramInt3 - 1, i)) {
/* 132 */           f5 = 0.5F;
/* 133 */           bool = false;
/*     */         } 
/*     */       } 
/* 136 */     } else if (j == 1) {
/* 137 */       f4 = 0.5F;
/* 138 */       f6 = 1.0F;
/*     */       
/* 140 */       int k = paramaak.a(paramInt1 - 1, paramInt2, paramInt3);
/* 141 */       int m = paramaak.h(paramInt1 - 1, paramInt2, paramInt3);
/* 142 */       if (d(k) && (i & 0x4) == (m & 0x4)) {
/* 143 */         int n = m & 0x3;
/* 144 */         if (n == 3 && !f(paramaak, paramInt1, paramInt2, paramInt3 + 1, i)) {
/* 145 */           f6 = 0.5F;
/* 146 */           bool = false;
/* 147 */         } else if (n == 2 && !f(paramaak, paramInt1, paramInt2, paramInt3 - 1, i)) {
/* 148 */           f5 = 0.5F;
/* 149 */           bool = false;
/*     */         } 
/*     */       } 
/* 152 */     } else if (j == 2) {
/* 153 */       f5 = 0.5F;
/* 154 */       f6 = 1.0F;
/*     */       
/* 156 */       int k = paramaak.a(paramInt1, paramInt2, paramInt3 + 1);
/* 157 */       int m = paramaak.h(paramInt1, paramInt2, paramInt3 + 1);
/* 158 */       if (d(k) && (i & 0x4) == (m & 0x4)) {
/* 159 */         int n = m & 0x3;
/* 160 */         if (n == 1 && !f(paramaak, paramInt1 + 1, paramInt2, paramInt3, i)) {
/* 161 */           f4 = 0.5F;
/* 162 */           bool = false;
/* 163 */         } else if (n == 0 && !f(paramaak, paramInt1 - 1, paramInt2, paramInt3, i)) {
/* 164 */           f3 = 0.5F;
/* 165 */           bool = false;
/*     */         } 
/*     */       } 
/* 168 */     } else if (j == 3) {
/* 169 */       int k = paramaak.a(paramInt1, paramInt2, paramInt3 - 1);
/* 170 */       int m = paramaak.h(paramInt1, paramInt2, paramInt3 - 1);
/* 171 */       if (d(k) && (i & 0x4) == (m & 0x4)) {
/* 172 */         int n = m & 0x3;
/* 173 */         if (n == 1 && !f(paramaak, paramInt1 + 1, paramInt2, paramInt3, i)) {
/* 174 */           f4 = 0.5F;
/* 175 */           bool = false;
/* 176 */         } else if (n == 0 && !f(paramaak, paramInt1 - 1, paramInt2, paramInt3, i)) {
/* 177 */           f3 = 0.5F;
/* 178 */           bool = false;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 183 */     a(f3, f1, f5, f4, f2, f6);
/* 184 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean h(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 192 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 193 */     int j = i & 0x3;
/*     */     
/* 195 */     float f1 = 0.5F;
/* 196 */     float f2 = 1.0F;
/*     */     
/* 198 */     if ((i & 0x4) != 0) {
/* 199 */       f1 = 0.0F;
/* 200 */       f2 = 0.5F;
/*     */     } 
/*     */     
/* 203 */     float f3 = 0.0F;
/* 204 */     float f4 = 0.5F;
/* 205 */     float f5 = 0.5F;
/* 206 */     float f6 = 1.0F;
/*     */     
/* 208 */     boolean bool = false;
/*     */     
/* 210 */     if (j == 0) {
/* 211 */       int k = paramaak.a(paramInt1 - 1, paramInt2, paramInt3);
/* 212 */       int m = paramaak.h(paramInt1 - 1, paramInt2, paramInt3);
/* 213 */       if (d(k) && (i & 0x4) == (m & 0x4)) {
/* 214 */         int n = m & 0x3;
/* 215 */         if (n == 3 && !f(paramaak, paramInt1, paramInt2, paramInt3 - 1, i)) {
/* 216 */           f5 = 0.0F;
/* 217 */           f6 = 0.5F;
/* 218 */           bool = true;
/* 219 */         } else if (n == 2 && !f(paramaak, paramInt1, paramInt2, paramInt3 + 1, i)) {
/* 220 */           f5 = 0.5F;
/* 221 */           f6 = 1.0F;
/* 222 */           bool = true;
/*     */         } 
/*     */       } 
/* 225 */     } else if (j == 1) {
/* 226 */       int k = paramaak.a(paramInt1 + 1, paramInt2, paramInt3);
/* 227 */       int m = paramaak.h(paramInt1 + 1, paramInt2, paramInt3);
/* 228 */       if (d(k) && (i & 0x4) == (m & 0x4)) {
/* 229 */         f3 = 0.5F;
/* 230 */         f4 = 1.0F;
/* 231 */         int n = m & 0x3;
/* 232 */         if (n == 3 && !f(paramaak, paramInt1, paramInt2, paramInt3 - 1, i)) {
/* 233 */           f5 = 0.0F;
/* 234 */           f6 = 0.5F;
/* 235 */           bool = true;
/* 236 */         } else if (n == 2 && !f(paramaak, paramInt1, paramInt2, paramInt3 + 1, i)) {
/* 237 */           f5 = 0.5F;
/* 238 */           f6 = 1.0F;
/* 239 */           bool = true;
/*     */         } 
/*     */       } 
/* 242 */     } else if (j == 2) {
/* 243 */       int k = paramaak.a(paramInt1, paramInt2, paramInt3 - 1);
/* 244 */       int m = paramaak.h(paramInt1, paramInt2, paramInt3 - 1);
/* 245 */       if (d(k) && (i & 0x4) == (m & 0x4)) {
/* 246 */         f5 = 0.0F;
/* 247 */         f6 = 0.5F;
/*     */         
/* 249 */         int n = m & 0x3;
/* 250 */         if (n == 1 && !f(paramaak, paramInt1 - 1, paramInt2, paramInt3, i)) {
/* 251 */           bool = true;
/* 252 */         } else if (n == 0 && !f(paramaak, paramInt1 + 1, paramInt2, paramInt3, i)) {
/* 253 */           f3 = 0.5F;
/* 254 */           f4 = 1.0F;
/* 255 */           bool = true;
/*     */         } 
/*     */       } 
/* 258 */     } else if (j == 3) {
/* 259 */       int k = paramaak.a(paramInt1, paramInt2, paramInt3 + 1);
/* 260 */       int m = paramaak.h(paramInt1, paramInt2, paramInt3 + 1);
/* 261 */       if (d(k) && (i & 0x4) == (m & 0x4)) {
/* 262 */         int n = m & 0x3;
/* 263 */         if (n == 1 && !f(paramaak, paramInt1 - 1, paramInt2, paramInt3, i)) {
/* 264 */           bool = true;
/* 265 */         } else if (n == 0 && !f(paramaak, paramInt1 + 1, paramInt2, paramInt3, i)) {
/* 266 */           f3 = 0.5F;
/* 267 */           f4 = 1.0F;
/* 268 */           bool = true;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 273 */     if (bool) {
/* 274 */       a(f3, f1, f5, f4, f2, f6);
/*     */     }
/* 276 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List paramList, mp parammp) {
/* 282 */     d(paramaab, paramInt1, paramInt2, paramInt3);
/* 283 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     
/* 285 */     boolean bool = g(paramaab, paramInt1, paramInt2, paramInt3);
/* 286 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     
/* 288 */     if (bool && 
/* 289 */       h(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 290 */       super.a(paramaab, paramInt1, paramInt2, paramInt3, paramaqx, paramList, parammp);
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 325 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 338 */     this.b.b(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {
/* 343 */     this.b.a(paramaab, paramInt1, paramInt2, paramInt3, paramsq);
/*     */   }
/*     */ 
/*     */   
/*     */   public void g(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 348 */     this.b.g(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int e(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 353 */     return this.b.e(paramaak, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public float f(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 358 */     return this.b.f(paramaak, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public float a(mp parammp) {
/* 363 */     return this.b.a(parammp);
/*     */   }
/*     */ 
/*     */   
/*     */   public int n() {
/* 368 */     return this.b.n();
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/* 373 */     return this.b.a(paramInt1, this.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/* 378 */     return this.b.a(paramaab);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 383 */     return this.b.c_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp, arc paramarc) {
/* 388 */     this.b.a(paramaab, paramInt1, paramInt2, paramInt3, parammp, paramarc);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean m() {
/* 393 */     return this.b.m();
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt, boolean paramBoolean) {
/* 398 */     return this.b.a(paramInt, paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 403 */     return this.b.c(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 408 */     a(paramaab, paramInt1, paramInt2, paramInt3, 0);
/* 409 */     this.b.a(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 414 */     this.b.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/* 424 */     this.b.b(paramaab, paramInt1, paramInt2, paramInt3, parammp);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 429 */     this.b.a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 434 */     return this.b.a(paramaab, paramInt1, paramInt2, paramInt3, paramsq, 0, 0.0F, 0.0F, 0.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, zw paramzw) {
/* 439 */     this.b.a(paramaab, paramInt1, paramInt2, paramInt3, paramzw);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/* 444 */     int i = kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3;
/* 445 */     int j = paramaab.h(paramInt1, paramInt2, paramInt3) & 0x4;
/*     */     
/* 447 */     if (i == 0) paramaab.b(paramInt1, paramInt2, paramInt3, 0x2 | j, 2); 
/* 448 */     if (i == 1) paramaab.b(paramInt1, paramInt2, paramInt3, 0x1 | j, 2); 
/* 449 */     if (i == 2) paramaab.b(paramInt1, paramInt2, paramInt3, 0x3 | j, 2); 
/* 450 */     if (i == 3) paramaab.b(paramInt1, paramInt2, paramInt3, 0x0 | j, 2);
/*     */   
/*     */   }
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/* 455 */     if (paramInt4 == 0 || (paramInt4 != 1 && paramFloat2 > 0.5D)) {
/* 456 */       return paramInt5 | 0x4;
/*     */     }
/* 458 */     return paramInt5;
/*     */   }
/*     */ 
/*     */   
/*     */   public ara a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, arc paramarc1, arc paramarc2) {
/* 463 */     ara[] arrayOfAra = new ara[8];
/* 464 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 465 */     int j = i & 0x3;
/* 466 */     boolean bool = ((i & 0x4) == 4) ? true : false;
/* 467 */     int[] arrayOfInt = a[j + (bool ? 4 : 0)];
/*     */     
/* 469 */     this.d = true;
/* 470 */     for (byte b = 0; b < 8; b++) {
/* 471 */       this.e = b;
/*     */       
/* 473 */       for (int k : arrayOfInt) {
/* 474 */         if (k == b);
/*     */       } 
/*     */       
/* 477 */       arrayOfAra[b] = super.a(paramaab, paramInt1, paramInt2, paramInt3, paramarc1, paramarc2);
/*     */     } 
/*     */     
/* 480 */     for (int k : arrayOfInt) {
/* 481 */       arrayOfAra[k] = null;
/*     */     }
/*     */     
/* 484 */     ara ara = null;
/* 485 */     double d = 0.0D;
/*     */     
/* 487 */     for (ara ara1 : arrayOfAra) {
/* 488 */       if (ara1 != null) {
/* 489 */         double d1 = ara1.f.e(paramarc2);
/*     */         
/* 491 */         if (d1 > d) {
/* 492 */           ara = ara1;
/* 493 */           d = d1;
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 498 */     return ara;
/*     */   }
/*     */   
/*     */   public void a(ly paramly) {}
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */