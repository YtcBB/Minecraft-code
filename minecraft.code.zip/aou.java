/*    */ import java.util.List;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aou
/*    */   extends amr
/*    */ {
/* 20 */   public static final String[] b = new String[] { "stone", "sand", "wood", "cobble", "brick", "smoothStoneBrick", "netherBrick", "quartz" };
/*    */ 
/*    */   
/*    */   private lx c;
/*    */ 
/*    */   
/*    */   public aou(int paramInt, boolean paramBoolean) {
/* 27 */     super(paramInt, paramBoolean, aif.e);
/* 28 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 33 */     int i = paramInt2 & 0x7;
/* 34 */     if (this.a && (paramInt2 & 0x8) != 0) {
/* 35 */       paramInt1 = 1;
/*    */     }
/* 37 */     if (i == 0) {
/* 38 */       if (paramInt1 == 1 || paramInt1 == 0) return this.cQ; 
/* 39 */       return this.c;
/* 40 */     }  if (i == 1)
/* 41 */       return apa.U.m(paramInt1); 
/* 42 */     if (i == 2)
/* 43 */       return apa.B.m(paramInt1); 
/* 44 */     if (i == 3)
/* 45 */       return apa.A.m(paramInt1); 
/* 46 */     if (i == 4)
/* 47 */       return apa.ap.m(paramInt1); 
/* 48 */     if (i == 5)
/* 49 */       return apa.bq.a(paramInt1, 0); 
/* 50 */     if (i == 6)
/* 51 */       return apa.bE.m(1); 
/* 52 */     if (i == 7) {
/* 53 */       return apa.cv.m(paramInt1);
/*    */     }
/*    */     
/* 56 */     return this.cQ;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 61 */     this.cQ = paramly.a("stoneslab_top");
/* 62 */     this.c = paramly.a("stoneslab_side");
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 67 */     return apa.ao.cz;
/*    */   }
/*    */ 
/*    */   
/*    */   protected wm c_(int paramInt) {
/* 72 */     return new wm(apa.ao.cz, 2, paramInt & 0x7);
/*    */   }
/*    */ 
/*    */   
/*    */   public String c(int paramInt) {
/* 77 */     if (paramInt < 0 || paramInt >= b.length) {
/* 78 */       paramInt = 0;
/*    */     }
/* 80 */     return a() + "." + b[paramInt];
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 85 */     if (paramInt == apa.an.cz)
/*    */       return; 
/* 87 */     for (byte b = 0; b <= 7; b++) {
/* 88 */       if (b != 2)
/*    */       {
/* 90 */         paramList.add(new wm(paramInt, 1, b));
/*    */       }
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aou.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */