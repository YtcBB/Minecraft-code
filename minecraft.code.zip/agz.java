/*    */ import java.util.Arrays;
/*    */ import java.util.List;
/*    */ import java.util.Map;
/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class agz
/*    */   extends ags
/*    */ {
/* 14 */   public static final List e = Arrays.asList(new aav[] { aav.c, aav.d });
/*    */   
/* 16 */   private int f = 0;
/* 17 */   private int g = 32;
/* 18 */   private int h = 8;
/*    */ 
/*    */   
/*    */   public agz() {}
/*    */ 
/*    */   
/*    */   public agz(Map paramMap) {
/* 25 */     this();
/*    */     
/* 27 */     for (Map.Entry entry : paramMap.entrySet()) {
/* 28 */       if (((String)entry.getKey()).equals("size")) {
/* 29 */         this.f = kx.a((String)entry.getValue(), this.f, 0); continue;
/* 30 */       }  if (((String)entry.getKey()).equals("distance")) {
/* 31 */         this.g = kx.a((String)entry.getValue(), this.g, this.h + 1);
/*    */       }
/*    */     } 
/*    */   }
/*    */ 
/*    */   
/*    */   protected boolean a(int paramInt1, int paramInt2) {
/* 38 */     int i = paramInt1;
/* 39 */     int j = paramInt2;
/* 40 */     if (paramInt1 < 0) paramInt1 -= this.g - 1; 
/* 41 */     if (paramInt2 < 0) paramInt2 -= this.g - 1;
/*    */     
/* 43 */     int k = paramInt1 / this.g;
/* 44 */     int m = paramInt2 / this.g;
/* 45 */     Random random = this.c.H(k, m, 10387312);
/* 46 */     k *= this.g;
/* 47 */     m *= this.g;
/* 48 */     k += random.nextInt(this.g - this.h);
/* 49 */     m += random.nextInt(this.g - this.h);
/* 50 */     paramInt1 = i;
/* 51 */     paramInt2 = j;
/*    */     
/* 53 */     if (paramInt1 == k && paramInt2 == m) {
/* 54 */       boolean bool = this.c.u().a(paramInt1 * 16 + 8, paramInt2 * 16 + 8, 0, e);
/* 55 */       if (bool) {
/* 56 */         return true;
/*    */       }
/*    */     } 
/*    */     
/* 60 */     return false;
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected agy b(int paramInt1, int paramInt2) {
/* 66 */     return new aha(this.c, this.b, paramInt1, paramInt2, this.f);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\agz.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */