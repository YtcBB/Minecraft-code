/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ait
/*     */ {
/*     */   private long b;
/*     */   protected ait a;
/*     */   private long c;
/*     */   private long d;
/*     */   
/*     */   public static ait[] a(long paramLong, aal paramaal) {
/*  13 */     ais ais = new ais(1L);
/*  14 */     aiq aiq = new aiq(2000L, ais);
/*  15 */     aij aij4 = new aij(1L, aiq);
/*  16 */     ajf ajf3 = new ajf(2001L, aij4);
/*  17 */     aij aij3 = new aij(2L, ajf3);
/*  18 */     ail ail = new ail(2L, aij3);
/*  19 */     ajf ajf2 = new ajf(2002L, ail);
/*  20 */     aij aij2 = new aij(3L, ajf2);
/*  21 */     ajf ajf1 = new ajf(2003L, aij2);
/*  22 */     aij aij1 = new aij(4L, ajf1);
/*  23 */     aik aik1 = new aik(5L, aij1);
/*     */     
/*  25 */     byte b1 = 4;
/*  26 */     if (paramaal == aal.d) {
/*  27 */       b1 = 6;
/*     */     }
/*     */     
/*  30 */     aik aik2 = aik1;
/*  31 */     ait ait1 = ajf.a(1000L, aik2, 0);
/*  32 */     ait1 = new aiv(100L, ait1);
/*  33 */     ait1 = ajf.a(1000L, ait1, b1 + 2);
/*  34 */     ait1 = new aiw(1L, ait1);
/*  35 */     ait1 = new aiz(1000L, ait1);
/*     */     
/*  37 */     aik aik3 = aik1;
/*  38 */     ait ait2 = ajf.a(1000L, aik3, 0);
/*  39 */     ait2 = new aim(200L, ait2, paramaal);
/*  40 */     ait2 = ajf.a(1000L, ait2, 2);
/*  41 */     ait2 = new aiu(1000L, ait2);
/*     */     
/*  43 */     for (byte b2 = 0; b2 < b1; b2++) {
/*  44 */       ait2 = new ajf((1000 + b2), ait2);
/*  45 */       if (b2 == 0) ait2 = new aij(3L, ait2);
/*     */       
/*  47 */       if (b2 == 1) {
/*  48 */         ait2 = new aiy(1000L, ait2);
/*     */       }
/*  50 */       if (b2 == 1) {
/*  51 */         ait2 = new ajb(1000L, ait2);
/*     */       }
/*     */     } 
/*     */     
/*  55 */     ait2 = new aiz(1000L, ait2);
/*     */     
/*  57 */     ait2 = new aix(100L, ait2, ait1);
/*     */     
/*  59 */     ait ait3 = ait2;
/*  60 */     aje aje = new aje(10L, ait2);
/*     */     
/*  62 */     ait2.a(paramLong);
/*  63 */     aje.a(paramLong);
/*     */     
/*  65 */     return new ait[] { ait2, aje, ait3 };
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public ait(long paramLong) {
/*  71 */     this.d = paramLong;
/*  72 */     this.d *= this.d * 6364136223846793005L + 1442695040888963407L;
/*  73 */     this.d += paramLong;
/*  74 */     this.d *= this.d * 6364136223846793005L + 1442695040888963407L;
/*  75 */     this.d += paramLong;
/*  76 */     this.d *= this.d * 6364136223846793005L + 1442695040888963407L;
/*  77 */     this.d += paramLong;
/*     */   }
/*     */   
/*     */   public void a(long paramLong) {
/*  81 */     this.b = paramLong;
/*  82 */     if (this.a != null) this.a.a(paramLong); 
/*  83 */     this.b *= this.b * 6364136223846793005L + 1442695040888963407L;
/*  84 */     this.b += this.d;
/*  85 */     this.b *= this.b * 6364136223846793005L + 1442695040888963407L;
/*  86 */     this.b += this.d;
/*  87 */     this.b *= this.b * 6364136223846793005L + 1442695040888963407L;
/*  88 */     this.b += this.d;
/*     */   }
/*     */   
/*     */   public void a(long paramLong1, long paramLong2) {
/*  92 */     this.c = this.b;
/*  93 */     this.c *= this.c * 6364136223846793005L + 1442695040888963407L;
/*  94 */     this.c += paramLong1;
/*  95 */     this.c *= this.c * 6364136223846793005L + 1442695040888963407L;
/*  96 */     this.c += paramLong2;
/*  97 */     this.c *= this.c * 6364136223846793005L + 1442695040888963407L;
/*  98 */     this.c += paramLong1;
/*  99 */     this.c *= this.c * 6364136223846793005L + 1442695040888963407L;
/* 100 */     this.c += paramLong2;
/*     */   }
/*     */   
/*     */   protected int a(int paramInt) {
/* 104 */     int i = (int)((this.c >> 24L) % paramInt);
/* 105 */     if (i < 0) i += paramInt; 
/* 106 */     this.c *= this.c * 6364136223846793005L + 1442695040888963407L;
/* 107 */     this.c += this.b;
/* 108 */     return i;
/*     */   }
/*     */   
/*     */   public abstract int[] a(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ait.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */