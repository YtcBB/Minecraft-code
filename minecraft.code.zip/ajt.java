/*     */ import java.io.DataInputStream;
/*     */ import java.io.DataOutputStream;
/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.io.IOException;
/*     */ import net.minecraft.server.MinecraftServer;
/*     */ 
/*     */ 
/*     */ public class ajt
/*     */   implements akf, akt
/*     */ {
/*     */   private final File a;
/*     */   private final File b;
/*     */   private final File c;
/*  16 */   private final long d = System.currentTimeMillis();
/*     */   private final String e;
/*     */   
/*     */   public ajt(File paramFile, String paramString, boolean paramBoolean) {
/*  20 */     this.a = new File(paramFile, paramString);
/*  21 */     this.a.mkdirs();
/*  22 */     this.b = new File(this.a, "players");
/*  23 */     this.c = new File(this.a, "data");
/*  24 */     this.c.mkdirs();
/*  25 */     this.e = paramString;
/*     */     
/*  27 */     if (paramBoolean) {
/*  28 */       this.b.mkdirs();
/*     */     }
/*     */     
/*  31 */     h();
/*     */   }
/*     */   
/*     */   private void h() {
/*     */     try {
/*  36 */       File file = new File(this.a, "session.lock");
/*  37 */       DataOutputStream dataOutputStream = new DataOutputStream(new FileOutputStream(file));
/*     */       try {
/*  39 */         dataOutputStream.writeLong(this.d);
/*     */       } finally {
/*  41 */         dataOutputStream.close();
/*     */       } 
/*  43 */     } catch (IOException iOException) {
/*  44 */       iOException.printStackTrace();
/*  45 */       throw new RuntimeException("Failed to check session lock, aborting");
/*     */     } 
/*     */   }
/*     */   
/*     */   protected File b() {
/*  50 */     return this.a;
/*     */   }
/*     */   
/*     */   public void c() {
/*     */     try {
/*  55 */       File file = new File(this.a, "session.lock");
/*  56 */       DataInputStream dataInputStream = new DataInputStream(new FileInputStream(file));
/*     */       try {
/*  58 */         if (dataInputStream.readLong() != this.d) {
/*  59 */           throw new aaf("The save is being accessed from another location, aborting");
/*     */         }
/*     */       } finally {
/*  62 */         dataInputStream.close();
/*     */       } 
/*  64 */     } catch (IOException iOException) {
/*  65 */       throw new aaf("Failed to check session lock, aborting");
/*     */     } 
/*     */   }
/*     */   
/*     */   public acb a(acn paramacn) {
/*  70 */     throw new RuntimeException("Old Chunk Storage is no longer supported.");
/*     */   }
/*     */   
/*     */   public ajv d() {
/*  74 */     File file = new File(this.a, "level.dat");
/*  75 */     if (file.exists()) {
/*     */       try {
/*  77 */         bs bs1 = cc.a(new FileInputStream(file));
/*  78 */         bs bs2 = bs1.l("Data");
/*     */         
/*  80 */         return new ajv(bs2);
/*     */       }
/*  82 */       catch (Exception exception) {
/*  83 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*  86 */     file = new File(this.a, "level.dat_old");
/*  87 */     if (file.exists()) {
/*     */       try {
/*  89 */         bs bs1 = cc.a(new FileInputStream(file));
/*  90 */         bs bs2 = bs1.l("Data");
/*     */         
/*  92 */         return new ajv(bs2);
/*     */       }
/*  94 */       catch (Exception exception) {
/*  95 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*  98 */     return null;
/*     */   }
/*     */   
/*     */   public void a(ajv paramajv, bs parambs) {
/* 102 */     bs bs1 = paramajv.a(parambs);
/*     */     
/* 104 */     bs bs2 = new bs();
/* 105 */     bs2.a("Data", bs1);
/*     */     
/*     */     try {
/* 108 */       File file1 = new File(this.a, "level.dat_new");
/* 109 */       File file2 = new File(this.a, "level.dat_old");
/* 110 */       File file3 = new File(this.a, "level.dat");
/*     */       
/* 112 */       cc.a(bs2, new FileOutputStream(file1));
/*     */       
/* 114 */       if (file2.exists()) file2.delete(); 
/* 115 */       file3.renameTo(file2);
/* 116 */       if (file3.exists()) file3.delete(); 
/* 117 */       file1.renameTo(file3);
/* 118 */       if (file1.exists()) file1.delete(); 
/* 119 */     } catch (Exception exception) {
/* 120 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void a(ajv paramajv) {
/* 125 */     bs bs1 = paramajv.a();
/*     */     
/* 127 */     bs bs2 = new bs();
/* 128 */     bs2.a("Data", bs1);
/*     */     
/*     */     try {
/* 131 */       File file1 = new File(this.a, "level.dat_new");
/* 132 */       File file2 = new File(this.a, "level.dat_old");
/* 133 */       File file3 = new File(this.a, "level.dat");
/*     */       
/* 135 */       cc.a(bs2, new FileOutputStream(file1));
/*     */       
/* 137 */       if (file2.exists()) file2.delete(); 
/* 138 */       file3.renameTo(file2);
/* 139 */       if (file3.exists()) file3.delete(); 
/* 140 */       file1.renameTo(file3);
/* 141 */       if (file1.exists()) file1.delete(); 
/* 142 */     } catch (Exception exception) {
/* 143 */       exception.printStackTrace();
/*     */     } 
/*     */   }
/*     */   
/*     */   public void a(sq paramsq) {
/*     */     try {
/* 149 */       bs bs = new bs();
/* 150 */       paramsq.e(bs);
/* 151 */       File file1 = new File(this.b, paramsq.bS + ".dat.tmp");
/* 152 */       File file2 = new File(this.b, paramsq.bS + ".dat");
/* 153 */       cc.a(bs, new FileOutputStream(file1));
/* 154 */       if (file2.exists()) file2.delete(); 
/* 155 */       file1.renameTo(file2);
/* 156 */     } catch (Exception exception) {
/* 157 */       MinecraftServer.D().al().b("Failed to save player data for " + paramsq.bS);
/*     */     } 
/*     */   }
/*     */   
/*     */   public bs b(sq paramsq) {
/* 162 */     bs bs = a(paramsq.bS);
/* 163 */     if (bs != null) {
/* 164 */       paramsq.f(bs);
/*     */     }
/* 166 */     return bs;
/*     */   }
/*     */   
/*     */   public bs a(String paramString) {
/*     */     try {
/* 171 */       File file = new File(this.b, paramString + ".dat");
/* 172 */       if (file.exists()) {
/* 173 */         return cc.a(new FileInputStream(file));
/*     */       }
/* 175 */     } catch (Exception exception) {
/* 176 */       MinecraftServer.D().al().b("Failed to load player data for " + paramString);
/*     */     } 
/* 178 */     return null;
/*     */   }
/*     */   
/*     */   public akt e() {
/* 182 */     return this;
/*     */   }
/*     */   
/*     */   public String[] f() {
/* 186 */     String[] arrayOfString = this.b.list();
/*     */     
/* 188 */     for (byte b = 0; b < arrayOfString.length; b++) {
/* 189 */       if (arrayOfString[b].endsWith(".dat")) {
/* 190 */         arrayOfString[b] = arrayOfString[b].substring(0, arrayOfString[b].length() - 4);
/*     */       }
/*     */     } 
/*     */     
/* 194 */     return arrayOfString;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a() {}
/*     */   
/*     */   public File b(String paramString) {
/* 201 */     return new File(this.c, paramString + ".dat");
/*     */   }
/*     */   
/*     */   public String g() {
/* 205 */     return this.e;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ajt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */