/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aqm
/*    */   extends aqp
/*    */ {
/* 11 */   public String[] a = new String[] { "", "", "", "" };
/*    */ 
/*    */   
/* 14 */   public int b = -1;
/*    */   
/*    */   private boolean c = true;
/*    */   
/*    */   public void b(bs parambs) {
/* 19 */     super.b(parambs);
/* 20 */     parambs.a("Text1", this.a[0]);
/* 21 */     parambs.a("Text2", this.a[1]);
/* 22 */     parambs.a("Text3", this.a[2]);
/* 23 */     parambs.a("Text4", this.a[3]);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(bs parambs) {
/* 28 */     this.c = false;
/* 29 */     super.a(parambs);
/* 30 */     for (byte b = 0; b < 4; b++) {
/* 31 */       this.a[b] = parambs.i("Text" + (b + 1));
/* 32 */       if (this.a[b].length() > 15) this.a[b] = this.a[b].substring(0, 15);
/*    */     
/*    */     } 
/*    */   }
/*    */   
/*    */   public ei m() {
/* 38 */     String[] arrayOfString = new String[4];
/* 39 */     System.arraycopy(this.a, 0, arrayOfString, 0, 4);
/* 40 */     return new fj(this.l, this.m, this.n, arrayOfString);
/*    */   }
/*    */   
/*    */   public boolean a() {
/* 44 */     return this.c;
/*    */   }
/*    */   
/*    */   public void a(boolean paramBoolean) {
/* 48 */     this.c = paramBoolean;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aqm.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */