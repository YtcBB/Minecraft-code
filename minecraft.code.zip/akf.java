import java.io.File;

public interface akf {
  ajv d();
  
  void c();
  
  acb a(acn paramacn);
  
  void a(ajv paramajv, bs parambs);
  
  void a(ajv paramajv);
  
  akt e();
  
  void a();
  
  File b(String paramString);
  
  String g();
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\akf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */