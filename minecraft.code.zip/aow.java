/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aow
/*     */   extends alh
/*     */ {
/*  14 */   private static final String[] a = new String[] { "deadbush", "tallgrass", "fern" };
/*     */ 
/*     */ 
/*     */   
/*     */   private lx[] b;
/*     */ 
/*     */ 
/*     */   
/*     */   protected aow(int paramInt) {
/*  23 */     super(paramInt, aif.l);
/*  24 */     float f = 0.4F;
/*  25 */     a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.8F, 0.5F + f);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  30 */     if (paramInt2 >= this.b.length) paramInt2 = 0; 
/*  31 */     return this.b[paramInt2];
/*     */   }
/*     */ 
/*     */   
/*     */   public int o() {
/*  36 */     double d1 = 0.5D;
/*  37 */     double d2 = 1.0D;
/*     */     
/*  39 */     return aaa.a(d1, d2);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(int paramInt) {
/*  44 */     if (paramInt == 0) return 16777215;
/*     */     
/*  46 */     return zx.c();
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  51 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/*  52 */     if (i == 0) return 16777215;
/*     */     
/*  54 */     return paramaak.a(paramInt1, paramInt3).k();
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  59 */     if (paramRandom.nextInt(8) == 0) {
/*  60 */       return wk.T.cp;
/*     */     }
/*     */     
/*  63 */     return -1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt, Random paramRandom) {
/*  68 */     return 1 + paramRandom.nextInt(paramInt * 2 + 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  73 */     if (!paramaab.I && paramsq.cd() != null && (paramsq.cd()).c == wk.bf.cp) {
/*  74 */       paramsq.a(kf.C[this.cz], 1);
/*     */ 
/*     */       
/*  77 */       b(paramaab, paramInt1, paramInt2, paramInt3, new wm(apa.ab, 1, paramInt4));
/*     */     } else {
/*  79 */       super.a(paramaab, paramsq, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int h(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  85 */     return paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/*  90 */     for (byte b = 1; b < 3; b++) {
/*  91 */       paramList.add(new wm(paramInt, 1, b));
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/*  97 */     this.b = new lx[a.length];
/*     */     
/*  99 */     for (byte b = 0; b < this.b.length; b++)
/* 100 */       this.b[b] = paramly.a(a[b]); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aow.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */