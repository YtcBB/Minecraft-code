/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aov
/*    */   extends apa
/*    */ {
/*    */   public aov(int paramInt) {
/* 10 */     super(paramInt, aif.e);
/* 11 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 16 */     return apa.A.cz;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aov.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */