/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ali
/*     */   extends apa
/*     */ {
/*     */   private final boolean a;
/*     */   
/*     */   protected ali(int paramInt, boolean paramBoolean) {
/*  20 */     super(paramInt, aif.q);
/*  21 */     b(true);
/*  22 */     a(ve.d);
/*  23 */     this.a = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  31 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  36 */     return this.a ? 30 : 20;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  45 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  55 */     if (paramInt4 == 2 && paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) return true; 
/*  56 */     if (paramInt4 == 3 && paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) return true; 
/*  57 */     if (paramInt4 == 4 && paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) return true; 
/*  58 */     if (paramInt4 == 5 && paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) return true; 
/*  59 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  64 */     if (paramaab.u(paramInt1 - 1, paramInt2, paramInt3))
/*  65 */       return true; 
/*  66 */     if (paramaab.u(paramInt1 + 1, paramInt2, paramInt3))
/*  67 */       return true; 
/*  68 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 - 1))
/*  69 */       return true; 
/*  70 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) {
/*  71 */       return true;
/*     */     }
/*  73 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  78 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*     */     
/*  80 */     int j = i & 0x8;
/*  81 */     i &= 0x7;
/*     */     
/*  83 */     if (paramInt4 == 2 && paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) { i = 4; }
/*  84 */     else if (paramInt4 == 3 && paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) { i = 3; }
/*  85 */     else if (paramInt4 == 4 && paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) { i = 2; }
/*  86 */     else if (paramInt4 == 5 && paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) { i = 1; }
/*  87 */     else { i = k(paramaab, paramInt1, paramInt2, paramInt3); }
/*     */     
/*  89 */     return i + j;
/*     */   }
/*     */   
/*     */   private int k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  93 */     if (paramaab.u(paramInt1 - 1, paramInt2, paramInt3))
/*  94 */       return 1; 
/*  95 */     if (paramaab.u(paramInt1 + 1, paramInt2, paramInt3))
/*  96 */       return 2; 
/*  97 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 - 1))
/*  98 */       return 3; 
/*  99 */     if (paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) {
/* 100 */       return 4;
/*     */     }
/* 102 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 107 */     if (m(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 108 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3) & 0x7;
/* 109 */       boolean bool = false;
/*     */       
/* 111 */       if (!paramaab.u(paramInt1 - 1, paramInt2, paramInt3) && i == 1) bool = true; 
/* 112 */       if (!paramaab.u(paramInt1 + 1, paramInt2, paramInt3) && i == 2) bool = true; 
/* 113 */       if (!paramaab.u(paramInt1, paramInt2, paramInt3 - 1) && i == 3) bool = true; 
/* 114 */       if (!paramaab.u(paramInt1, paramInt2, paramInt3 + 1) && i == 4) bool = true;
/*     */       
/* 116 */       if (bool) {
/* 117 */         c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 118 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   private boolean m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 124 */     if (!c(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 125 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 126 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/* 127 */       return false;
/*     */     } 
/* 129 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 134 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 135 */     d(i);
/*     */   }
/*     */   
/*     */   private void d(int paramInt) {
/* 139 */     int i = paramInt & 0x7;
/* 140 */     boolean bool = ((paramInt & 0x8) > 0) ? true : false;
/*     */     
/* 142 */     float f1 = 0.375F;
/* 143 */     float f2 = 0.625F;
/* 144 */     float f3 = 0.1875F;
/* 145 */     float f4 = 0.125F;
/* 146 */     if (bool) f4 = 0.0625F;
/*     */     
/* 148 */     if (i == 1) {
/* 149 */       a(0.0F, f1, 0.5F - f3, f4, f2, 0.5F + f3);
/* 150 */     } else if (i == 2) {
/* 151 */       a(1.0F - f4, f1, 0.5F - f3, 1.0F, f2, 0.5F + f3);
/* 152 */     } else if (i == 3) {
/* 153 */       a(0.5F - f3, f1, 0.0F, 0.5F + f3, f2, f4);
/* 154 */     } else if (i == 4) {
/* 155 */       a(0.5F - f3, f1, 1.0F - f4, 0.5F + f3, f2, 1.0F);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 166 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 167 */     int j = i & 0x7;
/* 168 */     int k = 8 - (i & 0x8);
/* 169 */     if (k == 0) return true;
/*     */     
/* 171 */     paramaab.b(paramInt1, paramInt2, paramInt3, j + k, 3);
/* 172 */     paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     
/* 174 */     paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "random.click", 0.3F, 0.6F);
/*     */     
/* 176 */     d(paramaab, paramInt1, paramInt2, paramInt3, j);
/*     */     
/* 178 */     paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */     
/* 180 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 185 */     if ((paramInt5 & 0x8) > 0) {
/* 186 */       int i = paramInt5 & 0x7;
/* 187 */       d(paramaab, paramInt1, paramInt2, paramInt3, i);
/*     */     } 
/* 189 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 194 */     return ((paramaak.h(paramInt1, paramInt2, paramInt3) & 0x8) > 0) ? 15 : 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 199 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 200 */     if ((i & 0x8) == 0) return 0; 
/* 201 */     int j = i & 0x7;
/*     */     
/* 203 */     if (j == 5 && paramInt4 == 1) return 15; 
/* 204 */     if (j == 4 && paramInt4 == 2) return 15; 
/* 205 */     if (j == 3 && paramInt4 == 3) return 15; 
/* 206 */     if (j == 2 && paramInt4 == 4) return 15; 
/* 207 */     if (j == 1 && paramInt4 == 5) return 15;
/*     */     
/* 209 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f() {
/* 214 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 219 */     if (paramaab.I)
/* 220 */       return;  int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 221 */     if ((i & 0x8) == 0) {
/*     */       return;
/*     */     }
/* 224 */     if (this.a) {
/* 225 */       n(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     } else {
/* 227 */       paramaab.b(paramInt1, paramInt2, paramInt3, i & 0x7, 3);
/*     */       
/* 229 */       int j = i & 0x7;
/* 230 */       d(paramaab, paramInt1, paramInt2, paramInt3, j);
/*     */       
/* 232 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "random.click", 0.3F, 0.5F);
/* 233 */       paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {
/* 239 */     float f1 = 0.1875F;
/* 240 */     float f2 = 0.125F;
/* 241 */     float f3 = 0.125F;
/* 242 */     a(0.5F - f1, 0.5F - f2, 0.5F - f3, 0.5F + f1, 0.5F + f2, 0.5F + f3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {
/* 247 */     if (paramaab.I)
/* 248 */       return;  if (!this.a)
/*     */       return; 
/* 250 */     if ((paramaab.h(paramInt1, paramInt2, paramInt3) & 0x8) != 0) {
/*     */       return;
/*     */     }
/*     */     
/* 254 */     n(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   private void n(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 258 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 259 */     int j = i & 0x7;
/* 260 */     boolean bool1 = ((i & 0x8) != 0) ? true : false;
/*     */ 
/*     */     
/* 263 */     d(i);
/* 264 */     List list = paramaab.a(ss.class, aqx.a().a(paramInt1 + this.cG, paramInt2 + this.cH, paramInt3 + this.cI, paramInt1 + this.cJ, paramInt2 + this.cK, paramInt3 + this.cL));
/* 265 */     boolean bool2 = !list.isEmpty() ? true : false;
/*     */     
/* 267 */     if (bool2 && !bool1) {
/* 268 */       paramaab.b(paramInt1, paramInt2, paramInt3, j | 0x8, 3);
/* 269 */       d(paramaab, paramInt1, paramInt2, paramInt3, j);
/* 270 */       paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */       
/* 272 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "random.click", 0.3F, 0.6F);
/*     */     } 
/* 274 */     if (!bool2 && bool1) {
/* 275 */       paramaab.b(paramInt1, paramInt2, paramInt3, j, 3);
/* 276 */       d(paramaab, paramInt1, paramInt2, paramInt3, j);
/* 277 */       paramaab.g(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*     */       
/* 279 */       paramaab.a(paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, "random.click", 0.3F, 0.5F);
/*     */     } 
/*     */     
/* 282 */     if (bool2) {
/* 283 */       paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */     }
/*     */   }
/*     */   
/*     */   private void d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 288 */     paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/*     */     
/* 290 */     if (paramInt4 == 1) {
/* 291 */       paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 292 */     } else if (paramInt4 == 2) {
/* 293 */       paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 294 */     } else if (paramInt4 == 3) {
/* 295 */       paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 296 */     } else if (paramInt4 == 4) {
/* 297 */       paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/*     */     } else {
/* 299 */       paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/*     */     } 
/*     */   }
/*     */   
/*     */   public void a(ly paramly) {}
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ali.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */