/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aql
/*    */   extends aqp
/*    */ {
/*  9 */   public byte a = 0;
/*    */   
/*    */   public boolean b = false;
/*    */   
/*    */   public void b(bs parambs) {
/* 14 */     super.b(parambs);
/* 15 */     parambs.a("note", this.a);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(bs parambs) {
/* 20 */     super.a(parambs);
/* 21 */     this.a = parambs.c("note");
/* 22 */     if (this.a < 0) this.a = 0; 
/* 23 */     if (this.a > 24) this.a = 24; 
/*    */   }
/*    */   
/*    */   public void a() {
/* 27 */     this.a = (byte)((this.a + 1) % 25);
/* 28 */     k_();
/*    */   }
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 32 */     if (paramaab.g(paramInt1, paramInt2 + 1, paramInt3) != aif.a)
/*    */       return; 
/* 34 */     aif aif = paramaab.g(paramInt1, paramInt2 - 1, paramInt3);
/*    */     
/* 36 */     byte b = 0;
/* 37 */     if (aif == aif.e) b = 1; 
/* 38 */     if (aif == aif.p) b = 2; 
/* 39 */     if (aif == aif.r) b = 3; 
/* 40 */     if (aif == aif.d) b = 4;
/*    */     
/* 42 */     paramaab.d(paramInt1, paramInt2, paramInt3, apa.V.cz, b, this.a);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aql.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */