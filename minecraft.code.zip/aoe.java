/*     */ import java.util.ArrayList;
/*     */ import java.util.HashSet;
/*     */ import java.util.Random;
/*     */ import java.util.Set;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aoe
/*     */   extends apa
/*     */ {
/*     */   private boolean a = true;
/*  20 */   private Set b = new HashSet();
/*     */   private lx c;
/*     */   private lx d;
/*     */   private lx e;
/*     */   private lx cR;
/*     */   
/*     */   public aoe(int paramInt) {
/*  27 */     super(paramInt, aif.q);
/*  28 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.0625F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  33 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  38 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  43 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  48 */     return 5;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  53 */     return 8388608;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  58 */     return (paramaab.w(paramInt1, paramInt2 - 1, paramInt3) || paramaab.a(paramInt1, paramInt2 - 1, paramInt3) == apa.bh.cz);
/*     */   }
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  62 */     a(paramaab, paramInt1, paramInt2, paramInt3, paramInt1, paramInt2, paramInt3);
/*  63 */     ArrayList<aat> arrayList = new ArrayList(this.b);
/*  64 */     this.b.clear();
/*  65 */     for (byte b = 0; b < arrayList.size(); b++) {
/*  66 */       aat aat = arrayList.get(b);
/*  67 */       paramaab.f(aat.a, aat.b, aat.c, this.cz);
/*     */     } 
/*     */   }
/*     */   
/*     */   private void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6) {
/*  72 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  73 */     int j = 0;
/*     */     
/*  75 */     j = d(paramaab, paramInt4, paramInt5, paramInt6, j);
/*     */     
/*  77 */     this.a = false;
/*  78 */     int k = paramaab.D(paramInt1, paramInt2, paramInt3);
/*  79 */     this.a = true;
/*     */     
/*  81 */     if (k > 0 && k > j - 1) {
/*  82 */       j = k;
/*     */     }
/*     */     
/*  85 */     int m = 0;
/*  86 */     for (byte b = 0; b < 4; b++) {
/*  87 */       int n = paramInt1;
/*  88 */       int i1 = paramInt3;
/*  89 */       if (b == 0) n--; 
/*  90 */       if (b == 1) n++; 
/*  91 */       if (b == 2) i1--; 
/*  92 */       if (b == 3) i1++;
/*     */       
/*  94 */       if (n != paramInt4 || i1 != paramInt6) m = d(paramaab, n, paramInt2, i1, m); 
/*  95 */       if (paramaab.u(n, paramInt2, i1) && !paramaab.u(paramInt1, paramInt2 + 1, paramInt3))
/*  96 */       { if ((n != paramInt4 || i1 != paramInt6) && paramInt2 >= paramInt5) m = d(paramaab, n, paramInt2 + 1, i1, m);
/*     */          }
/*  98 */       else if (!paramaab.u(n, paramInt2, i1) && (
/*  99 */         n != paramInt4 || i1 != paramInt6) && paramInt2 <= paramInt5) { m = d(paramaab, n, paramInt2 - 1, i1, m); }
/*     */     
/*     */     } 
/* 102 */     if (m > j) { j = m - 1; }
/* 103 */     else if (j > 0) { j--; }
/* 104 */     else { j = 0; }
/*     */     
/* 106 */     if (k > j - 1) {
/* 107 */       j = k;
/*     */     }
/*     */ 
/*     */     
/* 111 */     if (i != j) {
/*     */       
/* 113 */       paramaab.b(paramInt1, paramInt2, paramInt3, j, 2);
/*     */ 
/*     */       
/* 116 */       this.b.add(new aat(paramInt1, paramInt2, paramInt3));
/* 117 */       this.b.add(new aat(paramInt1 - 1, paramInt2, paramInt3));
/* 118 */       this.b.add(new aat(paramInt1 + 1, paramInt2, paramInt3));
/* 119 */       this.b.add(new aat(paramInt1, paramInt2 - 1, paramInt3));
/* 120 */       this.b.add(new aat(paramInt1, paramInt2 + 1, paramInt3));
/* 121 */       this.b.add(new aat(paramInt1, paramInt2, paramInt3 - 1));
/* 122 */       this.b.add(new aat(paramInt1, paramInt2, paramInt3 + 1));
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   private void m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 128 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) != this.cz)
/*     */       return; 
/* 130 */     paramaab.f(paramInt1, paramInt2, paramInt3, this.cz);
/* 131 */     paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 132 */     paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 133 */     paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 134 */     paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/*     */     
/* 136 */     paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/* 137 */     paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 142 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/* 143 */     if (paramaab.I)
/*     */       return; 
/* 145 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/* 146 */     paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/* 147 */     paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/*     */     
/* 149 */     m(paramaab, paramInt1 - 1, paramInt2, paramInt3);
/* 150 */     m(paramaab, paramInt1 + 1, paramInt2, paramInt3);
/* 151 */     m(paramaab, paramInt1, paramInt2, paramInt3 - 1);
/* 152 */     m(paramaab, paramInt1, paramInt2, paramInt3 + 1);
/*     */     
/* 154 */     if (paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) { m(paramaab, paramInt1 - 1, paramInt2 + 1, paramInt3); }
/* 155 */     else { m(paramaab, paramInt1 - 1, paramInt2 - 1, paramInt3); }
/* 156 */      if (paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) { m(paramaab, paramInt1 + 1, paramInt2 + 1, paramInt3); }
/* 157 */     else { m(paramaab, paramInt1 + 1, paramInt2 - 1, paramInt3); }
/* 158 */      if (paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) { m(paramaab, paramInt1, paramInt2 + 1, paramInt3 - 1); }
/* 159 */     else { m(paramaab, paramInt1, paramInt2 - 1, paramInt3 - 1); }
/* 160 */      if (paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) { m(paramaab, paramInt1, paramInt2 + 1, paramInt3 + 1); }
/* 161 */     else { m(paramaab, paramInt1, paramInt2 - 1, paramInt3 + 1); }
/*     */   
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 166 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/* 167 */     if (paramaab.I)
/*     */       return; 
/* 169 */     paramaab.f(paramInt1, paramInt2 + 1, paramInt3, this.cz);
/* 170 */     paramaab.f(paramInt1, paramInt2 - 1, paramInt3, this.cz);
/* 171 */     paramaab.f(paramInt1 + 1, paramInt2, paramInt3, this.cz);
/* 172 */     paramaab.f(paramInt1 - 1, paramInt2, paramInt3, this.cz);
/* 173 */     paramaab.f(paramInt1, paramInt2, paramInt3 + 1, this.cz);
/* 174 */     paramaab.f(paramInt1, paramInt2, paramInt3 - 1, this.cz);
/* 175 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     
/* 177 */     m(paramaab, paramInt1 - 1, paramInt2, paramInt3);
/* 178 */     m(paramaab, paramInt1 + 1, paramInt2, paramInt3);
/* 179 */     m(paramaab, paramInt1, paramInt2, paramInt3 - 1);
/* 180 */     m(paramaab, paramInt1, paramInt2, paramInt3 + 1);
/*     */     
/* 182 */     if (paramaab.u(paramInt1 - 1, paramInt2, paramInt3)) { m(paramaab, paramInt1 - 1, paramInt2 + 1, paramInt3); }
/* 183 */     else { m(paramaab, paramInt1 - 1, paramInt2 - 1, paramInt3); }
/* 184 */      if (paramaab.u(paramInt1 + 1, paramInt2, paramInt3)) { m(paramaab, paramInt1 + 1, paramInt2 + 1, paramInt3); }
/* 185 */     else { m(paramaab, paramInt1 + 1, paramInt2 - 1, paramInt3); }
/* 186 */      if (paramaab.u(paramInt1, paramInt2, paramInt3 - 1)) { m(paramaab, paramInt1, paramInt2 + 1, paramInt3 - 1); }
/* 187 */     else { m(paramaab, paramInt1, paramInt2 - 1, paramInt3 - 1); }
/* 188 */      if (paramaab.u(paramInt1, paramInt2, paramInt3 + 1)) { m(paramaab, paramInt1, paramInt2 + 1, paramInt3 + 1); }
/* 189 */     else { m(paramaab, paramInt1, paramInt2 - 1, paramInt3 + 1); }
/*     */   
/*     */   }
/*     */   private int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 193 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) != this.cz) return paramInt4; 
/* 194 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 195 */     if (i > paramInt4) return i; 
/* 196 */     return paramInt4;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 201 */     if (paramaab.I)
/*     */       return; 
/* 203 */     boolean bool = c(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     
/* 205 */     if (bool) {
/* 206 */       k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     } else {
/* 208 */       c(paramaab, paramInt1, paramInt2, paramInt3, 0, 0);
/* 209 */       paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */     } 
/*     */     
/* 212 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 217 */     return wk.aD.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 222 */     if (!this.a) return 0; 
/* 223 */     return b(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 228 */     if (!this.a) return 0; 
/* 229 */     int i = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 230 */     if (i == 0) {
/* 231 */       return 0;
/*     */     }
/*     */     
/* 234 */     if (paramInt4 == 1) return i;
/*     */     
/* 236 */     boolean bool1 = (g(paramaak, paramInt1 - 1, paramInt2, paramInt3, 1) || (!paramaak.u(paramInt1 - 1, paramInt2, paramInt3) && g(paramaak, paramInt1 - 1, paramInt2 - 1, paramInt3, -1))) ? true : false;
/*     */     
/* 238 */     boolean bool2 = (g(paramaak, paramInt1 + 1, paramInt2, paramInt3, 3) || (!paramaak.u(paramInt1 + 1, paramInt2, paramInt3) && g(paramaak, paramInt1 + 1, paramInt2 - 1, paramInt3, -1))) ? true : false;
/*     */     
/* 240 */     boolean bool3 = (g(paramaak, paramInt1, paramInt2, paramInt3 - 1, 2) || (!paramaak.u(paramInt1, paramInt2, paramInt3 - 1) && g(paramaak, paramInt1, paramInt2 - 1, paramInt3 - 1, -1))) ? true : false;
/*     */     
/* 242 */     boolean bool4 = (g(paramaak, paramInt1, paramInt2, paramInt3 + 1, 0) || (!paramaak.u(paramInt1, paramInt2, paramInt3 + 1) && g(paramaak, paramInt1, paramInt2 - 1, paramInt3 + 1, -1))) ? true : false;
/*     */ 
/*     */     
/* 245 */     if (!paramaak.u(paramInt1, paramInt2 + 1, paramInt3)) {
/* 246 */       if (paramaak.u(paramInt1 - 1, paramInt2, paramInt3) && g(paramaak, paramInt1 - 1, paramInt2 + 1, paramInt3, -1)) bool1 = true; 
/* 247 */       if (paramaak.u(paramInt1 + 1, paramInt2, paramInt3) && g(paramaak, paramInt1 + 1, paramInt2 + 1, paramInt3, -1)) bool2 = true; 
/* 248 */       if (paramaak.u(paramInt1, paramInt2, paramInt3 - 1) && g(paramaak, paramInt1, paramInt2 + 1, paramInt3 - 1, -1)) bool3 = true; 
/* 249 */       if (paramaak.u(paramInt1, paramInt2, paramInt3 + 1) && g(paramaak, paramInt1, paramInt2 + 1, paramInt3 + 1, -1)) bool4 = true;
/*     */     
/*     */     } 
/* 252 */     if (!bool3 && !bool2 && !bool1 && !bool4 && paramInt4 >= 2 && paramInt4 <= 5) return i;
/*     */     
/* 254 */     if (paramInt4 == 2 && bool3 && !bool1 && !bool2) return i; 
/* 255 */     if (paramInt4 == 3 && bool4 && !bool1 && !bool2) return i; 
/* 256 */     if (paramInt4 == 4 && bool1 && !bool3 && !bool4) return i; 
/* 257 */     if (paramInt4 == 5 && bool2 && !bool3 && !bool4) return i;
/*     */     
/* 259 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f() {
/* 264 */     return this.a;
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 269 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 270 */     if (i > 0) {
/* 271 */       double d1 = paramInt1 + 0.5D + (paramRandom.nextFloat() - 0.5D) * 0.2D;
/* 272 */       double d2 = (paramInt2 + 0.0625F);
/* 273 */       double d3 = paramInt3 + 0.5D + (paramRandom.nextFloat() - 0.5D) * 0.2D;
/*     */ 
/*     */       
/* 276 */       float f1 = i / 15.0F;
/* 277 */       float f2 = f1 * 0.6F + 0.4F;
/* 278 */       if (i == 0) f2 = 0.0F;
/*     */       
/* 280 */       float f3 = f1 * f1 * 0.7F - 0.5F;
/* 281 */       float f4 = f1 * f1 * 0.6F - 0.7F;
/* 282 */       if (f3 < 0.0F) f3 = 0.0F; 
/* 283 */       if (f4 < 0.0F) f4 = 0.0F;
/*     */       
/* 285 */       paramaab.a("reddust", d1, d2, d3, f2, f3, f4);
/*     */     } 
/*     */   }
/*     */   
/*     */   public static boolean f(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 290 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/* 291 */     if (i == apa.az.cz) return true; 
/* 292 */     if (i == 0) return false; 
/* 293 */     if (apa.bl.g(i)) {
/* 294 */       int j = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 295 */       return (paramInt4 == (j & 0x3) || paramInt4 == r.f[j & 0x3]);
/* 296 */     }  if (apa.r[i].f() && paramInt4 != -1) return true; 
/* 297 */     return false;
/*     */   }
/*     */   
/*     */   public static boolean g(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 301 */     if (f(paramaak, paramInt1, paramInt2, paramInt3, paramInt4)) {
/* 302 */       return true;
/*     */     }
/*     */     
/* 305 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/* 306 */     if (i == apa.bm.cz) {
/* 307 */       int j = paramaak.h(paramInt1, paramInt2, paramInt3);
/* 308 */       return (paramInt4 == (j & 0x3));
/*     */     } 
/* 310 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 315 */     return wk.aD.cp;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 320 */     this.c = paramly.a("redstoneDust_cross");
/* 321 */     this.d = paramly.a("redstoneDust_line");
/* 322 */     this.e = paramly.a("redstoneDust_cross_overlay");
/* 323 */     this.cR = paramly.a("redstoneDust_line_overlay");
/*     */     
/* 325 */     this.cQ = this.c;
/*     */   }
/*     */   
/*     */   public static lx b(String paramString) {
/* 329 */     if (paramString == "redstoneDust_cross") return apa.az.c; 
/* 330 */     if (paramString == "redstoneDust_line") return apa.az.d; 
/* 331 */     if (paramString == "redstoneDust_cross_overlay") return apa.az.e; 
/* 332 */     if (paramString == "redstoneDust_line_overlay") return apa.az.cR; 
/* 333 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aoe.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */