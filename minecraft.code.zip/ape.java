/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ape
/*    */ {
/*    */   public final String a;
/*    */   public final float b;
/*    */   public final float c;
/*    */   
/*    */   public ape(String paramString, float paramFloat1, float paramFloat2) {
/* 49 */     this.a = paramString;
/* 50 */     this.b = paramFloat1;
/* 51 */     this.c = paramFloat2;
/*    */   }
/*    */   
/*    */   public float c() {
/* 55 */     return this.b;
/*    */   }
/*    */   
/*    */   public float d() {
/* 59 */     return this.c;
/*    */   }
/*    */   
/*    */   public String a() {
/* 63 */     return "dig." + this.a;
/*    */   }
/*    */   
/*    */   public String e() {
/* 67 */     return "step." + this.a;
/*    */   }
/*    */   
/*    */   public String b() {
/* 71 */     return a();
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ape.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */