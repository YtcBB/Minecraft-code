/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ame
/*     */   extends apa
/*     */ {
/*     */   public ame(int paramInt) {
/*  12 */     super(paramInt, aif.B);
/*     */     
/*  14 */     a(0.0625F, 0.0F, 0.0625F, 0.9375F, 1.0F, 0.9375F);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  19 */     paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  24 */     paramaab.a(paramInt1, paramInt2, paramInt3, this.cz, a(paramaab));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  29 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   private void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  33 */     if (amt.a_(paramaab, paramInt1, paramInt2 - 1, paramInt3) && paramInt2 >= 0) {
/*  34 */       byte b = 32;
/*  35 */       if (amt.c || !paramaab.e(paramInt1 - b, paramInt2 - b, paramInt3 - b, paramInt1 + b, paramInt2 + b, paramInt3 + b)) {
/*  36 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*  37 */         while (amt.a_(paramaab, paramInt1, paramInt2 - 1, paramInt3) && paramInt2 > 0)
/*  38 */           paramInt2--; 
/*  39 */         if (paramInt2 > 0) {
/*  40 */           paramaab.f(paramInt1, paramInt2, paramInt3, this.cz, 0, 2);
/*     */         }
/*     */       } else {
/*  43 */         rg rg = new rg(paramaab, (paramInt1 + 0.5F), (paramInt2 + 0.5F), (paramInt3 + 0.5F), this.cz);
/*  44 */         paramaab.d(rg);
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  51 */     m(paramaab, paramInt1, paramInt2, paramInt3);
/*  52 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {
/*  58 */     m(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   private void m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  62 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) != this.cz)
/*     */       return; 
/*  64 */     for (byte b = 0; b < 'Ϩ'; b++) {
/*  65 */       int i = paramInt1 + paramaab.s.nextInt(16) - paramaab.s.nextInt(16);
/*  66 */       int j = paramInt2 + paramaab.s.nextInt(8) - paramaab.s.nextInt(8);
/*  67 */       int k = paramInt3 + paramaab.s.nextInt(16) - paramaab.s.nextInt(16);
/*  68 */       if (paramaab.a(i, j, k) == 0) {
/*  69 */         if (!paramaab.I) {
/*  70 */           paramaab.f(i, j, k, this.cz, paramaab.h(paramInt1, paramInt2, paramInt3), 2);
/*  71 */           paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */         } else {
/*  73 */           char c = '';
/*  74 */           for (byte b1 = 0; b1 < c; b1++) {
/*  75 */             double d1 = paramaab.s.nextDouble();
/*  76 */             float f1 = (paramaab.s.nextFloat() - 0.5F) * 0.2F;
/*  77 */             float f2 = (paramaab.s.nextFloat() - 0.5F) * 0.2F;
/*  78 */             float f3 = (paramaab.s.nextFloat() - 0.5F) * 0.2F;
/*     */             
/*  80 */             double d2 = i + (paramInt1 - i) * d1 + (paramaab.s.nextDouble() - 0.5D) * 1.0D + 0.5D;
/*  81 */             double d3 = j + (paramInt2 - j) * d1 + paramaab.s.nextDouble() * 1.0D - 0.5D;
/*  82 */             double d4 = k + (paramInt3 - k) * d1 + (paramaab.s.nextDouble() - 0.5D) * 1.0D + 0.5D;
/*  83 */             paramaab.a("portal", d2, d3, d4, f1, f2, f3);
/*     */           } 
/*     */         } 
/*     */         return;
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/*  93 */     return 5;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean c() {
/* 102 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/* 107 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 112 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/* 117 */     return 27;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 122 */     return 0;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ame.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */