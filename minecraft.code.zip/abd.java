/*     */ import java.util.Arrays;
/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ public class abd
/*     */   extends aba {
/*     */   private aav d;
/*     */   private float e;
/*     */   private float f;
/*     */   
/*     */   public abd(aav paramaav, float paramFloat1, float paramFloat2) {
/*  12 */     this.d = paramaav;
/*  13 */     this.e = paramFloat1;
/*  14 */     this.f = paramFloat2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aav a(int paramInt1, int paramInt2) {
/*  24 */     return this.d;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aav[] a(aav[] paramArrayOfaav, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  45 */     if (paramArrayOfaav == null || paramArrayOfaav.length < paramInt3 * paramInt4) {
/*  46 */       paramArrayOfaav = new aav[paramInt3 * paramInt4];
/*     */     }
/*     */     
/*  49 */     Arrays.fill((Object[])paramArrayOfaav, 0, paramInt3 * paramInt4, this.d);
/*     */     
/*  51 */     return paramArrayOfaav;
/*     */   }
/*     */ 
/*     */   
/*     */   public float[] b(float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  56 */     if (paramArrayOffloat == null || paramArrayOffloat.length < paramInt3 * paramInt4) {
/*  57 */       paramArrayOffloat = new float[paramInt3 * paramInt4];
/*     */     }
/*     */     
/*  60 */     Arrays.fill(paramArrayOffloat, 0, paramInt3 * paramInt4, this.e);
/*  61 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float[] a(float[] paramArrayOffloat, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  80 */     if (paramArrayOffloat == null || paramArrayOffloat.length < paramInt3 * paramInt4) {
/*  81 */       paramArrayOffloat = new float[paramInt3 * paramInt4];
/*     */     }
/*  83 */     Arrays.fill(paramArrayOffloat, 0, paramInt3 * paramInt4, this.f);
/*     */     
/*  85 */     return paramArrayOffloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aav[] b(aav[] paramArrayOfaav, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 109 */     if (paramArrayOfaav == null || paramArrayOfaav.length < paramInt3 * paramInt4) {
/* 110 */       paramArrayOfaav = new aav[paramInt3 * paramInt4];
/*     */     }
/*     */     
/* 113 */     Arrays.fill((Object[])paramArrayOfaav, 0, paramInt3 * paramInt4, this.d);
/*     */     
/* 115 */     return paramArrayOfaav;
/*     */   }
/*     */ 
/*     */   
/*     */   public aav[] a(aav[] paramArrayOfaav, int paramInt1, int paramInt2, int paramInt3, int paramInt4, boolean paramBoolean) {
/* 120 */     return b(paramArrayOfaav, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aat a(int paramInt1, int paramInt2, int paramInt3, List paramList, Random paramRandom) {
/* 135 */     if (paramList.contains(this.d)) {
/* 136 */       return new aat(paramInt1 - paramInt3 + paramRandom.nextInt(paramInt3 * 2 + 1), 0, paramInt2 - paramInt3 + paramRandom.nextInt(paramInt3 * 2 + 1));
/*     */     }
/*     */     
/* 139 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2, int paramInt3, List paramList) {
/* 149 */     return paramList.contains(this.d);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abd.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */