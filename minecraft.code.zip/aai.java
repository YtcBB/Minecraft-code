/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public final class aai
/*     */ {
/*     */   private final long a;
/*     */   private final aaj b;
/*     */   private final boolean c;
/*     */   private final boolean d;
/*     */   private final aal e;
/*     */   private boolean f;
/*     */   private boolean g;
/*  79 */   private String h = "";
/*     */   
/*     */   public aai(long paramLong, aaj paramaaj, boolean paramBoolean1, boolean paramBoolean2, aal paramaal) {
/*  82 */     this.a = paramLong;
/*  83 */     this.b = paramaaj;
/*  84 */     this.c = paramBoolean1;
/*  85 */     this.d = paramBoolean2;
/*  86 */     this.e = paramaal;
/*     */   }
/*     */   
/*     */   public aai(ajv paramajv) {
/*  90 */     this(paramajv.b(), paramajv.r(), paramajv.s(), paramajv.t(), paramajv.u());
/*     */   }
/*     */   
/*     */   public aai a() {
/*  94 */     this.g = true;
/*  95 */     return this;
/*     */   }
/*     */   
/*     */   public aai b() {
/*  99 */     this.f = true;
/* 100 */     return this;
/*     */   }
/*     */   
/*     */   public aai a(String paramString) {
/* 104 */     this.h = paramString;
/* 105 */     return this;
/*     */   }
/*     */   
/*     */   public boolean c() {
/* 109 */     return this.g;
/*     */   }
/*     */   
/*     */   public long d() {
/* 113 */     return this.a;
/*     */   }
/*     */   
/*     */   public aaj e() {
/* 117 */     return this.b;
/*     */   }
/*     */   
/*     */   public boolean f() {
/* 121 */     return this.d;
/*     */   }
/*     */   
/*     */   public boolean g() {
/* 125 */     return this.c;
/*     */   }
/*     */   
/*     */   public aal h() {
/* 129 */     return this.e;
/*     */   }
/*     */   
/*     */   public boolean i() {
/* 133 */     return this.f;
/*     */   }
/*     */   
/*     */   public static aaj a(int paramInt) {
/* 137 */     return aaj.a(paramInt);
/*     */   }
/*     */   
/*     */   public String j() {
/* 141 */     return this.h;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aai.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */