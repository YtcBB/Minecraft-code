import java.util.List;

public interface aki {
  akf a(String paramString, boolean paramBoolean);
  
  List b();
  
  void d();
  
  ajv c(String paramString);
  
  boolean e(String paramString);
  
  void a(String paramString1, String paramString2);
  
  boolean b(String paramString);
  
  boolean a(String paramString, lc paramlc);
  
  boolean f(String paramString);
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aki.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */