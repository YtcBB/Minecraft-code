/*     */ package paulscode.sound;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ListenerData
/*     */ {
/*     */   public Vector3D position;
/*     */   public Vector3D lookAt;
/*     */   public Vector3D up;
/*     */   public Vector3D velocity;
/*  65 */   public float angle = 0.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListenerData() {
/*  72 */     this.position = new Vector3D(0.0F, 0.0F, 0.0F);
/*  73 */     this.lookAt = new Vector3D(0.0F, 0.0F, -1.0F);
/*  74 */     this.up = new Vector3D(0.0F, 1.0F, 0.0F);
/*  75 */     this.velocity = new Vector3D(0.0F, 0.0F, 0.0F);
/*  76 */     this.angle = 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListenerData(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10) {
/*  96 */     this.position = new Vector3D(paramFloat1, paramFloat2, paramFloat3);
/*  97 */     this.lookAt = new Vector3D(paramFloat4, paramFloat5, paramFloat6);
/*  98 */     this.up = new Vector3D(paramFloat7, paramFloat8, paramFloat9);
/*  99 */     this.velocity = new Vector3D(0.0F, 0.0F, 0.0F);
/* 100 */     this.angle = paramFloat10;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListenerData(Vector3D paramVector3D1, Vector3D paramVector3D2, Vector3D paramVector3D3, float paramFloat) {
/* 113 */     this.position = paramVector3D1.clone();
/* 114 */     this.lookAt = paramVector3D2.clone();
/* 115 */     this.up = paramVector3D3.clone();
/* 116 */     this.velocity = new Vector3D(0.0F, 0.0F, 0.0F);
/* 117 */     this.angle = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6, float paramFloat7, float paramFloat8, float paramFloat9, float paramFloat10) {
/* 137 */     this.position.x = paramFloat1;
/* 138 */     this.position.y = paramFloat2;
/* 139 */     this.position.z = paramFloat3;
/* 140 */     this.lookAt.x = paramFloat4;
/* 141 */     this.lookAt.y = paramFloat5;
/* 142 */     this.lookAt.z = paramFloat6;
/* 143 */     this.up.x = paramFloat7;
/* 144 */     this.up.y = paramFloat8;
/* 145 */     this.up.z = paramFloat9;
/* 146 */     this.angle = paramFloat10;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(Vector3D paramVector3D1, Vector3D paramVector3D2, Vector3D paramVector3D3, float paramFloat) {
/* 159 */     this.position.x = paramVector3D1.x;
/* 160 */     this.position.y = paramVector3D1.y;
/* 161 */     this.position.z = paramVector3D1.z;
/* 162 */     this.lookAt.x = paramVector3D2.x;
/* 163 */     this.lookAt.y = paramVector3D2.y;
/* 164 */     this.lookAt.z = paramVector3D2.z;
/* 165 */     this.up.x = paramVector3D3.x;
/* 166 */     this.up.y = paramVector3D3.y;
/* 167 */     this.up.z = paramVector3D3.z;
/* 168 */     this.angle = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setData(ListenerData paramListenerData) {
/* 177 */     this.position.x = paramListenerData.position.x;
/* 178 */     this.position.y = paramListenerData.position.y;
/* 179 */     this.position.z = paramListenerData.position.z;
/* 180 */     this.lookAt.x = paramListenerData.lookAt.x;
/* 181 */     this.lookAt.y = paramListenerData.lookAt.y;
/* 182 */     this.lookAt.z = paramListenerData.lookAt.z;
/* 183 */     this.up.x = paramListenerData.up.x;
/* 184 */     this.up.y = paramListenerData.up.y;
/* 185 */     this.up.z = paramListenerData.up.z;
/* 186 */     this.angle = paramListenerData.angle;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 197 */     this.position.x = paramFloat1;
/* 198 */     this.position.y = paramFloat2;
/* 199 */     this.position.z = paramFloat3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(Vector3D paramVector3D) {
/* 208 */     this.position.x = paramVector3D.x;
/* 209 */     this.position.y = paramVector3D.y;
/* 210 */     this.position.z = paramVector3D.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrientation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 225 */     this.lookAt.x = paramFloat1;
/* 226 */     this.lookAt.y = paramFloat2;
/* 227 */     this.lookAt.z = paramFloat3;
/* 228 */     this.up.x = paramFloat4;
/* 229 */     this.up.y = paramFloat5;
/* 230 */     this.up.z = paramFloat6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setOrientation(Vector3D paramVector3D1, Vector3D paramVector3D2) {
/* 240 */     this.lookAt.x = paramVector3D1.x;
/* 241 */     this.lookAt.y = paramVector3D1.y;
/* 242 */     this.lookAt.z = paramVector3D1.z;
/* 243 */     this.up.x = paramVector3D2.x;
/* 244 */     this.up.y = paramVector3D2.y;
/* 245 */     this.up.z = paramVector3D2.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVelocity(Vector3D paramVector3D) {
/* 254 */     this.velocity.x = paramVector3D.x;
/* 255 */     this.velocity.y = paramVector3D.y;
/* 256 */     this.velocity.z = paramVector3D.z;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 267 */     this.velocity.x = paramFloat1;
/* 268 */     this.velocity.y = paramFloat2;
/* 269 */     this.velocity.z = paramFloat3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAngle(float paramFloat) {
/* 278 */     this.angle = paramFloat;
/* 279 */     this.lookAt.x = -1.0F * (float)Math.sin(this.angle);
/* 280 */     this.lookAt.z = -1.0F * (float)Math.cos(this.angle);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\ListenerData.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */