/*     */ package paulscode.sound;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class StreamThread
/*     */   extends SimpleThread
/*     */ {
/*     */   private SoundSystemLogger logger;
/*     */   private List streamingSources;
/*  61 */   private final Object listLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public StreamThread() {
/*  70 */     this.logger = SoundSystemConfig.getLogger();
/*     */     
/*  72 */     this.streamingSources = new LinkedList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void cleanup() {
/*  83 */     kill();
/*  84 */     super.cleanup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void run() {
/*  98 */     snooze(3600000L);
/*     */     
/* 100 */     while (!dying()) {
/*     */       
/* 102 */       while (!dying() && !this.streamingSources.isEmpty()) {
/*     */ 
/*     */         
/* 105 */         synchronized (this.listLock) {
/*     */           
/* 107 */           ListIterator<Source> listIterator = this.streamingSources.listIterator();
/* 108 */           while (!dying() && listIterator.hasNext()) {
/*     */             
/* 110 */             Source source = listIterator.next();
/* 111 */             if (source == null) {
/*     */               
/* 113 */               listIterator.remove(); continue;
/*     */             } 
/* 115 */             if (source.stopped()) {
/*     */               
/* 117 */               if (!source.rawDataStream)
/* 118 */                 listIterator.remove();  continue;
/*     */             } 
/* 120 */             if (!source.active()) {
/*     */               
/* 122 */               if (source.toLoop || source.rawDataStream)
/* 123 */                 source.toPlay = true; 
/* 124 */               listIterator.remove(); continue;
/*     */             } 
/* 126 */             if (!source.paused()) {
/*     */               
/* 128 */               source.checkFadeOut();
/* 129 */               if (!source.stream() && !source.rawDataStream)
/*     */               {
/* 131 */                 if (source.channel == null || !source.channel.processBuffer()) {
/*     */ 
/*     */                   
/* 134 */                   if (source.nextCodec == null)
/*     */                   {
/* 136 */                     source.readBuffersFromNextSoundInSequence();
/*     */                   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                   
/* 145 */                   if (source.toLoop) {
/*     */ 
/*     */                     
/* 148 */                     if (!source.playing()) {
/*     */ 
/*     */                       
/* 151 */                       SoundSystemConfig.notifyEOS(source.sourcename, source.getSoundSequenceQueueSize());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 157 */                       if (source.checkFadeOut()) {
/*     */ 
/*     */ 
/*     */ 
/*     */                         
/* 162 */                         source.preLoad = true;
/*     */ 
/*     */ 
/*     */                         
/*     */                         continue;
/*     */                       } 
/*     */ 
/*     */                       
/* 170 */                       source.incrementSoundSequence();
/* 171 */                       source.preLoad = true;
/*     */                     } 
/*     */ 
/*     */                     
/*     */                     continue;
/*     */                   } 
/*     */                   
/* 178 */                   if (!source.playing()) {
/*     */ 
/*     */                     
/* 181 */                     SoundSystemConfig.notifyEOS(source.sourcename, source.getSoundSequenceQueueSize());
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */                     
/* 187 */                     if (!source.checkFadeOut()) {
/*     */ 
/*     */ 
/*     */ 
/*     */                       
/* 192 */                       if (source.incrementSoundSequence()) {
/*     */                         
/* 194 */                         source.preLoad = true; continue;
/*     */                       } 
/* 196 */                       listIterator.remove();
/*     */                     } 
/*     */                   } 
/*     */                 } 
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */         
/* 205 */         if (!dying() && !this.streamingSources.isEmpty())
/* 206 */           snooze(20L); 
/*     */       } 
/* 208 */       if (!dying() && this.streamingSources.isEmpty()) {
/* 209 */         snooze(3600000L);
/*     */       }
/*     */     } 
/* 212 */     cleanup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void watch(Source paramSource) {
/* 224 */     if (paramSource == null) {
/*     */       return;
/*     */     }
/*     */     
/* 228 */     if (this.streamingSources.contains(paramSource)) {
/*     */       return;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 235 */     synchronized (this.listLock) {
/*     */ 
/*     */ 
/*     */ 
/*     */       
/* 240 */       ListIterator<Source> listIterator = this.streamingSources.listIterator();
/* 241 */       while (listIterator.hasNext()) {
/*     */         
/* 243 */         Source source = listIterator.next();
/* 244 */         if (source == null) {
/*     */           
/* 246 */           listIterator.remove(); continue;
/*     */         } 
/* 248 */         if (paramSource.channel == source.channel) {
/*     */           
/* 250 */           source.stop();
/* 251 */           listIterator.remove();
/*     */         } 
/*     */       } 
/*     */ 
/*     */       
/* 256 */       this.streamingSources.add(paramSource);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void message(String paramString) {
/* 266 */     this.logger.message(paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void importantMessage(String paramString) {
/* 275 */     this.logger.importantMessage(paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean errorCheck(boolean paramBoolean, String paramString) {
/* 286 */     return this.logger.errorCheck(paramBoolean, "StreamThread", paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void errorMessage(String paramString) {
/* 295 */     this.logger.errorMessage("StreamThread", paramString, 0);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\StreamThread.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */