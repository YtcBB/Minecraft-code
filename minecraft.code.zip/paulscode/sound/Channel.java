/*     */ package paulscode.sound;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class Channel
/*     */ {
/*  51 */   protected Class libraryType = Library.class;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int channelType;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SoundSystemLogger logger;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  68 */   public Source attachedSource = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  73 */   public int buffersUnqueued = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public Channel(int paramInt) {
/*  84 */     this.logger = SoundSystemConfig.getLogger();
/*     */     
/*  86 */     this.channelType = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/*  94 */     this.logger = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preLoadBuffers(LinkedList paramLinkedList) {
/* 104 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean queueBuffer(byte[] paramArrayOfbyte) {
/* 114 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int feedRawAudioData(byte[] paramArrayOfbyte) {
/* 124 */     return 1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int buffersProcessed() {
/* 133 */     return 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float millisecondsPlayed() {
/* 142 */     return -1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean processBuffer() {
/* 151 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAudioFormat(AudioFormat paramAudioFormat) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void play() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pause() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rewind() {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean playing() {
/* 207 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 216 */     String str = SoundSystemConfig.getLibraryTitle(this.libraryType);
/*     */     
/* 218 */     if (str.equals("No Sound")) {
/* 219 */       return "Channel";
/*     */     }
/* 221 */     return "Channel" + str;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void message(String paramString) {
/* 230 */     this.logger.message(paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void importantMessage(String paramString) {
/* 239 */     this.logger.importantMessage(paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected boolean errorCheck(boolean paramBoolean, String paramString) {
/* 250 */     return this.logger.errorCheck(paramBoolean, getClassName(), paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void errorMessage(String paramString) {
/* 259 */     this.logger.errorMessage(getClassName(), paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void printStackTrace(Exception paramException) {
/* 268 */     this.logger.printStackTrace(paramException, 1);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\Channel.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */