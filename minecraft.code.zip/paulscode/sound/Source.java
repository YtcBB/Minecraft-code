/*      */ package paulscode.sound;
/*      */ 
/*      */ import java.net.URL;
/*      */ import java.util.LinkedList;
/*      */ import java.util.ListIterator;
/*      */ import javax.sound.sampled.AudioFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Source
/*      */ {
/*   53 */   protected Class libraryType = Library.class;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean GET = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean SET = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static final boolean XXX = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private SoundSystemLogger logger;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean rawDataStream = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*   85 */   public AudioFormat rawDataFormat = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean temporary = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean priority = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean toStream = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean toLoop = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean toPlay = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  118 */   public String sourcename = "";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  123 */   public FilenameURL filenameURL = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vector3D position;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  133 */   public int attModel = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  138 */   public float distOrRoll = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Vector3D velocity;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  150 */   public float gain = 1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  155 */   public float sourceVolume = 1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  160 */   protected float pitch = 1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  165 */   public float distanceFromListener = 0.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  170 */   public Channel channel = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  175 */   public SoundBuffer soundBuffer = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean active = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean stopped = true;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean paused = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  195 */   protected ICodec codec = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  200 */   protected ICodec nextCodec = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  205 */   protected LinkedList nextBuffers = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  211 */   protected LinkedList soundSequenceQueue = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  216 */   protected final Object soundSequenceLock = new Object();
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean preLoad = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  228 */   protected float fadeOutGain = -1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  234 */   protected float fadeInGain = 1.0F;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  239 */   protected long fadeOutMilis = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  244 */   protected long fadeInMilis = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  249 */   protected long lastFadeCheck = 0L;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Source(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, SoundBuffer paramSoundBuffer, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/*  272 */     this.logger = SoundSystemConfig.getLogger();
/*      */     
/*  274 */     this.priority = paramBoolean1;
/*  275 */     this.toStream = paramBoolean2;
/*  276 */     this.toLoop = paramBoolean3;
/*  277 */     this.sourcename = paramString;
/*  278 */     this.filenameURL = paramFilenameURL;
/*  279 */     this.soundBuffer = paramSoundBuffer;
/*  280 */     this.position = new Vector3D(paramFloat1, paramFloat2, paramFloat3);
/*  281 */     this.attModel = paramInt;
/*  282 */     this.distOrRoll = paramFloat4;
/*  283 */     this.velocity = new Vector3D(0.0F, 0.0F, 0.0F);
/*  284 */     this.temporary = paramBoolean4;
/*      */     
/*  286 */     if (paramBoolean2 && paramFilenameURL != null) {
/*  287 */       this.codec = SoundSystemConfig.getCodec(paramFilenameURL.getFilename());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Source(Source paramSource, SoundBuffer paramSoundBuffer) {
/*  298 */     this.logger = SoundSystemConfig.getLogger();
/*      */     
/*  300 */     this.priority = paramSource.priority;
/*  301 */     this.toStream = paramSource.toStream;
/*  302 */     this.toLoop = paramSource.toLoop;
/*  303 */     this.sourcename = paramSource.sourcename;
/*  304 */     this.filenameURL = paramSource.filenameURL;
/*  305 */     this.position = paramSource.position.clone();
/*  306 */     this.attModel = paramSource.attModel;
/*  307 */     this.distOrRoll = paramSource.distOrRoll;
/*  308 */     this.velocity = paramSource.velocity.clone();
/*  309 */     this.temporary = paramSource.temporary;
/*      */     
/*  311 */     this.sourceVolume = paramSource.sourceVolume;
/*      */     
/*  313 */     this.rawDataStream = paramSource.rawDataStream;
/*  314 */     this.rawDataFormat = paramSource.rawDataFormat;
/*      */     
/*  316 */     this.soundBuffer = paramSoundBuffer;
/*      */     
/*  318 */     if (this.toStream && this.filenameURL != null) {
/*  319 */       this.codec = SoundSystemConfig.getCodec(this.filenameURL.getFilename());
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Source(AudioFormat paramAudioFormat, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  338 */     this.logger = SoundSystemConfig.getLogger();
/*      */     
/*  340 */     this.priority = paramBoolean;
/*  341 */     this.toStream = true;
/*  342 */     this.toLoop = false;
/*  343 */     this.sourcename = paramString;
/*  344 */     this.filenameURL = null;
/*  345 */     this.soundBuffer = null;
/*  346 */     this.position = new Vector3D(paramFloat1, paramFloat2, paramFloat3);
/*  347 */     this.attModel = paramInt;
/*  348 */     this.distOrRoll = paramFloat4;
/*  349 */     this.velocity = new Vector3D(0.0F, 0.0F, 0.0F);
/*  350 */     this.temporary = false;
/*      */     
/*  352 */     this.rawDataStream = true;
/*  353 */     this.rawDataFormat = paramAudioFormat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cleanup() {
/*  362 */     if (this.codec != null) {
/*  363 */       this.codec.cleanup();
/*      */     }
/*  365 */     synchronized (this.soundSequenceLock) {
/*      */       
/*  367 */       if (this.soundSequenceQueue != null)
/*  368 */         this.soundSequenceQueue.clear(); 
/*  369 */       this.soundSequenceQueue = null;
/*      */     } 
/*      */     
/*  372 */     this.sourcename = null;
/*  373 */     this.filenameURL = null;
/*  374 */     this.position = null;
/*  375 */     this.soundBuffer = null;
/*  376 */     this.codec = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void queueSound(FilenameURL paramFilenameURL) {
/*  387 */     if (!this.toStream) {
/*      */       
/*  389 */       errorMessage("Method 'queueSound' may only be used for streaming and MIDI sources.");
/*      */       
/*      */       return;
/*      */     } 
/*  393 */     if (paramFilenameURL == null) {
/*      */       
/*  395 */       errorMessage("File not specified in method 'queueSound'");
/*      */       
/*      */       return;
/*      */     } 
/*  399 */     synchronized (this.soundSequenceLock) {
/*      */       
/*  401 */       if (this.soundSequenceQueue == null)
/*  402 */         this.soundSequenceQueue = new LinkedList(); 
/*  403 */       this.soundSequenceQueue.add(paramFilenameURL);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dequeueSound(String paramString) {
/*  415 */     if (!this.toStream) {
/*      */       
/*  417 */       errorMessage("Method 'dequeueSound' may only be used for streaming and MIDI sources.");
/*      */       
/*      */       return;
/*      */     } 
/*  421 */     if (paramString == null || paramString.equals("")) {
/*      */       
/*  423 */       errorMessage("Filename not specified in method 'dequeueSound'");
/*      */       
/*      */       return;
/*      */     } 
/*  427 */     synchronized (this.soundSequenceLock) {
/*      */       
/*  429 */       if (this.soundSequenceQueue != null) {
/*      */         
/*  431 */         ListIterator<FilenameURL> listIterator = this.soundSequenceQueue.listIterator();
/*  432 */         while (listIterator.hasNext()) {
/*      */           
/*  434 */           if (((FilenameURL)listIterator.next()).getFilename().equals(paramString)) {
/*      */             
/*  436 */             listIterator.remove();
/*      */             break;
/*      */           } 
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fadeOut(FilenameURL paramFilenameURL, long paramLong) {
/*  457 */     if (!this.toStream) {
/*      */       
/*  459 */       errorMessage("Method 'fadeOut' may only be used for streaming and MIDI sources.");
/*      */       
/*      */       return;
/*      */     } 
/*  463 */     if (paramLong < 0L) {
/*      */       
/*  465 */       errorMessage("Miliseconds may not be negative in method 'fadeOut'.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  470 */     this.fadeOutMilis = paramLong;
/*  471 */     this.fadeInMilis = 0L;
/*  472 */     this.fadeOutGain = 1.0F;
/*  473 */     this.lastFadeCheck = System.currentTimeMillis();
/*      */     
/*  475 */     synchronized (this.soundSequenceLock) {
/*      */       
/*  477 */       if (this.soundSequenceQueue != null) {
/*  478 */         this.soundSequenceQueue.clear();
/*      */       }
/*  480 */       if (paramFilenameURL != null) {
/*      */         
/*  482 */         if (this.soundSequenceQueue == null)
/*  483 */           this.soundSequenceQueue = new LinkedList(); 
/*  484 */         this.soundSequenceQueue.add(paramFilenameURL);
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fadeOutIn(FilenameURL paramFilenameURL, long paramLong1, long paramLong2) {
/*  504 */     if (!this.toStream) {
/*      */       
/*  506 */       errorMessage("Method 'fadeOutIn' may only be used for streaming and MIDI sources.");
/*      */       
/*      */       return;
/*      */     } 
/*  510 */     if (paramFilenameURL == null) {
/*      */       
/*  512 */       errorMessage("Filename/URL not specified in method 'fadeOutIn'.");
/*      */       return;
/*      */     } 
/*  515 */     if (paramLong1 < 0L || paramLong2 < 0L) {
/*      */       
/*  517 */       errorMessage("Miliseconds may not be negative in method 'fadeOutIn'.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  522 */     this.fadeOutMilis = paramLong1;
/*  523 */     this.fadeInMilis = paramLong2;
/*      */     
/*  525 */     this.fadeOutGain = 1.0F;
/*  526 */     this.lastFadeCheck = System.currentTimeMillis();
/*      */     
/*  528 */     synchronized (this.soundSequenceLock) {
/*      */       
/*  530 */       if (this.soundSequenceQueue == null)
/*  531 */         this.soundSequenceQueue = new LinkedList(); 
/*  532 */       this.soundSequenceQueue.clear();
/*  533 */       this.soundSequenceQueue.add(paramFilenameURL);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean checkFadeOut() {
/*  546 */     if (!this.toStream) {
/*  547 */       return false;
/*      */     }
/*  549 */     if (this.fadeOutGain == -1.0F && this.fadeInGain == 1.0F) {
/*  550 */       return false;
/*      */     }
/*  552 */     long l1 = System.currentTimeMillis();
/*  553 */     long l2 = l1 - this.lastFadeCheck;
/*  554 */     this.lastFadeCheck = l1;
/*      */     
/*  556 */     if (this.fadeOutGain >= 0.0F) {
/*      */       
/*  558 */       if (this.fadeOutMilis == 0L) {
/*      */         
/*  560 */         this.fadeOutGain = -1.0F;
/*  561 */         this.fadeInGain = 0.0F;
/*  562 */         if (!incrementSoundSequence())
/*      */         {
/*  564 */           stop();
/*      */         }
/*  566 */         positionChanged();
/*  567 */         this.preLoad = true;
/*  568 */         return false;
/*      */       } 
/*      */ 
/*      */       
/*  572 */       float f = (float)l2 / (float)this.fadeOutMilis;
/*  573 */       this.fadeOutGain -= f;
/*  574 */       if (this.fadeOutGain <= 0.0F) {
/*      */         
/*  576 */         this.fadeOutGain = -1.0F;
/*  577 */         this.fadeInGain = 0.0F;
/*  578 */         if (!incrementSoundSequence())
/*  579 */           stop(); 
/*  580 */         positionChanged();
/*  581 */         this.preLoad = true;
/*  582 */         return false;
/*      */       } 
/*      */       
/*  585 */       positionChanged();
/*  586 */       return true;
/*      */     } 
/*      */     
/*  589 */     if (this.fadeInGain < 1.0F) {
/*      */       
/*  591 */       this.fadeOutGain = -1.0F;
/*  592 */       if (this.fadeInMilis == 0L) {
/*      */         
/*  594 */         this.fadeOutGain = -1.0F;
/*  595 */         this.fadeInGain = 1.0F;
/*      */       }
/*      */       else {
/*      */         
/*  599 */         float f = (float)l2 / (float)this.fadeInMilis;
/*  600 */         this.fadeInGain += f;
/*  601 */         if (this.fadeInGain >= 1.0F) {
/*      */           
/*  603 */           this.fadeOutGain = -1.0F;
/*  604 */           this.fadeInGain = 1.0F;
/*      */         } 
/*      */       } 
/*  607 */       positionChanged();
/*  608 */       return true;
/*      */     } 
/*  610 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean incrementSoundSequence() {
/*  622 */     if (!this.toStream) {
/*      */       
/*  624 */       errorMessage("Method 'incrementSoundSequence' may only be used for streaming and MIDI sources.");
/*      */       
/*  626 */       return false;
/*      */     } 
/*      */     
/*  629 */     synchronized (this.soundSequenceLock) {
/*      */       
/*  631 */       if (this.soundSequenceQueue != null && this.soundSequenceQueue.size() > 0) {
/*      */         
/*  633 */         this.filenameURL = this.soundSequenceQueue.remove(0);
/*  634 */         if (this.codec != null)
/*  635 */           this.codec.cleanup(); 
/*  636 */         this.codec = SoundSystemConfig.getCodec(this.filenameURL.getFilename());
/*  637 */         return true;
/*      */       } 
/*      */     } 
/*  640 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean readBuffersFromNextSoundInSequence() {
/*  652 */     if (!this.toStream) {
/*      */       
/*  654 */       errorMessage("Method 'readBuffersFromNextSoundInSequence' may only be used for streaming sources.");
/*      */       
/*  656 */       return false;
/*      */     } 
/*      */     
/*  659 */     synchronized (this.soundSequenceLock) {
/*      */       
/*  661 */       if (this.soundSequenceQueue != null && this.soundSequenceQueue.size() > 0) {
/*      */         
/*  663 */         if (this.nextCodec != null)
/*  664 */           this.nextCodec.cleanup(); 
/*  665 */         this.nextCodec = SoundSystemConfig.getCodec(((FilenameURL)this.soundSequenceQueue.get(0)).getFilename());
/*      */         
/*  667 */         this.nextCodec.initialize(((FilenameURL)this.soundSequenceQueue.get(0)).getURL());
/*      */         
/*  669 */         SoundBuffer soundBuffer = null;
/*  670 */         byte b = 0;
/*      */         
/*  672 */         for (; b < SoundSystemConfig.getNumberStreamingBuffers() && !this.nextCodec.endOfStream(); 
/*  673 */           b++) {
/*      */           
/*  675 */           soundBuffer = this.nextCodec.read();
/*  676 */           if (soundBuffer != null) {
/*      */             
/*  678 */             if (this.nextBuffers == null)
/*  679 */               this.nextBuffers = new LinkedList(); 
/*  680 */             this.nextBuffers.add(soundBuffer);
/*      */           } 
/*      */         } 
/*  683 */         return true;
/*      */       } 
/*      */     } 
/*  686 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int getSoundSequenceQueueSize() {
/*  696 */     if (this.soundSequenceQueue == null)
/*  697 */       return 0; 
/*  698 */     return this.soundSequenceQueue.size();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTemporary(boolean paramBoolean) {
/*  707 */     this.temporary = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void listenerMoved() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  724 */     this.position.x = paramFloat1;
/*  725 */     this.position.y = paramFloat2;
/*  726 */     this.position.z = paramFloat3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void positionChanged() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPriority(boolean paramBoolean) {
/*  743 */     this.priority = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLooping(boolean paramBoolean) {
/*  752 */     this.toLoop = paramBoolean;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttenuation(int paramInt) {
/*  761 */     this.attModel = paramInt;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDistOrRoll(float paramFloat) {
/*  771 */     this.distOrRoll = paramFloat;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  782 */     this.velocity.x = paramFloat1;
/*  783 */     this.velocity.y = paramFloat2;
/*  784 */     this.velocity.z = paramFloat3;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getDistanceFromListener() {
/*  793 */     return this.distanceFromListener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPitch(float paramFloat) {
/*  802 */     float f = paramFloat;
/*  803 */     if (f < 0.5F) {
/*  804 */       f = 0.5F;
/*  805 */     } else if (f > 2.0F) {
/*  806 */       f = 2.0F;
/*  807 */     }  this.pitch = f;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPitch() {
/*  816 */     return this.pitch;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean reverseByteOrder() {
/*  826 */     return SoundSystemConfig.reverseByteOrder(this.libraryType);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void changeSource(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, SoundBuffer paramSoundBuffer, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/*  849 */     this.priority = paramBoolean1;
/*  850 */     this.toStream = paramBoolean2;
/*  851 */     this.toLoop = paramBoolean3;
/*  852 */     this.sourcename = paramString;
/*  853 */     this.filenameURL = paramFilenameURL;
/*  854 */     this.soundBuffer = paramSoundBuffer;
/*  855 */     this.position.x = paramFloat1;
/*  856 */     this.position.y = paramFloat2;
/*  857 */     this.position.z = paramFloat3;
/*  858 */     this.attModel = paramInt;
/*  859 */     this.distOrRoll = paramFloat4;
/*  860 */     this.temporary = paramBoolean4;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int feedRawAudioData(Channel paramChannel, byte[] paramArrayOfbyte) {
/*  871 */     if (!active(false, false)) {
/*      */       
/*  873 */       this.toPlay = true;
/*  874 */       return -1;
/*      */     } 
/*  876 */     if (this.channel != paramChannel) {
/*      */       
/*  878 */       this.channel = paramChannel;
/*  879 */       this.channel.close();
/*  880 */       this.channel.setAudioFormat(this.rawDataFormat);
/*  881 */       positionChanged();
/*      */     } 
/*      */ 
/*      */     
/*  885 */     stopped(true, false);
/*  886 */     paused(true, false);
/*      */     
/*  888 */     return this.channel.feedRawAudioData(paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void play(Channel paramChannel) {
/*  897 */     if (!active(false, false)) {
/*      */       
/*  899 */       if (this.toLoop)
/*  900 */         this.toPlay = true; 
/*      */       return;
/*      */     } 
/*  903 */     if (this.channel != paramChannel) {
/*      */       
/*  905 */       this.channel = paramChannel;
/*  906 */       this.channel.close();
/*      */     } 
/*      */     
/*  909 */     stopped(true, false);
/*  910 */     paused(true, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean stream() {
/*  920 */     if (this.channel == null) {
/*  921 */       return false;
/*      */     }
/*  923 */     if (this.preLoad)
/*      */     {
/*  925 */       if (this.rawDataStream) {
/*  926 */         this.preLoad = false;
/*      */       } else {
/*  928 */         return preLoad();
/*      */       } 
/*      */     }
/*  931 */     if (this.rawDataStream) {
/*      */       
/*  933 */       if (stopped() || paused())
/*  934 */         return true; 
/*  935 */       if (this.channel.buffersProcessed() > 0)
/*  936 */         this.channel.processBuffer(); 
/*  937 */       return true;
/*      */     } 
/*      */ 
/*      */     
/*  941 */     if (this.codec == null)
/*  942 */       return false; 
/*  943 */     if (stopped())
/*  944 */       return false; 
/*  945 */     if (paused()) {
/*  946 */       return true;
/*      */     }
/*  948 */     int i = this.channel.buffersProcessed();
/*      */     
/*  950 */     SoundBuffer soundBuffer = null;
/*  951 */     for (byte b = 0; b < i; b++) {
/*      */       
/*  953 */       soundBuffer = this.codec.read();
/*  954 */       if (soundBuffer != null) {
/*      */         
/*  956 */         if (soundBuffer.audioData != null)
/*  957 */           this.channel.queueBuffer(soundBuffer.audioData); 
/*  958 */         soundBuffer.cleanup();
/*  959 */         soundBuffer = null;
/*  960 */         return true;
/*      */       } 
/*  962 */       if (this.codec.endOfStream())
/*      */       {
/*  964 */         synchronized (this.soundSequenceLock) {
/*      */           
/*  966 */           if (SoundSystemConfig.getStreamQueueFormatsMatch())
/*      */           {
/*  968 */             if (this.soundSequenceQueue != null && this.soundSequenceQueue.size() > 0) {
/*      */ 
/*      */               
/*  971 */               if (this.codec != null)
/*  972 */                 this.codec.cleanup(); 
/*  973 */               this.filenameURL = this.soundSequenceQueue.remove(0);
/*  974 */               this.codec = SoundSystemConfig.getCodec(this.filenameURL.getFilename());
/*      */               
/*  976 */               this.codec.initialize(this.filenameURL.getURL());
/*  977 */               soundBuffer = this.codec.read();
/*  978 */               if (soundBuffer != null)
/*      */               {
/*  980 */                 if (soundBuffer.audioData != null)
/*  981 */                   this.channel.queueBuffer(soundBuffer.audioData); 
/*  982 */                 soundBuffer.cleanup();
/*  983 */                 soundBuffer = null;
/*  984 */                 return true;
/*      */               }
/*      */             
/*  987 */             } else if (this.toLoop) {
/*      */               
/*  989 */               this.codec.initialize(this.filenameURL.getURL());
/*  990 */               soundBuffer = this.codec.read();
/*  991 */               if (soundBuffer != null) {
/*      */                 
/*  993 */                 if (soundBuffer.audioData != null)
/*  994 */                   this.channel.queueBuffer(soundBuffer.audioData); 
/*  995 */                 soundBuffer.cleanup();
/*  996 */                 soundBuffer = null;
/*  997 */                 return true;
/*      */               } 
/*      */             } 
/*      */           }
/*      */         } 
/*      */       }
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1040 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean preLoad() {
/* 1049 */     if (this.channel == null) {
/* 1050 */       return false;
/*      */     }
/* 1052 */     if (this.codec == null) {
/* 1053 */       return false;
/*      */     }
/* 1055 */     SoundBuffer soundBuffer = null;
/*      */     
/* 1057 */     boolean bool = false;
/* 1058 */     synchronized (this.soundSequenceLock) {
/*      */       
/* 1060 */       if (this.nextBuffers == null || this.nextBuffers.isEmpty()) {
/* 1061 */         bool = true;
/*      */       }
/*      */     } 
/* 1064 */     if (this.nextCodec != null && !bool) {
/*      */       
/* 1066 */       this.codec = this.nextCodec;
/* 1067 */       this.nextCodec = null;
/* 1068 */       synchronized (this.soundSequenceLock) {
/*      */         
/* 1070 */         while (!this.nextBuffers.isEmpty()) {
/*      */           
/* 1072 */           soundBuffer = this.nextBuffers.remove(0);
/* 1073 */           if (soundBuffer != null)
/*      */           {
/* 1075 */             if (soundBuffer.audioData != null)
/* 1076 */               this.channel.queueBuffer(soundBuffer.audioData); 
/* 1077 */             soundBuffer.cleanup();
/* 1078 */             soundBuffer = null;
/*      */           }
/*      */         
/*      */         } 
/*      */       } 
/*      */     } else {
/*      */       
/* 1085 */       this.nextCodec = null;
/* 1086 */       URL uRL = this.filenameURL.getURL();
/*      */       
/* 1088 */       this.codec.initialize(uRL);
/* 1089 */       for (byte b = 0; b < SoundSystemConfig.getNumberStreamingBuffers(); 
/* 1090 */         b++) {
/*      */         
/* 1092 */         soundBuffer = this.codec.read();
/* 1093 */         if (soundBuffer != null) {
/*      */           
/* 1095 */           if (soundBuffer.audioData != null)
/* 1096 */             this.channel.queueBuffer(soundBuffer.audioData); 
/* 1097 */           soundBuffer.cleanup();
/* 1098 */           soundBuffer = null;
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/* 1103 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pause() {
/* 1111 */     this.toPlay = false;
/* 1112 */     paused(true, true);
/* 1113 */     if (this.channel != null) {
/* 1114 */       this.channel.pause();
/*      */     } else {
/* 1116 */       errorMessage("Channel null in method 'pause'");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop() {
/* 1124 */     this.toPlay = false;
/* 1125 */     stopped(true, true);
/* 1126 */     paused(true, false);
/* 1127 */     if (this.channel != null) {
/* 1128 */       this.channel.stop();
/*      */     } else {
/* 1130 */       errorMessage("Channel null in method 'stop'");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rewind() {
/* 1138 */     if (paused(false, false))
/*      */     {
/* 1140 */       stop();
/*      */     }
/* 1142 */     if (this.channel != null) {
/*      */       
/* 1144 */       boolean bool = playing();
/* 1145 */       this.channel.rewind();
/* 1146 */       if (this.toStream && bool) {
/*      */         
/* 1148 */         stop();
/* 1149 */         play(this.channel);
/*      */       } 
/*      */     } else {
/*      */       
/* 1153 */       errorMessage("Channel null in method 'rewind'");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush() {
/* 1161 */     if (this.channel != null) {
/* 1162 */       this.channel.flush();
/*      */     } else {
/* 1164 */       errorMessage("Channel null in method 'flush'");
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cull() {
/* 1173 */     if (!active(false, false))
/*      */       return; 
/* 1175 */     if (playing() && this.toLoop)
/* 1176 */       this.toPlay = true; 
/* 1177 */     if (this.rawDataStream)
/* 1178 */       this.toPlay = true; 
/* 1179 */     active(true, false);
/* 1180 */     if (this.channel != null)
/* 1181 */       this.channel.close(); 
/* 1182 */     this.channel = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void activate() {
/* 1190 */     active(true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean active() {
/* 1199 */     return active(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean playing() {
/* 1208 */     if (this.channel == null || this.channel.attachedSource != this)
/* 1209 */       return false; 
/* 1210 */     if (paused() || stopped()) {
/* 1211 */       return false;
/*      */     }
/* 1213 */     return this.channel.playing();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean stopped() {
/* 1222 */     return stopped(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean paused() {
/* 1231 */     return paused(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float millisecondsPlayed() {
/* 1240 */     if (this.channel == null) {
/* 1241 */       return -1.0F;
/*      */     }
/* 1243 */     return this.channel.millisecondsPlayed();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized boolean active(boolean paramBoolean1, boolean paramBoolean2) {
/* 1252 */     if (paramBoolean1 == true)
/* 1253 */       this.active = paramBoolean2; 
/* 1254 */     return this.active;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized boolean stopped(boolean paramBoolean1, boolean paramBoolean2) {
/* 1263 */     if (paramBoolean1 == true)
/* 1264 */       this.stopped = paramBoolean2; 
/* 1265 */     return this.stopped;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private synchronized boolean paused(boolean paramBoolean1, boolean paramBoolean2) {
/* 1274 */     if (paramBoolean1 == true)
/* 1275 */       this.paused = paramBoolean2; 
/* 1276 */     return this.paused;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassName() {
/* 1285 */     String str = SoundSystemConfig.getLibraryTitle(this.libraryType);
/*      */     
/* 1287 */     if (str.equals("No Sound")) {
/* 1288 */       return "Source";
/*      */     }
/* 1290 */     return "Source" + str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void message(String paramString) {
/* 1298 */     this.logger.message(paramString, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void importantMessage(String paramString) {
/* 1307 */     this.logger.importantMessage(paramString, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean errorCheck(boolean paramBoolean, String paramString) {
/* 1318 */     return this.logger.errorCheck(paramBoolean, getClassName(), paramString, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void errorMessage(String paramString) {
/* 1327 */     this.logger.errorMessage(getClassName(), paramString, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void printStackTrace(Exception paramException) {
/* 1336 */     this.logger.printStackTrace(paramException, 1);
/*      */   }
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\Source.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */