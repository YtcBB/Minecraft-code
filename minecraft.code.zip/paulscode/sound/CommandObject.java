/*     */ package paulscode.sound;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CommandObject
/*     */ {
/*     */   public static final int INITIALIZE = 1;
/*     */   public static final int LOAD_SOUND = 2;
/*     */   public static final int LOAD_DATA = 3;
/*     */   public static final int UNLOAD_SOUND = 4;
/*     */   public static final int QUEUE_SOUND = 5;
/*     */   public static final int DEQUEUE_SOUND = 6;
/*     */   public static final int FADE_OUT = 7;
/*     */   public static final int FADE_OUT_IN = 8;
/*     */   public static final int CHECK_FADE_VOLUMES = 9;
/*     */   public static final int NEW_SOURCE = 10;
/*     */   public static final int RAW_DATA_STREAM = 11;
/*     */   public static final int QUICK_PLAY = 12;
/*     */   public static final int SET_POSITION = 13;
/*     */   public static final int SET_VOLUME = 14;
/*     */   public static final int SET_PITCH = 15;
/*     */   public static final int SET_PRIORITY = 16;
/*     */   public static final int SET_LOOPING = 17;
/*     */   public static final int SET_ATTENUATION = 18;
/*     */   public static final int SET_DIST_OR_ROLL = 19;
/*     */   public static final int CHANGE_DOPPLER_FACTOR = 20;
/*     */   public static final int CHANGE_DOPPLER_VELOCITY = 21;
/*     */   public static final int SET_VELOCITY = 22;
/*     */   public static final int SET_LISTENER_VELOCITY = 23;
/*     */   public static final int PLAY = 24;
/*     */   public static final int FEED_RAW_AUDIO_DATA = 25;
/*     */   public static final int PAUSE = 26;
/*     */   public static final int STOP = 27;
/*     */   public static final int REWIND = 28;
/*     */   public static final int FLUSH = 29;
/*     */   public static final int CULL = 30;
/*     */   public static final int ACTIVATE = 31;
/*     */   public static final int SET_TEMPORARY = 32;
/*     */   public static final int REMOVE_SOURCE = 33;
/*     */   public static final int MOVE_LISTENER = 34;
/*     */   public static final int SET_LISTENER_POSITION = 35;
/*     */   public static final int TURN_LISTENER = 36;
/*     */   public static final int SET_LISTENER_ANGLE = 37;
/*     */   public static final int SET_LISTENER_ORIENTATION = 38;
/*     */   public static final int SET_MASTER_VOLUME = 39;
/*     */   public static final int NEW_LIBRARY = 40;
/*     */   public byte[] buffer;
/*     */   public int[] intArgs;
/*     */   public float[] floatArgs;
/*     */   public long[] longArgs;
/*     */   public boolean[] boolArgs;
/*     */   public String[] stringArgs;
/*     */   public Class[] classArgs;
/*     */   public Object[] objectArgs;
/*     */   public int Command;
/*     */   
/*     */   public CommandObject(int paramInt) {
/* 252 */     this.Command = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt1, int paramInt2) {
/* 261 */     this.Command = paramInt1;
/* 262 */     this.intArgs = new int[1];
/* 263 */     this.intArgs[0] = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, Class paramClass) {
/* 273 */     this.Command = paramInt;
/* 274 */     this.classArgs = new Class[1];
/* 275 */     this.classArgs[0] = paramClass;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, float paramFloat) {
/* 284 */     this.Command = paramInt;
/* 285 */     this.floatArgs = new float[1];
/* 286 */     this.floatArgs[0] = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString) {
/* 295 */     this.Command = paramInt;
/* 296 */     this.stringArgs = new String[1];
/* 297 */     this.stringArgs[0] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, Object paramObject) {
/* 306 */     this.Command = paramInt;
/* 307 */     this.objectArgs = new Object[1];
/* 308 */     this.objectArgs[0] = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString, Object paramObject) {
/* 319 */     this.Command = paramInt;
/* 320 */     this.stringArgs = new String[1];
/* 321 */     this.stringArgs[0] = paramString;
/* 322 */     this.objectArgs = new Object[1];
/* 323 */     this.objectArgs[0] = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString, byte[] paramArrayOfbyte) {
/* 334 */     this.Command = paramInt;
/* 335 */     this.stringArgs = new String[1];
/* 336 */     this.stringArgs[0] = paramString;
/* 337 */     this.buffer = paramArrayOfbyte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString, Object paramObject, long paramLong) {
/* 349 */     this.Command = paramInt;
/* 350 */     this.stringArgs = new String[1];
/* 351 */     this.stringArgs[0] = paramString;
/* 352 */     this.objectArgs = new Object[1];
/* 353 */     this.objectArgs[0] = paramObject;
/* 354 */     this.longArgs = new long[1];
/* 355 */     this.longArgs[0] = paramLong;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString, Object paramObject, long paramLong1, long paramLong2) {
/* 368 */     this.Command = paramInt;
/* 369 */     this.stringArgs = new String[1];
/* 370 */     this.stringArgs[0] = paramString;
/* 371 */     this.objectArgs = new Object[1];
/* 372 */     this.objectArgs[0] = paramObject;
/* 373 */     this.longArgs = new long[2];
/* 374 */     this.longArgs[0] = paramLong1;
/* 375 */     this.longArgs[1] = paramLong2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString1, String paramString2) {
/* 385 */     this.Command = paramInt;
/* 386 */     this.stringArgs = new String[2];
/* 387 */     this.stringArgs[0] = paramString1;
/* 388 */     this.stringArgs[1] = paramString2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt1, String paramString, int paramInt2) {
/* 399 */     this.Command = paramInt1;
/* 400 */     this.intArgs = new int[1];
/* 401 */     this.stringArgs = new String[1];
/* 402 */     this.intArgs[0] = paramInt2;
/* 403 */     this.stringArgs[0] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString, float paramFloat) {
/* 414 */     this.Command = paramInt;
/* 415 */     this.floatArgs = new float[1];
/* 416 */     this.stringArgs = new String[1];
/* 417 */     this.floatArgs[0] = paramFloat;
/* 418 */     this.stringArgs[0] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString, boolean paramBoolean) {
/* 429 */     this.Command = paramInt;
/* 430 */     this.boolArgs = new boolean[1];
/* 431 */     this.stringArgs = new String[1];
/* 432 */     this.boolArgs[0] = paramBoolean;
/* 433 */     this.stringArgs[0] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 444 */     this.Command = paramInt;
/* 445 */     this.floatArgs = new float[3];
/* 446 */     this.floatArgs[0] = paramFloat1;
/* 447 */     this.floatArgs[1] = paramFloat2;
/* 448 */     this.floatArgs[2] = paramFloat3;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 461 */     this.Command = paramInt;
/* 462 */     this.floatArgs = new float[3];
/* 463 */     this.stringArgs = new String[1];
/* 464 */     this.floatArgs[0] = paramFloat1;
/* 465 */     this.floatArgs[1] = paramFloat2;
/* 466 */     this.floatArgs[2] = paramFloat3;
/* 467 */     this.stringArgs[0] = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt, float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 482 */     this.Command = paramInt;
/* 483 */     this.floatArgs = new float[6];
/* 484 */     this.floatArgs[0] = paramFloat1;
/* 485 */     this.floatArgs[1] = paramFloat2;
/* 486 */     this.floatArgs[2] = paramFloat3;
/* 487 */     this.floatArgs[3] = paramFloat4;
/* 488 */     this.floatArgs[4] = paramFloat5;
/* 489 */     this.floatArgs[5] = paramFloat6;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, Object paramObject, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt2, float paramFloat4) {
/* 511 */     this.Command = paramInt1;
/* 512 */     this.intArgs = new int[1];
/* 513 */     this.floatArgs = new float[4];
/* 514 */     this.boolArgs = new boolean[3];
/* 515 */     this.stringArgs = new String[1];
/* 516 */     this.objectArgs = new Object[1];
/* 517 */     this.intArgs[0] = paramInt2;
/* 518 */     this.floatArgs[0] = paramFloat1;
/* 519 */     this.floatArgs[1] = paramFloat2;
/* 520 */     this.floatArgs[2] = paramFloat3;
/* 521 */     this.floatArgs[3] = paramFloat4;
/* 522 */     this.boolArgs[0] = paramBoolean1;
/* 523 */     this.boolArgs[1] = paramBoolean2;
/* 524 */     this.boolArgs[2] = paramBoolean3;
/* 525 */     this.stringArgs[0] = paramString;
/* 526 */     this.objectArgs[0] = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt1, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, Object paramObject, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt2, float paramFloat4, boolean paramBoolean4) {
/* 550 */     this.Command = paramInt1;
/* 551 */     this.intArgs = new int[1];
/* 552 */     this.floatArgs = new float[4];
/* 553 */     this.boolArgs = new boolean[4];
/* 554 */     this.stringArgs = new String[1];
/* 555 */     this.objectArgs = new Object[1];
/* 556 */     this.intArgs[0] = paramInt2;
/* 557 */     this.floatArgs[0] = paramFloat1;
/* 558 */     this.floatArgs[1] = paramFloat2;
/* 559 */     this.floatArgs[2] = paramFloat3;
/* 560 */     this.floatArgs[3] = paramFloat4;
/* 561 */     this.boolArgs[0] = paramBoolean1;
/* 562 */     this.boolArgs[1] = paramBoolean2;
/* 563 */     this.boolArgs[2] = paramBoolean3;
/* 564 */     this.boolArgs[3] = paramBoolean4;
/* 565 */     this.stringArgs[0] = paramString;
/* 566 */     this.objectArgs[0] = paramObject;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CommandObject(int paramInt1, Object paramObject, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt2, float paramFloat4) {
/* 588 */     this.Command = paramInt1;
/* 589 */     this.intArgs = new int[1];
/* 590 */     this.floatArgs = new float[4];
/* 591 */     this.boolArgs = new boolean[1];
/* 592 */     this.stringArgs = new String[1];
/* 593 */     this.objectArgs = new Object[1];
/* 594 */     this.intArgs[0] = paramInt2;
/* 595 */     this.floatArgs[0] = paramFloat1;
/* 596 */     this.floatArgs[1] = paramFloat2;
/* 597 */     this.floatArgs[2] = paramFloat3;
/* 598 */     this.floatArgs[3] = paramFloat4;
/* 599 */     this.boolArgs[0] = paramBoolean;
/* 600 */     this.stringArgs[0] = paramString;
/* 601 */     this.objectArgs[0] = paramObject;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\CommandObject.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */