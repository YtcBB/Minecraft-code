/*     */ package paulscode.sound.codecs;
/*     */ 
/*     */ import com.jcraft.jogg.Packet;
/*     */ import com.jcraft.jogg.Page;
/*     */ import com.jcraft.jogg.StreamState;
/*     */ import com.jcraft.jogg.SyncState;
/*     */ import com.jcraft.jorbis.Block;
/*     */ import com.jcraft.jorbis.Comment;
/*     */ import com.jcraft.jorbis.DspState;
/*     */ import com.jcraft.jorbis.Info;
/*     */ import java.io.IOException;
/*     */ import java.io.InputStream;
/*     */ import java.net.URL;
/*     */ import java.net.URLConnection;
/*     */ import java.net.UnknownServiceException;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import paulscode.sound.ICodec;
/*     */ import paulscode.sound.SoundBuffer;
/*     */ import paulscode.sound.SoundSystemConfig;
/*     */ import paulscode.sound.SoundSystemLogger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class CodecJOrbis
/*     */   implements ICodec
/*     */ {
/*     */   private static final boolean GET = false;
/*     */   private static final boolean SET = true;
/*     */   private static final boolean XXX = false;
/*     */   protected URL url;
/*  98 */   protected URLConnection urlConnection = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private InputStream inputStream;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private AudioFormat audioFormat;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean endOfStream = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean initialized = false;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 124 */   private byte[] buffer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int bufferSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 134 */   private int count = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 139 */   private int index = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int convertedBufferSize;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 149 */   private byte[] convertedBuffer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private float[][][] pcmInfo;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private int[] pcmIndex;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 164 */   private Packet joggPacket = new Packet();
/*     */ 
/*     */ 
/*     */   
/* 168 */   private Page joggPage = new Page();
/*     */ 
/*     */ 
/*     */   
/* 172 */   private StreamState joggStreamState = new StreamState();
/*     */ 
/*     */ 
/*     */   
/* 176 */   private SyncState joggSyncState = new SyncState();
/*     */ 
/*     */ 
/*     */   
/* 180 */   private DspState jorbisDspState = new DspState();
/*     */ 
/*     */ 
/*     */   
/* 184 */   private Block jorbisBlock = new Block(this.jorbisDspState);
/*     */ 
/*     */ 
/*     */   
/* 188 */   private Comment jorbisComment = new Comment();
/*     */ 
/*     */ 
/*     */   
/* 192 */   private Info jorbisInfo = new Info();
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private SoundSystemLogger logger;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public CodecJOrbis() {
/* 204 */     this.logger = SoundSystemConfig.getLogger();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void reverseByteOrder(boolean paramBoolean) {}
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean initialize(URL paramURL) {
/* 222 */     initialized(true, false);
/*     */     
/* 224 */     if (this.joggStreamState != null)
/* 225 */       this.joggStreamState.clear(); 
/* 226 */     if (this.jorbisBlock != null)
/* 227 */       this.jorbisBlock.clear(); 
/* 228 */     if (this.jorbisDspState != null)
/* 229 */       this.jorbisDspState.clear(); 
/* 230 */     if (this.jorbisInfo != null)
/* 231 */       this.jorbisInfo.clear(); 
/* 232 */     if (this.joggSyncState != null) {
/* 233 */       this.joggSyncState.clear();
/*     */     }
/* 235 */     if (this.inputStream != null) {
/*     */       
/*     */       try {
/*     */         
/* 239 */         this.inputStream.close();
/*     */       }
/* 241 */       catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */     
/* 245 */     this.url = paramURL;
/*     */     
/* 247 */     this.bufferSize = 8192;
/*     */     
/* 249 */     this.buffer = null;
/* 250 */     this.count = 0;
/* 251 */     this.index = 0;
/*     */     
/* 253 */     this.joggStreamState = new StreamState();
/* 254 */     this.jorbisBlock = new Block(this.jorbisDspState);
/* 255 */     this.jorbisDspState = new DspState();
/* 256 */     this.jorbisInfo = new Info();
/* 257 */     this.joggSyncState = new SyncState();
/*     */ 
/*     */     
/*     */     try {
/* 261 */       this.urlConnection = paramURL.openConnection();
/*     */     }
/* 263 */     catch (UnknownServiceException unknownServiceException) {
/*     */       
/* 265 */       errorMessage("Unable to create a UrlConnection in method 'initialize'.");
/*     */       
/* 267 */       printStackTrace(unknownServiceException);
/* 268 */       cleanup();
/* 269 */       return false;
/*     */     }
/* 271 */     catch (IOException iOException) {
/*     */       
/* 273 */       errorMessage("Unable to create a UrlConnection in method 'initialize'.");
/*     */       
/* 275 */       printStackTrace(iOException);
/* 276 */       cleanup();
/* 277 */       return false;
/*     */     } 
/* 279 */     if (this.urlConnection != null) {
/*     */       
/*     */       try {
/*     */         
/* 283 */         this.inputStream = openInputStream();
/*     */       }
/* 285 */       catch (IOException iOException) {
/*     */         
/* 287 */         errorMessage("Unable to acquire inputstream in method 'initialize'.");
/*     */         
/* 289 */         printStackTrace(iOException);
/* 290 */         cleanup();
/* 291 */         return false;
/*     */       } 
/*     */     }
/*     */     
/* 295 */     endOfStream(true, false);
/*     */     
/* 297 */     this.joggSyncState.init();
/* 298 */     this.joggSyncState.buffer(this.bufferSize);
/* 299 */     this.buffer = this.joggSyncState.data;
/*     */ 
/*     */     
/*     */     try {
/* 303 */       if (!readHeader())
/*     */       {
/* 305 */         errorMessage("Error reading the header");
/* 306 */         return false;
/*     */       }
/*     */     
/* 309 */     } catch (IOException iOException) {
/*     */       
/* 311 */       errorMessage("Error reading the header");
/* 312 */       return false;
/*     */     } 
/*     */     
/* 315 */     this.convertedBufferSize = this.bufferSize * 2;
/*     */     
/* 317 */     this.jorbisDspState.synthesis_init(this.jorbisInfo);
/* 318 */     this.jorbisBlock.init(this.jorbisDspState);
/*     */     
/* 320 */     int i = this.jorbisInfo.channels;
/* 321 */     int j = this.jorbisInfo.rate;
/*     */     
/* 323 */     this.audioFormat = new AudioFormat(j, 16, i, true, false);
/*     */     
/* 325 */     this.pcmInfo = new float[1][][];
/* 326 */     this.pcmIndex = new int[this.jorbisInfo.channels];
/*     */     
/* 328 */     initialized(true, true);
/*     */     
/* 330 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   protected InputStream openInputStream() {
/* 335 */     return this.urlConnection.getInputStream();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean initialized() {
/* 345 */     return initialized(false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SoundBuffer read() {
/* 356 */     byte[] arrayOfByte = null;
/*     */     
/* 358 */     while (!endOfStream(false, false) && (arrayOfByte == null || arrayOfByte.length < SoundSystemConfig.getStreamingBufferSize())) {
/*     */ 
/*     */       
/* 361 */       if (arrayOfByte == null) {
/* 362 */         arrayOfByte = readBytes(); continue;
/*     */       } 
/* 364 */       arrayOfByte = appendByteArrays(arrayOfByte, readBytes());
/*     */     } 
/*     */     
/* 367 */     if (arrayOfByte == null) {
/* 368 */       return null;
/*     */     }
/* 370 */     return new SoundBuffer(arrayOfByte, this.audioFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SoundBuffer readAll() {
/* 382 */     byte[] arrayOfByte = null;
/*     */     
/* 384 */     while (!endOfStream(false, false)) {
/*     */       
/* 386 */       if (arrayOfByte == null) {
/* 387 */         arrayOfByte = readBytes(); continue;
/*     */       } 
/* 389 */       arrayOfByte = appendByteArrays(arrayOfByte, readBytes());
/*     */     } 
/*     */     
/* 392 */     if (arrayOfByte == null) {
/* 393 */       return null;
/*     */     }
/* 395 */     return new SoundBuffer(arrayOfByte, this.audioFormat);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean endOfStream() {
/* 404 */     return endOfStream(false, false);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 412 */     this.joggStreamState.clear();
/* 413 */     this.jorbisBlock.clear();
/* 414 */     this.jorbisDspState.clear();
/* 415 */     this.jorbisInfo.clear();
/* 416 */     this.joggSyncState.clear();
/*     */     
/* 418 */     if (this.inputStream != null) {
/*     */       
/*     */       try {
/*     */         
/* 422 */         this.inputStream.close();
/*     */       }
/* 424 */       catch (IOException iOException) {}
/*     */     }
/*     */ 
/*     */     
/* 428 */     this.joggStreamState = null;
/* 429 */     this.jorbisBlock = null;
/* 430 */     this.jorbisDspState = null;
/* 431 */     this.jorbisInfo = null;
/* 432 */     this.joggSyncState = null;
/* 433 */     this.inputStream = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public AudioFormat getAudioFormat() {
/* 443 */     return this.audioFormat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean readHeader() {
/* 454 */     this.index = this.joggSyncState.buffer(this.bufferSize);
/*     */     
/* 456 */     int i = this.inputStream.read(this.joggSyncState.data, this.index, this.bufferSize);
/* 457 */     if (i < 0) {
/* 458 */       i = 0;
/*     */     }
/* 460 */     this.joggSyncState.wrote(i);
/*     */     
/* 462 */     if (this.joggSyncState.pageout(this.joggPage) != 1) {
/*     */ 
/*     */       
/* 465 */       if (i < this.bufferSize) {
/* 466 */         return true;
/*     */       }
/* 468 */       errorMessage("Ogg header not recognized in method 'readHeader'.");
/* 469 */       return false;
/*     */     } 
/*     */ 
/*     */     
/* 473 */     this.joggStreamState.init(this.joggPage.serialno());
/*     */     
/* 475 */     this.jorbisInfo.init();
/* 476 */     this.jorbisComment.init();
/* 477 */     if (this.joggStreamState.pagein(this.joggPage) < 0) {
/*     */       
/* 479 */       errorMessage("Problem with first Ogg header page in method 'readHeader'.");
/*     */       
/* 481 */       return false;
/*     */     } 
/*     */     
/* 484 */     if (this.joggStreamState.packetout(this.joggPacket) != 1) {
/*     */       
/* 486 */       errorMessage("Problem with first Ogg header packet in method 'readHeader'.");
/*     */       
/* 488 */       return false;
/*     */     } 
/*     */     
/* 491 */     if (this.jorbisInfo.synthesis_headerin(this.jorbisComment, this.joggPacket) < 0) {
/*     */       
/* 493 */       errorMessage("File does not contain Vorbis header in method 'readHeader'.");
/*     */       
/* 495 */       return false;
/*     */     } 
/*     */     
/* 498 */     byte b = 0;
/* 499 */     while (b < 2) {
/*     */       
/* 501 */       while (b < 2) {
/*     */         
/* 503 */         int j = this.joggSyncState.pageout(this.joggPage);
/* 504 */         if (j == 0)
/*     */           break; 
/* 506 */         if (j == 1) {
/*     */           
/* 508 */           this.joggStreamState.pagein(this.joggPage);
/* 509 */           while (b < 2) {
/*     */             
/* 511 */             j = this.joggStreamState.packetout(this.joggPacket);
/* 512 */             if (j == 0) {
/*     */               break;
/*     */             }
/* 515 */             if (j == -1) {
/*     */               
/* 517 */               errorMessage("Secondary Ogg header corrupt in method 'readHeader'.");
/*     */               
/* 519 */               return false;
/*     */             } 
/*     */             
/* 522 */             this.jorbisInfo.synthesis_headerin(this.jorbisComment, this.joggPacket);
/*     */             
/* 524 */             b++;
/*     */           } 
/*     */         } 
/*     */       } 
/* 528 */       this.index = this.joggSyncState.buffer(this.bufferSize);
/* 529 */       i = this.inputStream.read(this.joggSyncState.data, this.index, this.bufferSize);
/* 530 */       if (i < 0)
/* 531 */         i = 0; 
/* 532 */       if (i == 0 && b < 2) {
/*     */         
/* 534 */         errorMessage("End of file reached before finished readingOgg header in method 'readHeader'");
/*     */         
/* 536 */         return false;
/*     */       } 
/*     */       
/* 539 */       this.joggSyncState.wrote(i);
/*     */     } 
/*     */     
/* 542 */     this.index = this.joggSyncState.buffer(this.bufferSize);
/* 543 */     this.buffer = this.joggSyncState.data;
/*     */     
/* 545 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private byte[] readBytes() {
/* 554 */     if (!initialized(false, false)) {
/* 555 */       return null;
/*     */     }
/* 557 */     if (endOfStream(false, false)) {
/* 558 */       return null;
/*     */     }
/* 560 */     if (this.convertedBuffer == null)
/* 561 */       this.convertedBuffer = new byte[this.convertedBufferSize]; 
/* 562 */     byte[] arrayOfByte = null;
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 567 */     switch (this.joggSyncState.pageout(this.joggPage)) {
/*     */       case -1:
/*     */       case 0:
/*     */         break;
/*     */ 
/*     */       
/*     */       default:
/* 574 */         this.joggStreamState.pagein(this.joggPage);
/* 575 */         if (this.joggPage.granulepos() == 0L) {
/*     */           
/* 577 */           endOfStream(true, true);
/* 578 */           return null;
/*     */         } 
/*     */ 
/*     */         
/*     */         while (true) {
/* 583 */           switch (this.joggStreamState.packetout(this.joggPacket)) {
/*     */             case 0:
/*     */               break;
/*     */             
/*     */             case -1:
/*     */               continue;
/*     */           } 
/*     */           
/* 591 */           if (this.jorbisBlock.synthesis(this.joggPacket) == 0) {
/* 592 */             this.jorbisDspState.synthesis_blockin(this.jorbisBlock);
/*     */           }
/*     */           int i;
/* 595 */           while ((i = this.jorbisDspState.synthesis_pcmout(this.pcmInfo, this.pcmIndex)) > 0) {
/*     */             
/* 597 */             float[][] arrayOfFloat = this.pcmInfo[0];
/* 598 */             int j = (i < this.convertedBufferSize) ? i : this.convertedBufferSize;
/*     */             
/* 600 */             for (byte b = 0; b < this.jorbisInfo.channels; b++) {
/*     */               
/* 602 */               int k = b * 2;
/* 603 */               int m = this.pcmIndex[b];
/* 604 */               for (byte b1 = 0; b1 < j; b1++) {
/*     */                 
/* 606 */                 int n = (int)(arrayOfFloat[b][m + b1] * 32767.0D);
/*     */                 
/* 608 */                 if (n > 32767)
/* 609 */                   n = 32767; 
/* 610 */                 if (n < -32768)
/* 611 */                   n = -32768; 
/* 612 */                 if (n < 0)
/* 613 */                   n |= 0x8000; 
/* 614 */                 this.convertedBuffer[k] = (byte)n;
/* 615 */                 this.convertedBuffer[k + 1] = (byte)(n >>> 8);
/*     */                 
/* 617 */                 k += 2 * this.jorbisInfo.channels;
/*     */               } 
/*     */             } 
/* 620 */             this.jorbisDspState.synthesis_read(j);
/*     */             
/* 622 */             arrayOfByte = appendByteArrays(arrayOfByte, this.convertedBuffer, 2 * this.jorbisInfo.channels * j);
/*     */           } 
/*     */         } 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 630 */         if (this.joggPage.eos() != 0) {
/* 631 */           endOfStream(true, true);
/*     */         }
/*     */         break;
/*     */     } 
/* 635 */     if (!endOfStream(false, false)) {
/*     */       
/* 637 */       this.index = this.joggSyncState.buffer(this.bufferSize);
/* 638 */       this.buffer = this.joggSyncState.data;
/*     */       
/*     */       try {
/* 641 */         this.count = this.inputStream.read(this.buffer, this.index, this.bufferSize);
/*     */       }
/* 643 */       catch (Exception exception) {
/*     */         
/* 645 */         printStackTrace(exception);
/* 646 */         return null;
/*     */       } 
/* 648 */       if (this.count == -1) {
/* 649 */         return arrayOfByte;
/*     */       }
/* 651 */       this.joggSyncState.wrote(this.count);
/* 652 */       if (this.count == 0) {
/* 653 */         endOfStream(true, true);
/*     */       }
/*     */     } 
/* 656 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean initialized(boolean paramBoolean1, boolean paramBoolean2) {
/* 667 */     if (paramBoolean1 == true)
/* 668 */       this.initialized = paramBoolean2; 
/* 669 */     return this.initialized;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private synchronized boolean endOfStream(boolean paramBoolean1, boolean paramBoolean2) {
/* 680 */     if (paramBoolean1 == true)
/* 681 */       this.endOfStream = paramBoolean2; 
/* 682 */     return this.endOfStream;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] trimArray(byte[] paramArrayOfbyte, int paramInt) {
/* 694 */     byte[] arrayOfByte = null;
/* 695 */     if (paramArrayOfbyte != null && paramArrayOfbyte.length > paramInt) {
/*     */       
/* 697 */       arrayOfByte = new byte[paramInt];
/* 698 */       System.arraycopy(paramArrayOfbyte, 0, arrayOfByte, 0, paramInt);
/*     */     } 
/* 700 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] appendByteArrays(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2, int paramInt) {
/*     */     byte[] arrayOfByte;
/* 715 */     int i = paramInt;
/*     */ 
/*     */     
/* 718 */     if (paramArrayOfbyte2 == null || paramArrayOfbyte2.length == 0) {
/* 719 */       i = 0;
/* 720 */     } else if (paramArrayOfbyte2.length < paramInt) {
/* 721 */       i = paramArrayOfbyte2.length;
/*     */     } 
/* 723 */     if (paramArrayOfbyte1 == null && (paramArrayOfbyte2 == null || i <= 0))
/*     */     {
/*     */       
/* 726 */       return null;
/*     */     }
/* 728 */     if (paramArrayOfbyte1 == null) {
/*     */ 
/*     */       
/* 731 */       arrayOfByte = new byte[i];
/*     */       
/* 733 */       System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, 0, i);
/* 734 */       paramArrayOfbyte2 = null;
/*     */     }
/* 736 */     else if (paramArrayOfbyte2 == null || i <= 0) {
/*     */ 
/*     */       
/* 739 */       arrayOfByte = new byte[paramArrayOfbyte1.length];
/*     */       
/* 741 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, paramArrayOfbyte1.length);
/* 742 */       paramArrayOfbyte1 = null;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 747 */       arrayOfByte = new byte[paramArrayOfbyte1.length + i];
/* 748 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, paramArrayOfbyte1.length);
/*     */       
/* 750 */       System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, paramArrayOfbyte1.length, i);
/*     */       
/* 752 */       paramArrayOfbyte1 = null;
/* 753 */       paramArrayOfbyte2 = null;
/*     */     } 
/*     */     
/* 756 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static byte[] appendByteArrays(byte[] paramArrayOfbyte1, byte[] paramArrayOfbyte2) {
/*     */     byte[] arrayOfByte;
/* 769 */     if (paramArrayOfbyte1 == null && paramArrayOfbyte2 == null)
/*     */     {
/*     */       
/* 772 */       return null;
/*     */     }
/* 774 */     if (paramArrayOfbyte1 == null) {
/*     */ 
/*     */       
/* 777 */       arrayOfByte = new byte[paramArrayOfbyte2.length];
/*     */       
/* 779 */       System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, 0, paramArrayOfbyte2.length);
/* 780 */       paramArrayOfbyte2 = null;
/*     */     }
/* 782 */     else if (paramArrayOfbyte2 == null) {
/*     */ 
/*     */       
/* 785 */       arrayOfByte = new byte[paramArrayOfbyte1.length];
/*     */       
/* 787 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, paramArrayOfbyte1.length);
/* 788 */       paramArrayOfbyte1 = null;
/*     */     
/*     */     }
/*     */     else {
/*     */       
/* 793 */       arrayOfByte = new byte[paramArrayOfbyte1.length + paramArrayOfbyte2.length];
/* 794 */       System.arraycopy(paramArrayOfbyte1, 0, arrayOfByte, 0, paramArrayOfbyte1.length);
/*     */       
/* 796 */       System.arraycopy(paramArrayOfbyte2, 0, arrayOfByte, paramArrayOfbyte1.length, paramArrayOfbyte2.length);
/*     */       
/* 798 */       paramArrayOfbyte1 = null;
/* 799 */       paramArrayOfbyte2 = null;
/*     */     } 
/*     */     
/* 802 */     return arrayOfByte;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void errorMessage(String paramString) {
/* 811 */     this.logger.errorMessage("CodecJOrbis", paramString, 0);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void printStackTrace(Exception paramException) {
/* 820 */     this.logger.printStackTrace(paramException, 1);
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\codecs\CodecJOrbis.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */