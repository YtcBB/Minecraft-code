/*     */ package paulscode.sound.libraries;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import java.util.List;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.Clip;
/*     */ import javax.sound.sampled.DataLine;
/*     */ import javax.sound.sampled.FloatControl;
/*     */ import javax.sound.sampled.Mixer;
/*     */ import javax.sound.sampled.SourceDataLine;
/*     */ import paulscode.sound.Channel;
/*     */ import paulscode.sound.SoundBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelJavaSound
/*     */   extends Channel
/*     */ {
/*  63 */   public Clip clip = null;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   SoundBuffer soundBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  75 */   public SourceDataLine sourceDataLine = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private List streamBuffers;
/*     */ 
/*     */ 
/*     */   
/*  84 */   private int processed = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  91 */   private Mixer myMixer = null;
/*     */ 
/*     */ 
/*     */   
/*  95 */   private AudioFormat myFormat = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private FloatControl gainControl = null;
/*     */ 
/*     */ 
/*     */   
/* 104 */   private FloatControl panControl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 109 */   private FloatControl sampleRateControl = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 114 */   private float initialGain = 0.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 119 */   private float initialSampleRate = 0.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean toLoop = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelJavaSound(int paramInt, Mixer paramMixer) {
/* 136 */     super(paramInt);
/* 137 */     this.libraryType = LibraryJavaSound.class;
/*     */     
/* 139 */     this.myMixer = paramMixer;
/* 140 */     this.clip = null;
/* 141 */     this.sourceDataLine = null;
/* 142 */     this.streamBuffers = new LinkedList();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 152 */     if (this.streamBuffers != null) {
/*     */       
/* 154 */       SoundBuffer soundBuffer = null;
/* 155 */       while (!this.streamBuffers.isEmpty()) {
/*     */         
/* 157 */         soundBuffer = this.streamBuffers.remove(0);
/* 158 */         soundBuffer.cleanup();
/* 159 */         soundBuffer = null;
/*     */       } 
/* 161 */       this.streamBuffers.clear();
/*     */     } 
/*     */     
/* 164 */     this.clip = null;
/* 165 */     this.soundBuffer = null;
/* 166 */     this.sourceDataLine = null;
/* 167 */     this.streamBuffers.clear();
/* 168 */     this.myMixer = null;
/* 169 */     this.myFormat = null;
/* 170 */     this.streamBuffers = null;
/*     */     
/* 172 */     super.cleanup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void newMixer(Mixer paramMixer) {
/* 181 */     if (this.myMixer != paramMixer) {
/*     */ 
/*     */       
/*     */       try {
/* 185 */         if (this.clip != null) {
/* 186 */           this.clip.close();
/* 187 */         } else if (this.sourceDataLine != null) {
/* 188 */           this.sourceDataLine.close();
/*     */         } 
/* 190 */       } catch (SecurityException securityException) {}
/*     */ 
/*     */       
/* 193 */       this.myMixer = paramMixer;
/* 194 */       if (this.attachedSource != null)
/*     */       {
/* 196 */         if (this.channelType == 0 && this.soundBuffer != null) {
/*     */           
/* 198 */           attachBuffer(this.soundBuffer);
/* 199 */         } else if (this.myFormat != null) {
/* 200 */           resetStream(this.myFormat);
/*     */         } 
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean attachBuffer(SoundBuffer paramSoundBuffer) {
/* 213 */     if (errorCheck((this.channelType != 0), "Buffers may only be attached to non-streaming sources"))
/*     */     {
/*     */       
/* 216 */       return false;
/*     */     }
/*     */     
/* 219 */     if (errorCheck((this.myMixer == null), "Mixer null in method 'attachBuffer'"))
/*     */     {
/* 221 */       return false;
/*     */     }
/*     */     
/* 224 */     if (errorCheck((paramSoundBuffer == null), "Buffer null in method 'attachBuffer'"))
/*     */     {
/* 226 */       return false;
/*     */     }
/*     */     
/* 229 */     if (errorCheck((paramSoundBuffer.audioData == null), "Buffer missing audio data in method 'attachBuffer'"))
/*     */     {
/*     */       
/* 232 */       return false;
/*     */     }
/*     */     
/* 235 */     if (errorCheck((paramSoundBuffer.audioFormat == null), "Buffer missing format information in method 'attachBuffer'"))
/*     */     {
/*     */       
/* 238 */       return false;
/*     */     }
/*     */     
/* 241 */     DataLine.Info info = new DataLine.Info(Clip.class, paramSoundBuffer.audioFormat);
/* 242 */     if (errorCheck(!AudioSystem.isLineSupported(info), "Line not supported in method 'attachBuffer'"))
/*     */     {
/* 244 */       return false;
/*     */     }
/* 246 */     Clip clip = null;
/*     */     
/*     */     try {
/* 249 */       clip = (Clip)this.myMixer.getLine(info);
/*     */     }
/* 251 */     catch (Exception exception) {
/*     */       
/* 253 */       errorMessage("Unable to create clip in method 'attachBuffer'");
/* 254 */       printStackTrace(exception);
/* 255 */       return false;
/*     */     } 
/*     */     
/* 258 */     if (errorCheck((clip == null), "New clip null in method 'attachBuffer'"))
/*     */     {
/* 260 */       return false;
/*     */     }
/*     */     
/* 263 */     if (this.clip != null) {
/*     */       
/* 265 */       this.clip.stop();
/* 266 */       this.clip.flush();
/* 267 */       this.clip.close();
/*     */     } 
/*     */ 
/*     */     
/* 271 */     this.clip = clip;
/* 272 */     this.soundBuffer = paramSoundBuffer;
/* 273 */     this.myFormat = paramSoundBuffer.audioFormat;
/* 274 */     clip = null;
/*     */ 
/*     */     
/*     */     try {
/* 278 */       this.clip.open(this.myFormat, paramSoundBuffer.audioData, 0, paramSoundBuffer.audioData.length);
/*     */     }
/* 280 */     catch (Exception exception) {
/*     */       
/* 282 */       errorMessage("Unable to attach buffer to clip in method 'attachBuffer'");
/*     */       
/* 284 */       printStackTrace(exception);
/* 285 */       return false;
/*     */     } 
/*     */     
/* 288 */     resetControls();
/*     */ 
/*     */     
/* 291 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAudioFormat(AudioFormat paramAudioFormat) {
/* 301 */     resetStream(paramAudioFormat);
/* 302 */     if (this.attachedSource != null && this.attachedSource.rawDataStream && this.attachedSource.active() && this.sourceDataLine != null)
/*     */     {
/* 304 */       this.sourceDataLine.start();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean resetStream(AudioFormat paramAudioFormat) {
/* 315 */     if (errorCheck((this.myMixer == null), "Mixer null in method 'resetStream'"))
/*     */     {
/* 317 */       return false;
/*     */     }
/*     */     
/* 320 */     if (errorCheck((paramAudioFormat == null), "AudioFormat null in method 'resetStream'"))
/*     */     {
/* 322 */       return false;
/*     */     }
/*     */     
/* 325 */     DataLine.Info info = new DataLine.Info(SourceDataLine.class, paramAudioFormat);
/* 326 */     if (errorCheck(!AudioSystem.isLineSupported(info), "Line not supported in method 'resetStream'"))
/*     */     {
/* 328 */       return false;
/*     */     }
/* 330 */     SourceDataLine sourceDataLine = null;
/*     */     
/*     */     try {
/* 333 */       sourceDataLine = (SourceDataLine)this.myMixer.getLine(info);
/*     */     }
/* 335 */     catch (Exception exception) {
/*     */       
/* 337 */       errorMessage("Unable to create a SourceDataLine in method 'resetStream'");
/*     */       
/* 339 */       printStackTrace(exception);
/* 340 */       return false;
/*     */     } 
/*     */     
/* 343 */     if (errorCheck((sourceDataLine == null), "New SourceDataLine null in method 'resetStream'"))
/*     */     {
/* 345 */       return false;
/*     */     }
/* 347 */     this.streamBuffers.clear();
/* 348 */     this.processed = 0;
/*     */ 
/*     */     
/* 351 */     if (this.sourceDataLine != null) {
/*     */       
/* 353 */       this.sourceDataLine.stop();
/* 354 */       this.sourceDataLine.flush();
/* 355 */       this.sourceDataLine.close();
/*     */     } 
/*     */ 
/*     */     
/* 359 */     this.sourceDataLine = sourceDataLine;
/* 360 */     this.myFormat = paramAudioFormat;
/* 361 */     sourceDataLine = null;
/*     */ 
/*     */     
/*     */     try {
/* 365 */       this.sourceDataLine.open(this.myFormat);
/*     */     }
/* 367 */     catch (Exception exception) {
/*     */       
/* 369 */       errorMessage("Unable to open the new SourceDataLine in method 'resetStream'");
/*     */       
/* 371 */       printStackTrace(exception);
/* 372 */       return false;
/*     */     } 
/*     */     
/* 375 */     resetControls();
/*     */ 
/*     */     
/* 378 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetControls() {
/* 386 */     switch (this.channelType) {
/*     */       
/*     */       case 0:
/*     */         
/*     */         try {
/*     */           
/* 392 */           if (!this.clip.isControlSupported(FloatControl.Type.PAN)) {
/* 393 */             this.panControl = null;
/*     */           } else {
/*     */             
/* 396 */             this.panControl = (FloatControl)this.clip.getControl(FloatControl.Type.PAN);
/*     */           }
/*     */         
/* 399 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */           
/* 401 */           this.panControl = null;
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 406 */           if (!this.clip.isControlSupported(FloatControl.Type.MASTER_GAIN))
/*     */           {
/* 408 */             this.gainControl = null;
/* 409 */             this.initialGain = 0.0F;
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 414 */             this.gainControl = (FloatControl)this.clip.getControl(FloatControl.Type.MASTER_GAIN);
/*     */ 
/*     */             
/* 417 */             this.initialGain = this.gainControl.getValue();
/*     */           }
/*     */         
/* 420 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */           
/* 422 */           this.gainControl = null;
/* 423 */           this.initialGain = 0.0F;
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 428 */           if (!this.clip.isControlSupported(FloatControl.Type.SAMPLE_RATE))
/*     */           {
/* 430 */             this.sampleRateControl = null;
/* 431 */             this.initialSampleRate = 0.0F;
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 436 */             this.sampleRateControl = (FloatControl)this.clip.getControl(FloatControl.Type.SAMPLE_RATE);
/*     */ 
/*     */             
/* 439 */             this.initialSampleRate = this.sampleRateControl.getValue();
/*     */           }
/*     */         
/* 442 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */           
/* 444 */           this.sampleRateControl = null;
/* 445 */           this.initialSampleRate = 0.0F;
/*     */         } 
/*     */         return;
/*     */ 
/*     */ 
/*     */       
/*     */       case 1:
/*     */         try {
/* 453 */           if (!this.sourceDataLine.isControlSupported(FloatControl.Type.PAN)) {
/*     */             
/* 455 */             this.panControl = null;
/*     */           } else {
/*     */             
/* 458 */             this.panControl = (FloatControl)this.sourceDataLine.getControl(FloatControl.Type.PAN);
/*     */           }
/*     */         
/* 461 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */           
/* 463 */           this.panControl = null;
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 468 */           if (!this.sourceDataLine.isControlSupported(FloatControl.Type.MASTER_GAIN))
/*     */           {
/*     */             
/* 471 */             this.gainControl = null;
/* 472 */             this.initialGain = 0.0F;
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 477 */             this.gainControl = (FloatControl)this.sourceDataLine.getControl(FloatControl.Type.MASTER_GAIN);
/*     */ 
/*     */             
/* 480 */             this.initialGain = this.gainControl.getValue();
/*     */           }
/*     */         
/* 483 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */           
/* 485 */           this.gainControl = null;
/* 486 */           this.initialGain = 0.0F;
/*     */         } 
/*     */ 
/*     */         
/*     */         try {
/* 491 */           if (!this.sourceDataLine.isControlSupported(FloatControl.Type.SAMPLE_RATE))
/*     */           {
/*     */             
/* 494 */             this.sampleRateControl = null;
/* 495 */             this.initialSampleRate = 0.0F;
/*     */           
/*     */           }
/*     */           else
/*     */           {
/* 500 */             this.sampleRateControl = (FloatControl)this.sourceDataLine.getControl(FloatControl.Type.SAMPLE_RATE);
/*     */ 
/*     */             
/* 503 */             this.initialSampleRate = this.sampleRateControl.getValue();
/*     */           }
/*     */         
/* 506 */         } catch (IllegalArgumentException illegalArgumentException) {
/*     */           
/* 508 */           this.sampleRateControl = null;
/* 509 */           this.initialSampleRate = 0.0F;
/*     */         } 
/*     */         return;
/*     */     } 
/* 513 */     errorMessage("Unrecognized channel type in method 'resetControls'");
/*     */     
/* 515 */     this.panControl = null;
/* 516 */     this.gainControl = null;
/* 517 */     this.sampleRateControl = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLooping(boolean paramBoolean) {
/* 528 */     this.toLoop = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPan(float paramFloat) {
/* 539 */     if (this.panControl == null)
/*     */       return; 
/* 541 */     float f = paramFloat;
/*     */     
/* 543 */     if (f < -1.0F)
/* 544 */       f = -1.0F; 
/* 545 */     if (f > 1.0F) {
/* 546 */       f = 1.0F;
/*     */     }
/* 548 */     this.panControl.setValue(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setGain(float paramFloat) {
/* 558 */     if (this.gainControl == null) {
/*     */       return;
/*     */     }
/*     */     
/* 562 */     float f1 = paramFloat;
/* 563 */     if (f1 < 0.0F)
/* 564 */       f1 = 0.0F; 
/* 565 */     if (f1 > 1.0F) {
/* 566 */       f1 = 1.0F;
/*     */     }
/* 568 */     double d1 = this.gainControl.getMinimum();
/* 569 */     double d2 = this.initialGain;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 575 */     double d3 = 0.5D * d2 - d1;
/* 576 */     double d4 = Math.log(10.0D) / 20.0D;
/* 577 */     float f2 = (float)(d1 + 1.0D / d4 * Math.log(1.0D + (Math.exp(d4 * d3) - 1.0D) * f1));
/*     */ 
/*     */ 
/*     */     
/* 581 */     this.gainControl.setValue(f2);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPitch(float paramFloat) {
/* 591 */     if (this.sampleRateControl == null) {
/*     */       return;
/*     */     }
/*     */     
/* 595 */     float f = paramFloat;
/*     */ 
/*     */     
/* 598 */     if (f < 0.5F)
/* 599 */       f = 0.5F; 
/* 600 */     if (f > 2.0F) {
/* 601 */       f = 2.0F;
/*     */     }
/* 603 */     f *= this.initialSampleRate;
/*     */ 
/*     */     
/* 606 */     this.sampleRateControl.setValue(f);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preLoadBuffers(LinkedList<byte[]> paramLinkedList) {
/* 618 */     if (errorCheck((this.channelType != 1), "Buffers may only be queued for streaming sources."))
/*     */     {
/* 620 */       return false;
/*     */     }
/*     */     
/* 623 */     if (errorCheck((this.sourceDataLine == null), "SourceDataLine null in method 'preLoadBuffers'."))
/*     */     {
/* 625 */       return false;
/*     */     }
/* 627 */     this.sourceDataLine.start();
/*     */     
/* 629 */     if (paramLinkedList.isEmpty()) {
/* 630 */       return true;
/*     */     }
/*     */     
/* 633 */     byte[] arrayOfByte = paramLinkedList.remove(0);
/*     */ 
/*     */     
/* 636 */     if (errorCheck((arrayOfByte == null), "Missing sound-bytes in method 'preLoadBuffers'."))
/*     */     {
/* 638 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 642 */     while (!paramLinkedList.isEmpty())
/*     */     {
/* 644 */       this.streamBuffers.add(new SoundBuffer(paramLinkedList.remove(0), this.myFormat));
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 649 */     this.sourceDataLine.write(arrayOfByte, 0, arrayOfByte.length);
/*     */ 
/*     */     
/* 652 */     this.processed = 0;
/*     */     
/* 654 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean queueBuffer(byte[] paramArrayOfbyte) {
/* 666 */     if (errorCheck((this.channelType != 1), "Buffers may only be queued for streaming sources."))
/*     */     {
/* 668 */       return false;
/*     */     }
/*     */     
/* 671 */     if (errorCheck((this.sourceDataLine == null), "SourceDataLine null in method 'queueBuffer'."))
/*     */     {
/* 673 */       return false;
/*     */     }
/*     */     
/* 676 */     if (errorCheck((this.myFormat == null), "AudioFormat null in method 'queueBuffer'"))
/*     */     {
/* 678 */       return false;
/*     */     }
/*     */     
/* 681 */     this.streamBuffers.add(new SoundBuffer(paramArrayOfbyte, this.myFormat));
/*     */ 
/*     */     
/* 684 */     processBuffer();
/*     */     
/* 686 */     this.processed = 0;
/* 687 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean processBuffer() {
/* 699 */     if (errorCheck((this.channelType != 1), "Buffers are only processed for streaming sources."))
/*     */     {
/* 701 */       return false;
/*     */     }
/*     */     
/* 704 */     if (errorCheck((this.sourceDataLine == null), "SourceDataLine null in method 'processBuffer'."))
/*     */     {
/* 706 */       return false;
/*     */     }
/* 708 */     if (this.streamBuffers == null || this.streamBuffers.isEmpty()) {
/* 709 */       return false;
/*     */     }
/*     */     
/* 712 */     SoundBuffer soundBuffer = this.streamBuffers.remove(0);
/*     */     
/* 714 */     this.sourceDataLine.write(soundBuffer.audioData, 0, soundBuffer.audioData.length);
/*     */     
/* 716 */     if (!this.sourceDataLine.isActive())
/* 717 */       this.sourceDataLine.start(); 
/* 718 */     soundBuffer.cleanup();
/* 719 */     soundBuffer = null;
/*     */     
/* 721 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int feedRawAudioData(byte[] paramArrayOfbyte) {
/* 733 */     if (errorCheck((this.channelType != 1), "Raw audio data can only be processed by streaming sources."))
/*     */     {
/* 735 */       return -1;
/*     */     }
/* 737 */     if (errorCheck((this.streamBuffers == null), "StreamBuffers queue null in method 'feedRawAudioData'."))
/*     */     {
/* 739 */       return -1;
/*     */     }
/* 741 */     this.streamBuffers.add(new SoundBuffer(paramArrayOfbyte, this.myFormat));
/* 742 */     return buffersProcessed();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int buffersProcessed() {
/* 753 */     this.processed = 0;
/*     */ 
/*     */     
/* 756 */     if (errorCheck((this.channelType != 1), "Buffers may only be queued for streaming sources.")) {
/*     */ 
/*     */       
/* 759 */       if (this.streamBuffers != null)
/* 760 */         this.streamBuffers.clear(); 
/* 761 */       return 0;
/*     */     } 
/*     */ 
/*     */     
/* 765 */     if (this.sourceDataLine == null) {
/*     */       
/* 767 */       if (this.streamBuffers != null)
/* 768 */         this.streamBuffers.clear(); 
/* 769 */       return 0;
/*     */     } 
/*     */     
/* 772 */     if (this.sourceDataLine.available() > 0)
/*     */     {
/* 774 */       this.processed = 1;
/*     */     }
/*     */     
/* 777 */     return this.processed;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 788 */     if (this.channelType != 1) {
/*     */       return;
/*     */     }
/*     */     
/* 792 */     if (errorCheck((this.sourceDataLine == null), "SourceDataLine null in method 'flush'.")) {
/*     */       return;
/*     */     }
/*     */     
/* 796 */     this.sourceDataLine.stop();
/* 797 */     this.sourceDataLine.flush();
/* 798 */     this.sourceDataLine.drain();
/*     */     
/* 800 */     this.streamBuffers.clear();
/* 801 */     this.processed = 0;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/* 810 */     switch (this.channelType) {
/*     */       
/*     */       case 0:
/* 813 */         if (this.clip != null) {
/*     */           
/* 815 */           this.clip.stop();
/* 816 */           this.clip.flush();
/* 817 */           this.clip.close();
/*     */         } 
/*     */         break;
/*     */       case 1:
/* 821 */         if (this.sourceDataLine != null) {
/*     */           
/* 823 */           flush();
/* 824 */           this.sourceDataLine.close();
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void play() {
/* 839 */     switch (this.channelType) {
/*     */       
/*     */       case 0:
/* 842 */         if (this.clip != null) {
/*     */           
/* 844 */           if (this.toLoop) {
/*     */             
/* 846 */             this.clip.stop();
/* 847 */             this.clip.loop(-1);
/*     */             
/*     */             break;
/*     */           } 
/* 851 */           this.clip.stop();
/* 852 */           this.clip.start();
/*     */         } 
/*     */         break;
/*     */ 
/*     */       
/*     */       case 1:
/* 858 */         if (this.sourceDataLine != null)
/*     */         {
/* 860 */           this.sourceDataLine.start();
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pause() {
/* 874 */     switch (this.channelType) {
/*     */       
/*     */       case 0:
/* 877 */         if (this.clip != null)
/* 878 */           this.clip.stop(); 
/*     */         break;
/*     */       case 1:
/* 881 */         if (this.sourceDataLine != null) {
/* 882 */           this.sourceDataLine.stop();
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 896 */     switch (this.channelType) {
/*     */       
/*     */       case 0:
/* 899 */         if (this.clip != null) {
/*     */           
/* 901 */           this.clip.stop();
/* 902 */           this.clip.setFramePosition(0);
/*     */         } 
/*     */         break;
/*     */       case 1:
/* 906 */         if (this.sourceDataLine != null) {
/* 907 */           this.sourceDataLine.stop();
/*     */         }
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rewind() {
/* 921 */     switch (this.channelType) {
/*     */       
/*     */       case 0:
/* 924 */         if (this.clip != null) {
/*     */           
/* 926 */           boolean bool = this.clip.isRunning();
/* 927 */           this.clip.stop();
/* 928 */           this.clip.setFramePosition(0);
/* 929 */           if (bool) {
/*     */             
/* 931 */             if (this.toLoop) {
/* 932 */               this.clip.loop(-1); break;
/*     */             } 
/* 934 */             this.clip.start();
/*     */           } 
/*     */         } 
/*     */         break;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float millisecondsPlayed() {
/* 953 */     switch (this.channelType) {
/*     */       
/*     */       case 0:
/* 956 */         if (this.clip == null)
/* 957 */           return -1.0F; 
/* 958 */         return (float)this.clip.getMicrosecondPosition() / 1000.0F;
/*     */       case 1:
/* 960 */         if (this.sourceDataLine == null)
/* 961 */           return -1.0F; 
/* 962 */         return (float)this.sourceDataLine.getMicrosecondPosition() / 1000.0F;
/*     */     } 
/* 964 */     return -1.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean playing() {
/* 976 */     switch (this.channelType) {
/*     */       
/*     */       case 0:
/* 979 */         if (this.clip == null)
/* 980 */           return false; 
/* 981 */         return this.clip.isActive();
/*     */       case 1:
/* 983 */         if (this.sourceDataLine == null)
/* 984 */           return false; 
/* 985 */         return this.sourceDataLine.isActive();
/*     */     } 
/* 987 */     return false;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\libraries\ChannelJavaSound.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */