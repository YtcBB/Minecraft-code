/*      */ package paulscode.sound.libraries;
/*      */ 
/*      */ import java.net.URL;
/*      */ import java.nio.ByteBuffer;
/*      */ import java.nio.FloatBuffer;
/*      */ import java.nio.IntBuffer;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.Set;
/*      */ import javax.sound.sampled.AudioFormat;
/*      */ import org.lwjgl.BufferUtils;
/*      */ import org.lwjgl.LWJGLException;
/*      */ import org.lwjgl.openal.AL;
/*      */ import org.lwjgl.openal.AL10;
/*      */ import paulscode.sound.Channel;
/*      */ import paulscode.sound.FilenameURL;
/*      */ import paulscode.sound.ICodec;
/*      */ import paulscode.sound.Library;
/*      */ import paulscode.sound.ListenerData;
/*      */ import paulscode.sound.SoundBuffer;
/*      */ import paulscode.sound.SoundSystemConfig;
/*      */ import paulscode.sound.Source;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LibraryLWJGLOpenAL
/*      */   extends Library
/*      */ {
/*      */   private static final boolean GET = false;
/*      */   private static final boolean SET = true;
/*      */   private static final boolean XXX = false;
/*  122 */   private FloatBuffer listenerPositionAL = null;
/*      */ 
/*      */ 
/*      */   
/*  126 */   private FloatBuffer listenerOrientation = null;
/*      */ 
/*      */ 
/*      */   
/*  130 */   private FloatBuffer listenerVelocity = null;
/*      */ 
/*      */ 
/*      */   
/*  134 */   private HashMap ALBufferMap = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean alPitchSupported = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LibraryLWJGLOpenAL() {
/*  149 */     this.ALBufferMap = new HashMap<Object, Object>();
/*  150 */     this.reverseByteOrder = true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() {
/*  159 */     boolean bool = false;
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  164 */       AL.create();
/*  165 */       bool = checkALError();
/*      */     }
/*  167 */     catch (LWJGLException lWJGLException) {
/*      */ 
/*      */       
/*  170 */       errorMessage("Unable to initialize OpenAL.  Probable cause: OpenAL not supported.");
/*      */       
/*  172 */       printStackTrace((Exception)lWJGLException);
/*  173 */       throw new LibraryLWJGLOpenAL$Exception(lWJGLException.getMessage(), 101);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  178 */     if (bool) {
/*  179 */       importantMessage("OpenAL did not initialize properly!");
/*      */     } else {
/*  181 */       message("OpenAL initialized.");
/*      */     } 
/*      */     
/*  184 */     this.listenerPositionAL = BufferUtils.createFloatBuffer(3).put(new float[] { this.listener.position.x, this.listener.position.y, this.listener.position.z });
/*      */ 
/*      */ 
/*      */     
/*  188 */     this.listenerOrientation = BufferUtils.createFloatBuffer(6).put(new float[] { this.listener.lookAt.x, this.listener.lookAt.y, this.listener.lookAt.z, this.listener.up.x, this.listener.up.y, this.listener.up.z });
/*      */ 
/*      */ 
/*      */     
/*  192 */     this.listenerVelocity = BufferUtils.createFloatBuffer(3).put(new float[] { 0.0F, 0.0F, 0.0F });
/*      */ 
/*      */ 
/*      */     
/*  196 */     this.listenerPositionAL.flip();
/*  197 */     this.listenerOrientation.flip();
/*  198 */     this.listenerVelocity.flip();
/*      */ 
/*      */     
/*  201 */     AL10.alListener(4100, this.listenerPositionAL);
/*  202 */     bool = (checkALError() || bool);
/*  203 */     AL10.alListener(4111, this.listenerOrientation);
/*  204 */     bool = (checkALError() || bool);
/*  205 */     AL10.alListener(4102, this.listenerVelocity);
/*  206 */     bool = (checkALError() || bool);
/*      */     
/*  208 */     AL10.alDopplerFactor(SoundSystemConfig.getDopplerFactor());
/*  209 */     bool = (checkALError() || bool);
/*      */     
/*  211 */     AL10.alDopplerVelocity(SoundSystemConfig.getDopplerVelocity());
/*  212 */     bool = (checkALError() || bool);
/*      */ 
/*      */     
/*  215 */     if (bool) {
/*      */       
/*  217 */       importantMessage("OpenAL did not initialize properly!");
/*  218 */       throw new LibraryLWJGLOpenAL$Exception("Problem encountered while loading OpenAL or creating the listener.  Probable cause:  OpenAL not supported", 101);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  226 */     super.init();
/*      */ 
/*      */     
/*  229 */     ChannelLWJGLOpenAL channelLWJGLOpenAL = this.normalChannels.get(1);
/*      */ 
/*      */     
/*      */     try {
/*  233 */       AL10.alSourcef(channelLWJGLOpenAL.ALSource.get(0), 4099, 1.0F);
/*      */       
/*  235 */       if (checkALError()) {
/*      */         
/*  237 */         alPitchSupported(true, false);
/*  238 */         throw new LibraryLWJGLOpenAL$Exception("OpenAL: AL_PITCH not supported.", 108);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/*  243 */       alPitchSupported(true, true);
/*      */     
/*      */     }
/*  246 */     catch (Exception exception) {
/*      */       
/*  248 */       alPitchSupported(true, false);
/*  249 */       throw new LibraryLWJGLOpenAL$Exception("OpenAL: AL_PITCH not supported.", 108);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean libraryCompatible() {
/*  260 */     if (AL.isCreated()) {
/*  261 */       return true;
/*      */     }
/*      */     
/*      */     try {
/*  265 */       AL.create();
/*      */     }
/*  267 */     catch (Exception exception) {
/*      */       
/*  269 */       return false;
/*      */     } 
/*      */ 
/*      */     
/*      */     try {
/*  274 */       AL.destroy();
/*      */     }
/*  276 */     catch (Exception exception) {}
/*      */ 
/*      */     
/*  279 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Channel createChannel(int paramInt) {
/*  294 */     IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
/*      */     
/*      */     try {
/*  297 */       AL10.alGenSources(intBuffer);
/*      */     }
/*  299 */     catch (Exception exception) {
/*      */       
/*  301 */       AL10.alGetError();
/*  302 */       return null;
/*      */     } 
/*      */     
/*  305 */     if (AL10.alGetError() != 0) {
/*  306 */       return null;
/*      */     }
/*  308 */     return new ChannelLWJGLOpenAL(paramInt, intBuffer);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cleanup() {
/*  319 */     super.cleanup();
/*      */     
/*  321 */     Set set = this.bufferMap.keySet();
/*  322 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  327 */     while (iterator.hasNext()) {
/*      */       
/*  329 */       String str = iterator.next();
/*  330 */       IntBuffer intBuffer = (IntBuffer)this.ALBufferMap.get(str);
/*  331 */       if (intBuffer != null) {
/*      */         
/*  333 */         AL10.alDeleteBuffers(intBuffer);
/*  334 */         checkALError();
/*  335 */         intBuffer.clear();
/*      */       } 
/*      */     } 
/*      */     
/*  339 */     this.bufferMap.clear();
/*  340 */     AL.destroy();
/*      */     
/*  342 */     this.bufferMap = null;
/*  343 */     this.listenerPositionAL = null;
/*  344 */     this.listenerOrientation = null;
/*  345 */     this.listenerVelocity = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean loadSound(FilenameURL paramFilenameURL) {
/*  357 */     if (this.bufferMap == null) {
/*      */       
/*  359 */       this.bufferMap = new HashMap<Object, Object>();
/*  360 */       importantMessage("Buffer Map was null in method 'loadSound'");
/*      */     } 
/*      */     
/*  363 */     if (this.ALBufferMap == null) {
/*      */       
/*  365 */       this.ALBufferMap = new HashMap<Object, Object>();
/*  366 */       importantMessage("Open AL Buffer Map was null in method'loadSound'");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  371 */     if (errorCheck((paramFilenameURL == null), "Filename/URL not specified in method 'loadSound'"))
/*      */     {
/*  373 */       return false;
/*      */     }
/*      */     
/*  376 */     if (this.bufferMap.get(paramFilenameURL.getFilename()) != null) {
/*  377 */       return true;
/*      */     }
/*  379 */     ICodec iCodec = SoundSystemConfig.getCodec(paramFilenameURL.getFilename());
/*  380 */     if (errorCheck((iCodec == null), "No codec found for file '" + paramFilenameURL.getFilename() + "' in method 'loadSound'"))
/*      */     {
/*      */       
/*  383 */       return false; } 
/*  384 */     iCodec.reverseByteOrder(true);
/*      */     
/*  386 */     URL uRL = paramFilenameURL.getURL();
/*  387 */     if (errorCheck((uRL == null), "Unable to open file '" + paramFilenameURL.getFilename() + "' in method 'loadSound'"))
/*      */     {
/*      */       
/*  390 */       return false;
/*      */     }
/*  392 */     iCodec.initialize(uRL);
/*  393 */     SoundBuffer soundBuffer = iCodec.readAll();
/*  394 */     iCodec.cleanup();
/*  395 */     iCodec = null;
/*  396 */     if (errorCheck((soundBuffer == null), "Sound buffer null in method 'loadSound'"))
/*      */     {
/*  398 */       return false;
/*      */     }
/*  400 */     this.bufferMap.put(paramFilenameURL.getFilename(), soundBuffer);
/*      */     
/*  402 */     AudioFormat audioFormat = soundBuffer.audioFormat;
/*  403 */     char c = Character.MIN_VALUE;
/*  404 */     if (audioFormat.getChannels() == 1) {
/*      */       
/*  406 */       if (audioFormat.getSampleSizeInBits() == 8)
/*      */       {
/*  408 */         c = 'ᄀ';
/*      */       }
/*  410 */       else if (audioFormat.getSampleSizeInBits() == 16)
/*      */       {
/*  412 */         c = 'ᄁ';
/*      */       }
/*      */       else
/*      */       {
/*  416 */         errorMessage("Illegal sample size in method 'loadSound'");
/*  417 */         return false;
/*      */       }
/*      */     
/*  420 */     } else if (audioFormat.getChannels() == 2) {
/*      */       
/*  422 */       if (audioFormat.getSampleSizeInBits() == 8)
/*      */       {
/*  424 */         c = 'ᄂ';
/*      */       }
/*  426 */       else if (audioFormat.getSampleSizeInBits() == 16)
/*      */       {
/*  428 */         c = 'ᄃ';
/*      */       }
/*      */       else
/*      */       {
/*  432 */         errorMessage("Illegal sample size in method 'loadSound'");
/*  433 */         return false;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  438 */       errorMessage("File neither mono nor stereo in method 'loadSound'");
/*      */       
/*  440 */       return false;
/*      */     } 
/*      */     
/*  443 */     IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
/*  444 */     AL10.alGenBuffers(intBuffer);
/*  445 */     if (errorCheck((AL10.alGetError() != 0), "alGenBuffers error when loading " + paramFilenameURL.getFilename()))
/*      */     {
/*      */       
/*  448 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  453 */     AL10.alBufferData(intBuffer.get(0), c, (ByteBuffer)BufferUtils.createByteBuffer(soundBuffer.audioData.length).put(soundBuffer.audioData).flip(), (int)audioFormat.getSampleRate());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  459 */     if (errorCheck((AL10.alGetError() != 0), "alBufferData error when loading " + paramFilenameURL.getFilename()))
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  464 */       if (errorCheck((intBuffer == null), "Sound buffer was not created for " + paramFilenameURL.getFilename()))
/*      */       {
/*      */         
/*  467 */         return false; } 
/*      */     }
/*  469 */     this.ALBufferMap.put(paramFilenameURL.getFilename(), intBuffer);
/*      */     
/*  471 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean loadSound(SoundBuffer paramSoundBuffer, String paramString) {
/*  486 */     if (this.bufferMap == null) {
/*      */       
/*  488 */       this.bufferMap = new HashMap<Object, Object>();
/*  489 */       importantMessage("Buffer Map was null in method 'loadSound'");
/*      */     } 
/*      */     
/*  492 */     if (this.ALBufferMap == null) {
/*      */       
/*  494 */       this.ALBufferMap = new HashMap<Object, Object>();
/*  495 */       importantMessage("Open AL Buffer Map was null in method'loadSound'");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  500 */     if (errorCheck((paramString == null), "Identifier not specified in method 'loadSound'"))
/*      */     {
/*  502 */       return false;
/*      */     }
/*      */     
/*  505 */     if (this.bufferMap.get(paramString) != null) {
/*  506 */       return true;
/*      */     }
/*  508 */     if (errorCheck((paramSoundBuffer == null), "Sound buffer null in method 'loadSound'"))
/*      */     {
/*  510 */       return false;
/*      */     }
/*  512 */     this.bufferMap.put(paramString, paramSoundBuffer);
/*      */     
/*  514 */     AudioFormat audioFormat = paramSoundBuffer.audioFormat;
/*  515 */     char c = Character.MIN_VALUE;
/*  516 */     if (audioFormat.getChannels() == 1) {
/*      */       
/*  518 */       if (audioFormat.getSampleSizeInBits() == 8)
/*      */       {
/*  520 */         c = 'ᄀ';
/*      */       }
/*  522 */       else if (audioFormat.getSampleSizeInBits() == 16)
/*      */       {
/*  524 */         c = 'ᄁ';
/*      */       }
/*      */       else
/*      */       {
/*  528 */         errorMessage("Illegal sample size in method 'loadSound'");
/*  529 */         return false;
/*      */       }
/*      */     
/*  532 */     } else if (audioFormat.getChannels() == 2) {
/*      */       
/*  534 */       if (audioFormat.getSampleSizeInBits() == 8)
/*      */       {
/*  536 */         c = 'ᄂ';
/*      */       }
/*  538 */       else if (audioFormat.getSampleSizeInBits() == 16)
/*      */       {
/*  540 */         c = 'ᄃ';
/*      */       }
/*      */       else
/*      */       {
/*  544 */         errorMessage("Illegal sample size in method 'loadSound'");
/*  545 */         return false;
/*      */       }
/*      */     
/*      */     } else {
/*      */       
/*  550 */       errorMessage("File neither mono nor stereo in method 'loadSound'");
/*      */       
/*  552 */       return false;
/*      */     } 
/*      */     
/*  555 */     IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
/*  556 */     AL10.alGenBuffers(intBuffer);
/*  557 */     if (errorCheck((AL10.alGetError() != 0), "alGenBuffers error when saving " + paramString))
/*      */     {
/*      */       
/*  560 */       return false;
/*      */     }
/*      */ 
/*      */ 
/*      */     
/*  565 */     AL10.alBufferData(intBuffer.get(0), c, (ByteBuffer)BufferUtils.createByteBuffer(paramSoundBuffer.audioData.length).put(paramSoundBuffer.audioData).flip(), (int)audioFormat.getSampleRate());
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  571 */     if (errorCheck((AL10.alGetError() != 0), "alBufferData error when saving " + paramString))
/*      */     {
/*      */ 
/*      */ 
/*      */       
/*  576 */       if (errorCheck((intBuffer == null), "Sound buffer was not created for " + paramString))
/*      */       {
/*      */         
/*  579 */         return false; } 
/*      */     }
/*  581 */     this.ALBufferMap.put(paramString, intBuffer);
/*      */     
/*  583 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unloadSound(String paramString) {
/*  596 */     this.ALBufferMap.remove(paramString);
/*  597 */     super.unloadSound(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMasterVolume(float paramFloat) {
/*  607 */     super.setMasterVolume(paramFloat);
/*      */     
/*  609 */     AL10.alListenerf(4106, paramFloat);
/*  610 */     checkALError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newSource(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  631 */     IntBuffer intBuffer = null;
/*  632 */     if (!paramBoolean2) {
/*      */ 
/*      */       
/*  635 */       intBuffer = (IntBuffer)this.ALBufferMap.get(paramFilenameURL.getFilename());
/*      */ 
/*      */       
/*  638 */       if (intBuffer == null)
/*      */       {
/*  640 */         if (!loadSound(paramFilenameURL)) {
/*      */           
/*  642 */           errorMessage("Source '" + paramString + "' was not created " + "because an error occurred while loading " + paramFilenameURL.getFilename());
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */       }
/*      */ 
/*      */       
/*  650 */       intBuffer = (IntBuffer)this.ALBufferMap.get(paramFilenameURL.getFilename());
/*      */       
/*  652 */       if (intBuffer == null) {
/*      */         
/*  654 */         errorMessage("Source '" + paramString + "' was not created " + "because a sound buffer was not found for " + paramFilenameURL.getFilename());
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*  660 */     SoundBuffer soundBuffer = null;
/*      */     
/*  662 */     if (!paramBoolean2) {
/*      */ 
/*      */       
/*  665 */       soundBuffer = (SoundBuffer)this.bufferMap.get(paramFilenameURL.getFilename());
/*      */       
/*  667 */       if (soundBuffer == null)
/*      */       {
/*  669 */         if (!loadSound(paramFilenameURL)) {
/*      */           
/*  671 */           errorMessage("Source '" + paramString + "' was not created " + "because an error occurred while loading " + paramFilenameURL.getFilename());
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */       }
/*      */       
/*  678 */       soundBuffer = (SoundBuffer)this.bufferMap.get(paramFilenameURL.getFilename());
/*      */       
/*  680 */       if (soundBuffer == null) {
/*      */         
/*  682 */         errorMessage("Source '" + paramString + "' was not created " + "because audio data was not found for " + paramFilenameURL.getFilename());
/*      */ 
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*  689 */     this.sourceMap.put(paramString, new SourceLWJGLOpenAL(this.listenerPositionAL, intBuffer, paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, soundBuffer, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawDataStream(AudioFormat paramAudioFormat, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  713 */     this.sourceMap.put(paramString, new SourceLWJGLOpenAL(this.listenerPositionAL, paramAudioFormat, paramBoolean, paramString, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void quickPlay(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/*  739 */     IntBuffer intBuffer = null;
/*  740 */     if (!paramBoolean2) {
/*      */ 
/*      */       
/*  743 */       intBuffer = (IntBuffer)this.ALBufferMap.get(paramFilenameURL.getFilename());
/*      */       
/*  745 */       if (intBuffer == null) {
/*  746 */         loadSound(paramFilenameURL);
/*      */       }
/*  748 */       intBuffer = (IntBuffer)this.ALBufferMap.get(paramFilenameURL.getFilename());
/*      */       
/*  750 */       if (intBuffer == null) {
/*      */         
/*  752 */         errorMessage("Sound buffer was not created for " + paramFilenameURL.getFilename());
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*  758 */     SoundBuffer soundBuffer = null;
/*      */     
/*  760 */     if (!paramBoolean2) {
/*      */ 
/*      */       
/*  763 */       soundBuffer = (SoundBuffer)this.bufferMap.get(paramFilenameURL.getFilename());
/*      */       
/*  765 */       if (soundBuffer == null)
/*      */       {
/*  767 */         if (!loadSound(paramFilenameURL)) {
/*      */           
/*  769 */           errorMessage("Source '" + paramString + "' was not created " + "because an error occurred while loading " + paramFilenameURL.getFilename());
/*      */ 
/*      */           
/*      */           return;
/*      */         } 
/*      */       }
/*      */       
/*  776 */       soundBuffer = (SoundBuffer)this.bufferMap.get(paramFilenameURL.getFilename());
/*      */       
/*  778 */       if (soundBuffer == null) {
/*      */         
/*  780 */         errorMessage("Source '" + paramString + "' was not created " + "because audio data was not found for " + paramFilenameURL.getFilename());
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*  786 */     SourceLWJGLOpenAL sourceLWJGLOpenAL = new SourceLWJGLOpenAL(this.listenerPositionAL, intBuffer, paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, soundBuffer, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, false);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  794 */     this.sourceMap.put(paramString, sourceLWJGLOpenAL);
/*  795 */     play(sourceLWJGLOpenAL);
/*  796 */     if (paramBoolean4) {
/*  797 */       sourceLWJGLOpenAL.setTemporary(true);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copySources(HashMap paramHashMap) {
/*  807 */     if (paramHashMap == null)
/*      */       return; 
/*  809 */     Set set = paramHashMap.keySet();
/*  810 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  815 */     if (this.bufferMap == null) {
/*      */       
/*  817 */       this.bufferMap = new HashMap<Object, Object>();
/*  818 */       importantMessage("Buffer Map was null in method 'copySources'");
/*      */     } 
/*      */     
/*  821 */     if (this.ALBufferMap == null) {
/*      */       
/*  823 */       this.ALBufferMap = new HashMap<Object, Object>();
/*  824 */       importantMessage("Open AL Buffer Map was null in method'copySources'");
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*  829 */     this.sourceMap.clear();
/*      */ 
/*      */ 
/*      */     
/*  833 */     while (iterator.hasNext()) {
/*      */       
/*  835 */       String str = iterator.next();
/*  836 */       Source source = (Source)paramHashMap.get(str);
/*  837 */       if (source != null) {
/*      */         
/*  839 */         SoundBuffer soundBuffer = null;
/*  840 */         if (!source.toStream) {
/*      */           
/*  842 */           loadSound(source.filenameURL);
/*  843 */           soundBuffer = (SoundBuffer)this.bufferMap.get(source.filenameURL.getFilename());
/*      */         } 
/*  845 */         if (source.toStream || soundBuffer != null) {
/*  846 */           this.sourceMap.put(str, new SourceLWJGLOpenAL(this.listenerPositionAL, (IntBuffer)this.ALBufferMap.get(source.filenameURL.getFilename()), source, soundBuffer));
/*      */         }
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  864 */     super.setListenerPosition(paramFloat1, paramFloat2, paramFloat3);
/*      */     
/*  866 */     this.listenerPositionAL.put(0, paramFloat1);
/*  867 */     this.listenerPositionAL.put(1, paramFloat2);
/*  868 */     this.listenerPositionAL.put(2, paramFloat3);
/*      */ 
/*      */     
/*  871 */     AL10.alListener(4100, this.listenerPositionAL);
/*      */     
/*  873 */     checkALError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerAngle(float paramFloat) {
/*  884 */     super.setListenerAngle(paramFloat);
/*      */     
/*  886 */     this.listenerOrientation.put(0, this.listener.lookAt.x);
/*  887 */     this.listenerOrientation.put(2, this.listener.lookAt.z);
/*      */ 
/*      */     
/*  890 */     AL10.alListener(4111, this.listenerOrientation);
/*      */     
/*  892 */     checkALError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerOrientation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/*  908 */     super.setListenerOrientation(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*  909 */     this.listenerOrientation.put(0, paramFloat1);
/*  910 */     this.listenerOrientation.put(1, paramFloat2);
/*  911 */     this.listenerOrientation.put(2, paramFloat3);
/*  912 */     this.listenerOrientation.put(3, paramFloat4);
/*  913 */     this.listenerOrientation.put(4, paramFloat5);
/*  914 */     this.listenerOrientation.put(5, paramFloat6);
/*  915 */     AL10.alListener(4111, this.listenerOrientation);
/*  916 */     checkALError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerData(ListenerData paramListenerData) {
/*  927 */     super.setListenerData(paramListenerData);
/*      */     
/*  929 */     this.listenerPositionAL.put(0, paramListenerData.position.x);
/*  930 */     this.listenerPositionAL.put(1, paramListenerData.position.y);
/*  931 */     this.listenerPositionAL.put(2, paramListenerData.position.z);
/*  932 */     AL10.alListener(4100, this.listenerPositionAL);
/*  933 */     checkALError();
/*      */     
/*  935 */     this.listenerOrientation.put(0, paramListenerData.lookAt.x);
/*  936 */     this.listenerOrientation.put(1, paramListenerData.lookAt.y);
/*  937 */     this.listenerOrientation.put(2, paramListenerData.lookAt.z);
/*  938 */     this.listenerOrientation.put(3, paramListenerData.up.x);
/*  939 */     this.listenerOrientation.put(4, paramListenerData.up.y);
/*  940 */     this.listenerOrientation.put(5, paramListenerData.up.z);
/*  941 */     AL10.alListener(4111, this.listenerOrientation);
/*  942 */     checkALError();
/*      */     
/*  944 */     this.listenerVelocity.put(0, paramListenerData.velocity.x);
/*  945 */     this.listenerVelocity.put(1, paramListenerData.velocity.y);
/*  946 */     this.listenerVelocity.put(2, paramListenerData.velocity.z);
/*  947 */     AL10.alListener(4102, this.listenerVelocity);
/*  948 */     checkALError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  960 */     super.setListenerVelocity(paramFloat1, paramFloat2, paramFloat3);
/*      */     
/*  962 */     this.listenerVelocity.put(0, this.listener.velocity.x);
/*  963 */     this.listenerVelocity.put(1, this.listener.velocity.y);
/*  964 */     this.listenerVelocity.put(2, this.listener.velocity.z);
/*  965 */     AL10.alListener(4102, this.listenerVelocity);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dopplerChanged() {
/*  974 */     super.dopplerChanged();
/*      */     
/*  976 */     AL10.alDopplerFactor(SoundSystemConfig.getDopplerFactor());
/*  977 */     checkALError();
/*  978 */     AL10.alDopplerVelocity(SoundSystemConfig.getDopplerVelocity());
/*  979 */     checkALError();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private boolean checkALError() {
/*  988 */     switch (AL10.alGetError()) {
/*      */       
/*      */       case 0:
/*  991 */         return false;
/*      */       case 40961:
/*  993 */         errorMessage("Invalid name parameter.");
/*  994 */         return true;
/*      */       case 40962:
/*  996 */         errorMessage("Invalid parameter.");
/*  997 */         return true;
/*      */       case 40963:
/*  999 */         errorMessage("Invalid enumerated parameter value.");
/* 1000 */         return true;
/*      */       case 40964:
/* 1002 */         errorMessage("Illegal call.");
/* 1003 */         return true;
/*      */       case 40965:
/* 1005 */         errorMessage("Unable to allocate memory.");
/* 1006 */         return true;
/*      */     } 
/* 1008 */     errorMessage("An unrecognized error occurred.");
/* 1009 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean alPitchSupported() {
/* 1019 */     return alPitchSupported(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static synchronized boolean alPitchSupported(boolean paramBoolean1, boolean paramBoolean2) {
/* 1030 */     if (paramBoolean1 == true)
/* 1031 */       alPitchSupported = paramBoolean2; 
/* 1032 */     return alPitchSupported;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTitle() {
/* 1041 */     return "LWJGL OpenAL";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDescription() {
/* 1050 */     return "The LWJGL binding of OpenAL.  For more information, see http://www.lwjgl.org";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassName() {
/* 1061 */     return "LibraryLWJGLOpenAL";
/*      */   }
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\libraries\LibraryLWJGLOpenAL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */