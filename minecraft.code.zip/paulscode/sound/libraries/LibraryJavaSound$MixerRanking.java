/*      */ package paulscode.sound.libraries;
/*      */ 
/*      */ import javax.sound.sampled.AudioFormat;
/*      */ import javax.sound.sampled.AudioSystem;
/*      */ import javax.sound.sampled.Clip;
/*      */ import javax.sound.sampled.DataLine;
/*      */ import javax.sound.sampled.FloatControl;
/*      */ import javax.sound.sampled.Mixer;
/*      */ import javax.sound.sampled.SourceDataLine;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class LibraryJavaSound$MixerRanking
/*      */ {
/*      */   public static final int HIGH = 1;
/*      */   public static final int MEDIUM = 2;
/*      */   public static final int LOW = 3;
/*      */   public static final int NONE = 4;
/*  793 */   public static int MIXER_EXISTS_PRIORITY = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  798 */   public static int MIN_SAMPLE_RATE_PRIORITY = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  803 */   public static int MAX_SAMPLE_RATE_PRIORITY = 1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  808 */   public static int LINE_COUNT_PRIORITY = 1;
/*      */ 
/*      */ 
/*      */   
/*  812 */   public static int GAIN_CONTROL_PRIORITY = 2;
/*      */ 
/*      */ 
/*      */   
/*  816 */   public static int PAN_CONTROL_PRIORITY = 2;
/*      */ 
/*      */ 
/*      */   
/*  820 */   public static int SAMPLE_RATE_CONTROL_PRIORITY = 3;
/*      */ 
/*      */ 
/*      */   
/*  824 */   public Mixer.Info mixerInfo = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  829 */   public int rank = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean mixerExists = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean minSampleRateOK = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean maxSampleRateOK = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean lineCountOK = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean gainControlOK = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean panControlOK = false;
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean sampleRateControlOK = false;
/*      */ 
/*      */ 
/*      */   
/*  867 */   public int minSampleRatePossible = -1;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  872 */   public int maxSampleRatePossible = -1;
/*      */ 
/*      */ 
/*      */   
/*  876 */   public int maxLinesPossible = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LibraryJavaSound$MixerRanking() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LibraryJavaSound$MixerRanking(Mixer.Info paramInfo, int paramInt, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, boolean paramBoolean4, boolean paramBoolean5, boolean paramBoolean6, boolean paramBoolean7) {
/*  902 */     this.mixerInfo = paramInfo;
/*  903 */     this.rank = paramInt;
/*  904 */     this.mixerExists = paramBoolean1;
/*  905 */     this.minSampleRateOK = paramBoolean2;
/*  906 */     this.maxSampleRateOK = paramBoolean3;
/*  907 */     this.lineCountOK = paramBoolean4;
/*  908 */     this.gainControlOK = paramBoolean5;
/*  909 */     this.panControlOK = paramBoolean6;
/*  910 */     this.sampleRateControlOK = paramBoolean7;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rank(Mixer.Info paramInfo) {
/*  921 */     if (paramInfo == null) {
/*  922 */       throw new LibraryJavaSound$Exception("No Mixer info specified in method 'MixerRanking.rank'", this);
/*      */     }
/*  924 */     this.mixerInfo = paramInfo;
/*      */ 
/*      */     
/*      */     try {
/*  928 */       mixer = AudioSystem.getMixer(this.mixerInfo);
/*      */     }
/*  930 */     catch (Exception exception) {
/*      */       
/*  932 */       throw new LibraryJavaSound$Exception("Unable to acquire the specified Mixer in method 'MixerRanking.rank'", this);
/*      */     } 
/*      */     
/*  935 */     if (mixer == null) {
/*  936 */       throw new LibraryJavaSound$Exception("Unable to acquire the specified Mixer in method 'MixerRanking.rank'", this);
/*      */     }
/*  938 */     this.mixerExists = true;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  945 */       AudioFormat audioFormat1 = new AudioFormat(LibraryJavaSound.access$000(false, 0), 16, 2, true, false);
/*      */       
/*  947 */       info = new DataLine.Info(SourceDataLine.class, audioFormat1);
/*      */     }
/*  949 */     catch (Exception exception) {
/*      */       
/*  951 */       throw new LibraryJavaSound$Exception("Invalid minimum sample-rate specified in method 'MixerRanking.rank'", this);
/*      */     } 
/*      */     
/*  954 */     if (!AudioSystem.isLineSupported(info)) {
/*      */       
/*  956 */       if (MIN_SAMPLE_RATE_PRIORITY == 1) {
/*  957 */         throw new LibraryJavaSound$Exception("Specified minimum sample-rate not possible for Mixer '" + this.mixerInfo.getName() + "'", this);
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  963 */       this.minSampleRateOK = true;
/*      */     } 
/*      */     
/*      */     try {
/*  967 */       AudioFormat audioFormat1 = new AudioFormat(LibraryJavaSound.access$100(false, 0), 16, 2, true, false);
/*      */       
/*  969 */       info = new DataLine.Info(SourceDataLine.class, audioFormat1);
/*      */     }
/*  971 */     catch (Exception exception) {
/*      */       
/*  973 */       throw new LibraryJavaSound$Exception("Invalid maximum sample-rate specified in method 'MixerRanking.rank'", this);
/*      */     } 
/*      */     
/*  976 */     if (!AudioSystem.isLineSupported(info)) {
/*      */       
/*  978 */       if (MAX_SAMPLE_RATE_PRIORITY == 1) {
/*  979 */         throw new LibraryJavaSound$Exception("Specified maximum sample-rate not possible for Mixer '" + this.mixerInfo.getName() + "'", this);
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/*  985 */       this.maxSampleRateOK = true;
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  992 */     if (this.minSampleRateOK) {
/*      */       
/*  994 */       this.minSampleRatePossible = LibraryJavaSound.access$000(false, 0);
/*      */     
/*      */     }
/*      */     else {
/*      */       
/*  999 */       int i = LibraryJavaSound.access$000(false, 0);
/* 1000 */       int j = LibraryJavaSound.access$100(false, 0);
/* 1001 */       while (j - i > 1) {
/*      */         
/* 1003 */         int k = i + (j - i) / 2;
/* 1004 */         AudioFormat audioFormat1 = new AudioFormat(k, 16, 2, true, false);
/* 1005 */         info = new DataLine.Info(SourceDataLine.class, audioFormat1);
/* 1006 */         if (AudioSystem.isLineSupported(info)) {
/*      */           
/* 1008 */           this.minSampleRatePossible = k;
/* 1009 */           j = k;
/*      */           
/*      */           continue;
/*      */         } 
/* 1013 */         i = k;
/*      */       } 
/*      */     } 
/*      */     
/* 1017 */     if (this.maxSampleRateOK) {
/*      */       
/* 1019 */       this.maxSampleRatePossible = LibraryJavaSound.access$100(false, 0);
/*      */     }
/* 1021 */     else if (this.minSampleRatePossible != -1) {
/*      */ 
/*      */       
/* 1024 */       int j = LibraryJavaSound.access$100(false, 0);
/* 1025 */       int i = this.minSampleRatePossible;
/* 1026 */       while (j - i > 1) {
/*      */         
/* 1028 */         int k = i + (j - i) / 2;
/* 1029 */         AudioFormat audioFormat1 = new AudioFormat(k, 16, 2, true, false);
/* 1030 */         info = new DataLine.Info(SourceDataLine.class, audioFormat1);
/* 1031 */         if (AudioSystem.isLineSupported(info)) {
/*      */           
/* 1033 */           this.maxSampleRatePossible = k;
/* 1034 */           i = k;
/*      */           
/*      */           continue;
/*      */         } 
/* 1038 */         j = k;
/*      */       } 
/*      */     } 
/*      */ 
/*      */     
/* 1043 */     if (this.minSampleRatePossible == -1 || this.maxSampleRatePossible == -1) {
/* 1044 */       throw new LibraryJavaSound$Exception("No possible sample-rate found for Mixer '" + this.mixerInfo.getName() + "'", this);
/*      */     }
/*      */ 
/*      */ 
/*      */     
/* 1049 */     AudioFormat audioFormat = new AudioFormat(this.minSampleRatePossible, 16, 2, true, false);
/* 1050 */     Clip clip = null;
/*      */     
/*      */     try {
/* 1053 */       DataLine.Info info1 = new DataLine.Info(Clip.class, audioFormat);
/*      */       
/* 1055 */       clip = (Clip)mixer.getLine(info1);
/* 1056 */       byte[] arrayOfByte = new byte[10];
/* 1057 */       clip.open(audioFormat, arrayOfByte, 0, arrayOfByte.length);
/*      */     }
/* 1059 */     catch (Exception exception) {
/*      */       
/* 1061 */       throw new LibraryJavaSound$Exception("Unable to attach an actual audio buffer to an actual Clip... Mixer '" + this.mixerInfo.getName() + "' is unuseable.", this);
/*      */     } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1068 */     this.maxLinesPossible = 1;
/* 1069 */     DataLine.Info info = new DataLine.Info(SourceDataLine.class, audioFormat);
/* 1070 */     SourceDataLine[] arrayOfSourceDataLine = new SourceDataLine[LibraryJavaSound.access$200(false, 0) - 1];
/*      */     
/* 1072 */     boolean bool = false;
/*      */     
/* 1074 */     for (byte b = 1; b < arrayOfSourceDataLine.length + 1; b++) {
/*      */ 
/*      */       
/*      */       try {
/* 1078 */         arrayOfSourceDataLine[b - 1] = (SourceDataLine)mixer.getLine(info);
/*      */       }
/* 1080 */       catch (Exception exception) {
/*      */         
/* 1082 */         if (b == 0) {
/* 1083 */           throw new LibraryJavaSound$Exception("No output lines possible for Mixer '" + this.mixerInfo.getName() + "'", this);
/*      */         }
/*      */         
/* 1086 */         if (LINE_COUNT_PRIORITY == 1) {
/* 1087 */           throw new LibraryJavaSound$Exception("Specified maximum number of lines not possible for Mixer '" + this.mixerInfo.getName() + "'", this);
/*      */         }
/*      */         
/*      */         break;
/*      */       } 
/* 1092 */       this.maxLinesPossible = b + 1;
/*      */     } 
/*      */     
/*      */     try {
/* 1096 */       clip.close();
/*      */     }
/* 1098 */     catch (Exception exception) {}
/*      */     
/* 1100 */     clip = null;
/* 1101 */     if (this.maxLinesPossible == LibraryJavaSound.access$200(false, 0))
/*      */     {
/* 1103 */       this.lineCountOK = true;
/*      */     }
/*      */ 
/*      */     
/* 1107 */     if (!LibraryJavaSound.access$300(false, false)) {
/*      */       
/* 1109 */       GAIN_CONTROL_PRIORITY = 4;
/*      */     }
/* 1111 */     else if (!arrayOfSourceDataLine[0].isControlSupported(FloatControl.Type.MASTER_GAIN)) {
/*      */ 
/*      */       
/* 1114 */       if (GAIN_CONTROL_PRIORITY == 1) {
/* 1115 */         throw new LibraryJavaSound$Exception("Gain control not available for Mixer '" + this.mixerInfo.getName() + "'", this);
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1121 */       this.gainControlOK = true;
/*      */     } 
/* 1123 */     if (!LibraryJavaSound.access$400(false, false)) {
/*      */       
/* 1125 */       PAN_CONTROL_PRIORITY = 4;
/*      */     }
/* 1127 */     else if (!arrayOfSourceDataLine[0].isControlSupported(FloatControl.Type.PAN)) {
/*      */       
/* 1129 */       if (PAN_CONTROL_PRIORITY == 1) {
/* 1130 */         throw new LibraryJavaSound$Exception("Pan control not available for Mixer '" + this.mixerInfo.getName() + "'", this);
/*      */       
/*      */       }
/*      */     }
/*      */     else {
/*      */       
/* 1136 */       this.panControlOK = true;
/*      */     } 
/* 1138 */     if (!LibraryJavaSound.access$500(false, false)) {
/*      */       
/* 1140 */       SAMPLE_RATE_CONTROL_PRIORITY = 4;
/*      */     }
/* 1142 */     else if (!arrayOfSourceDataLine[0].isControlSupported(FloatControl.Type.SAMPLE_RATE)) {
/*      */ 
/*      */       
/* 1145 */       if (SAMPLE_RATE_CONTROL_PRIORITY == 1) {
/* 1146 */         throw new LibraryJavaSound$Exception("Sample-rate control not available for Mixer '" + this.mixerInfo.getName() + "'", this);
/*      */       
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1153 */       this.sampleRateControlOK = true;
/*      */     } 
/*      */ 
/*      */     
/* 1157 */     this.rank += getRankValue(this.mixerExists, MIXER_EXISTS_PRIORITY);
/* 1158 */     this.rank += getRankValue(this.minSampleRateOK, MIN_SAMPLE_RATE_PRIORITY);
/* 1159 */     this.rank += getRankValue(this.maxSampleRateOK, MAX_SAMPLE_RATE_PRIORITY);
/* 1160 */     this.rank += getRankValue(this.lineCountOK, LINE_COUNT_PRIORITY);
/* 1161 */     this.rank += getRankValue(this.gainControlOK, GAIN_CONTROL_PRIORITY);
/* 1162 */     this.rank += getRankValue(this.panControlOK, PAN_CONTROL_PRIORITY);
/* 1163 */     this.rank += getRankValue(this.sampleRateControlOK, SAMPLE_RATE_CONTROL_PRIORITY);
/*      */ 
/*      */ 
/*      */     
/* 1167 */     Mixer mixer = null;
/* 1168 */     audioFormat = null;
/* 1169 */     info = null;
/* 1170 */     arrayOfSourceDataLine = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private int getRankValue(boolean paramBoolean, int paramInt) {
/* 1182 */     if (paramBoolean) {
/* 1183 */       return 2;
/*      */     }
/*      */     
/* 1186 */     if (paramInt == 4) {
/* 1187 */       return 2;
/*      */     }
/* 1189 */     if (paramInt == 3) {
/* 1190 */       return 1;
/*      */     }
/* 1192 */     return 0;
/*      */   }
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\libraries\LibraryJavaSound$MixerRanking.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */