/*     */ package paulscode.sound.libraries;
/*     */ 
/*     */ import java.nio.FloatBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.LinkedList;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.openal.AL10;
/*     */ import paulscode.sound.Channel;
/*     */ import paulscode.sound.FilenameURL;
/*     */ import paulscode.sound.SoundBuffer;
/*     */ import paulscode.sound.SoundSystemConfig;
/*     */ import paulscode.sound.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourceLWJGLOpenAL
/*     */   extends Source
/*     */ {
/*  97 */   private ChannelLWJGLOpenAL channelOpenAL = (ChannelLWJGLOpenAL)this.channel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private IntBuffer myBuffer;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatBuffer listenerPosition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatBuffer sourcePosition;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private FloatBuffer sourceVelocity;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceLWJGLOpenAL(FloatBuffer paramFloatBuffer, IntBuffer paramIntBuffer, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, SoundBuffer paramSoundBuffer, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/* 144 */     super(paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, paramSoundBuffer, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, paramBoolean4);
/*     */     
/* 146 */     if (this.codec != null)
/* 147 */       this.codec.reverseByteOrder(true); 
/* 148 */     this.listenerPosition = paramFloatBuffer;
/* 149 */     this.myBuffer = paramIntBuffer;
/* 150 */     this.libraryType = LibraryLWJGLOpenAL.class;
/* 151 */     this.pitch = 1.0F;
/* 152 */     resetALInformation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceLWJGLOpenAL(FloatBuffer paramFloatBuffer, IntBuffer paramIntBuffer, Source paramSource, SoundBuffer paramSoundBuffer) {
/* 165 */     super(paramSource, paramSoundBuffer);
/* 166 */     if (this.codec != null)
/* 167 */       this.codec.reverseByteOrder(true); 
/* 168 */     this.listenerPosition = paramFloatBuffer;
/* 169 */     this.myBuffer = paramIntBuffer;
/* 170 */     this.libraryType = LibraryLWJGLOpenAL.class;
/* 171 */     this.pitch = 1.0F;
/* 172 */     resetALInformation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceLWJGLOpenAL(FloatBuffer paramFloatBuffer, AudioFormat paramAudioFormat, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/* 193 */     super(paramAudioFormat, paramBoolean, paramString, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4);
/*     */     
/* 195 */     this.listenerPosition = paramFloatBuffer;
/* 196 */     this.libraryType = LibraryLWJGLOpenAL.class;
/* 197 */     this.pitch = 1.0F;
/* 198 */     resetALInformation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 208 */     super.cleanup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeSource(FloatBuffer paramFloatBuffer, IntBuffer paramIntBuffer, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, SoundBuffer paramSoundBuffer, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/* 236 */     changeSource(paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, paramSoundBuffer, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, paramBoolean4);
/*     */ 
/*     */     
/* 239 */     this.listenerPosition = paramFloatBuffer;
/* 240 */     this.myBuffer = paramIntBuffer;
/* 241 */     this.pitch = 1.0F;
/* 242 */     resetALInformation();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean incrementSoundSequence() {
/* 255 */     if (!this.toStream) {
/*     */       
/* 257 */       errorMessage("Method 'incrementSoundSequence' may only be used for streaming sources.");
/*     */       
/* 259 */       return false;
/*     */     } 
/* 261 */     synchronized (this.soundSequenceLock) {
/*     */       
/* 263 */       if (this.soundSequenceQueue != null && this.soundSequenceQueue.size() > 0) {
/*     */         
/* 265 */         this.filenameURL = this.soundSequenceQueue.remove(0);
/* 266 */         if (this.codec != null)
/* 267 */           this.codec.cleanup(); 
/* 268 */         this.codec = SoundSystemConfig.getCodec(this.filenameURL.getFilename());
/* 269 */         if (this.codec != null) {
/*     */           
/* 271 */           this.codec.reverseByteOrder(true);
/* 272 */           if (this.codec.getAudioFormat() == null) {
/* 273 */             this.codec.initialize(this.filenameURL.getURL());
/*     */           }
/* 275 */           AudioFormat audioFormat = this.codec.getAudioFormat();
/*     */           
/* 277 */           if (audioFormat == null) {
/*     */             
/* 279 */             errorMessage("Audio Format null in method 'incrementSoundSequence'");
/*     */             
/* 281 */             return false;
/*     */           } 
/*     */           
/* 284 */           char c = Character.MIN_VALUE;
/* 285 */           if (audioFormat.getChannels() == 1) {
/*     */             
/* 287 */             if (audioFormat.getSampleSizeInBits() == 8)
/*     */             {
/* 289 */               c = 'ᄀ';
/*     */             }
/* 291 */             else if (audioFormat.getSampleSizeInBits() == 16)
/*     */             {
/* 293 */               c = 'ᄁ';
/*     */             }
/*     */             else
/*     */             {
/* 297 */               errorMessage("Illegal sample size in method 'incrementSoundSequence'");
/*     */               
/* 299 */               return false;
/*     */             }
/*     */           
/* 302 */           } else if (audioFormat.getChannels() == 2) {
/*     */             
/* 304 */             if (audioFormat.getSampleSizeInBits() == 8)
/*     */             {
/* 306 */               c = 'ᄂ';
/*     */             }
/* 308 */             else if (audioFormat.getSampleSizeInBits() == 16)
/*     */             {
/* 310 */               c = 'ᄃ';
/*     */             }
/*     */             else
/*     */             {
/* 314 */               errorMessage("Illegal sample size in method 'incrementSoundSequence'");
/*     */               
/* 316 */               return false;
/*     */             }
/*     */           
/*     */           } else {
/*     */             
/* 321 */             errorMessage("Audio data neither mono nor stereo in method 'incrementSoundSequence'");
/*     */             
/* 323 */             return false;
/*     */           } 
/*     */ 
/*     */           
/* 327 */           this.channelOpenAL.setFormat(c, (int)audioFormat.getSampleRate());
/*     */           
/* 329 */           this.preLoad = true;
/*     */         } 
/* 331 */         return true;
/*     */       } 
/*     */     } 
/* 334 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void listenerMoved() {
/* 343 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 355 */     super.setPosition(paramFloat1, paramFloat2, paramFloat3);
/*     */ 
/*     */     
/* 358 */     if (this.sourcePosition == null) {
/* 359 */       resetALInformation();
/*     */     } else {
/* 361 */       positionChanged();
/*     */     } 
/*     */     
/* 364 */     this.sourcePosition.put(0, paramFloat1);
/* 365 */     this.sourcePosition.put(1, paramFloat2);
/* 366 */     this.sourcePosition.put(2, paramFloat3);
/*     */ 
/*     */     
/* 369 */     if (this.channel != null && this.channel.attachedSource == this && this.channelOpenAL != null && this.channelOpenAL.ALSource != null) {
/*     */ 
/*     */ 
/*     */       
/* 373 */       AL10.alSource(this.channelOpenAL.ALSource.get(0), 4100, this.sourcePosition);
/*     */       
/* 375 */       checkALError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void positionChanged() {
/* 385 */     calculateDistance();
/* 386 */     calculateGain();
/*     */     
/* 388 */     if (this.channel != null && this.channel.attachedSource == this && this.channelOpenAL != null && this.channelOpenAL.ALSource != null) {
/*     */ 
/*     */       
/* 391 */       AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4106, this.gain * this.sourceVolume * Math.abs(this.fadeOutGain) * this.fadeInGain);
/*     */ 
/*     */ 
/*     */       
/* 395 */       checkALError();
/*     */     } 
/* 397 */     checkPitch();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void checkPitch() {
/* 405 */     if (this.channel != null && this.channel.attachedSource == this && LibraryLWJGLOpenAL.alPitchSupported() && this.channelOpenAL != null && this.channelOpenAL.ALSource != null) {
/*     */ 
/*     */ 
/*     */       
/* 409 */       AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4099, this.pitch);
/*     */       
/* 411 */       checkALError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setLooping(boolean paramBoolean) {
/* 422 */     super.setLooping(paramBoolean);
/*     */ 
/*     */     
/* 425 */     if (this.channel != null && this.channel.attachedSource == this && this.channelOpenAL != null && this.channelOpenAL.ALSource != null) {
/*     */ 
/*     */       
/* 428 */       if (paramBoolean) {
/* 429 */         AL10.alSourcei(this.channelOpenAL.ALSource.get(0), 4103, 1);
/*     */       } else {
/*     */         
/* 432 */         AL10.alSourcei(this.channelOpenAL.ALSource.get(0), 4103, 0);
/*     */       } 
/* 434 */       checkALError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttenuation(int paramInt) {
/* 445 */     super.setAttenuation(paramInt);
/*     */     
/* 447 */     if (this.channel != null && this.channel.attachedSource == this && this.channelOpenAL != null && this.channelOpenAL.ALSource != null) {
/*     */ 
/*     */ 
/*     */       
/* 451 */       if (paramInt == 1) {
/* 452 */         AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4129, this.distOrRoll);
/*     */       } else {
/*     */         
/* 455 */         AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4129, 0.0F);
/*     */       } 
/* 457 */       checkALError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDistOrRoll(float paramFloat) {
/* 469 */     super.setDistOrRoll(paramFloat);
/*     */     
/* 471 */     if (this.channel != null && this.channel.attachedSource == this && this.channelOpenAL != null && this.channelOpenAL.ALSource != null) {
/*     */ 
/*     */ 
/*     */       
/* 475 */       if (this.attModel == 1) {
/* 476 */         AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4129, paramFloat);
/*     */       } else {
/*     */         
/* 479 */         AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4129, 0.0F);
/*     */       } 
/* 481 */       checkALError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 494 */     super.setVelocity(paramFloat1, paramFloat2, paramFloat3);
/*     */     
/* 496 */     this.sourceVelocity = BufferUtils.createFloatBuffer(3).put(new float[] { paramFloat1, paramFloat2, paramFloat3 });
/*     */     
/* 498 */     this.sourceVelocity.flip();
/*     */     
/* 500 */     if (this.channel != null && this.channel.attachedSource == this && this.channelOpenAL != null && this.channelOpenAL.ALSource != null) {
/*     */ 
/*     */       
/* 503 */       AL10.alSource(this.channelOpenAL.ALSource.get(0), 4102, this.sourceVelocity);
/*     */       
/* 505 */       checkALError();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPitch(float paramFloat) {
/* 516 */     super.setPitch(paramFloat);
/* 517 */     checkPitch();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void play(Channel paramChannel) {
/* 527 */     if (!active()) {
/*     */       
/* 529 */       if (this.toLoop) {
/* 530 */         this.toPlay = true;
/*     */       }
/*     */       return;
/*     */     } 
/* 534 */     if (paramChannel == null) {
/*     */       
/* 536 */       errorMessage("Unable to play source, because channel was null");
/*     */       
/*     */       return;
/*     */     } 
/* 540 */     boolean bool = (this.channel != paramChannel) ? true : false;
/* 541 */     if (this.channel != null && this.channel.attachedSource != this) {
/* 542 */       bool = true;
/*     */     }
/* 544 */     boolean bool1 = paused();
/*     */     
/* 546 */     super.play(paramChannel);
/*     */     
/* 548 */     this.channelOpenAL = (ChannelLWJGLOpenAL)this.channel;
/*     */ 
/*     */ 
/*     */     
/* 552 */     if (bool) {
/*     */       
/* 554 */       setPosition(this.position.x, this.position.y, this.position.z);
/* 555 */       checkPitch();
/*     */ 
/*     */       
/* 558 */       if (this.channelOpenAL != null && this.channelOpenAL.ALSource != null) {
/*     */         
/* 560 */         if (LibraryLWJGLOpenAL.alPitchSupported()) {
/*     */           
/* 562 */           AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4099, this.pitch);
/*     */           
/* 564 */           checkALError();
/*     */         } 
/* 566 */         AL10.alSource(this.channelOpenAL.ALSource.get(0), 4100, this.sourcePosition);
/*     */         
/* 568 */         checkALError();
/*     */         
/* 570 */         AL10.alSource(this.channelOpenAL.ALSource.get(0), 4102, this.sourceVelocity);
/*     */ 
/*     */         
/* 573 */         checkALError();
/*     */         
/* 575 */         if (this.attModel == 1) {
/* 576 */           AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4129, this.distOrRoll);
/*     */         } else {
/*     */           
/* 579 */           AL10.alSourcef(this.channelOpenAL.ALSource.get(0), 4129, 0.0F);
/*     */         } 
/* 581 */         checkALError();
/*     */         
/* 583 */         if (this.toLoop && !this.toStream) {
/* 584 */           AL10.alSourcei(this.channelOpenAL.ALSource.get(0), 4103, 1);
/*     */         } else {
/*     */           
/* 587 */           AL10.alSourcei(this.channelOpenAL.ALSource.get(0), 4103, 0);
/*     */         } 
/* 589 */         checkALError();
/*     */       } 
/* 591 */       if (!this.toStream) {
/*     */ 
/*     */ 
/*     */         
/* 595 */         if (this.myBuffer == null) {
/*     */           
/* 597 */           errorMessage("No sound buffer to play");
/*     */           
/*     */           return;
/*     */         } 
/* 601 */         this.channelOpenAL.attachBuffer(this.myBuffer);
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/* 606 */     if (!playing()) {
/*     */       
/* 608 */       if (this.toStream && !bool1) {
/*     */         
/* 610 */         if (this.codec == null) {
/*     */           
/* 612 */           errorMessage("Decoder null in method 'play'");
/*     */           return;
/*     */         } 
/* 615 */         if (this.codec.getAudioFormat() == null) {
/* 616 */           this.codec.initialize(this.filenameURL.getURL());
/*     */         }
/* 618 */         AudioFormat audioFormat = this.codec.getAudioFormat();
/*     */         
/* 620 */         if (audioFormat == null) {
/*     */           
/* 622 */           errorMessage("Audio Format null in method 'play'");
/*     */           
/*     */           return;
/*     */         } 
/* 626 */         char c = Character.MIN_VALUE;
/* 627 */         if (audioFormat.getChannels() == 1) {
/*     */           
/* 629 */           if (audioFormat.getSampleSizeInBits() == 8) {
/*     */             
/* 631 */             c = 'ᄀ';
/*     */           }
/* 633 */           else if (audioFormat.getSampleSizeInBits() == 16) {
/*     */             
/* 635 */             c = 'ᄁ';
/*     */           }
/*     */           else {
/*     */             
/* 639 */             errorMessage("Illegal sample size in method 'play'");
/*     */             
/*     */             return;
/*     */           } 
/* 643 */         } else if (audioFormat.getChannels() == 2) {
/*     */           
/* 645 */           if (audioFormat.getSampleSizeInBits() == 8) {
/*     */             
/* 647 */             c = 'ᄂ';
/*     */           }
/* 649 */           else if (audioFormat.getSampleSizeInBits() == 16) {
/*     */             
/* 651 */             c = 'ᄃ';
/*     */           }
/*     */           else {
/*     */             
/* 655 */             errorMessage("Illegal sample size in method 'play'");
/*     */ 
/*     */             
/*     */             return;
/*     */           } 
/*     */         } else {
/* 661 */           errorMessage("Audio data neither mono nor stereo in method 'play'");
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */         
/* 667 */         this.channelOpenAL.setFormat(c, (int)audioFormat.getSampleRate());
/*     */         
/* 669 */         this.preLoad = true;
/*     */       } 
/* 671 */       this.channel.play();
/* 672 */       if (this.pitch != 1.0F) {
/* 673 */         checkPitch();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preLoad() {
/* 684 */     if (this.codec == null) {
/* 685 */       return false;
/*     */     }
/* 687 */     this.codec.initialize(this.filenameURL.getURL());
/* 688 */     LinkedList<byte[]> linkedList = new LinkedList();
/* 689 */     for (byte b = 0; b < SoundSystemConfig.getNumberStreamingBuffers(); b++) {
/*     */       
/* 691 */       this.soundBuffer = this.codec.read();
/*     */       
/* 693 */       if (this.soundBuffer == null || this.soundBuffer.audioData == null) {
/*     */         break;
/*     */       }
/* 696 */       linkedList.add(this.soundBuffer.audioData);
/*     */     } 
/* 698 */     positionChanged();
/*     */     
/* 700 */     this.channel.preLoadBuffers(linkedList);
/*     */     
/* 702 */     this.preLoad = false;
/* 703 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void resetALInformation() {
/* 712 */     this.sourcePosition = BufferUtils.createFloatBuffer(3).put(new float[] { this.position.x, this.position.y, this.position.z });
/*     */     
/* 714 */     this.sourceVelocity = BufferUtils.createFloatBuffer(3).put(new float[] { this.velocity.x, this.velocity.y, this.velocity.z });
/*     */ 
/*     */ 
/*     */     
/* 718 */     this.sourcePosition.flip();
/* 719 */     this.sourceVelocity.flip();
/*     */     
/* 721 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calculateDistance() {
/* 729 */     if (this.listenerPosition != null) {
/*     */ 
/*     */       
/* 732 */       double d1 = (this.position.x - this.listenerPosition.get(0));
/* 733 */       double d2 = (this.position.y - this.listenerPosition.get(1));
/* 734 */       double d3 = (this.position.z - this.listenerPosition.get(2));
/* 735 */       this.distanceFromListener = (float)Math.sqrt(d1 * d1 + d2 * d2 + d3 * d3);
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private void calculateGain() {
/* 746 */     if (this.attModel == 2) {
/*     */       
/* 748 */       if (this.distanceFromListener <= 0.0F) {
/*     */         
/* 750 */         this.gain = 1.0F;
/*     */       }
/* 752 */       else if (this.distanceFromListener >= this.distOrRoll) {
/*     */         
/* 754 */         this.gain = 0.0F;
/*     */       }
/*     */       else {
/*     */         
/* 758 */         this.gain = 1.0F - this.distanceFromListener / this.distOrRoll;
/*     */       } 
/* 760 */       if (this.gain > 1.0F)
/* 761 */         this.gain = 1.0F; 
/* 762 */       if (this.gain < 0.0F) {
/* 763 */         this.gain = 0.0F;
/*     */       }
/*     */     } else {
/*     */       
/* 767 */       this.gain = 1.0F;
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkALError() {
/* 777 */     switch (AL10.alGetError()) {
/*     */       
/*     */       case 0:
/* 780 */         return false;
/*     */       case 40961:
/* 782 */         errorMessage("Invalid name parameter.");
/* 783 */         return true;
/*     */       case 40962:
/* 785 */         errorMessage("Invalid parameter.");
/* 786 */         return true;
/*     */       case 40963:
/* 788 */         errorMessage("Invalid enumerated parameter value.");
/* 789 */         return true;
/*     */       case 40964:
/* 791 */         errorMessage("Illegal call.");
/* 792 */         return true;
/*     */       case 40965:
/* 794 */         errorMessage("Unable to allocate memory.");
/* 795 */         return true;
/*     */     } 
/* 797 */     errorMessage("An unrecognized error occurred.");
/* 798 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\libraries\SourceLWJGLOpenAL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */