/*     */ package paulscode.sound.libraries;
/*     */ 
/*     */ import java.util.LinkedList;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import paulscode.sound.Channel;
/*     */ import paulscode.sound.FilenameURL;
/*     */ import paulscode.sound.ListenerData;
/*     */ import paulscode.sound.SoundBuffer;
/*     */ import paulscode.sound.SoundSystemConfig;
/*     */ import paulscode.sound.Source;
/*     */ import paulscode.sound.Vector3D;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SourceJavaSound
/*     */   extends Source
/*     */ {
/*  56 */   protected ChannelJavaSound channelJavaSound = (ChannelJavaSound)this.channel;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ListenerData listener;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  66 */   private float pan = 0.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceJavaSound(ListenerData paramListenerData, boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, SoundBuffer paramSoundBuffer, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/*  90 */     super(paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, paramSoundBuffer, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, paramBoolean4);
/*     */     
/*  92 */     this.libraryType = LibraryJavaSound.class;
/*     */ 
/*     */     
/*  95 */     this.listener = paramListenerData;
/*  96 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceJavaSound(ListenerData paramListenerData, Source paramSource, SoundBuffer paramSoundBuffer) {
/* 108 */     super(paramSource, paramSoundBuffer);
/* 109 */     this.libraryType = LibraryJavaSound.class;
/*     */ 
/*     */     
/* 112 */     this.listener = paramListenerData;
/* 113 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public SourceJavaSound(ListenerData paramListenerData, AudioFormat paramAudioFormat, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/* 133 */     super(paramAudioFormat, paramBoolean, paramString, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4);
/*     */     
/* 135 */     this.libraryType = LibraryJavaSound.class;
/*     */ 
/*     */     
/* 138 */     this.listener = paramListenerData;
/* 139 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 149 */     super.cleanup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void changeSource(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, SoundBuffer paramSoundBuffer, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/* 175 */     super.changeSource(paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, paramSoundBuffer, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, paramBoolean4);
/*     */ 
/*     */     
/* 178 */     if (this.channelJavaSound != null)
/* 179 */       this.channelJavaSound.setLooping(paramBoolean3); 
/* 180 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void listenerMoved() {
/* 189 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 201 */     super.setVelocity(paramFloat1, paramFloat2, paramFloat3);
/* 202 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 214 */     super.setPosition(paramFloat1, paramFloat2, paramFloat3);
/* 215 */     positionChanged();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void positionChanged() {
/* 224 */     calculateGain();
/* 225 */     calculatePan();
/* 226 */     calculatePitch();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setPitch(float paramFloat) {
/* 236 */     super.setPitch(paramFloat);
/* 237 */     calculatePitch();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAttenuation(int paramInt) {
/* 247 */     super.setAttenuation(paramInt);
/* 248 */     calculateGain();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setDistOrRoll(float paramFloat) {
/* 259 */     super.setDistOrRoll(paramFloat);
/* 260 */     calculateGain();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void play(Channel paramChannel) {
/* 270 */     if (!active()) {
/*     */       
/* 272 */       if (this.toLoop) {
/* 273 */         this.toPlay = true;
/*     */       }
/*     */       return;
/*     */     } 
/* 277 */     if (paramChannel == null) {
/*     */       
/* 279 */       errorMessage("Unable to play source, because channel was null");
/*     */       
/*     */       return;
/*     */     } 
/* 283 */     boolean bool = (this.channel != paramChannel) ? true : false;
/* 284 */     if (this.channel != null && this.channel.attachedSource != this) {
/* 285 */       bool = true;
/*     */     }
/* 287 */     boolean bool1 = paused();
/* 288 */     boolean bool2 = stopped();
/*     */     
/* 290 */     super.play(paramChannel);
/*     */     
/* 292 */     this.channelJavaSound = (ChannelJavaSound)this.channel;
/*     */ 
/*     */ 
/*     */     
/* 296 */     if (bool) {
/*     */       
/* 298 */       if (this.channelJavaSound != null) {
/* 299 */         this.channelJavaSound.setLooping(this.toLoop);
/*     */       }
/* 301 */       if (!this.toStream) {
/*     */ 
/*     */ 
/*     */         
/* 305 */         if (this.soundBuffer == null) {
/*     */           
/* 307 */           errorMessage("No sound buffer to play");
/*     */           
/*     */           return;
/*     */         } 
/* 311 */         this.channelJavaSound.attachBuffer(this.soundBuffer);
/*     */       } 
/*     */     } 
/* 314 */     positionChanged();
/*     */ 
/*     */     
/* 317 */     if (bool2 || !playing()) {
/*     */       
/* 319 */       if (this.toStream && !bool1)
/*     */       {
/* 321 */         this.preLoad = true;
/*     */       }
/* 323 */       this.channel.play();
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preLoad() {
/* 334 */     if (this.codec == null)
/*     */     {
/* 336 */       return false;
/*     */     }
/*     */     
/* 339 */     boolean bool = false;
/* 340 */     synchronized (this.soundSequenceLock) {
/*     */       
/* 342 */       if (this.nextBuffers == null || this.nextBuffers.isEmpty()) {
/* 343 */         bool = true;
/*     */       }
/*     */     } 
/* 346 */     LinkedList<byte[]> linkedList = new LinkedList();
/* 347 */     if (this.nextCodec != null && !bool) {
/*     */       
/* 349 */       this.codec = this.nextCodec;
/* 350 */       this.nextCodec = null;
/* 351 */       synchronized (this.soundSequenceLock) {
/*     */         
/* 353 */         while (!this.nextBuffers.isEmpty()) {
/*     */           
/* 355 */           this.soundBuffer = this.nextBuffers.remove(0);
/* 356 */           if (this.soundBuffer != null && this.soundBuffer.audioData != null) {
/* 357 */             linkedList.add(this.soundBuffer.audioData);
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } else {
/*     */       
/* 363 */       this.codec.initialize(this.filenameURL.getURL());
/*     */       
/* 365 */       for (byte b = 0; b < SoundSystemConfig.getNumberStreamingBuffers(); b++) {
/*     */         
/* 367 */         this.soundBuffer = this.codec.read();
/*     */         
/* 369 */         if (this.soundBuffer == null || this.soundBuffer.audioData == null) {
/*     */           break;
/*     */         }
/* 372 */         linkedList.add(this.soundBuffer.audioData);
/*     */       } 
/* 374 */       this.channelJavaSound.resetStream(this.codec.getAudioFormat());
/*     */     } 
/* 376 */     positionChanged();
/*     */     
/* 378 */     this.channel.preLoadBuffers(linkedList);
/*     */     
/* 380 */     this.preLoad = false;
/* 381 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void calculateGain() {
/* 390 */     float f4, f5, f1 = this.position.x - this.listener.position.x;
/* 391 */     float f2 = this.position.y - this.listener.position.y;
/* 392 */     float f3 = this.position.z - this.listener.position.z;
/*     */     
/* 394 */     this.distanceFromListener = (float)Math.sqrt((f1 * f1 + f2 * f2 + f3 * f3));
/*     */ 
/*     */ 
/*     */     
/* 398 */     switch (this.attModel) {
/*     */       
/*     */       case 2:
/* 401 */         if (this.distanceFromListener <= 0.0F) {
/*     */           
/* 403 */           this.gain = 1.0F; break;
/*     */         } 
/* 405 */         if (this.distanceFromListener >= this.distOrRoll) {
/*     */           
/* 407 */           this.gain = 0.0F;
/*     */           
/*     */           break;
/*     */         } 
/* 411 */         this.gain = 1.0F - this.distanceFromListener / this.distOrRoll;
/*     */         break;
/*     */       
/*     */       case 1:
/* 415 */         if (this.distanceFromListener <= 0.0F) {
/*     */           
/* 417 */           this.gain = 1.0F;
/*     */           
/*     */           break;
/*     */         } 
/* 421 */         f4 = 5.0E-4F;
/* 422 */         f5 = this.distOrRoll * this.distanceFromListener * this.distanceFromListener * f4;
/*     */ 
/*     */ 
/*     */ 
/*     */         
/* 427 */         if (f5 < 0.0F) {
/* 428 */           f5 = 0.0F;
/*     */         }
/* 430 */         this.gain = 1.0F / (1.0F + f5);
/*     */         break;
/*     */       
/*     */       default:
/* 434 */         this.gain = 1.0F;
/*     */         break;
/*     */     } 
/*     */     
/* 438 */     if (this.gain > 1.0F)
/* 439 */       this.gain = 1.0F; 
/* 440 */     if (this.gain < 0.0F) {
/* 441 */       this.gain = 0.0F;
/*     */     }
/* 443 */     this.gain *= this.sourceVolume * SoundSystemConfig.getMasterGain() * Math.abs(this.fadeOutGain) * this.fadeInGain;
/*     */ 
/*     */ 
/*     */     
/* 447 */     if (this.channel != null && this.channel.attachedSource == this && this.channelJavaSound != null)
/*     */     {
/* 449 */       this.channelJavaSound.setGain(this.gain);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void calculatePan() {
/* 458 */     Vector3D vector3D = this.listener.up.cross(this.listener.lookAt);
/* 459 */     vector3D.normalize();
/* 460 */     float f1 = this.position.dot(this.position.subtract(this.listener.position), vector3D);
/* 461 */     float f2 = this.position.dot(this.position.subtract(this.listener.position), this.listener.lookAt);
/*     */     
/* 463 */     vector3D = null;
/* 464 */     float f3 = (float)Math.atan2(f1, f2);
/* 465 */     this.pan = (float)-Math.sin(f3);
/*     */     
/* 467 */     if (this.channel != null && this.channel.attachedSource == this && this.channelJavaSound != null)
/*     */     {
/*     */       
/* 470 */       if (this.attModel == 0) {
/* 471 */         this.channelJavaSound.setPan(0.0F);
/*     */       } else {
/* 473 */         this.channelJavaSound.setPan(this.pan);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void calculatePitch() {
/* 483 */     if (this.channel != null && this.channel.attachedSource == this && this.channelJavaSound != null)
/*     */     {
/*     */ 
/*     */       
/* 487 */       if (SoundSystemConfig.getDopplerFactor() == 0.0F) {
/*     */         
/* 489 */         this.channelJavaSound.setPitch(this.pitch);
/*     */       }
/*     */       else {
/*     */         
/* 493 */         float f1 = 343.3F;
/*     */         
/* 495 */         Vector3D vector3D1 = this.velocity;
/* 496 */         Vector3D vector3D2 = this.listener.velocity;
/* 497 */         float f2 = SoundSystemConfig.getDopplerVelocity();
/* 498 */         float f3 = SoundSystemConfig.getDopplerFactor();
/* 499 */         Vector3D vector3D3 = this.listener.position.subtract(this.position);
/*     */         
/* 501 */         float f4 = vector3D3.dot(vector3D2) / vector3D3.length();
/* 502 */         float f5 = vector3D3.dot(vector3D1) / vector3D3.length();
/*     */         
/* 504 */         f5 = min(f5, f1 / f3);
/* 505 */         f4 = min(f4, f1 / f3);
/* 506 */         float f6 = this.pitch * (f1 * f2 - f3 * f4) / (f1 * f2 - f3 * f5);
/*     */ 
/*     */         
/* 509 */         if (f6 < 0.5F) {
/* 510 */           f6 = 0.5F;
/* 511 */         } else if (f6 > 2.0F) {
/* 512 */           f6 = 2.0F;
/*     */         } 
/* 514 */         this.channelJavaSound.setPitch(f6);
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public float min(float paramFloat1, float paramFloat2) {
/* 521 */     if (paramFloat1 < paramFloat2)
/* 522 */       return paramFloat1; 
/* 523 */     return paramFloat2;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\libraries\SourceJavaSound.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */