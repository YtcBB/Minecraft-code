/*     */ package paulscode.sound.libraries;
/*     */ 
/*     */ import java.nio.ByteBuffer;
/*     */ import java.nio.IntBuffer;
/*     */ import java.util.LinkedList;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import org.lwjgl.BufferUtils;
/*     */ import org.lwjgl.openal.AL10;
/*     */ import paulscode.sound.Channel;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class ChannelLWJGLOpenAL
/*     */   extends Channel
/*     */ {
/*     */   public IntBuffer ALSource;
/*     */   public int ALformat;
/*     */   public int sampleRate;
/* 112 */   public float millisPreviouslyPlayed = 0.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public ChannelLWJGLOpenAL(int paramInt, IntBuffer paramIntBuffer) {
/* 124 */     super(paramInt);
/* 125 */     this.libraryType = LibraryLWJGLOpenAL.class;
/* 126 */     this.ALSource = paramIntBuffer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 136 */     if (this.ALSource != null) {
/*     */ 
/*     */       
/*     */       try {
/*     */         
/* 141 */         AL10.alSourceStop(this.ALSource);
/* 142 */         AL10.alGetError();
/*     */       }
/* 144 */       catch (Exception exception) {}
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 149 */         AL10.alDeleteSources(this.ALSource);
/* 150 */         AL10.alGetError();
/*     */       }
/* 152 */       catch (Exception exception) {}
/*     */       
/* 154 */       this.ALSource.clear();
/*     */     } 
/* 156 */     this.ALSource = null;
/*     */     
/* 158 */     super.cleanup();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean attachBuffer(IntBuffer paramIntBuffer) {
/* 170 */     if (errorCheck((this.channelType != 0), "Sound buffers may only be attached to normal sources."))
/*     */     {
/*     */       
/* 173 */       return false;
/*     */     }
/*     */     
/* 176 */     AL10.alSourcei(this.ALSource.get(0), 4105, paramIntBuffer.get(0));
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 181 */     if (this.attachedSource != null && this.attachedSource.soundBuffer != null && this.attachedSource.soundBuffer.audioFormat != null)
/*     */     {
/* 183 */       setAudioFormat(this.attachedSource.soundBuffer.audioFormat);
/*     */     }
/*     */     
/* 186 */     return checkALError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setAudioFormat(AudioFormat paramAudioFormat) {
/* 195 */     char c = Character.MIN_VALUE;
/* 196 */     if (paramAudioFormat.getChannels() == 1) {
/*     */       
/* 198 */       if (paramAudioFormat.getSampleSizeInBits() == 8) {
/*     */         
/* 200 */         c = 'ᄀ';
/*     */       }
/* 202 */       else if (paramAudioFormat.getSampleSizeInBits() == 16) {
/*     */         
/* 204 */         c = 'ᄁ';
/*     */       }
/*     */       else {
/*     */         
/* 208 */         errorMessage("Illegal sample size in method 'setAudioFormat'");
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/* 213 */     } else if (paramAudioFormat.getChannels() == 2) {
/*     */       
/* 215 */       if (paramAudioFormat.getSampleSizeInBits() == 8) {
/*     */         
/* 217 */         c = 'ᄂ';
/*     */       }
/* 219 */       else if (paramAudioFormat.getSampleSizeInBits() == 16) {
/*     */         
/* 221 */         c = 'ᄃ';
/*     */       }
/*     */       else {
/*     */         
/* 225 */         errorMessage("Illegal sample size in method 'setAudioFormat'");
/*     */ 
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } else {
/* 232 */       errorMessage("Audio data neither mono nor stereo in method 'setAudioFormat'");
/*     */       
/*     */       return;
/*     */     } 
/* 236 */     this.ALformat = c;
/* 237 */     this.sampleRate = (int)paramAudioFormat.getSampleRate();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setFormat(int paramInt1, int paramInt2) {
/* 247 */     this.ALformat = paramInt1;
/* 248 */     this.sampleRate = paramInt2;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean preLoadBuffers(LinkedList<byte[]> paramLinkedList) {
/* 260 */     if (errorCheck((this.channelType != 1), "Buffers may only be queued for streaming sources."))
/*     */     {
/* 262 */       return false;
/*     */     }
/* 264 */     if (errorCheck((paramLinkedList == null), "Buffer List null in method 'preLoadBuffers'"))
/*     */     {
/* 266 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */     
/* 271 */     boolean bool = playing();
/*     */     
/* 273 */     if (bool) {
/*     */       
/* 275 */       AL10.alSourceStop(this.ALSource.get(0));
/* 276 */       checkALError();
/*     */     } 
/*     */     
/* 279 */     int i = AL10.alGetSourcei(this.ALSource.get(0), 4118);
/*     */     
/* 281 */     if (i > 0) {
/*     */       
/* 283 */       IntBuffer intBuffer1 = BufferUtils.createIntBuffer(i);
/* 284 */       AL10.alGenBuffers(intBuffer1);
/* 285 */       if (errorCheck(checkALError(), "Error clearing stream buffers in method 'preLoadBuffers'"))
/*     */       {
/* 287 */         return false; } 
/* 288 */       AL10.alSourceUnqueueBuffers(this.ALSource.get(0), intBuffer1);
/* 289 */       if (errorCheck(checkALError(), "Error unqueuing stream buffers in method 'preLoadBuffers'"))
/*     */       {
/* 291 */         return false;
/*     */       }
/*     */     } 
/*     */     
/* 295 */     if (bool) {
/*     */       
/* 297 */       AL10.alSourcePlay(this.ALSource.get(0));
/* 298 */       checkALError();
/*     */     } 
/*     */     
/* 301 */     IntBuffer intBuffer = BufferUtils.createIntBuffer(paramLinkedList.size());
/* 302 */     AL10.alGenBuffers(intBuffer);
/* 303 */     if (errorCheck(checkALError(), "Error generating stream buffers in method 'preLoadBuffers'"))
/*     */     {
/* 305 */       return false;
/*     */     }
/* 307 */     ByteBuffer byteBuffer = null;
/* 308 */     for (byte b = 0; b < paramLinkedList.size(); b++) {
/*     */ 
/*     */ 
/*     */       
/* 312 */       byteBuffer = (ByteBuffer)BufferUtils.createByteBuffer(((byte[])paramLinkedList.get(b)).length).put(paramLinkedList.get(b)).flip();
/*     */ 
/*     */ 
/*     */       
/*     */       try {
/* 317 */         AL10.alBufferData(intBuffer.get(b), this.ALformat, byteBuffer, this.sampleRate);
/*     */       
/*     */       }
/* 320 */       catch (Exception exception) {
/*     */         
/* 322 */         errorMessage("Error creating buffers in method 'preLoadBuffers'");
/*     */         
/* 324 */         printStackTrace(exception);
/* 325 */         return false;
/*     */       } 
/* 327 */       if (errorCheck(checkALError(), "Error creating buffers in method 'preLoadBuffers'"))
/*     */       {
/* 329 */         return false;
/*     */       }
/*     */     } 
/*     */ 
/*     */     
/*     */     try {
/* 335 */       AL10.alSourceQueueBuffers(this.ALSource.get(0), intBuffer);
/*     */     }
/* 337 */     catch (Exception exception) {
/*     */       
/* 339 */       errorMessage("Error queuing buffers in method 'preLoadBuffers'");
/* 340 */       printStackTrace(exception);
/* 341 */       return false;
/*     */     } 
/* 343 */     if (errorCheck(checkALError(), "Error queuing buffers in method 'preLoadBuffers'"))
/*     */     {
/* 345 */       return false;
/*     */     }
/* 347 */     AL10.alSourcePlay(this.ALSource.get(0));
/* 348 */     if (errorCheck(checkALError(), "Error playing source in method 'preLoadBuffers'"))
/*     */     {
/* 350 */       return false;
/*     */     }
/*     */     
/* 353 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean queueBuffer(byte[] paramArrayOfbyte) {
/* 365 */     if (errorCheck((this.channelType != 1), "Buffers may only be queued for streaming sources."))
/*     */     {
/* 367 */       return false;
/*     */     }
/*     */     
/* 370 */     ByteBuffer byteBuffer = (ByteBuffer)BufferUtils.createByteBuffer(paramArrayOfbyte.length).put(paramArrayOfbyte).flip();
/*     */ 
/*     */     
/* 373 */     IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
/*     */     
/* 375 */     AL10.alSourceUnqueueBuffers(this.ALSource.get(0), intBuffer);
/* 376 */     if (checkALError()) {
/* 377 */       return false;
/*     */     }
/* 379 */     if (AL10.alIsBuffer(intBuffer.get(0)))
/* 380 */       this.millisPreviouslyPlayed += millisInBuffer(intBuffer.get(0)); 
/* 381 */     checkALError();
/*     */     
/* 383 */     AL10.alBufferData(intBuffer.get(0), this.ALformat, byteBuffer, this.sampleRate);
/* 384 */     if (checkALError()) {
/* 385 */       return false;
/*     */     }
/* 387 */     AL10.alSourceQueueBuffers(this.ALSource.get(0), intBuffer);
/* 388 */     if (checkALError()) {
/* 389 */       return false;
/*     */     }
/* 391 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int feedRawAudioData(byte[] paramArrayOfbyte) {
/*     */     IntBuffer intBuffer;
/* 403 */     if (errorCheck((this.channelType != 1), "Raw audio data can only be fed to streaming sources."))
/*     */     {
/* 405 */       return -1;
/*     */     }
/*     */     
/* 408 */     ByteBuffer byteBuffer = (ByteBuffer)BufferUtils.createByteBuffer(paramArrayOfbyte.length).put(paramArrayOfbyte).flip();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 414 */     int i = AL10.alGetSourcei(this.ALSource.get(0), 4118);
/*     */     
/* 416 */     if (i > 0) {
/*     */       
/* 418 */       intBuffer = BufferUtils.createIntBuffer(i);
/* 419 */       AL10.alGenBuffers(intBuffer);
/* 420 */       if (errorCheck(checkALError(), "Error clearing stream buffers in method 'feedRawAudioData'"))
/*     */       {
/* 422 */         return -1; } 
/* 423 */       AL10.alSourceUnqueueBuffers(this.ALSource.get(0), intBuffer);
/* 424 */       if (errorCheck(checkALError(), "Error unqueuing stream buffers in method 'feedRawAudioData'"))
/*     */       {
/* 426 */         return -1; } 
/* 427 */       if (AL10.alIsBuffer(intBuffer.get(0)))
/* 428 */         this.millisPreviouslyPlayed += millisInBuffer(intBuffer.get(0)); 
/* 429 */       checkALError();
/*     */     }
/*     */     else {
/*     */       
/* 433 */       intBuffer = BufferUtils.createIntBuffer(1);
/* 434 */       AL10.alGenBuffers(intBuffer);
/* 435 */       if (errorCheck(checkALError(), "Error generating stream buffers in method 'preLoadBuffers'"))
/*     */       {
/* 437 */         return -1;
/*     */       }
/*     */     } 
/* 440 */     AL10.alBufferData(intBuffer.get(0), this.ALformat, byteBuffer, this.sampleRate);
/* 441 */     if (checkALError()) {
/* 442 */       return -1;
/*     */     }
/* 444 */     AL10.alSourceQueueBuffers(this.ALSource.get(0), intBuffer);
/* 445 */     if (checkALError()) {
/* 446 */       return -1;
/*     */     }
/* 448 */     if (this.attachedSource != null && this.attachedSource.channel == this && this.attachedSource.active())
/*     */     {
/*     */ 
/*     */       
/* 452 */       if (!playing()) {
/*     */         
/* 454 */         AL10.alSourcePlay(this.ALSource.get(0));
/* 455 */         checkALError();
/*     */       } 
/*     */     }
/*     */     
/* 459 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float millisInBuffer(int paramInt) {
/* 468 */     return AL10.alGetBufferi(paramInt, 8196) / AL10.alGetBufferi(paramInt, 8195) / AL10.alGetBufferi(paramInt, 8194) / 8.0F / this.sampleRate * 1000.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public float millisecondsPlayed() {
/* 482 */     float f1 = AL10.alGetSourcei(this.ALSource.get(0), 4134);
/*     */ 
/*     */     
/* 485 */     float f2 = 1.0F;
/* 486 */     switch (this.ALformat) {
/*     */       
/*     */       case 4352:
/* 489 */         f2 = 1.0F;
/*     */         break;
/*     */       case 4353:
/* 492 */         f2 = 2.0F;
/*     */         break;
/*     */       case 4354:
/* 495 */         f2 = 2.0F;
/*     */         break;
/*     */       case 4355:
/* 498 */         f2 = 4.0F;
/*     */         break;
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 504 */     f1 = f1 / f2 / this.sampleRate * 1000.0F;
/*     */ 
/*     */ 
/*     */     
/* 508 */     if (this.channelType == 1) {
/* 509 */       f1 += this.millisPreviouslyPlayed;
/*     */     }
/*     */     
/* 512 */     return f1;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int buffersProcessed() {
/* 523 */     if (this.channelType != 1) {
/* 524 */       return 0;
/*     */     }
/*     */     
/* 527 */     int i = AL10.alGetSourcei(this.ALSource.get(0), 4118);
/*     */ 
/*     */ 
/*     */     
/* 531 */     if (checkALError()) {
/* 532 */       return 0;
/*     */     }
/*     */     
/* 535 */     return i;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void flush() {
/* 546 */     if (this.channelType != 1) {
/*     */       return;
/*     */     }
/*     */     
/* 550 */     int i = AL10.alGetSourcei(this.ALSource.get(0), 4117);
/*     */ 
/*     */     
/* 553 */     if (checkALError()) {
/*     */       return;
/*     */     }
/* 556 */     IntBuffer intBuffer = BufferUtils.createIntBuffer(1);
/* 557 */     while (i > 0) {
/*     */ 
/*     */       
/*     */       try {
/* 561 */         AL10.alSourceUnqueueBuffers(this.ALSource.get(0), intBuffer);
/*     */       }
/* 563 */       catch (Exception exception) {
/*     */         return;
/*     */       } 
/*     */       
/* 567 */       if (checkALError())
/*     */         return; 
/* 569 */       i--;
/*     */     } 
/* 571 */     this.millisPreviouslyPlayed = 0.0F;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void close() {
/*     */     try {
/* 582 */       AL10.alSourceStop(this.ALSource.get(0));
/* 583 */       AL10.alGetError();
/*     */     }
/* 585 */     catch (Exception exception) {}
/*     */ 
/*     */     
/* 588 */     if (this.channelType == 1) {
/* 589 */       flush();
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void play() {
/* 599 */     AL10.alSourcePlay(this.ALSource.get(0));
/* 600 */     checkALError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void pause() {
/* 609 */     AL10.alSourcePause(this.ALSource.get(0));
/* 610 */     checkALError();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void stop() {
/* 620 */     AL10.alSourceStop(this.ALSource.get(0));
/* 621 */     if (!checkALError()) {
/* 622 */       this.millisPreviouslyPlayed = 0.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rewind() {
/* 633 */     if (this.channelType == 1) {
/*     */       return;
/*     */     }
/* 636 */     AL10.alSourceRewind(this.ALSource.get(0));
/* 637 */     if (!checkALError()) {
/* 638 */       this.millisPreviouslyPlayed = 0.0F;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean playing() {
/* 651 */     int i = AL10.alGetSourcei(this.ALSource.get(0), 4112);
/*     */     
/* 653 */     if (checkALError()) {
/* 654 */       return false;
/*     */     }
/* 656 */     return (i == 4114);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private boolean checkALError() {
/* 665 */     switch (AL10.alGetError()) {
/*     */       
/*     */       case 0:
/* 668 */         return false;
/*     */       case 40961:
/* 670 */         errorMessage("Invalid name parameter.");
/* 671 */         return true;
/*     */       case 40962:
/* 673 */         errorMessage("Invalid parameter.");
/* 674 */         return true;
/*     */       case 40963:
/* 676 */         errorMessage("Invalid enumerated parameter value.");
/* 677 */         return true;
/*     */       case 40964:
/* 679 */         errorMessage("Illegal call.");
/* 680 */         return true;
/*     */       case 40965:
/* 682 */         errorMessage("Unable to allocate memory.");
/* 683 */         return true;
/*     */     } 
/* 685 */     errorMessage("An unrecognized error occurred.");
/* 686 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\libraries\ChannelLWJGLOpenAL.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */