/*     */ package paulscode.sound.libraries;
/*     */ 
/*     */ import java.net.URL;
/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.ListIterator;
/*     */ import java.util.Set;
/*     */ import javax.sound.sampled.AudioFormat;
/*     */ import javax.sound.sampled.AudioSystem;
/*     */ import javax.sound.sampled.Mixer;
/*     */ import paulscode.sound.Channel;
/*     */ import paulscode.sound.FilenameURL;
/*     */ import paulscode.sound.ICodec;
/*     */ import paulscode.sound.Library;
/*     */ import paulscode.sound.SoundBuffer;
/*     */ import paulscode.sound.SoundSystem;
/*     */ import paulscode.sound.SoundSystemConfig;
/*     */ import paulscode.sound.SoundSystemException;
/*     */ import paulscode.sound.Source;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class LibraryJavaSound
/*     */   extends Library
/*     */ {
/*     */   private static final boolean GET = false;
/*     */   private static final boolean SET = true;
/*     */   private static final int XXX = 0;
/*  85 */   private final int maxClipSize = 1048576;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  90 */   private static Mixer myMixer = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  95 */   private static LibraryJavaSound$MixerRanking myMixerRanking = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 100 */   private static LibraryJavaSound instance = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 105 */   private static int minSampleRate = 4000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 110 */   private static int maxSampleRate = 48000;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 115 */   private static int lineCount = 32;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean useGainControl = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean usePanControl = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean useSampleRateControl = true;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public LibraryJavaSound() {
/* 141 */     instance = this;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void init() {
/* 150 */     LibraryJavaSound$MixerRanking libraryJavaSound$MixerRanking = null;
/*     */     
/* 152 */     if (myMixer == null) {
/*     */ 
/*     */       
/* 155 */       for (Mixer.Info info : AudioSystem.getMixerInfo()) {
/*     */         
/* 157 */         if (info.getName().equals("Java Sound Audio Engine")) {
/*     */ 
/*     */           
/* 160 */           libraryJavaSound$MixerRanking = new LibraryJavaSound$MixerRanking();
/*     */           
/*     */           try {
/* 163 */             libraryJavaSound$MixerRanking.rank(info);
/*     */           }
/* 165 */           catch (LibraryJavaSound$Exception libraryJavaSound$Exception) {
/*     */             break;
/*     */           } 
/*     */ 
/*     */           
/* 170 */           if (libraryJavaSound$MixerRanking.rank < 14) {
/*     */             break;
/*     */           }
/* 173 */           myMixer = AudioSystem.getMixer(info);
/* 174 */           mixerRanking(true, libraryJavaSound$MixerRanking);
/*     */           
/*     */           break;
/*     */         } 
/*     */       } 
/* 179 */       if (myMixer == null) {
/*     */ 
/*     */         
/* 182 */         LibraryJavaSound$MixerRanking libraryJavaSound$MixerRanking1 = libraryJavaSound$MixerRanking;
/* 183 */         for (Mixer.Info info : AudioSystem.getMixerInfo()) {
/*     */           
/* 185 */           libraryJavaSound$MixerRanking = new LibraryJavaSound$MixerRanking();
/*     */ 
/*     */           
/*     */           try {
/* 189 */             libraryJavaSound$MixerRanking.rank(info);
/*     */           }
/* 191 */           catch (LibraryJavaSound$Exception libraryJavaSound$Exception) {}
/*     */ 
/*     */           
/* 194 */           if (libraryJavaSound$MixerRanking1 == null || libraryJavaSound$MixerRanking.rank > libraryJavaSound$MixerRanking1.rank)
/*     */           {
/* 196 */             libraryJavaSound$MixerRanking1 = libraryJavaSound$MixerRanking;
/*     */           }
/*     */         } 
/* 199 */         if (libraryJavaSound$MixerRanking1 == null) {
/* 200 */           throw new LibraryJavaSound$Exception("No useable mixers found!", new LibraryJavaSound$MixerRanking());
/*     */         }
/*     */ 
/*     */         
/*     */         try {
/* 205 */           myMixer = AudioSystem.getMixer(libraryJavaSound$MixerRanking1.mixerInfo);
/* 206 */           mixerRanking(true, libraryJavaSound$MixerRanking1);
/*     */         }
/* 208 */         catch (Exception exception) {
/*     */ 
/*     */           
/* 211 */           throw new LibraryJavaSound$Exception("No useable mixers available!", new LibraryJavaSound$MixerRanking());
/*     */         } 
/*     */       } 
/*     */     } 
/*     */ 
/*     */ 
/*     */     
/* 218 */     setMasterVolume(1.0F);
/*     */ 
/*     */     
/* 221 */     message("JavaSound initialized.");
/*     */     
/* 223 */     super.init();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean libraryCompatible() {
/* 233 */     for (Mixer.Info info : AudioSystem.getMixerInfo()) {
/*     */       
/* 235 */       if (info.getName().equals("Java Sound Audio Engine"))
/* 236 */         return true; 
/*     */     } 
/* 238 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected Channel createChannel(int paramInt) {
/* 250 */     return new ChannelJavaSound(paramInt, myMixer);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void cleanup() {
/* 259 */     super.cleanup();
/* 260 */     instance = null;
/* 261 */     myMixer = null;
/* 262 */     myMixerRanking = null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean loadSound(FilenameURL paramFilenameURL) {
/* 274 */     if (this.bufferMap == null) {
/*     */       
/* 276 */       this.bufferMap = new HashMap<Object, Object>();
/* 277 */       importantMessage("Buffer Map was null in method 'loadSound'");
/*     */     } 
/*     */ 
/*     */     
/* 281 */     if (errorCheck((paramFilenameURL == null), "Filename/URL not specified in method 'loadSound'"))
/*     */     {
/* 283 */       return false;
/*     */     }
/*     */     
/* 286 */     if (this.bufferMap.get(paramFilenameURL.getFilename()) != null) {
/* 287 */       return true;
/*     */     }
/* 289 */     ICodec iCodec = SoundSystemConfig.getCodec(paramFilenameURL.getFilename());
/* 290 */     if (errorCheck((iCodec == null), "No codec found for file '" + paramFilenameURL.getFilename() + "' in method 'loadSound'"))
/*     */     {
/*     */       
/* 293 */       return false; } 
/* 294 */     URL uRL = paramFilenameURL.getURL();
/*     */     
/* 296 */     if (errorCheck((uRL == null), "Unable to open file '" + paramFilenameURL.getFilename() + "' in method 'loadSound'"))
/*     */     {
/*     */       
/* 299 */       return false;
/*     */     }
/* 301 */     iCodec.initialize(uRL);
/* 302 */     SoundBuffer soundBuffer = iCodec.readAll();
/* 303 */     iCodec.cleanup();
/* 304 */     iCodec = null;
/* 305 */     if (soundBuffer != null) {
/* 306 */       this.bufferMap.put(paramFilenameURL.getFilename(), soundBuffer);
/*     */     } else {
/* 308 */       errorMessage("Sound buffer null in method 'loadSound'");
/*     */     } 
/* 310 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean loadSound(SoundBuffer paramSoundBuffer, String paramString) {
/* 325 */     if (this.bufferMap == null) {
/*     */       
/* 327 */       this.bufferMap = new HashMap<Object, Object>();
/* 328 */       importantMessage("Buffer Map was null in method 'loadSound'");
/*     */     } 
/*     */ 
/*     */     
/* 332 */     if (errorCheck((paramString == null), "Identifier not specified in method 'loadSound'"))
/*     */     {
/* 334 */       return false;
/*     */     }
/*     */     
/* 337 */     if (this.bufferMap.get(paramString) != null) {
/* 338 */       return true;
/*     */     }
/*     */     
/* 341 */     if (paramSoundBuffer != null) {
/* 342 */       this.bufferMap.put(paramString, paramSoundBuffer);
/*     */     } else {
/* 344 */       errorMessage("Sound buffer null in method 'loadSound'");
/*     */     } 
/* 346 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setMasterVolume(float paramFloat) {
/* 356 */     super.setMasterVolume(paramFloat);
/*     */     
/* 358 */     Set set = this.sourceMap.keySet();
/* 359 */     Iterator<String> iterator = set.iterator();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 364 */     while (iterator.hasNext()) {
/*     */       
/* 366 */       String str = iterator.next();
/* 367 */       Source source = (Source)this.sourceMap.get(str);
/* 368 */       if (source != null) {
/* 369 */         source.positionChanged();
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void newSource(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/* 391 */     SoundBuffer soundBuffer = null;
/*     */     
/* 393 */     if (!paramBoolean2) {
/*     */ 
/*     */       
/* 396 */       soundBuffer = (SoundBuffer)this.bufferMap.get(paramFilenameURL.getFilename());
/*     */       
/* 398 */       if (soundBuffer == null)
/*     */       {
/* 400 */         if (!loadSound(paramFilenameURL)) {
/*     */           
/* 402 */           errorMessage("Source '" + paramString + "' was not created " + "because an error occurred while loading " + paramFilenameURL.getFilename());
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */       
/* 409 */       soundBuffer = (SoundBuffer)this.bufferMap.get(paramFilenameURL.getFilename());
/*     */       
/* 411 */       if (soundBuffer == null) {
/*     */         
/* 413 */         errorMessage("Source '" + paramString + "' was not created " + "because audio data was not found for " + paramFilenameURL.getFilename());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 420 */     if (!paramBoolean2 && soundBuffer != null) {
/* 421 */       soundBuffer.trimData(1048576);
/*     */     }
/* 423 */     this.sourceMap.put(paramString, new SourceJavaSound(this.listener, paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, soundBuffer, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, false));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void rawDataStream(AudioFormat paramAudioFormat, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/* 446 */     this.sourceMap.put(paramString, new SourceJavaSound(this.listener, paramAudioFormat, paramBoolean, paramString, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void quickPlay(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/* 472 */     SoundBuffer soundBuffer = null;
/*     */     
/* 474 */     if (!paramBoolean2) {
/*     */ 
/*     */       
/* 477 */       soundBuffer = (SoundBuffer)this.bufferMap.get(paramFilenameURL.getFilename());
/*     */       
/* 479 */       if (soundBuffer == null)
/*     */       {
/* 481 */         if (!loadSound(paramFilenameURL)) {
/*     */           
/* 483 */           errorMessage("Source '" + paramString + "' was not created " + "because an error occurred while loading " + paramFilenameURL.getFilename());
/*     */ 
/*     */           
/*     */           return;
/*     */         } 
/*     */       }
/*     */       
/* 490 */       soundBuffer = (SoundBuffer)this.bufferMap.get(paramFilenameURL.getFilename());
/*     */       
/* 492 */       if (soundBuffer == null) {
/*     */         
/* 494 */         errorMessage("Source '" + paramString + "' was not created " + "because audio data was not found for " + paramFilenameURL.getFilename());
/*     */ 
/*     */         
/*     */         return;
/*     */       } 
/*     */     } 
/*     */     
/* 501 */     if (!paramBoolean2 && soundBuffer != null) {
/* 502 */       soundBuffer.trimData(1048576);
/*     */     }
/* 504 */     this.sourceMap.put(paramString, new SourceJavaSound(this.listener, paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, soundBuffer, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, paramBoolean4));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void copySources(HashMap paramHashMap) {
/* 518 */     if (paramHashMap == null)
/*     */       return; 
/* 520 */     Set set = paramHashMap.keySet();
/* 521 */     Iterator<String> iterator = set.iterator();
/*     */ 
/*     */ 
/*     */ 
/*     */     
/* 526 */     if (this.bufferMap == null) {
/*     */       
/* 528 */       this.bufferMap = new HashMap<Object, Object>();
/* 529 */       importantMessage("Buffer Map was null in method 'copySources'");
/*     */     } 
/*     */ 
/*     */     
/* 533 */     this.sourceMap.clear();
/*     */ 
/*     */ 
/*     */     
/* 537 */     while (iterator.hasNext()) {
/*     */       
/* 539 */       String str = iterator.next();
/* 540 */       Source source = (Source)paramHashMap.get(str);
/* 541 */       if (source != null) {
/*     */         
/* 543 */         SoundBuffer soundBuffer = null;
/* 544 */         if (!source.toStream) {
/*     */           
/* 546 */           loadSound(source.filenameURL);
/* 547 */           soundBuffer = (SoundBuffer)this.bufferMap.get(source.filenameURL.getFilename());
/*     */         } 
/* 549 */         if (!source.toStream && soundBuffer != null)
/*     */         {
/* 551 */           soundBuffer.trimData(1048576);
/*     */         }
/* 553 */         if (source.toStream || soundBuffer != null)
/*     */         {
/* 555 */           this.sourceMap.put(str, new SourceJavaSound(this.listener, source, soundBuffer));
/*     */         }
/*     */       } 
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void setListenerVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 571 */     super.setListenerVelocity(paramFloat1, paramFloat2, paramFloat3);
/*     */     
/* 573 */     listenerMoved();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void dopplerChanged() {
/* 582 */     super.dopplerChanged();
/*     */     
/* 584 */     listenerMoved();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static Mixer getMixer() {
/* 593 */     return mixer(false, (Mixer)null);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setMixer(Mixer paramMixer) {
/* 603 */     mixer(true, paramMixer);
/* 604 */     SoundSystemException soundSystemException = SoundSystem.getLastException();
/* 605 */     SoundSystem.setException(null);
/* 606 */     if (soundSystemException != null) {
/* 607 */       throw soundSystemException;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized Mixer mixer(boolean paramBoolean, Mixer paramMixer) {
/* 618 */     if (paramBoolean == true) {
/*     */       
/* 620 */       if (paramMixer == null) {
/* 621 */         return myMixer;
/*     */       }
/* 623 */       LibraryJavaSound$MixerRanking libraryJavaSound$MixerRanking = new LibraryJavaSound$MixerRanking();
/*     */       
/*     */       try {
/* 626 */         libraryJavaSound$MixerRanking.rank(paramMixer.getMixerInfo());
/*     */       }
/* 628 */       catch (LibraryJavaSound$Exception libraryJavaSound$Exception) {
/*     */         
/* 630 */         SoundSystemConfig.getLogger().printStackTrace((Exception)libraryJavaSound$Exception, 1);
/* 631 */         SoundSystem.setException(libraryJavaSound$Exception);
/*     */       } 
/* 633 */       myMixer = paramMixer;
/* 634 */       mixerRanking(true, libraryJavaSound$MixerRanking);
/*     */       
/* 636 */       if (instance != null) {
/*     */         
/* 638 */         ListIterator<ChannelJavaSound> listIterator = instance.normalChannels.listIterator();
/*     */         
/* 640 */         SoundSystem.setException(null);
/* 641 */         while (listIterator.hasNext()) {
/*     */           
/* 643 */           ChannelJavaSound channelJavaSound = listIterator.next();
/* 644 */           channelJavaSound.newMixer(paramMixer);
/*     */         } 
/* 646 */         listIterator = instance.streamingChannels.listIterator();
/* 647 */         while (listIterator.hasNext()) {
/*     */           
/* 649 */           ChannelJavaSound channelJavaSound = listIterator.next();
/* 650 */           channelJavaSound.newMixer(paramMixer);
/*     */         } 
/*     */       } 
/*     */     } 
/* 654 */     return myMixer;
/*     */   }
/*     */ 
/*     */   
/*     */   public static LibraryJavaSound$MixerRanking getMixerRanking() {
/* 659 */     return mixerRanking(false, (LibraryJavaSound$MixerRanking)null);
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   private static synchronized LibraryJavaSound$MixerRanking mixerRanking(boolean paramBoolean, LibraryJavaSound$MixerRanking paramLibraryJavaSound$MixerRanking) {
/* 665 */     if (paramBoolean == true)
/* 666 */       myMixerRanking = paramLibraryJavaSound$MixerRanking; 
/* 667 */     return myMixerRanking;
/*     */   }
/*     */ 
/*     */   
/*     */   public static void setMinSampleRate(int paramInt) {
/* 672 */     minSampleRate(true, paramInt);
/*     */   }
/*     */   
/*     */   private static synchronized int minSampleRate(boolean paramBoolean, int paramInt) {
/* 676 */     if (paramBoolean == true)
/* 677 */       minSampleRate = paramInt; 
/* 678 */     return minSampleRate;
/*     */   }
/*     */   
/*     */   public static void setMaxSampleRate(int paramInt) {
/* 682 */     maxSampleRate(true, paramInt);
/*     */   }
/*     */   
/*     */   private static synchronized int maxSampleRate(boolean paramBoolean, int paramInt) {
/* 686 */     if (paramBoolean == true)
/* 687 */       maxSampleRate = paramInt; 
/* 688 */     return maxSampleRate;
/*     */   }
/*     */   
/*     */   public static void setLineCount(int paramInt) {
/* 692 */     lineCount(true, paramInt);
/*     */   }
/*     */   
/*     */   private static synchronized int lineCount(boolean paramBoolean, int paramInt) {
/* 696 */     if (paramBoolean == true)
/* 697 */       lineCount = paramInt; 
/* 698 */     return lineCount;
/*     */   }
/*     */   
/*     */   public static void useGainControl(boolean paramBoolean) {
/* 702 */     useGainControl(true, paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized boolean useGainControl(boolean paramBoolean1, boolean paramBoolean2) {
/* 707 */     if (paramBoolean1 == true)
/* 708 */       useGainControl = paramBoolean2; 
/* 709 */     return useGainControl;
/*     */   }
/*     */   
/*     */   public static void usePanControl(boolean paramBoolean) {
/* 713 */     usePanControl(true, paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized boolean usePanControl(boolean paramBoolean1, boolean paramBoolean2) {
/* 718 */     if (paramBoolean1 == true)
/* 719 */       usePanControl = paramBoolean2; 
/* 720 */     return usePanControl;
/*     */   }
/*     */   
/*     */   public static void useSampleRateControl(boolean paramBoolean) {
/* 724 */     useSampleRateControl(true, paramBoolean);
/*     */   }
/*     */ 
/*     */   
/*     */   private static synchronized boolean useSampleRateControl(boolean paramBoolean1, boolean paramBoolean2) {
/* 729 */     if (paramBoolean1 == true)
/* 730 */       useSampleRateControl = paramBoolean2; 
/* 731 */     return useSampleRateControl;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getTitle() {
/* 740 */     return "Java Sound";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getDescription() {
/* 749 */     return "The Java Sound API.  For more information, see http://java.sun.com/products/java-media/sound/";
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public String getClassName() {
/* 760 */     return "LibraryJavaSound";
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\libraries\LibraryJavaSound.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */