/*      */ package paulscode.sound;
/*      */ 
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.Set;
/*      */ import javax.sound.sampled.AudioFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class Library
/*      */ {
/*      */   private SoundSystemLogger logger;
/*      */   protected ListenerData listener;
/*   68 */   protected HashMap bufferMap = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected HashMap sourceMap;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private MidiChannel midiChannel;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List streamingChannels;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected List normalChannels;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] streamingChannelSourceNames;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private String[] normalChannelSourceNames;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  103 */   private int nextStreamingChannel = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  108 */   private int nextNormalChannel = 0;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected StreamThread streamThread;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean reverseByteOrder = false;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Library() {
/*  129 */     this.logger = SoundSystemConfig.getLogger();
/*      */ 
/*      */     
/*  132 */     this.bufferMap = new HashMap<Object, Object>();
/*      */ 
/*      */     
/*  135 */     this.sourceMap = new HashMap<Object, Object>();
/*      */     
/*  137 */     this.listener = new ListenerData(0.0F, 0.0F, 0.0F, 0.0F, 0.0F, -1.0F, 0.0F, 1.0F, 0.0F, 0.0F);
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  142 */     this.streamingChannels = new LinkedList();
/*  143 */     this.normalChannels = new LinkedList();
/*  144 */     this.streamingChannelSourceNames = new String[SoundSystemConfig.getNumberStreamingChannels()];
/*      */     
/*  146 */     this.normalChannelSourceNames = new String[SoundSystemConfig.getNumberNormalChannels()];
/*      */ 
/*      */     
/*  149 */     this.streamThread = new StreamThread();
/*  150 */     this.streamThread.start();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cleanup() {
/*  166 */     this.streamThread.kill();
/*  167 */     this.streamThread.interrupt();
/*      */ 
/*      */     
/*  170 */     for (byte b = 0; b < 50; b++) {
/*      */       
/*  172 */       if (!this.streamThread.alive()) {
/*      */         break;
/*      */       }
/*      */       try {
/*  176 */         Thread.sleep(100L);
/*      */       }
/*  178 */       catch (Exception exception) {}
/*      */     } 
/*      */ 
/*      */     
/*  182 */     if (this.streamThread.alive()) {
/*      */       
/*  184 */       errorMessage("Stream thread did not die!");
/*  185 */       message("Ignoring errors... continuing clean-up.");
/*      */     } 
/*      */     
/*  188 */     if (this.midiChannel != null) {
/*      */       
/*  190 */       this.midiChannel.cleanup();
/*  191 */       this.midiChannel = null;
/*      */     } 
/*      */     
/*  194 */     Channel channel = null;
/*  195 */     if (this.streamingChannels != null) {
/*      */       
/*  197 */       while (!this.streamingChannels.isEmpty()) {
/*      */         
/*  199 */         channel = this.streamingChannels.remove(0);
/*  200 */         channel.close();
/*  201 */         channel.cleanup();
/*  202 */         channel = null;
/*      */       } 
/*  204 */       this.streamingChannels.clear();
/*  205 */       this.streamingChannels = null;
/*      */     } 
/*  207 */     if (this.normalChannels != null) {
/*      */       
/*  209 */       while (!this.normalChannels.isEmpty()) {
/*      */         
/*  211 */         channel = this.normalChannels.remove(0);
/*  212 */         channel.close();
/*  213 */         channel.cleanup();
/*  214 */         channel = null;
/*      */       } 
/*  216 */       this.normalChannels.clear();
/*  217 */       this.normalChannels = null;
/*      */     } 
/*      */     
/*  220 */     Set set = this.sourceMap.keySet();
/*  221 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  226 */     while (iterator.hasNext()) {
/*      */       
/*  228 */       String str = iterator.next();
/*  229 */       Source source = (Source)this.sourceMap.get(str);
/*  230 */       if (source != null)
/*  231 */         source.cleanup(); 
/*      */     } 
/*  233 */     this.sourceMap.clear();
/*  234 */     this.sourceMap = null;
/*      */     
/*  236 */     this.listener = null;
/*  237 */     this.streamThread = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void init() {
/*  245 */     Channel channel = null;
/*      */     
/*      */     byte b;
/*  248 */     for (b = 0; b < SoundSystemConfig.getNumberStreamingChannels(); b++) {
/*      */       
/*  250 */       channel = createChannel(1);
/*  251 */       if (channel == null)
/*      */         break; 
/*  253 */       this.streamingChannels.add(channel);
/*      */     } 
/*      */     
/*  256 */     for (b = 0; b < SoundSystemConfig.getNumberNormalChannels(); b++) {
/*      */       
/*  258 */       channel = createChannel(0);
/*  259 */       if (channel == null)
/*      */         break; 
/*  261 */       this.normalChannels.add(channel);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean libraryCompatible() {
/*  271 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected Channel createChannel(int paramInt) {
/*  283 */     return new Channel(paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean loadSound(FilenameURL paramFilenameURL) {
/*  293 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean loadSound(SoundBuffer paramSoundBuffer, String paramString) {
/*  306 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LinkedList getAllLoadedFilenames() {
/*  315 */     LinkedList linkedList = new LinkedList();
/*  316 */     Set set = this.bufferMap.keySet();
/*  317 */     Iterator iterator = set.iterator();
/*      */ 
/*      */     
/*  320 */     while (iterator.hasNext())
/*      */     {
/*  322 */       linkedList.add(iterator.next());
/*      */     }
/*      */     
/*  325 */     return linkedList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public LinkedList getAllSourcenames() {
/*  334 */     LinkedList<String> linkedList = new LinkedList();
/*  335 */     Set set = this.sourceMap.keySet();
/*  336 */     Iterator<String> iterator = set.iterator();
/*      */     
/*  338 */     if (this.midiChannel != null) {
/*  339 */       linkedList.add(this.midiChannel.getSourcename());
/*      */     }
/*      */     
/*  342 */     while (iterator.hasNext())
/*      */     {
/*  344 */       linkedList.add(iterator.next());
/*      */     }
/*      */     
/*  347 */     return linkedList;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unloadSound(String paramString) {
/*  359 */     this.bufferMap.remove(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawDataStream(AudioFormat paramAudioFormat, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  376 */     this.sourceMap.put(paramString, new Source(paramAudioFormat, paramBoolean, paramString, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newSource(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  399 */     this.sourceMap.put(paramString, new Source(paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, null, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, false));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void quickPlay(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/*  424 */     this.sourceMap.put(paramString, new Source(paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, null, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, paramBoolean4));
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTemporary(String paramString, boolean paramBoolean) {
/*  439 */     Source source = (Source)this.sourceMap.get(paramString);
/*  440 */     if (source != null) {
/*  441 */       source.setTemporary(paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPosition(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  453 */     Source source = (Source)this.sourceMap.get(paramString);
/*  454 */     if (source != null) {
/*  455 */       source.setPosition(paramFloat1, paramFloat2, paramFloat3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPriority(String paramString, boolean paramBoolean) {
/*  466 */     Source source = (Source)this.sourceMap.get(paramString);
/*  467 */     if (source != null) {
/*  468 */       source.setPriority(paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLooping(String paramString, boolean paramBoolean) {
/*  479 */     Source source = (Source)this.sourceMap.get(paramString);
/*  480 */     if (source != null) {
/*  481 */       source.setLooping(paramBoolean);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttenuation(String paramString, int paramInt) {
/*  491 */     Source source = (Source)this.sourceMap.get(paramString);
/*  492 */     if (source != null) {
/*  493 */       source.setAttenuation(paramInt);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDistOrRoll(String paramString, float paramFloat) {
/*  503 */     Source source = (Source)this.sourceMap.get(paramString);
/*  504 */     if (source != null) {
/*  505 */       source.setDistOrRoll(paramFloat);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVelocity(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  517 */     Source source = (Source)this.sourceMap.get(paramString);
/*  518 */     if (source != null) {
/*  519 */       source.setVelocity(paramFloat1, paramFloat2, paramFloat3);
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  530 */     this.listener.setVelocity(paramFloat1, paramFloat2, paramFloat3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dopplerChanged() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float millisecondsPlayed(String paramString) {
/*  545 */     if (paramString == null || paramString.equals("")) {
/*      */       
/*  547 */       errorMessage("Sourcename not specified in method 'millisecondsPlayed'");
/*      */       
/*  549 */       return -1.0F;
/*      */     } 
/*      */     
/*  552 */     if (midiSourcename(paramString)) {
/*      */       
/*  554 */       errorMessage("Unable to calculate milliseconds for MIDI source.");
/*  555 */       return -1.0F;
/*      */     } 
/*      */ 
/*      */     
/*  559 */     Source source = (Source)this.sourceMap.get(paramString);
/*  560 */     if (source == null)
/*      */     {
/*  562 */       errorMessage("Source '" + paramString + "' not found in " + "method 'millisecondsPlayed'");
/*      */     }
/*      */     
/*  565 */     return source.millisecondsPlayed();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int feedRawAudioData(String paramString, byte[] paramArrayOfbyte) {
/*  578 */     if (paramString == null || paramString.equals("")) {
/*      */       
/*  580 */       errorMessage("Sourcename not specified in method 'feedRawAudioData'");
/*      */       
/*  582 */       return -1;
/*      */     } 
/*      */     
/*  585 */     if (midiSourcename(paramString)) {
/*      */       
/*  587 */       errorMessage("Raw audio data can not be fed to the MIDI channel.");
/*      */       
/*  589 */       return -1;
/*      */     } 
/*      */ 
/*      */     
/*  593 */     Source source = (Source)this.sourceMap.get(paramString);
/*  594 */     if (source == null)
/*      */     {
/*  596 */       errorMessage("Source '" + paramString + "' not found in " + "method 'feedRawAudioData'");
/*      */     }
/*      */     
/*  599 */     return feedRawAudioData(source, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public int feedRawAudioData(Source paramSource, byte[] paramArrayOfbyte) {
/*  613 */     if (paramSource == null) {
/*      */       
/*  615 */       errorMessage("Source parameter null in method 'feedRawAudioData'");
/*      */       
/*  617 */       return -1;
/*      */     } 
/*  619 */     if (!paramSource.toStream) {
/*      */       
/*  621 */       errorMessage("Only a streaming source may be specified in method 'feedRawAudioData'");
/*      */       
/*  623 */       return -1;
/*      */     } 
/*  625 */     if (!paramSource.rawDataStream) {
/*      */       
/*  627 */       errorMessage("Streaming source already associated with a file or URL in method'feedRawAudioData'");
/*      */       
/*  629 */       return -1;
/*      */     } 
/*      */     
/*  632 */     if (!paramSource.playing() || paramSource.channel == null) {
/*      */       Channel channel;
/*      */       
/*  635 */       if (paramSource.channel != null && paramSource.channel.attachedSource == paramSource) {
/*      */         
/*  637 */         channel = paramSource.channel;
/*      */       } else {
/*  639 */         channel = getNextChannel(paramSource);
/*      */       } 
/*  641 */       int i = paramSource.feedRawAudioData(channel, paramArrayOfbyte);
/*  642 */       channel.attachedSource = paramSource;
/*  643 */       this.streamThread.watch(paramSource);
/*  644 */       this.streamThread.interrupt();
/*  645 */       return i;
/*      */     } 
/*      */     
/*  648 */     return paramSource.feedRawAudioData(paramSource.channel, paramArrayOfbyte);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void play(String paramString) {
/*  657 */     if (paramString == null || paramString.equals("")) {
/*      */       
/*  659 */       errorMessage("Sourcename not specified in method 'play'");
/*      */       
/*      */       return;
/*      */     } 
/*  663 */     if (midiSourcename(paramString)) {
/*      */       
/*  665 */       this.midiChannel.play();
/*      */     }
/*      */     else {
/*      */       
/*  669 */       Source source = (Source)this.sourceMap.get(paramString);
/*  670 */       if (source == null)
/*      */       {
/*  672 */         errorMessage("Source '" + paramString + "' not found in " + "method 'play'");
/*      */       }
/*      */       
/*  675 */       play(source);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void play(Source paramSource) {
/*  685 */     if (paramSource == null) {
/*      */       return;
/*      */     }
/*      */ 
/*      */     
/*  690 */     if (paramSource.rawDataStream) {
/*      */       return;
/*      */     }
/*  693 */     if (!paramSource.active()) {
/*      */       return;
/*      */     }
/*  696 */     if (!paramSource.playing()) {
/*      */       
/*  698 */       Channel channel = getNextChannel(paramSource);
/*      */       
/*  700 */       if (paramSource != null && channel != null) {
/*      */         
/*  702 */         if (paramSource.channel != null && paramSource.channel.attachedSource != paramSource)
/*      */         {
/*  704 */           paramSource.channel = null; } 
/*  705 */         channel.attachedSource = paramSource;
/*  706 */         paramSource.play(channel);
/*  707 */         if (paramSource.toStream) {
/*      */           
/*  709 */           this.streamThread.watch(paramSource);
/*  710 */           this.streamThread.interrupt();
/*      */         } 
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop(String paramString) {
/*  722 */     if (paramString == null || paramString.equals("")) {
/*      */       
/*  724 */       errorMessage("Sourcename not specified in method 'stop'");
/*      */       return;
/*      */     } 
/*  727 */     if (midiSourcename(paramString)) {
/*      */       
/*  729 */       this.midiChannel.stop();
/*      */     }
/*      */     else {
/*      */       
/*  733 */       Source source = (Source)this.sourceMap.get(paramString);
/*  734 */       if (source != null) {
/*  735 */         source.stop();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pause(String paramString) {
/*  745 */     if (paramString == null || paramString.equals("")) {
/*      */       
/*  747 */       errorMessage("Sourcename not specified in method 'stop'");
/*      */       return;
/*      */     } 
/*  750 */     if (midiSourcename(paramString)) {
/*      */       
/*  752 */       this.midiChannel.pause();
/*      */     }
/*      */     else {
/*      */       
/*  756 */       Source source = (Source)this.sourceMap.get(paramString);
/*  757 */       if (source != null) {
/*  758 */         source.pause();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rewind(String paramString) {
/*  768 */     if (midiSourcename(paramString)) {
/*      */       
/*  770 */       this.midiChannel.rewind();
/*      */     }
/*      */     else {
/*      */       
/*  774 */       Source source = (Source)this.sourceMap.get(paramString);
/*  775 */       if (source != null) {
/*  776 */         source.rewind();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush(String paramString) {
/*  786 */     if (midiSourcename(paramString)) {
/*  787 */       errorMessage("You can not flush the MIDI channel");
/*      */     } else {
/*      */       
/*  790 */       Source source = (Source)this.sourceMap.get(paramString);
/*  791 */       if (source != null) {
/*  792 */         source.flush();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cull(String paramString) {
/*  803 */     Source source = (Source)this.sourceMap.get(paramString);
/*  804 */     if (source != null) {
/*  805 */       source.cull();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void activate(String paramString) {
/*  814 */     Source source = (Source)this.sourceMap.get(paramString);
/*  815 */     if (source != null) {
/*      */       
/*  817 */       source.activate();
/*  818 */       if (source.toPlay) {
/*  819 */         play(source);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMasterVolume(float paramFloat) {
/*  829 */     SoundSystemConfig.setMasterGain(paramFloat);
/*  830 */     if (this.midiChannel != null) {
/*  831 */       this.midiChannel.resetGain();
/*      */     }
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVolume(String paramString, float paramFloat) {
/*  841 */     if (midiSourcename(paramString)) {
/*      */       
/*  843 */       this.midiChannel.setVolume(paramFloat);
/*      */     }
/*      */     else {
/*      */       
/*  847 */       Source source = (Source)this.sourceMap.get(paramString);
/*  848 */       if (source != null) {
/*      */         
/*  850 */         float f = paramFloat;
/*  851 */         if (f < 0.0F) {
/*  852 */           f = 0.0F;
/*  853 */         } else if (f > 1.0F) {
/*  854 */           f = 1.0F;
/*      */         } 
/*  856 */         source.sourceVolume = f;
/*  857 */         source.positionChanged();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getVolume(String paramString) {
/*  870 */     if (midiSourcename(paramString))
/*      */     {
/*  872 */       return this.midiChannel.getVolume();
/*      */     }
/*      */ 
/*      */     
/*  876 */     Source source = (Source)this.sourceMap.get(paramString);
/*  877 */     if (source != null) {
/*  878 */       return source.sourceVolume;
/*      */     }
/*  880 */     return 0.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPitch(String paramString, float paramFloat) {
/*  891 */     if (!midiSourcename(paramString)) {
/*      */       
/*  893 */       Source source = (Source)this.sourceMap.get(paramString);
/*  894 */       if (source != null) {
/*      */         
/*  896 */         float f = paramFloat;
/*  897 */         if (f < 0.5F) {
/*  898 */           f = 0.5F;
/*  899 */         } else if (f > 2.0F) {
/*  900 */           f = 2.0F;
/*      */         } 
/*  902 */         source.setPitch(f);
/*  903 */         source.positionChanged();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPitch(String paramString) {
/*  915 */     if (!midiSourcename(paramString)) {
/*      */       
/*  917 */       Source source = (Source)this.sourceMap.get(paramString);
/*  918 */       if (source != null)
/*  919 */         return source.getPitch(); 
/*      */     } 
/*  921 */     return 1.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveListener(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  932 */     setListenerPosition(this.listener.position.x + paramFloat1, this.listener.position.y + paramFloat2, this.listener.position.z + paramFloat3);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/*  945 */     this.listener.setPosition(paramFloat1, paramFloat2, paramFloat3);
/*      */     
/*  947 */     Set set = this.sourceMap.keySet();
/*  948 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  953 */     while (iterator.hasNext()) {
/*      */       
/*  955 */       String str = iterator.next();
/*  956 */       Source source = (Source)this.sourceMap.get(str);
/*  957 */       if (source != null) {
/*  958 */         source.positionChanged();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void turnListener(float paramFloat) {
/*  969 */     setListenerAngle(this.listener.angle + paramFloat);
/*      */     
/*  971 */     Set set = this.sourceMap.keySet();
/*  972 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  977 */     while (iterator.hasNext()) {
/*      */       
/*  979 */       String str = iterator.next();
/*  980 */       Source source = (Source)this.sourceMap.get(str);
/*  981 */       if (source != null) {
/*  982 */         source.positionChanged();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerAngle(float paramFloat) {
/*  993 */     this.listener.setAngle(paramFloat);
/*      */     
/*  995 */     Set set = this.sourceMap.keySet();
/*  996 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1001 */     while (iterator.hasNext()) {
/*      */       
/* 1003 */       String str = iterator.next();
/* 1004 */       Source source = (Source)this.sourceMap.get(str);
/* 1005 */       if (source != null) {
/* 1006 */         source.positionChanged();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerOrientation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 1022 */     this.listener.setOrientation(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */     
/* 1024 */     Set set = this.sourceMap.keySet();
/* 1025 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1030 */     while (iterator.hasNext()) {
/*      */       
/* 1032 */       String str = iterator.next();
/* 1033 */       Source source = (Source)this.sourceMap.get(str);
/* 1034 */       if (source != null) {
/* 1035 */         source.positionChanged();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerData(ListenerData paramListenerData) {
/* 1046 */     this.listener.setData(paramListenerData);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void copySources(HashMap paramHashMap) {
/* 1055 */     if (paramHashMap == null)
/*      */       return; 
/* 1057 */     Set set = paramHashMap.keySet();
/* 1058 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1063 */     this.sourceMap.clear();
/*      */ 
/*      */     
/* 1066 */     while (iterator.hasNext()) {
/*      */       
/* 1068 */       String str = iterator.next();
/* 1069 */       Source source = (Source)paramHashMap.get(str);
/* 1070 */       if (source != null) {
/*      */         
/* 1072 */         loadSound(source.filenameURL);
/* 1073 */         this.sourceMap.put(str, new Source(source, null));
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSource(String paramString) {
/* 1084 */     Source source = (Source)this.sourceMap.get(paramString);
/* 1085 */     if (source != null)
/* 1086 */       source.cleanup(); 
/* 1087 */     this.sourceMap.remove(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeTemporarySources() {
/* 1095 */     Set set = this.sourceMap.keySet();
/* 1096 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1101 */     while (iterator.hasNext()) {
/*      */       
/* 1103 */       String str = iterator.next();
/* 1104 */       Source source = (Source)this.sourceMap.get(str);
/* 1105 */       if (source != null && source.temporary && !source.playing()) {
/*      */ 
/*      */         
/* 1108 */         source.cleanup();
/* 1109 */         iterator.remove();
/*      */       } 
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private Channel getNextChannel(Source paramSource) {
/*      */     int j;
/*      */     List<Channel> list;
/*      */     String[] arrayOfString;
/* 1130 */     if (paramSource == null) {
/* 1131 */       return null;
/*      */     }
/* 1133 */     String str = paramSource.sourcename;
/* 1134 */     if (str == null) {
/* 1135 */       return null;
/*      */     }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1144 */     if (paramSource.toStream) {
/*      */       
/* 1146 */       j = this.nextStreamingChannel;
/* 1147 */       list = this.streamingChannels;
/* 1148 */       arrayOfString = this.streamingChannelSourceNames;
/*      */     }
/*      */     else {
/*      */       
/* 1152 */       j = this.nextNormalChannel;
/* 1153 */       list = this.normalChannels;
/* 1154 */       arrayOfString = this.normalChannelSourceNames;
/*      */     } 
/*      */     
/* 1157 */     int i = list.size();
/*      */     
/*      */     byte b;
/* 1160 */     for (b = 0; b < i; b++) {
/*      */       
/* 1162 */       if (str.equals(arrayOfString[b])) {
/* 1163 */         return list.get(b);
/*      */       }
/*      */     } 
/* 1166 */     int k = j;
/*      */ 
/*      */     
/* 1169 */     for (b = 0; b < i; b++) {
/*      */       Source source;
/* 1171 */       String str1 = arrayOfString[k];
/* 1172 */       if (str1 == null) {
/* 1173 */         source = null;
/*      */       } else {
/* 1175 */         source = (Source)this.sourceMap.get(str1);
/*      */       } 
/* 1177 */       if (source == null || !source.playing()) {
/*      */         
/* 1179 */         if (paramSource.toStream) {
/*      */           
/* 1181 */           this.nextStreamingChannel = k + 1;
/* 1182 */           if (this.nextStreamingChannel >= i) {
/* 1183 */             this.nextStreamingChannel = 0;
/*      */           }
/*      */         } else {
/*      */           
/* 1187 */           this.nextNormalChannel = k + 1;
/* 1188 */           if (this.nextNormalChannel >= i)
/* 1189 */             this.nextNormalChannel = 0; 
/*      */         } 
/* 1191 */         arrayOfString[k] = str;
/* 1192 */         return list.get(k);
/*      */       } 
/* 1194 */       k++;
/* 1195 */       if (k >= i) {
/* 1196 */         k = 0;
/*      */       }
/*      */     } 
/* 1199 */     k = j;
/*      */     
/* 1201 */     for (b = 0; b < i; b++) {
/*      */       Source source;
/* 1203 */       String str1 = arrayOfString[k];
/* 1204 */       if (str1 == null) {
/* 1205 */         source = null;
/*      */       } else {
/* 1207 */         source = (Source)this.sourceMap.get(str1);
/*      */       } 
/* 1209 */       if (source == null || !source.playing() || !source.priority) {
/*      */         
/* 1211 */         if (paramSource.toStream) {
/*      */           
/* 1213 */           this.nextStreamingChannel = k + 1;
/* 1214 */           if (this.nextStreamingChannel >= i) {
/* 1215 */             this.nextStreamingChannel = 0;
/*      */           }
/*      */         } else {
/*      */           
/* 1219 */           this.nextNormalChannel = k + 1;
/* 1220 */           if (this.nextNormalChannel >= i)
/* 1221 */             this.nextNormalChannel = 0; 
/*      */         } 
/* 1223 */         arrayOfString[k] = str;
/* 1224 */         return list.get(k);
/*      */       } 
/* 1226 */       k++;
/* 1227 */       if (k >= i) {
/* 1228 */         k = 0;
/*      */       }
/*      */     } 
/* 1231 */     return null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void replaySources() {
/* 1241 */     Set set = this.sourceMap.keySet();
/* 1242 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1247 */     while (iterator.hasNext()) {
/*      */       
/* 1249 */       String str = iterator.next();
/* 1250 */       Source source = (Source)this.sourceMap.get(str);
/* 1251 */       if (source != null)
/*      */       {
/* 1253 */         if (source.toPlay && !source.playing()) {
/*      */           
/* 1255 */           play(str);
/* 1256 */           source.toPlay = false;
/*      */         } 
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void queueSound(String paramString, FilenameURL paramFilenameURL) {
/* 1271 */     if (midiSourcename(paramString)) {
/*      */       
/* 1273 */       this.midiChannel.queueSound(paramFilenameURL);
/*      */     }
/*      */     else {
/*      */       
/* 1277 */       Source source = (Source)this.sourceMap.get(paramString);
/* 1278 */       if (source != null) {
/* 1279 */         source.queueSound(paramFilenameURL);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dequeueSound(String paramString1, String paramString2) {
/* 1292 */     if (midiSourcename(paramString1)) {
/*      */       
/* 1294 */       this.midiChannel.dequeueSound(paramString2);
/*      */     }
/*      */     else {
/*      */       
/* 1298 */       Source source = (Source)this.sourceMap.get(paramString1);
/* 1299 */       if (source != null) {
/* 1300 */         source.dequeueSound(paramString2);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fadeOut(String paramString, FilenameURL paramFilenameURL, long paramLong) {
/* 1320 */     if (midiSourcename(paramString)) {
/*      */       
/* 1322 */       this.midiChannel.fadeOut(paramFilenameURL, paramLong);
/*      */     }
/*      */     else {
/*      */       
/* 1326 */       Source source = (Source)this.sourceMap.get(paramString);
/* 1327 */       if (source != null) {
/* 1328 */         source.fadeOut(paramFilenameURL, paramLong);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fadeOutIn(String paramString, FilenameURL paramFilenameURL, long paramLong1, long paramLong2) {
/* 1349 */     if (midiSourcename(paramString)) {
/*      */       
/* 1351 */       this.midiChannel.fadeOutIn(paramFilenameURL, paramLong1, paramLong2);
/*      */     }
/*      */     else {
/*      */       
/* 1355 */       Source source = (Source)this.sourceMap.get(paramString);
/* 1356 */       if (source != null) {
/* 1357 */         source.fadeOutIn(paramFilenameURL, paramLong1, paramLong2);
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkFadeVolumes() {
/* 1374 */     if (this.midiChannel != null) {
/* 1375 */       this.midiChannel.resetGain();
/*      */     }
/*      */     
/* 1378 */     for (byte b = 0; b < this.streamingChannels.size(); b++) {
/*      */       
/* 1380 */       Channel channel = this.streamingChannels.get(b);
/* 1381 */       if (channel != null) {
/*      */         
/* 1383 */         Source source = channel.attachedSource;
/* 1384 */         if (source != null)
/* 1385 */           source.checkFadeOut(); 
/*      */       } 
/*      */     } 
/* 1388 */     Object object1 = null;
/* 1389 */     Object object2 = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadMidi(boolean paramBoolean, String paramString, FilenameURL paramFilenameURL) {
/* 1401 */     if (paramFilenameURL == null) {
/*      */       
/* 1403 */       errorMessage("Filename/URL not specified in method 'loadMidi'.");
/*      */       
/*      */       return;
/*      */     } 
/* 1407 */     if (!paramFilenameURL.getFilename().matches(SoundSystemConfig.EXTENSION_MIDI)) {
/*      */ 
/*      */       
/* 1410 */       errorMessage("Filename/identifier doesn't end in '.mid' or'.midi' in method loadMidi.");
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/* 1415 */     if (this.midiChannel == null) {
/*      */       
/* 1417 */       this.midiChannel = new MidiChannel(paramBoolean, paramString, paramFilenameURL);
/*      */     }
/*      */     else {
/*      */       
/* 1421 */       this.midiChannel.switchSource(paramBoolean, paramString, paramFilenameURL);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unloadMidi() {
/* 1430 */     if (this.midiChannel != null)
/* 1431 */       this.midiChannel.cleanup(); 
/* 1432 */     this.midiChannel = null;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean midiSourcename(String paramString) {
/* 1442 */     if (this.midiChannel == null || paramString == null) {
/* 1443 */       return false;
/*      */     }
/* 1445 */     if (this.midiChannel.getSourcename() == null || paramString.equals("")) {
/* 1446 */       return false;
/*      */     }
/* 1448 */     if (paramString.equals(this.midiChannel.getSourcename())) {
/* 1449 */       return true;
/*      */     }
/* 1451 */     return false;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public Source getSource(String paramString) {
/* 1462 */     return (Source)this.sourceMap.get(paramString);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public MidiChannel getMidiChannel() {
/* 1472 */     return this.midiChannel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMidiChannel(MidiChannel paramMidiChannel) {
/* 1482 */     if (this.midiChannel != null && this.midiChannel != paramMidiChannel) {
/* 1483 */       this.midiChannel.cleanup();
/*      */     }
/* 1485 */     this.midiChannel = paramMidiChannel;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void listenerMoved() {
/* 1493 */     Set set = this.sourceMap.keySet();
/* 1494 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 1499 */     while (iterator.hasNext()) {
/*      */       
/* 1501 */       String str = iterator.next();
/* 1502 */       Source source = (Source)this.sourceMap.get(str);
/* 1503 */       if (source != null)
/*      */       {
/* 1505 */         source.listenerMoved();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public HashMap getSources() {
/* 1516 */     return this.sourceMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ListenerData getListenerData() {
/* 1525 */     return this.listener;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean reverseByteOrder() {
/* 1535 */     return this.reverseByteOrder;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getTitle() {
/* 1543 */     return "No Sound";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static String getDescription() {
/* 1552 */     return "Silent Mode";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String getClassName() {
/* 1561 */     return "Library";
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void message(String paramString) {
/* 1570 */     this.logger.message(paramString, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void importantMessage(String paramString) {
/* 1579 */     this.logger.importantMessage(paramString, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean errorCheck(boolean paramBoolean, String paramString) {
/* 1590 */     return this.logger.errorCheck(paramBoolean, getClassName(), paramString, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void errorMessage(String paramString) {
/* 1599 */     this.logger.errorMessage(getClassName(), paramString, 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void printStackTrace(Exception paramException) {
/* 1608 */     this.logger.printStackTrace(paramException, 1);
/*      */   }
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\Library.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */