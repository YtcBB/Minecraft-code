package paulscode.sound;

public interface IStreamListener {
  void endOfStream(String paramString, int paramInt);
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\IStreamListener.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */