/*     */ package paulscode.sound;
/*     */ 
/*     */ import java.lang.reflect.InvocationTargetException;
/*     */ import java.lang.reflect.Method;
/*     */ import java.util.LinkedList;
/*     */ import java.util.ListIterator;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class SoundSystemConfig
/*     */ {
/*  55 */   public static final Object THREAD_SYNC = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TYPE_NORMAL = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int TYPE_STREAMING = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int ATTENUATION_NONE = 0;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int ATTENUATION_ROLLOFF = 1;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static final int ATTENUATION_LINEAR = 2;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  94 */   public static String EXTENSION_MIDI = ".*[mM][iI][dD][iI]?$";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  99 */   public static String PREFIX_URL = "^[hH][tT][tT][pP]://.*";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 112 */   private static SoundSystemLogger logger = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static LinkedList libraries;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 122 */   private static LinkedList codecs = null;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 127 */   private static LinkedList streamListeners = null;
/*     */ 
/*     */ 
/*     */   
/* 131 */   private static final Object streamListenersLock = new Object();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 138 */   private static int numberNormalChannels = 28;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 144 */   private static int numberStreamingChannels = 4;
/*     */ 
/*     */ 
/*     */   
/* 148 */   private static float masterGain = 1.0F;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 153 */   private static int defaultAttenuationModel = 1;
/*     */ 
/*     */ 
/*     */   
/* 157 */   private static float defaultRolloffFactor = 0.03F;
/*     */ 
/*     */ 
/*     */   
/* 161 */   private static float dopplerFactor = 0.0F;
/*     */ 
/*     */ 
/*     */   
/* 165 */   private static float dopplerVelocity = 1.0F;
/*     */ 
/*     */ 
/*     */   
/* 169 */   private static float defaultFadeDistance = 1000.0F;
/*     */ 
/*     */ 
/*     */   
/* 173 */   private static String soundFilesPackage = "Sounds/";
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 178 */   private static int streamingBufferSize = 131072;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 183 */   private static int numberStreamingBuffers = 3;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean streamQueueFormatsMatch = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 196 */   private static int maxFileSize = 268435456;
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 201 */   private static int fileChunkSize = 1048576;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static boolean midiCodec = false;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 215 */   private static String overrideMIDISynthesizer = "";
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addLibrary(Class<?> paramClass) {
/* 231 */     if (paramClass == null) {
/* 232 */       throw new SoundSystemException("Parameter null in method 'addLibrary'", 2);
/*     */     }
/*     */     
/* 235 */     if (!Library.class.isAssignableFrom(paramClass)) {
/* 236 */       throw new SoundSystemException("The specified class does not extend class 'Library' in method 'addLibrary'");
/*     */     }
/*     */     
/* 239 */     if (libraries == null) {
/* 240 */       libraries = new LinkedList();
/*     */     }
/* 242 */     if (!libraries.contains(paramClass)) {
/* 243 */       libraries.add(paramClass);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeLibrary(Class paramClass) {
/* 253 */     if (libraries == null || paramClass == null) {
/*     */       return;
/*     */     }
/* 256 */     libraries.remove(paramClass);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static LinkedList getLibraries() {
/* 265 */     return libraries;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean libraryCompatible(Class<?> paramClass) {
/* 275 */     if (paramClass == null) {
/*     */       
/* 277 */       errorMessage("Parameter 'libraryClass' null in method'librayCompatible'");
/*     */       
/* 279 */       return false;
/*     */     } 
/* 281 */     if (!Library.class.isAssignableFrom(paramClass)) {
/*     */       
/* 283 */       errorMessage("The specified class does not extend class 'Library' in method 'libraryCompatible'");
/*     */       
/* 285 */       return false;
/*     */     } 
/*     */     
/* 288 */     Object object = runMethod(paramClass, "libraryCompatible", new Class[0], new Object[0]);
/*     */ 
/*     */     
/* 291 */     if (object == null) {
/*     */       
/* 293 */       errorMessage("Method 'Library.libraryCompatible' returned 'null' in method 'libraryCompatible'");
/*     */       
/* 295 */       return false;
/*     */     } 
/*     */     
/* 298 */     return ((Boolean)object).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLibraryTitle(Class<?> paramClass) {
/* 308 */     if (paramClass == null) {
/*     */       
/* 310 */       errorMessage("Parameter 'libraryClass' null in method'getLibrayTitle'");
/*     */       
/* 312 */       return null;
/*     */     } 
/* 314 */     if (!Library.class.isAssignableFrom(paramClass)) {
/*     */       
/* 316 */       errorMessage("The specified class does not extend class 'Library' in method 'getLibraryTitle'");
/*     */       
/* 318 */       return null;
/*     */     } 
/*     */     
/* 321 */     Object object = runMethod(paramClass, "getTitle", new Class[0], new Object[0]);
/*     */     
/* 323 */     if (object == null) {
/*     */       
/* 325 */       errorMessage("Method 'Library.getTitle' returned 'null' in method 'getLibraryTitle'");
/*     */       
/* 327 */       return null;
/*     */     } 
/*     */     
/* 330 */     return (String)object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static String getLibraryDescription(Class<?> paramClass) {
/* 340 */     if (paramClass == null) {
/*     */       
/* 342 */       errorMessage("Parameter 'libraryClass' null in method'getLibrayDescription'");
/*     */       
/* 344 */       return null;
/*     */     } 
/* 346 */     if (!Library.class.isAssignableFrom(paramClass)) {
/*     */       
/* 348 */       errorMessage("The specified class does not extend class 'Library' in method 'getLibraryDescription'");
/*     */       
/* 350 */       return null;
/*     */     } 
/*     */     
/* 353 */     Object object = runMethod(paramClass, "getDescription", new Class[0], new Object[0]);
/*     */     
/* 355 */     if (object == null) {
/*     */       
/* 357 */       errorMessage("Method 'Library.getDescription' returned 'null' in method 'getLibraryDescription'");
/*     */       
/* 359 */       return null;
/*     */     } 
/*     */     
/* 362 */     return (String)object;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean reverseByteOrder(Class<?> paramClass) {
/* 372 */     if (paramClass == null) {
/*     */       
/* 374 */       errorMessage("Parameter 'libraryClass' null in method'reverseByteOrder'");
/*     */       
/* 376 */       return false;
/*     */     } 
/* 378 */     if (!Library.class.isAssignableFrom(paramClass)) {
/*     */       
/* 380 */       errorMessage("The specified class does not extend class 'Library' in method 'reverseByteOrder'");
/*     */       
/* 382 */       return false;
/*     */     } 
/*     */     
/* 385 */     Object object = runMethod(paramClass, "reversByteOrder", new Class[0], new Object[0]);
/*     */     
/* 387 */     if (object == null) {
/*     */       
/* 389 */       errorMessage("Method 'Library.reverseByteOrder' returned 'null' in method 'getLibraryDescription'");
/*     */       
/* 391 */       return false;
/*     */     } 
/*     */     
/* 394 */     return ((Boolean)object).booleanValue();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void setLogger(SoundSystemLogger paramSoundSystemLogger) {
/* 420 */     logger = paramSoundSystemLogger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static SoundSystemLogger getLogger() {
/* 428 */     return logger;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setNumberNormalChannels(int paramInt) {
/* 445 */     numberNormalChannels = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized int getNumberNormalChannels() {
/* 455 */     return numberNormalChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setNumberStreamingChannels(int paramInt) {
/* 470 */     numberStreamingChannels = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized int getNumberStreamingChannels() {
/* 479 */     return numberStreamingChannels;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setMasterGain(float paramFloat) {
/* 488 */     masterGain = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized float getMasterGain() {
/* 497 */     return masterGain;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultAttenuation(int paramInt) {
/* 507 */     defaultAttenuationModel = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized int getDefaultAttenuation() {
/* 515 */     return defaultAttenuationModel;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultRolloff(float paramFloat) {
/* 523 */     defaultRolloffFactor = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized float getDopplerFactor() {
/* 531 */     return dopplerFactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDopplerFactor(float paramFloat) {
/* 542 */     dopplerFactor = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized float getDopplerVelocity() {
/* 550 */     return dopplerVelocity;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDopplerVelocity(float paramFloat) {
/* 561 */     dopplerVelocity = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized float getDefaultRolloff() {
/* 569 */     return defaultRolloffFactor;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setDefaultFadeDistance(float paramFloat) {
/* 577 */     defaultFadeDistance = paramFloat;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized float getDefaultFadeDistance() {
/* 585 */     return defaultFadeDistance;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setSoundFilesPackage(String paramString) {
/* 593 */     soundFilesPackage = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String getSoundFilesPackage() {
/* 601 */     return soundFilesPackage;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setStreamingBufferSize(int paramInt) {
/* 609 */     streamingBufferSize = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized int getStreamingBufferSize() {
/* 617 */     return streamingBufferSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setNumberStreamingBuffers(int paramInt) {
/* 627 */     numberStreamingBuffers = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized int getNumberStreamingBuffers() {
/* 635 */     return numberStreamingBuffers;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setStreamQueueFormatsMatch(boolean paramBoolean) {
/* 647 */     streamQueueFormatsMatch = paramBoolean;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized boolean getStreamQueueFormatsMatch() {
/* 659 */     return streamQueueFormatsMatch;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setMaxFileSize(int paramInt) {
/* 670 */     maxFileSize = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized int getMaxFileSize() {
/* 678 */     return maxFileSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setFileChunkSize(int paramInt) {
/* 687 */     fileChunkSize = paramInt;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized int getFileChunkSize() {
/* 696 */     return fileChunkSize;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized String getOverrideMIDISynthesizer() {
/* 705 */     return overrideMIDISynthesizer;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setOverrideMIDISynthesizer(String paramString) {
/* 715 */     overrideMIDISynthesizer = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized void setCodec(String paramString, Class<?> paramClass) {
/* 727 */     if (paramString == null) {
/* 728 */       throw new SoundSystemException("Parameter 'extension' null in method 'setCodec'.", 2);
/*     */     }
/*     */     
/* 731 */     if (paramClass == null) {
/* 732 */       throw new SoundSystemException("Parameter 'iCodecClass' null in method 'setCodec'.", 2);
/*     */     }
/*     */     
/* 735 */     if (!ICodec.class.isAssignableFrom(paramClass)) {
/* 736 */       throw new SoundSystemException("The specified class does not implement interface 'ICodec' in method 'setCodec'", 3);
/*     */     }
/*     */ 
/*     */     
/* 740 */     if (codecs == null) {
/* 741 */       codecs = new LinkedList();
/*     */     }
/* 743 */     ListIterator<SoundSystemConfig$Codec> listIterator = codecs.listIterator();
/*     */ 
/*     */     
/* 746 */     while (listIterator.hasNext()) {
/*     */       
/* 748 */       SoundSystemConfig$Codec soundSystemConfig$Codec = listIterator.next();
/* 749 */       if (paramString.matches(soundSystemConfig$Codec.extensionRegX))
/* 750 */         listIterator.remove(); 
/*     */     } 
/* 752 */     codecs.add(new SoundSystemConfig$Codec(paramString, paramClass));
/*     */ 
/*     */ 
/*     */     
/* 756 */     if (paramString.matches(EXTENSION_MIDI)) {
/* 757 */       midiCodec = true;
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static synchronized ICodec getCodec(String paramString) {
/* 767 */     if (codecs == null) {
/* 768 */       return null;
/*     */     }
/* 770 */     ListIterator<SoundSystemConfig$Codec> listIterator = codecs.listIterator();
/*     */ 
/*     */     
/* 773 */     while (listIterator.hasNext()) {
/*     */       
/* 775 */       SoundSystemConfig$Codec soundSystemConfig$Codec = listIterator.next();
/* 776 */       if (paramString.matches(soundSystemConfig$Codec.extensionRegX)) {
/* 777 */         return soundSystemConfig$Codec.getInstance();
/*     */       }
/*     */     } 
/* 780 */     return null;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static boolean midiCodec() {
/* 790 */     return midiCodec;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void addStreamListener(IStreamListener paramIStreamListener) {
/* 800 */     synchronized (streamListenersLock) {
/*     */       
/* 802 */       if (streamListeners == null) {
/* 803 */         streamListeners = new LinkedList();
/*     */       }
/* 805 */       if (!streamListeners.contains(paramIStreamListener)) {
/* 806 */         streamListeners.add(paramIStreamListener);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void removeStreamListener(IStreamListener paramIStreamListener) {
/* 817 */     synchronized (streamListenersLock) {
/*     */       
/* 819 */       if (streamListeners == null) {
/* 820 */         streamListeners = new LinkedList();
/*     */       }
/* 822 */       if (streamListeners.contains(paramIStreamListener)) {
/* 823 */         streamListeners.remove(paramIStreamListener);
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public static void notifyEOS(String paramString, int paramInt) {
/* 835 */     synchronized (streamListenersLock) {
/*     */       
/* 837 */       if (streamListeners == null)
/*     */         return; 
/*     */     } 
/* 840 */     String str = paramString;
/* 841 */     int i = paramInt;
/*     */     
/* 843 */     (new SoundSystemConfig$1(str, i)).start();
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static void errorMessage(String paramString) {
/* 878 */     if (logger != null) {
/* 879 */       logger.errorMessage("SoundSystemConfig", paramString, 0);
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   private static Object runMethod(Class paramClass, String paramString, Class[] paramArrayOfClass, Object[] paramArrayOfObject) {
/* 897 */     Method method = null;
/*     */     
/*     */     try {
/* 900 */       method = paramClass.getMethod(paramString, paramArrayOfClass);
/*     */     }
/* 902 */     catch (NoSuchMethodException noSuchMethodException) {
/*     */       
/* 904 */       errorMessage("NoSuchMethodException thrown when attempting to call method '" + paramString + "' in " + "method 'runMethod'");
/*     */ 
/*     */       
/* 907 */       return null;
/*     */     }
/* 909 */     catch (SecurityException securityException) {
/*     */       
/* 911 */       errorMessage("Access denied when attempting to call method '" + paramString + "' in method 'runMethod'");
/*     */       
/* 913 */       return null;
/*     */     }
/* 915 */     catch (NullPointerException nullPointerException) {
/*     */       
/* 917 */       errorMessage("NullPointerException thrown when attempting to call method '" + paramString + "' in " + "method 'runMethod'");
/*     */ 
/*     */       
/* 920 */       return null;
/*     */     } 
/* 922 */     if (method == null) {
/*     */       
/* 924 */       errorMessage("Method '" + paramString + "' not found for the class " + "specified in method 'runMethod'");
/*     */       
/* 926 */       return null;
/*     */     } 
/*     */     
/* 929 */     Object object = null;
/*     */     
/*     */     try {
/* 932 */       object = method.invoke(null, paramArrayOfObject);
/*     */     }
/* 934 */     catch (IllegalAccessException illegalAccessException) {
/*     */       
/* 936 */       errorMessage("IllegalAccessException thrown when attempting to invoke method '" + paramString + "' in " + "method 'runMethod'");
/*     */ 
/*     */       
/* 939 */       return null;
/*     */     }
/* 941 */     catch (IllegalArgumentException illegalArgumentException) {
/*     */       
/* 943 */       errorMessage("IllegalArgumentException thrown when attempting to invoke method '" + paramString + "' in " + "method 'runMethod'");
/*     */ 
/*     */       
/* 946 */       return null;
/*     */     }
/* 948 */     catch (InvocationTargetException invocationTargetException) {
/*     */       
/* 950 */       errorMessage("InvocationTargetException thrown while attempting to invoke method 'Library.getTitle' in method 'getLibraryTitle'");
/*     */ 
/*     */       
/* 953 */       return null;
/*     */     }
/* 955 */     catch (NullPointerException nullPointerException) {
/*     */       
/* 957 */       errorMessage("NullPointerException thrown when attempting to invoke method '" + paramString + "' in " + "method 'runMethod'");
/*     */ 
/*     */       
/* 960 */       return null;
/*     */     }
/* 962 */     catch (ExceptionInInitializerError exceptionInInitializerError) {
/*     */       
/* 964 */       errorMessage("ExceptionInInitializerError thrown when attempting to invoke method '" + paramString + "' in " + "method 'runMethod'");
/*     */ 
/*     */       
/* 967 */       return null;
/*     */     } 
/*     */     
/* 970 */     return object;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\SoundSystemConfig.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */