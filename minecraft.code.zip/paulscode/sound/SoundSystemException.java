/*    */ package paulscode.sound;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class SoundSystemException
/*    */   extends Exception
/*    */ {
/*    */   public static final int ERROR_NONE = 0;
/*    */   public static final int UNKNOWN_ERROR = 1;
/*    */   public static final int NULL_PARAMETER = 2;
/*    */   public static final int CLASS_TYPE_MISMATCH = 3;
/*    */   public static final int LIBRARY_NULL = 4;
/*    */   public static final int LIBRARY_TYPE = 5;
/* 69 */   private int myType = 1;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SoundSystemException(String paramString) {
/* 76 */     super(paramString);
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public SoundSystemException(String paramString, int paramInt) {
/* 86 */     super(paramString);
/* 87 */     this.myType = paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public int getType() {
/* 92 */     return this.myType;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\SoundSystemException.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */