/*      */ package paulscode.sound;
/*      */ 
/*      */ import java.net.URL;
/*      */ import java.util.HashMap;
/*      */ import java.util.Iterator;
/*      */ import java.util.LinkedList;
/*      */ import java.util.List;
/*      */ import java.util.ListIterator;
/*      */ import java.util.Random;
/*      */ import java.util.Set;
/*      */ import javax.sound.sampled.AudioFormat;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ public class SoundSystem
/*      */ {
/*      */   private static final boolean GET = false;
/*      */   private static final boolean SET = true;
/*      */   private static final boolean XXX = false;
/*      */   protected SoundSystemLogger logger;
/*      */   protected Library soundLibrary;
/*      */   protected List commandQueue;
/*      */   private List sourcePlayList;
/*      */   protected CommandThread commandThread;
/*      */   public Random randomNumberGenerator;
/*  115 */   protected String className = "SoundSystem";
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  120 */   private static Class currentLibrary = null;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean initialized = false;
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*  130 */   private static SoundSystemException lastException = null;
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SoundSystem() {
/*  142 */     this.logger = SoundSystemConfig.getLogger();
/*      */     
/*  144 */     if (this.logger == null) {
/*      */       
/*  146 */       this.logger = new SoundSystemLogger();
/*  147 */       SoundSystemConfig.setLogger(this.logger);
/*      */     } 
/*      */     
/*  150 */     linkDefaultLibrariesAndCodecs();
/*      */     
/*  152 */     LinkedList linkedList = SoundSystemConfig.getLibraries();
/*      */     
/*  154 */     if (linkedList != null) {
/*      */       
/*  156 */       ListIterator<Class<?>> listIterator = linkedList.listIterator();
/*      */       
/*  158 */       while (listIterator.hasNext()) {
/*      */         
/*  160 */         Class clazz = listIterator.next();
/*      */         
/*      */         try {
/*  163 */           init(clazz);
/*      */           
/*      */           return;
/*  166 */         } catch (SoundSystemException soundSystemException) {
/*      */           
/*  168 */           this.logger.printExceptionMessage(soundSystemException, 1);
/*      */         } 
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/*  174 */       init(Library.class);
/*      */       
/*      */       return;
/*  177 */     } catch (SoundSystemException soundSystemException) {
/*      */       
/*  179 */       this.logger.printExceptionMessage(soundSystemException, 1);
/*      */       return;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public SoundSystem(Class paramClass) {
/*  192 */     this.logger = SoundSystemConfig.getLogger();
/*      */     
/*  194 */     if (this.logger == null) {
/*      */       
/*  196 */       this.logger = new SoundSystemLogger();
/*  197 */       SoundSystemConfig.setLogger(this.logger);
/*      */     } 
/*  199 */     linkDefaultLibrariesAndCodecs();
/*      */     
/*  201 */     init(paramClass);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void linkDefaultLibrariesAndCodecs() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void init(Class paramClass) {
/*  225 */     message("", 0);
/*  226 */     message("Starting up " + this.className + "...", 0);
/*      */ 
/*      */     
/*  229 */     this.randomNumberGenerator = new Random();
/*      */     
/*  231 */     this.commandQueue = new LinkedList();
/*      */     
/*  233 */     this.sourcePlayList = new LinkedList();
/*      */ 
/*      */     
/*  236 */     this.commandThread = new CommandThread(this);
/*  237 */     this.commandThread.start();
/*      */     
/*  239 */     snooze(200L);
/*      */     
/*  241 */     newLibrary(paramClass);
/*  242 */     message("", 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cleanup() {
/*  251 */     boolean bool = false;
/*  252 */     message("", 0);
/*  253 */     message(this.className + " shutting down...", 0);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  258 */       this.commandThread.kill();
/*  259 */       this.commandThread.interrupt();
/*      */     }
/*  261 */     catch (Exception exception) {
/*      */       
/*  263 */       bool = true;
/*      */     } 
/*      */     
/*  266 */     if (!bool)
/*      */     {
/*      */       
/*  269 */       for (byte b = 0; b < 50; b++) {
/*      */         
/*  271 */         if (!this.commandThread.alive())
/*      */           break; 
/*  273 */         snooze(100L);
/*      */       } 
/*      */     }
/*      */ 
/*      */     
/*  278 */     if (bool || this.commandThread.alive()) {
/*      */       
/*  280 */       errorMessage("Command thread did not die!", 0);
/*  281 */       message("Ignoring errors... continuing clean-up.", 0);
/*      */     } 
/*      */     
/*  284 */     initialized(true, false);
/*  285 */     currentLibrary(true, null);
/*      */ 
/*      */     
/*      */     try {
/*  289 */       if (this.soundLibrary != null) {
/*  290 */         this.soundLibrary.cleanup();
/*      */       }
/*  292 */     } catch (Exception exception) {
/*      */       
/*  294 */       errorMessage("Problem during Library.cleanup()!", 0);
/*  295 */       message("Ignoring errors... continuing clean-up.", 0);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  301 */       if (this.commandQueue != null) {
/*  302 */         this.commandQueue.clear();
/*      */       }
/*  304 */     } catch (Exception exception) {
/*      */       
/*  306 */       errorMessage("Unable to clear the command queue!", 0);
/*  307 */       message("Ignoring errors... continuing clean-up.", 0);
/*      */     } 
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/*  313 */       if (this.sourcePlayList != null) {
/*  314 */         this.sourcePlayList.clear();
/*      */       }
/*  316 */     } catch (Exception exception) {
/*      */       
/*  318 */       errorMessage("Unable to clear the source management list!", 0);
/*  319 */       message("Ignoring errors... continuing clean-up.", 0);
/*      */     } 
/*      */ 
/*      */     
/*  323 */     this.randomNumberGenerator = null;
/*  324 */     this.soundLibrary = null;
/*  325 */     this.commandQueue = null;
/*  326 */     this.sourcePlayList = null;
/*  327 */     this.commandThread = null;
/*      */     
/*  329 */     importantMessage("Author: Paul Lamb, www.paulscode.com", 1);
/*  330 */     message("", 0);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void interruptCommandThread() {
/*  342 */     if (this.commandThread == null) {
/*      */       
/*  344 */       errorMessage("Command Thread null in method 'interruptCommandThread'", 0);
/*      */       
/*      */       return;
/*      */     } 
/*      */     
/*  349 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadSound(String paramString) {
/*  363 */     CommandQueue(new CommandObject(2, new FilenameURL(paramString)));
/*      */ 
/*      */     
/*  366 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadSound(URL paramURL, String paramString) {
/*  380 */     CommandQueue(new CommandObject(2, new FilenameURL(paramURL, paramString)));
/*      */ 
/*      */     
/*  383 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void loadSound(byte[] paramArrayOfbyte, AudioFormat paramAudioFormat, String paramString) {
/*  397 */     CommandQueue(new CommandObject(3, paramString, new SoundBuffer(paramArrayOfbyte, paramAudioFormat)));
/*      */ 
/*      */ 
/*      */     
/*  401 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void unloadSound(String paramString) {
/*  417 */     CommandQueue(new CommandObject(4, paramString));
/*      */     
/*  419 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void queueSound(String paramString1, String paramString2) {
/*  437 */     CommandQueue(new CommandObject(5, paramString1, new FilenameURL(paramString2)));
/*      */ 
/*      */     
/*  440 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void queueSound(String paramString1, URL paramURL, String paramString2) {
/*  457 */     CommandQueue(new CommandObject(5, paramString1, new FilenameURL(paramURL, paramString2)));
/*      */ 
/*      */     
/*  460 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void dequeueSound(String paramString1, String paramString2) {
/*  473 */     CommandQueue(new CommandObject(6, paramString1, paramString2));
/*      */ 
/*      */     
/*  476 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fadeOut(String paramString1, String paramString2, long paramLong) {
/*  499 */     FilenameURL filenameURL = null;
/*  500 */     if (paramString2 != null) {
/*  501 */       filenameURL = new FilenameURL(paramString2);
/*      */     }
/*  503 */     CommandQueue(new CommandObject(7, paramString1, filenameURL, paramLong));
/*      */ 
/*      */     
/*  506 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fadeOut(String paramString1, URL paramURL, String paramString2, long paramLong) {
/*  529 */     FilenameURL filenameURL = null;
/*  530 */     if (paramURL != null && paramString2 != null) {
/*  531 */       filenameURL = new FilenameURL(paramURL, paramString2);
/*      */     }
/*  533 */     CommandQueue(new CommandObject(7, paramString1, filenameURL, paramLong));
/*      */ 
/*      */     
/*  536 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fadeOutIn(String paramString1, String paramString2, long paramLong1, long paramLong2) {
/*  562 */     CommandQueue(new CommandObject(8, paramString1, new FilenameURL(paramString2), paramLong1, paramLong2));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  567 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void fadeOutIn(String paramString1, URL paramURL, String paramString2, long paramLong1, long paramLong2) {
/*  592 */     CommandQueue(new CommandObject(8, paramString1, new FilenameURL(paramURL, paramString2), paramLong1, paramLong2));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  597 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void checkFadeVolumes() {
/*  614 */     CommandQueue(new CommandObject(9));
/*      */     
/*  616 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void backgroundMusic(String paramString1, String paramString2, boolean paramBoolean) {
/*  634 */     CommandQueue(new CommandObject(12, true, true, paramBoolean, paramString1, new FilenameURL(paramString2), 0.0F, 0.0F, 0.0F, 0, 0.0F, false));
/*      */ 
/*      */ 
/*      */     
/*  638 */     CommandQueue(new CommandObject(24, paramString1));
/*      */     
/*  640 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void backgroundMusic(String paramString1, URL paramURL, String paramString2, boolean paramBoolean) {
/*  657 */     CommandQueue(new CommandObject(12, true, true, paramBoolean, paramString1, new FilenameURL(paramURL, paramString2), 0.0F, 0.0F, 0.0F, 0, 0.0F, false));
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  663 */     CommandQueue(new CommandObject(24, paramString1));
/*      */     
/*  665 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newSource(boolean paramBoolean1, String paramString1, String paramString2, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  686 */     CommandQueue(new CommandObject(10, paramBoolean1, false, paramBoolean2, paramString1, new FilenameURL(paramString2), paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4));
/*      */ 
/*      */ 
/*      */     
/*  690 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newSource(boolean paramBoolean1, String paramString1, URL paramURL, String paramString2, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  712 */     CommandQueue(new CommandObject(10, paramBoolean1, false, paramBoolean2, paramString1, new FilenameURL(paramURL, paramString2), paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  717 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newStreamingSource(boolean paramBoolean1, String paramString1, String paramString2, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  741 */     CommandQueue(new CommandObject(10, paramBoolean1, true, paramBoolean2, paramString1, new FilenameURL(paramString2), paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4));
/*      */ 
/*      */ 
/*      */     
/*  745 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void newStreamingSource(boolean paramBoolean1, String paramString1, URL paramURL, String paramString2, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  768 */     CommandQueue(new CommandObject(10, paramBoolean1, true, paramBoolean2, paramString1, new FilenameURL(paramURL, paramString2), paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4));
/*      */ 
/*      */ 
/*      */     
/*  772 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rawDataStream(AudioFormat paramAudioFormat, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  793 */     CommandQueue(new CommandObject(11, paramAudioFormat, paramBoolean, paramString, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4));
/*      */ 
/*      */     
/*  796 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String quickPlay(boolean paramBoolean1, String paramString, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  819 */     String str = "Source_" + this.randomNumberGenerator.nextInt() + "_" + this.randomNumberGenerator.nextInt();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  824 */     CommandQueue(new CommandObject(12, paramBoolean1, false, paramBoolean2, str, new FilenameURL(paramString), paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, true));
/*      */ 
/*      */ 
/*      */     
/*  828 */     CommandQueue(new CommandObject(24, str));
/*      */     
/*  830 */     this.commandThread.interrupt();
/*      */ 
/*      */     
/*  833 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String quickPlay(boolean paramBoolean1, URL paramURL, String paramString, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  857 */     String str = "Source_" + this.randomNumberGenerator.nextInt() + "_" + this.randomNumberGenerator.nextInt();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  862 */     CommandQueue(new CommandObject(12, paramBoolean1, false, paramBoolean2, str, new FilenameURL(paramURL, paramString), paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, true));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  867 */     CommandQueue(new CommandObject(24, str));
/*      */     
/*  869 */     this.commandThread.interrupt();
/*      */ 
/*      */     
/*  872 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String quickStream(boolean paramBoolean1, String paramString, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  900 */     String str = "Source_" + this.randomNumberGenerator.nextInt() + "_" + this.randomNumberGenerator.nextInt();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  905 */     CommandQueue(new CommandObject(12, paramBoolean1, true, paramBoolean2, str, new FilenameURL(paramString), paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, true));
/*      */ 
/*      */ 
/*      */     
/*  909 */     CommandQueue(new CommandObject(24, str));
/*      */     
/*  911 */     this.commandThread.interrupt();
/*      */ 
/*      */     
/*  914 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public String quickStream(boolean paramBoolean1, URL paramURL, String paramString, boolean paramBoolean2, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/*  940 */     String str = "Source_" + this.randomNumberGenerator.nextInt() + "_" + this.randomNumberGenerator.nextInt();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  945 */     CommandQueue(new CommandObject(12, paramBoolean1, true, paramBoolean2, str, new FilenameURL(paramURL, paramString), paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, true));
/*      */ 
/*      */ 
/*      */ 
/*      */     
/*  950 */     CommandQueue(new CommandObject(24, str));
/*      */     
/*  952 */     this.commandThread.interrupt();
/*      */ 
/*      */     
/*  955 */     return str;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPosition(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
/*  967 */     CommandQueue(new CommandObject(13, paramString, paramFloat1, paramFloat2, paramFloat3));
/*      */     
/*  969 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVolume(String paramString, float paramFloat) {
/*  978 */     CommandQueue(new CommandObject(14, paramString, paramFloat));
/*      */     
/*  980 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getVolume(String paramString) {
/*  991 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/*  993 */       if (this.soundLibrary != null) {
/*  994 */         return this.soundLibrary.getVolume(paramString);
/*      */       }
/*  996 */       return 0.0F;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPitch(String paramString, float paramFloat) {
/* 1007 */     CommandQueue(new CommandObject(15, paramString, paramFloat));
/*      */     
/* 1009 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getPitch(String paramString) {
/* 1019 */     if (this.soundLibrary != null) {
/* 1020 */       return this.soundLibrary.getPitch(paramString);
/*      */     }
/* 1022 */     return 1.0F;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setPriority(String paramString, boolean paramBoolean) {
/* 1033 */     CommandQueue(new CommandObject(16, paramString, paramBoolean));
/*      */     
/* 1035 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setLooping(String paramString, boolean paramBoolean) {
/* 1044 */     CommandQueue(new CommandObject(17, paramString, paramBoolean));
/*      */     
/* 1046 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setAttenuation(String paramString, int paramInt) {
/* 1057 */     CommandQueue(new CommandObject(18, paramString, paramInt));
/*      */     
/* 1059 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setDistOrRoll(String paramString, float paramFloat) {
/* 1070 */     CommandQueue(new CommandObject(19, paramString, paramFloat));
/*      */     
/* 1072 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void changeDopplerFactor(float paramFloat) {
/* 1083 */     CommandQueue(new CommandObject(20, paramFloat));
/*      */     
/* 1085 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void changeDopplerVelocity(float paramFloat) {
/* 1096 */     CommandQueue(new CommandObject(21, paramFloat));
/*      */     
/* 1098 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setVelocity(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1112 */     CommandQueue(new CommandObject(22, paramString, paramFloat1, paramFloat2, paramFloat3));
/*      */     
/* 1114 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1127 */     CommandQueue(new CommandObject(23, paramFloat1, paramFloat2, paramFloat3));
/*      */     
/* 1129 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float millisecondsPlayed(String paramString) {
/* 1138 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 1140 */       return this.soundLibrary.millisecondsPlayed(paramString);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void feedRawAudioData(String paramString, byte[] paramArrayOfbyte) {
/* 1159 */     CommandQueue(new CommandObject(25, paramString, paramArrayOfbyte));
/*      */     
/* 1161 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void play(String paramString) {
/* 1169 */     CommandQueue(new CommandObject(24, paramString));
/* 1170 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void pause(String paramString) {
/* 1178 */     CommandQueue(new CommandObject(26, paramString));
/* 1179 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void stop(String paramString) {
/* 1187 */     CommandQueue(new CommandObject(27, paramString));
/* 1188 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void rewind(String paramString) {
/* 1196 */     CommandQueue(new CommandObject(28, paramString));
/* 1197 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void flush(String paramString) {
/* 1205 */     CommandQueue(new CommandObject(29, paramString));
/* 1206 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void cull(String paramString) {
/* 1216 */     CommandQueue(new CommandObject(30, paramString));
/* 1217 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void activate(String paramString) {
/* 1227 */     CommandQueue(new CommandObject(31, paramString));
/* 1228 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setTemporary(String paramString, boolean paramBoolean) {
/* 1245 */     CommandQueue(new CommandObject(32, paramString, paramBoolean));
/*      */     
/* 1247 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeSource(String paramString) {
/* 1256 */     CommandQueue(new CommandObject(33, paramString));
/*      */     
/* 1258 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void moveListener(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1268 */     CommandQueue(new CommandObject(34, paramFloat1, paramFloat2, paramFloat3));
/*      */     
/* 1270 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1280 */     CommandQueue(new CommandObject(35, paramFloat1, paramFloat2, paramFloat3));
/*      */     
/* 1282 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void turnListener(float paramFloat) {
/* 1291 */     CommandQueue(new CommandObject(36, paramFloat));
/*      */     
/* 1293 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerAngle(float paramFloat) {
/* 1301 */     CommandQueue(new CommandObject(37, paramFloat));
/*      */     
/* 1303 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setListenerOrientation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 1317 */     CommandQueue(new CommandObject(38, paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6));
/*      */     
/* 1319 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void setMasterVolume(float paramFloat) {
/* 1328 */     CommandQueue(new CommandObject(39, paramFloat));
/*      */     
/* 1330 */     this.commandThread.interrupt();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public float getMasterVolume() {
/* 1339 */     return SoundSystemConfig.getMasterGain();
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public ListenerData getListenerData() {
/* 1349 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 1351 */       return this.soundLibrary.getListenerData();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean switchLibrary(Class<Library> paramClass) {
/* 1364 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 1366 */       initialized(true, false);
/*      */       
/* 1368 */       HashMap hashMap = null;
/* 1369 */       ListenerData listenerData = null;
/*      */       
/* 1371 */       boolean bool = false;
/* 1372 */       MidiChannel midiChannel = null;
/* 1373 */       FilenameURL filenameURL = null;
/* 1374 */       String str = "";
/* 1375 */       boolean bool1 = true;
/*      */       
/* 1377 */       if (this.soundLibrary != null) {
/*      */         
/* 1379 */         currentLibrary(true, null);
/* 1380 */         hashMap = copySources(this.soundLibrary.getSources());
/* 1381 */         listenerData = this.soundLibrary.getListenerData();
/* 1382 */         midiChannel = this.soundLibrary.getMidiChannel();
/* 1383 */         if (midiChannel != null) {
/*      */           
/* 1385 */           bool = true;
/* 1386 */           bool1 = midiChannel.getLooping();
/* 1387 */           str = midiChannel.getSourcename();
/* 1388 */           filenameURL = midiChannel.getFilenameURL();
/*      */         } 
/*      */         
/* 1391 */         this.soundLibrary.cleanup();
/* 1392 */         this.soundLibrary = null;
/*      */       } 
/* 1394 */       message("", 0);
/* 1395 */       message("Switching to " + SoundSystemConfig.getLibraryTitle(paramClass), 0);
/*      */       
/* 1397 */       message("(" + SoundSystemConfig.getLibraryDescription(paramClass) + ")", 1);
/*      */ 
/*      */ 
/*      */       
/*      */       try {
/* 1402 */         this.soundLibrary = paramClass.newInstance();
/*      */       }
/* 1404 */       catch (InstantiationException instantiationException) {
/*      */         
/* 1406 */         errorMessage("The specified library did not load properly", 1);
/*      */       }
/* 1408 */       catch (IllegalAccessException illegalAccessException) {
/*      */         
/* 1410 */         errorMessage("The specified library did not load properly", 1);
/*      */       }
/* 1412 */       catch (ExceptionInInitializerError exceptionInInitializerError) {
/*      */         
/* 1414 */         errorMessage("The specified library did not load properly", 1);
/*      */       }
/* 1416 */       catch (SecurityException securityException) {
/*      */         
/* 1418 */         errorMessage("The specified library did not load properly", 1);
/*      */       } 
/*      */       
/* 1421 */       if (errorCheck((this.soundLibrary == null), "Library null after initialization in method 'switchLibrary'", 1)) {
/*      */ 
/*      */         
/* 1424 */         SoundSystemException soundSystemException = new SoundSystemException(this.className + " did not load properly.  " + "Library was null after initialization.", 4);
/*      */ 
/*      */ 
/*      */         
/* 1428 */         lastException(true, soundSystemException);
/* 1429 */         initialized(true, true);
/* 1430 */         throw soundSystemException;
/*      */       } 
/*      */ 
/*      */       
/*      */       try {
/* 1435 */         this.soundLibrary.init();
/*      */       }
/* 1437 */       catch (SoundSystemException soundSystemException) {
/*      */         
/* 1439 */         lastException(true, soundSystemException);
/* 1440 */         initialized(true, true);
/* 1441 */         throw soundSystemException;
/*      */       } 
/*      */       
/* 1444 */       this.soundLibrary.setListenerData(listenerData);
/* 1445 */       if (bool) {
/*      */         
/* 1447 */         if (midiChannel != null)
/* 1448 */           midiChannel.cleanup(); 
/* 1449 */         midiChannel = new MidiChannel(bool1, str, filenameURL);
/*      */         
/* 1451 */         this.soundLibrary.setMidiChannel(midiChannel);
/*      */       } 
/* 1453 */       this.soundLibrary.copySources(hashMap);
/*      */       
/* 1455 */       message("", 0);
/*      */       
/* 1457 */       lastException(true, null);
/* 1458 */       initialized(true, true);
/*      */       
/* 1460 */       return true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean newLibrary(Class paramClass) {
/* 1473 */     initialized(true, false);
/*      */     
/* 1475 */     CommandQueue(new CommandObject(40, paramClass));
/*      */     
/* 1477 */     this.commandThread.interrupt();
/*      */     
/* 1479 */     for (byte b = 0; !initialized(false, false) && b < 100; b++) {
/*      */       
/* 1481 */       snooze(400L);
/* 1482 */       this.commandThread.interrupt();
/*      */     } 
/*      */     
/* 1485 */     if (!initialized(false, false)) {
/*      */       
/* 1487 */       SoundSystemException soundSystemException1 = new SoundSystemException(this.className + " did not load after 30 seconds.", 4);
/*      */ 
/*      */ 
/*      */       
/* 1491 */       lastException(true, soundSystemException1);
/* 1492 */       throw soundSystemException1;
/*      */     } 
/*      */ 
/*      */     
/* 1496 */     SoundSystemException soundSystemException = lastException(false, null);
/* 1497 */     if (soundSystemException != null) {
/* 1498 */       throw soundSystemException;
/*      */     }
/* 1500 */     return true;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandNewLibrary(Class<Library> paramClass) {
/* 1513 */     initialized(true, false);
/*      */     
/* 1515 */     String str = "Initializing ";
/* 1516 */     if (this.soundLibrary != null) {
/*      */       
/* 1518 */       currentLibrary(true, null);
/*      */       
/* 1520 */       str = "Switching to ";
/* 1521 */       this.soundLibrary.cleanup();
/* 1522 */       this.soundLibrary = null;
/*      */     } 
/* 1524 */     message(str + SoundSystemConfig.getLibraryTitle(paramClass), 0);
/*      */     
/* 1526 */     message("(" + SoundSystemConfig.getLibraryDescription(paramClass) + ")", 1);
/*      */ 
/*      */ 
/*      */     
/*      */     try {
/* 1531 */       this.soundLibrary = paramClass.newInstance();
/*      */     }
/* 1533 */     catch (InstantiationException instantiationException) {
/*      */       
/* 1535 */       errorMessage("The specified library did not load properly", 1);
/*      */     }
/* 1537 */     catch (IllegalAccessException illegalAccessException) {
/*      */       
/* 1539 */       errorMessage("The specified library did not load properly", 1);
/*      */     }
/* 1541 */     catch (ExceptionInInitializerError exceptionInInitializerError) {
/*      */       
/* 1543 */       errorMessage("The specified library did not load properly", 1);
/*      */     }
/* 1545 */     catch (SecurityException securityException) {
/*      */       
/* 1547 */       errorMessage("The specified library did not load properly", 1);
/*      */     } 
/*      */     
/* 1550 */     if (errorCheck((this.soundLibrary == null), "Library null after initialization in method 'newLibrary'", 1)) {
/*      */ 
/*      */       
/* 1553 */       lastException(true, new SoundSystemException(this.className + " did not load properly.  " + "Library was null after initialization.", 4));
/*      */ 
/*      */ 
/*      */       
/* 1557 */       importantMessage("Switching to silent mode", 1);
/*      */ 
/*      */       
/*      */       try {
/* 1561 */         this.soundLibrary = new Library();
/*      */       }
/* 1563 */       catch (SoundSystemException soundSystemException) {
/*      */         
/* 1565 */         lastException(true, new SoundSystemException("Silent mode did not load properly.  Library was null after initialization.", 4));
/*      */ 
/*      */ 
/*      */         
/* 1569 */         initialized(true, true);
/*      */         
/*      */         return;
/*      */       } 
/*      */     } 
/*      */     
/*      */     try {
/* 1576 */       this.soundLibrary.init();
/*      */     }
/* 1578 */     catch (SoundSystemException soundSystemException) {
/*      */       
/* 1580 */       lastException(true, soundSystemException);
/* 1581 */       initialized(true, true);
/*      */       
/*      */       return;
/*      */     } 
/* 1585 */     lastException(true, null);
/* 1586 */     initialized(true, true);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandInitialize() {
/*      */     try {
/* 1599 */       if (errorCheck((this.soundLibrary == null), "Library null after initialization in method 'CommandInitialize'", 1)) {
/*      */ 
/*      */ 
/*      */         
/* 1603 */         SoundSystemException soundSystemException = new SoundSystemException(this.className + " did not load properly.  " + "Library was null after initialization.", 4);
/*      */ 
/*      */ 
/*      */         
/* 1607 */         lastException(true, soundSystemException);
/* 1608 */         throw soundSystemException;
/*      */       } 
/* 1610 */       this.soundLibrary.init();
/*      */     }
/* 1612 */     catch (SoundSystemException soundSystemException) {
/*      */       
/* 1614 */       lastException(true, soundSystemException);
/* 1615 */       initialized(true, true);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandLoadSound(FilenameURL paramFilenameURL) {
/* 1626 */     if (this.soundLibrary != null) {
/* 1627 */       this.soundLibrary.loadSound(paramFilenameURL);
/*      */     } else {
/* 1629 */       errorMessage("Variable 'soundLibrary' null in method 'CommandLoadSound'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandLoadSound(SoundBuffer paramSoundBuffer, String paramString) {
/* 1643 */     if (this.soundLibrary != null) {
/* 1644 */       this.soundLibrary.loadSound(paramSoundBuffer, paramString);
/*      */     } else {
/* 1646 */       errorMessage("Variable 'soundLibrary' null in method 'CommandLoadSound'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandUnloadSound(String paramString) {
/* 1657 */     if (this.soundLibrary != null) {
/* 1658 */       this.soundLibrary.unloadSound(paramString);
/*      */     } else {
/* 1660 */       errorMessage("Variable 'soundLibrary' null in method 'CommandLoadSound'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandQueueSound(String paramString, FilenameURL paramFilenameURL) {
/* 1675 */     if (this.soundLibrary != null) {
/* 1676 */       this.soundLibrary.queueSound(paramString, paramFilenameURL);
/*      */     } else {
/* 1678 */       errorMessage("Variable 'soundLibrary' null in method 'CommandQueueSound'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandDequeueSound(String paramString1, String paramString2) {
/* 1692 */     if (this.soundLibrary != null) {
/* 1693 */       this.soundLibrary.dequeueSound(paramString1, paramString2);
/*      */     } else {
/* 1695 */       errorMessage("Variable 'soundLibrary' null in method 'CommandDequeueSound'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandFadeOut(String paramString, FilenameURL paramFilenameURL, long paramLong) {
/* 1716 */     if (this.soundLibrary != null) {
/* 1717 */       this.soundLibrary.fadeOut(paramString, paramFilenameURL, paramLong);
/*      */     } else {
/* 1719 */       errorMessage("Variable 'soundLibrary' null in method 'CommandFadeOut'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandFadeOutIn(String paramString, FilenameURL paramFilenameURL, long paramLong1, long paramLong2) {
/* 1741 */     if (this.soundLibrary != null) {
/* 1742 */       this.soundLibrary.fadeOutIn(paramString, paramFilenameURL, paramLong1, paramLong2);
/*      */     } else {
/*      */       
/* 1745 */       errorMessage("Variable 'soundLibrary' null in method 'CommandFadeOutIn'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandCheckFadeVolumes() {
/* 1763 */     if (this.soundLibrary != null) {
/* 1764 */       this.soundLibrary.checkFadeVolumes();
/*      */     } else {
/* 1766 */       errorMessage("Variable 'soundLibrary' null in method 'CommandCheckFadeVolumes'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandNewSource(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/* 1790 */     if (this.soundLibrary != null) {
/*      */       
/* 1792 */       if (paramFilenameURL.getFilename().matches(SoundSystemConfig.EXTENSION_MIDI) && !SoundSystemConfig.midiCodec())
/*      */       {
/*      */ 
/*      */         
/* 1796 */         this.soundLibrary.loadMidi(paramBoolean3, paramString, paramFilenameURL);
/*      */       }
/*      */       else
/*      */       {
/* 1800 */         this.soundLibrary.newSource(paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4);
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1806 */       errorMessage("Variable 'soundLibrary' null in method 'CommandNewSource'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandRawDataStream(AudioFormat paramAudioFormat, boolean paramBoolean, String paramString, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4) {
/* 1827 */     if (this.soundLibrary != null) {
/* 1828 */       this.soundLibrary.rawDataStream(paramAudioFormat, paramBoolean, paramString, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4);
/*      */     } else {
/*      */       
/* 1831 */       errorMessage("Variable 'soundLibrary' null in method 'CommandRawDataStream'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandQuickPlay(boolean paramBoolean1, boolean paramBoolean2, boolean paramBoolean3, String paramString, FilenameURL paramFilenameURL, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt, float paramFloat4, boolean paramBoolean4) {
/* 1857 */     if (this.soundLibrary != null) {
/*      */       
/* 1859 */       if (paramFilenameURL.getFilename().matches(SoundSystemConfig.EXTENSION_MIDI) && !SoundSystemConfig.midiCodec())
/*      */       {
/*      */         
/* 1862 */         this.soundLibrary.loadMidi(paramBoolean3, paramString, paramFilenameURL);
/*      */       }
/*      */       else
/*      */       {
/* 1866 */         this.soundLibrary.quickPlay(paramBoolean1, paramBoolean2, paramBoolean3, paramString, paramFilenameURL, paramFloat1, paramFloat2, paramFloat3, paramInt, paramFloat4, paramBoolean4);
/*      */       }
/*      */     
/*      */     }
/*      */     else {
/*      */       
/* 1872 */       errorMessage("Variable 'soundLibrary' null in method 'CommandQuickPlay'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetPosition(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 1887 */     if (this.soundLibrary != null) {
/* 1888 */       this.soundLibrary.setPosition(paramString, paramFloat1, paramFloat2, paramFloat3);
/*      */     } else {
/* 1890 */       errorMessage("Variable 'soundLibrary' null in method 'CommandMoveSource'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetVolume(String paramString, float paramFloat) {
/* 1902 */     if (this.soundLibrary != null) {
/* 1903 */       this.soundLibrary.setVolume(paramString, paramFloat);
/*      */     } else {
/* 1905 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetVolume'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetPitch(String paramString, float paramFloat) {
/* 1917 */     if (this.soundLibrary != null) {
/* 1918 */       this.soundLibrary.setPitch(paramString, paramFloat);
/*      */     } else {
/* 1920 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetPitch'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetPriority(String paramString, boolean paramBoolean) {
/* 1933 */     if (this.soundLibrary != null) {
/* 1934 */       this.soundLibrary.setPriority(paramString, paramBoolean);
/*      */     } else {
/* 1936 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetPriority'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetLooping(String paramString, boolean paramBoolean) {
/* 1948 */     if (this.soundLibrary != null) {
/* 1949 */       this.soundLibrary.setLooping(paramString, paramBoolean);
/*      */     } else {
/* 1951 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetLooping'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetAttenuation(String paramString, int paramInt) {
/* 1965 */     if (this.soundLibrary != null) {
/* 1966 */       this.soundLibrary.setAttenuation(paramString, paramInt);
/*      */     } else {
/* 1968 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetAttenuation'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetDistOrRoll(String paramString, float paramFloat) {
/* 1981 */     if (this.soundLibrary != null) {
/* 1982 */       this.soundLibrary.setDistOrRoll(paramString, paramFloat);
/*      */     } else {
/* 1984 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetDistOrRoll'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandChangeDopplerFactor(float paramFloat) {
/* 1998 */     if (this.soundLibrary != null) {
/*      */       
/* 2000 */       SoundSystemConfig.setDopplerFactor(paramFloat);
/* 2001 */       this.soundLibrary.dopplerChanged();
/*      */     } else {
/*      */       
/* 2004 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetDopplerFactor'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandChangeDopplerVelocity(float paramFloat) {
/* 2018 */     if (this.soundLibrary != null) {
/*      */       
/* 2020 */       SoundSystemConfig.setDopplerVelocity(paramFloat);
/* 2021 */       this.soundLibrary.dopplerChanged();
/*      */     } else {
/*      */       
/* 2024 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetDopplerFactor'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetVelocity(String paramString, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2041 */     if (this.soundLibrary != null) {
/* 2042 */       this.soundLibrary.setVelocity(paramString, paramFloat1, paramFloat2, paramFloat3);
/*      */     } else {
/* 2044 */       errorMessage("Variable 'soundLibrary' null in method 'CommandVelocity'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetListenerVelocity(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2060 */     if (this.soundLibrary != null) {
/* 2061 */       this.soundLibrary.setListenerVelocity(paramFloat1, paramFloat2, paramFloat3);
/*      */     } else {
/* 2063 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetListenerVelocity'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandPlay(String paramString) {
/* 2075 */     if (this.soundLibrary != null) {
/* 2076 */       this.soundLibrary.play(paramString);
/*      */     } else {
/* 2078 */       errorMessage("Variable 'soundLibrary' null in method 'CommandPlay'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandFeedRawAudioData(String paramString, byte[] paramArrayOfbyte) {
/* 2092 */     if (this.soundLibrary != null) {
/* 2093 */       this.soundLibrary.feedRawAudioData(paramString, paramArrayOfbyte);
/*      */     } else {
/* 2095 */       errorMessage("Variable 'soundLibrary' null in method 'CommandFeedRawAudioData'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandPause(String paramString) {
/* 2106 */     if (this.soundLibrary != null) {
/* 2107 */       this.soundLibrary.pause(paramString);
/*      */     } else {
/* 2109 */       errorMessage("Variable 'soundLibrary' null in method 'CommandPause'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandStop(String paramString) {
/* 2120 */     if (this.soundLibrary != null) {
/* 2121 */       this.soundLibrary.stop(paramString);
/*      */     } else {
/* 2123 */       errorMessage("Variable 'soundLibrary' null in method 'CommandStop'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandRewind(String paramString) {
/* 2134 */     if (this.soundLibrary != null) {
/* 2135 */       this.soundLibrary.rewind(paramString);
/*      */     } else {
/* 2137 */       errorMessage("Variable 'soundLibrary' null in method 'CommandRewind'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandFlush(String paramString) {
/* 2148 */     if (this.soundLibrary != null) {
/* 2149 */       this.soundLibrary.flush(paramString);
/*      */     } else {
/* 2151 */       errorMessage("Variable 'soundLibrary' null in method 'CommandFlush'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetTemporary(String paramString, boolean paramBoolean) {
/* 2170 */     if (this.soundLibrary != null) {
/* 2171 */       this.soundLibrary.setTemporary(paramString, paramBoolean);
/*      */     } else {
/* 2173 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetActive'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandRemoveSource(String paramString) {
/* 2184 */     if (this.soundLibrary != null) {
/* 2185 */       this.soundLibrary.removeSource(paramString);
/*      */     } else {
/* 2187 */       errorMessage("Variable 'soundLibrary' null in method 'CommandRemoveSource'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandMoveListener(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2200 */     if (this.soundLibrary != null) {
/* 2201 */       this.soundLibrary.moveListener(paramFloat1, paramFloat2, paramFloat3);
/*      */     } else {
/* 2203 */       errorMessage("Variable 'soundLibrary' null in method 'CommandMoveListener'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetListenerPosition(float paramFloat1, float paramFloat2, float paramFloat3) {
/* 2216 */     if (this.soundLibrary != null) {
/* 2217 */       this.soundLibrary.setListenerPosition(paramFloat1, paramFloat2, paramFloat3);
/*      */     } else {
/* 2219 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetListenerPosition'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandTurnListener(float paramFloat) {
/* 2232 */     if (this.soundLibrary != null) {
/* 2233 */       this.soundLibrary.turnListener(paramFloat);
/*      */     } else {
/* 2235 */       errorMessage("Variable 'soundLibrary' null in method 'CommandTurnListener'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetListenerAngle(float paramFloat) {
/* 2247 */     if (this.soundLibrary != null) {
/* 2248 */       this.soundLibrary.setListenerAngle(paramFloat);
/*      */     } else {
/* 2250 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetListenerAngle'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetListenerOrientation(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 2269 */     if (this.soundLibrary != null) {
/* 2270 */       this.soundLibrary.setListenerOrientation(paramFloat1, paramFloat2, paramFloat3, paramFloat4, paramFloat5, paramFloat6);
/*      */     } else {
/*      */       
/* 2273 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetListenerOrientation'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandCull(String paramString) {
/* 2286 */     if (this.soundLibrary != null) {
/* 2287 */       this.soundLibrary.cull(paramString);
/*      */     } else {
/* 2289 */       errorMessage("Variable 'soundLibrary' null in method 'CommandCull'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandActivate(String paramString) {
/* 2300 */     if (this.soundLibrary != null) {
/* 2301 */       this.soundLibrary.activate(paramString);
/*      */     } else {
/* 2303 */       errorMessage("Variable 'soundLibrary' null in method 'CommandActivate'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private void CommandSetMasterVolume(float paramFloat) {
/* 2315 */     if (this.soundLibrary != null) {
/* 2316 */       this.soundLibrary.setMasterVolume(paramFloat);
/*      */     } else {
/* 2318 */       errorMessage("Variable 'soundLibrary' null in method 'CommandSetMasterVolume'", 0);
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void ManageSources() {}
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean CommandQueue(CommandObject paramCommandObject) {
/* 2359 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 2361 */       if (paramCommandObject == null) {
/*      */ 
/*      */         
/* 2364 */         boolean bool = false;
/*      */ 
/*      */ 
/*      */         
/* 2368 */         while (this.commandQueue != null && this.commandQueue.size() > 0) {
/*      */ 
/*      */           
/* 2371 */           CommandObject commandObject = this.commandQueue.remove(0);
/*      */           
/* 2373 */           if (commandObject != null)
/*      */           {
/* 2375 */             switch (commandObject.Command) {
/*      */               
/*      */               case 1:
/* 2378 */                 CommandInitialize();
/*      */               
/*      */               case 2:
/* 2381 */                 CommandLoadSound((FilenameURL)commandObject.objectArgs[0]);
/*      */ 
/*      */               
/*      */               case 3:
/* 2385 */                 CommandLoadSound((SoundBuffer)commandObject.objectArgs[0], commandObject.stringArgs[0]);
/*      */ 
/*      */ 
/*      */               
/*      */               case 4:
/* 2390 */                 CommandUnloadSound(commandObject.stringArgs[0]);
/*      */               
/*      */               case 5:
/* 2393 */                 CommandQueueSound(commandObject.stringArgs[0], (FilenameURL)commandObject.objectArgs[0]);
/*      */ 
/*      */               
/*      */               case 6:
/* 2397 */                 CommandDequeueSound(commandObject.stringArgs[0], commandObject.stringArgs[1]);
/*      */ 
/*      */               
/*      */               case 7:
/* 2401 */                 CommandFadeOut(commandObject.stringArgs[0], (FilenameURL)commandObject.objectArgs[0], commandObject.longArgs[0]);
/*      */ 
/*      */ 
/*      */               
/*      */               case 8:
/* 2406 */                 CommandFadeOutIn(commandObject.stringArgs[0], (FilenameURL)commandObject.objectArgs[0], commandObject.longArgs[0], commandObject.longArgs[1]);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 9:
/* 2412 */                 CommandCheckFadeVolumes();
/*      */               
/*      */               case 10:
/* 2415 */                 CommandNewSource(commandObject.boolArgs[0], commandObject.boolArgs[1], commandObject.boolArgs[2], commandObject.stringArgs[0], (FilenameURL)commandObject.objectArgs[0], commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2], commandObject.intArgs[0], commandObject.floatArgs[3]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 11:
/* 2427 */                 CommandRawDataStream((AudioFormat)commandObject.objectArgs[0], commandObject.boolArgs[0], commandObject.stringArgs[0], commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2], commandObject.intArgs[0], commandObject.floatArgs[3]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 12:
/* 2438 */                 CommandQuickPlay(commandObject.boolArgs[0], commandObject.boolArgs[1], commandObject.boolArgs[2], commandObject.stringArgs[0], (FilenameURL)commandObject.objectArgs[0], commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2], commandObject.intArgs[0], commandObject.floatArgs[3], commandObject.boolArgs[3]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 13:
/* 2451 */                 CommandSetPosition(commandObject.stringArgs[0], commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2]);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 14:
/* 2457 */                 CommandSetVolume(commandObject.stringArgs[0], commandObject.floatArgs[0]);
/*      */ 
/*      */               
/*      */               case 15:
/* 2461 */                 CommandSetPitch(commandObject.stringArgs[0], commandObject.floatArgs[0]);
/*      */ 
/*      */               
/*      */               case 16:
/* 2465 */                 CommandSetPriority(commandObject.stringArgs[0], commandObject.boolArgs[0]);
/*      */ 
/*      */               
/*      */               case 17:
/* 2469 */                 CommandSetLooping(commandObject.stringArgs[0], commandObject.boolArgs[0]);
/*      */ 
/*      */               
/*      */               case 18:
/* 2473 */                 CommandSetAttenuation(commandObject.stringArgs[0], commandObject.intArgs[0]);
/*      */ 
/*      */               
/*      */               case 19:
/* 2477 */                 CommandSetDistOrRoll(commandObject.stringArgs[0], commandObject.floatArgs[0]);
/*      */ 
/*      */               
/*      */               case 20:
/* 2481 */                 CommandChangeDopplerFactor(commandObject.floatArgs[0]);
/*      */ 
/*      */               
/*      */               case 21:
/* 2485 */                 CommandChangeDopplerVelocity(commandObject.floatArgs[0]);
/*      */ 
/*      */               
/*      */               case 22:
/* 2489 */                 CommandSetVelocity(commandObject.stringArgs[0], commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 23:
/* 2496 */                 CommandSetListenerVelocity(commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 24:
/* 2508 */                 this.sourcePlayList.add(commandObject);
/*      */               
/*      */               case 25:
/* 2511 */                 this.sourcePlayList.add(commandObject);
/*      */ 
/*      */               
/*      */               case 26:
/* 2515 */                 CommandPause(commandObject.stringArgs[0]);
/*      */               
/*      */               case 27:
/* 2518 */                 CommandStop(commandObject.stringArgs[0]);
/*      */               
/*      */               case 28:
/* 2521 */                 CommandRewind(commandObject.stringArgs[0]);
/*      */               
/*      */               case 29:
/* 2524 */                 CommandFlush(commandObject.stringArgs[0]);
/*      */               
/*      */               case 30:
/* 2527 */                 CommandCull(commandObject.stringArgs[0]);
/*      */               
/*      */               case 31:
/* 2530 */                 bool = true;
/* 2531 */                 CommandActivate(commandObject.stringArgs[0]);
/*      */               
/*      */               case 32:
/* 2534 */                 CommandSetTemporary(commandObject.stringArgs[0], commandObject.boolArgs[0]);
/*      */ 
/*      */               
/*      */               case 33:
/* 2538 */                 CommandRemoveSource(commandObject.stringArgs[0]);
/*      */               
/*      */               case 34:
/* 2541 */                 CommandMoveListener(commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2]);
/*      */ 
/*      */ 
/*      */               
/*      */               case 35:
/* 2546 */                 CommandSetListenerPosition(commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2]);
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 36:
/* 2552 */                 CommandTurnListener(commandObject.floatArgs[0]);
/*      */               
/*      */               case 37:
/* 2555 */                 CommandSetListenerAngle(commandObject.floatArgs[0]);
/*      */ 
/*      */               
/*      */               case 38:
/* 2559 */                 CommandSetListenerOrientation(commandObject.floatArgs[0], commandObject.floatArgs[1], commandObject.floatArgs[2], commandObject.floatArgs[3], commandObject.floatArgs[4], commandObject.floatArgs[5]);
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */               
/*      */               case 39:
/* 2568 */                 CommandSetMasterVolume(commandObject.floatArgs[0]);
/*      */ 
/*      */               
/*      */               case 40:
/* 2572 */                 CommandNewLibrary(commandObject.classArgs[0]);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */         } 
/* 2583 */         if (bool) {
/* 2584 */           this.soundLibrary.replaySources();
/*      */         }
/*      */ 
/*      */ 
/*      */         
/* 2589 */         while (this.sourcePlayList != null && this.sourcePlayList.size() > 0) {
/*      */ 
/*      */           
/* 2592 */           CommandObject commandObject = this.sourcePlayList.remove(0);
/* 2593 */           if (commandObject != null)
/*      */           {
/*      */             
/* 2596 */             switch (commandObject.Command) {
/*      */               
/*      */               case 24:
/* 2599 */                 CommandPlay(commandObject.stringArgs[0]);
/*      */               
/*      */               case 25:
/* 2602 */                 CommandFeedRawAudioData(commandObject.stringArgs[0], commandObject.buffer);
/*      */             } 
/*      */ 
/*      */ 
/*      */ 
/*      */           
/*      */           }
/*      */         } 
/* 2610 */         return (this.commandQueue != null && this.commandQueue.size() > 0);
/*      */       } 
/*      */ 
/*      */ 
/*      */       
/* 2615 */       if (this.commandQueue == null) {
/* 2616 */         return false;
/*      */       }
/* 2618 */       this.commandQueue.add(paramCommandObject);
/*      */ 
/*      */       
/* 2621 */       return true;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public void removeTemporarySources() {
/* 2633 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 2635 */       if (this.soundLibrary != null) {
/* 2636 */         this.soundLibrary.removeTemporarySources();
/*      */       }
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean playing(String paramString) {
/* 2647 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 2649 */       if (this.soundLibrary == null) {
/* 2650 */         return false;
/*      */       }
/* 2652 */       Source source = (Source)this.soundLibrary.getSources().get(paramString);
/*      */       
/* 2654 */       if (source == null) {
/* 2655 */         return false;
/*      */       }
/* 2657 */       return source.playing();
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public boolean playing() {
/* 2667 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 2669 */       if (this.soundLibrary == null) {
/* 2670 */         return false;
/*      */       }
/* 2672 */       HashMap hashMap = this.soundLibrary.getSources();
/* 2673 */       if (hashMap == null) {
/* 2674 */         return false;
/*      */       }
/* 2676 */       Set set = hashMap.keySet();
/* 2677 */       Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */       
/* 2681 */       while (iterator.hasNext()) {
/*      */         
/* 2683 */         String str = iterator.next();
/* 2684 */         Source source = (Source)hashMap.get(str);
/* 2685 */         if (source != null && 
/* 2686 */           source.playing()) {
/* 2687 */           return true;
/*      */         }
/*      */       } 
/* 2690 */       return false;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private HashMap copySources(HashMap paramHashMap) {
/* 2704 */     Set set = paramHashMap.keySet();
/* 2705 */     Iterator<String> iterator = set.iterator();
/*      */ 
/*      */ 
/*      */ 
/*      */     
/* 2710 */     HashMap<Object, Object> hashMap = new HashMap<Object, Object>();
/*      */ 
/*      */ 
/*      */     
/* 2714 */     while (iterator.hasNext()) {
/*      */       
/* 2716 */       String str = iterator.next();
/* 2717 */       Source source = (Source)paramHashMap.get(str);
/* 2718 */       if (source != null)
/* 2719 */         hashMap.put(str, new Source(source, null)); 
/*      */     } 
/* 2721 */     return hashMap;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean libraryCompatible(Class paramClass) {
/* 2732 */     SoundSystemLogger soundSystemLogger = SoundSystemConfig.getLogger();
/*      */     
/* 2734 */     if (soundSystemLogger == null) {
/*      */       
/* 2736 */       soundSystemLogger = new SoundSystemLogger();
/* 2737 */       SoundSystemConfig.setLogger(soundSystemLogger);
/*      */     } 
/* 2739 */     soundSystemLogger.message("", 0);
/* 2740 */     soundSystemLogger.message("Checking if " + SoundSystemConfig.getLibraryTitle(paramClass) + " is compatible...", 0);
/*      */ 
/*      */ 
/*      */     
/* 2744 */     boolean bool = SoundSystemConfig.libraryCompatible(paramClass);
/*      */     
/* 2746 */     if (bool) {
/* 2747 */       soundSystemLogger.message("...yes", 1);
/*      */     } else {
/* 2749 */       soundSystemLogger.message("...no", 1);
/*      */     } 
/* 2751 */     return bool;
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static Class currentLibrary() {
/* 2760 */     return currentLibrary(false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static boolean initialized() {
/* 2769 */     return initialized(false, false);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static SoundSystemException getLastException() {
/* 2778 */     return lastException(false, null);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   public static void setException(SoundSystemException paramSoundSystemException) {
/* 2788 */     lastException(true, paramSoundSystemException);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static boolean initialized(boolean paramBoolean1, boolean paramBoolean2) {
/* 2799 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 2801 */       if (paramBoolean1 == true)
/* 2802 */         initialized = paramBoolean2; 
/* 2803 */       return initialized;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static Class currentLibrary(boolean paramBoolean, Class paramClass) {
/* 2816 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 2818 */       if (paramBoolean == true)
/* 2819 */         currentLibrary = paramClass; 
/* 2820 */       return currentLibrary;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   private static SoundSystemException lastException(boolean paramBoolean, SoundSystemException paramSoundSystemException) {
/* 2834 */     synchronized (SoundSystemConfig.THREAD_SYNC) {
/*      */       
/* 2836 */       if (paramBoolean == true)
/* 2837 */         lastException = paramSoundSystemException; 
/* 2838 */       return lastException;
/*      */     } 
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected static void snooze(long paramLong) {
/*      */     try {
/* 2849 */       Thread.sleep(paramLong);
/*      */     }
/* 2851 */     catch (InterruptedException interruptedException) {}
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void message(String paramString, int paramInt) {
/* 2861 */     this.logger.message(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void importantMessage(String paramString, int paramInt) {
/* 2871 */     this.logger.importantMessage(paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected boolean errorCheck(boolean paramBoolean, String paramString, int paramInt) {
/* 2883 */     return this.logger.errorCheck(paramBoolean, this.className, paramString, paramInt);
/*      */   }
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */ 
/*      */   
/*      */   protected void errorMessage(String paramString, int paramInt) {
/* 2893 */     this.logger.errorMessage(this.className, paramString, paramInt);
/*      */   }
/*      */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\SoundSystem.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */