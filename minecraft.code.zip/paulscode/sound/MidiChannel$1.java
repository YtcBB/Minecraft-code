package paulscode.sound;


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\paulscode\sound\MidiChannel$1.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */