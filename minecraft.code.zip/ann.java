/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class ann
/*    */   extends apa
/*    */ {
/*    */   private lx a;
/*    */   private lx b;
/*    */   
/*    */   protected ann(int paramInt) {
/* 19 */     super(paramInt, aif.b);
/* 20 */     b(true);
/* 21 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 26 */     if (paramInt1 == 1) return this.a; 
/* 27 */     if (paramInt1 == 0) return apa.z.m(paramInt1); 
/* 28 */     return this.cQ;
/*    */   }
/*    */ 
/*    */   
/*    */   public lx b_(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 33 */     if (paramInt4 == 1) return this.a; 
/* 34 */     if (paramInt4 == 0) return apa.z.m(paramInt4); 
/* 35 */     aif aif = paramaak.g(paramInt1, paramInt2 + 1, paramInt3);
/* 36 */     if (aif == aif.w || aif == aif.x) return this.b; 
/* 37 */     return this.cQ;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 42 */     this.cQ = paramly.a("mycel_side");
/* 43 */     this.a = paramly.a("mycel_top");
/* 44 */     this.b = paramly.a("snow_side");
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 49 */     if (paramaab.I)
/*    */       return; 
/* 51 */     if (paramaab.n(paramInt1, paramInt2 + 1, paramInt3) < 4 && apa.t[paramaab.a(paramInt1, paramInt2 + 1, paramInt3)] > 2) {
/* 52 */       paramaab.c(paramInt1, paramInt2, paramInt3, apa.z.cz);
/*    */     }
/* 54 */     else if (paramaab.n(paramInt1, paramInt2 + 1, paramInt3) >= 9) {
/* 55 */       for (byte b = 0; b < 4; b++) {
/* 56 */         int i = paramInt1 + paramRandom.nextInt(3) - 1;
/* 57 */         int j = paramInt2 + paramRandom.nextInt(5) - 3;
/* 58 */         int k = paramInt3 + paramRandom.nextInt(3) - 1;
/* 59 */         int m = paramaab.a(i, j + 1, k);
/* 60 */         if (paramaab.a(i, j, k) == apa.z.cz && paramaab.n(i, j + 1, k) >= 4 && apa.t[m] <= 2) {
/* 61 */           paramaab.c(i, j, k, this.cz);
/*    */         }
/*    */       } 
/*    */     } 
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 70 */     super.b(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/* 71 */     if (paramRandom.nextInt(10) == 0) paramaab.a("townaura", (paramInt1 + paramRandom.nextFloat()), (paramInt2 + 1.1F), (paramInt3 + paramRandom.nextFloat()), 0.0D, 0.0D, 0.0D);
/*    */   
/*    */   }
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 76 */     return apa.z.a(0, paramRandom, paramInt2);
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ann.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */