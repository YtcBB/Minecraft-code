/*    */ public class aic
/*    */   extends aif
/*    */ {
/*    */   public aic(aih paramaih) {
/*  5 */     super(paramaih);
/*  6 */     p();
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean a() {
/* 11 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean b() {
/* 16 */     return false;
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean c() {
/* 21 */     return false;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aic.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */