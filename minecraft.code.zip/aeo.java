/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aeo
/*     */   extends agw
/*     */ {
/*     */   private final int a;
/*     */   private final boolean b;
/*     */   
/*     */   public aeo(int paramInt1, Random paramRandom, aek paramaek, int paramInt2) {
/* 410 */     super(paramInt1);
/* 411 */     this.a = paramInt2;
/* 412 */     this.e = paramaek;
/* 413 */     this.b = (paramaek.c() > 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public static aek a(List paramList, Random paramRandom, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 418 */     aek aek = new aek(paramInt1, paramInt2, paramInt3, paramInt1, paramInt2 + 2, paramInt3);
/*     */     
/* 420 */     if (paramRandom.nextInt(4) == 0) {
/* 421 */       aek.e += 4;
/*     */     }
/*     */     
/* 424 */     switch (paramInt4) {
/*     */       case 2:
/* 426 */         aek.a = paramInt1 - 1;
/* 427 */         aek.d = paramInt1 + 3;
/* 428 */         aek.c = paramInt3 - 4;
/*     */         break;
/*     */       case 0:
/* 431 */         aek.a = paramInt1 - 1;
/* 432 */         aek.d = paramInt1 + 3;
/* 433 */         aek.f = paramInt3 + 4;
/*     */         break;
/*     */       case 1:
/* 436 */         aek.a = paramInt1 - 4;
/* 437 */         aek.c = paramInt3 - 1;
/* 438 */         aek.f = paramInt3 + 3;
/*     */         break;
/*     */       case 3:
/* 441 */         aek.d = paramInt1 + 4;
/* 442 */         aek.c = paramInt3 - 1;
/* 443 */         aek.f = paramInt3 + 3;
/*     */         break;
/*     */     } 
/*     */     
/* 447 */     if (agw.a(paramList, aek) != null) {
/* 448 */       return null;
/*     */     }
/*     */     
/* 451 */     return aek;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(agw paramagw, List paramList, Random paramRandom) {
/* 457 */     int i = c();
/*     */ 
/*     */     
/* 460 */     switch (this.a) {
/*     */       case 2:
/* 462 */         aem.a(paramagw, paramList, paramRandom, this.e.a + 1, this.e.b, this.e.c - 1, 2, i);
/* 463 */         aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b, this.e.c + 1, 1, i);
/* 464 */         aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b, this.e.c + 1, 3, i);
/*     */         break;
/*     */       case 0:
/* 467 */         aem.a(paramagw, paramList, paramRandom, this.e.a + 1, this.e.b, this.e.f + 1, 0, i);
/* 468 */         aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b, this.e.c + 1, 1, i);
/* 469 */         aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b, this.e.c + 1, 3, i);
/*     */         break;
/*     */       case 1:
/* 472 */         aem.a(paramagw, paramList, paramRandom, this.e.a + 1, this.e.b, this.e.c - 1, 2, i);
/* 473 */         aem.a(paramagw, paramList, paramRandom, this.e.a + 1, this.e.b, this.e.f + 1, 0, i);
/* 474 */         aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b, this.e.c + 1, 1, i);
/*     */         break;
/*     */       case 3:
/* 477 */         aem.a(paramagw, paramList, paramRandom, this.e.a + 1, this.e.b, this.e.c - 1, 2, i);
/* 478 */         aem.a(paramagw, paramList, paramRandom, this.e.a + 1, this.e.b, this.e.f + 1, 0, i);
/* 479 */         aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b, this.e.c + 1, 3, i);
/*     */         break;
/*     */     } 
/*     */     
/* 483 */     if (this.b) {
/* 484 */       if (paramRandom.nextBoolean()) aem.a(paramagw, paramList, paramRandom, this.e.a + 1, this.e.b + 3 + 1, this.e.c - 1, 2, i); 
/* 485 */       if (paramRandom.nextBoolean()) aem.a(paramagw, paramList, paramRandom, this.e.a - 1, this.e.b + 3 + 1, this.e.c + 1, 1, i); 
/* 486 */       if (paramRandom.nextBoolean()) aem.a(paramagw, paramList, paramRandom, this.e.d + 1, this.e.b + 3 + 1, this.e.c + 1, 3, i); 
/* 487 */       if (paramRandom.nextBoolean()) aem.a(paramagw, paramList, paramRandom, this.e.a + 1, this.e.b + 3 + 1, this.e.f + 1, 0, i);
/*     */     
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, aek paramaek) {
/* 494 */     if (a(paramaab, paramaek)) {
/* 495 */       return false;
/*     */     }
/*     */ 
/*     */     
/* 499 */     if (this.b) {
/* 500 */       a(paramaab, paramaek, this.e.a + 1, this.e.b, this.e.c, this.e.d - 1, this.e.b + 3 - 1, this.e.f, 0, 0, false);
/* 501 */       a(paramaab, paramaek, this.e.a, this.e.b, this.e.c + 1, this.e.d, this.e.b + 3 - 1, this.e.f - 1, 0, 0, false);
/* 502 */       a(paramaab, paramaek, this.e.a + 1, this.e.e - 2, this.e.c, this.e.d - 1, this.e.e, this.e.f, 0, 0, false);
/* 503 */       a(paramaab, paramaek, this.e.a, this.e.e - 2, this.e.c + 1, this.e.d, this.e.e, this.e.f - 1, 0, 0, false);
/* 504 */       a(paramaab, paramaek, this.e.a + 1, this.e.b + 3, this.e.c + 1, this.e.d - 1, this.e.b + 3, this.e.f - 1, 0, 0, false);
/*     */     } else {
/*     */       
/* 507 */       a(paramaab, paramaek, this.e.a + 1, this.e.b, this.e.c, this.e.d - 1, this.e.e, this.e.f, 0, 0, false);
/* 508 */       a(paramaab, paramaek, this.e.a, this.e.b, this.e.c + 1, this.e.d, this.e.e, this.e.f - 1, 0, 0, false);
/*     */     } 
/*     */ 
/*     */     
/* 512 */     a(paramaab, paramaek, this.e.a + 1, this.e.b, this.e.c + 1, this.e.a + 1, this.e.e, this.e.c + 1, apa.B.cz, 0, false);
/* 513 */     a(paramaab, paramaek, this.e.a + 1, this.e.b, this.e.f - 1, this.e.a + 1, this.e.e, this.e.f - 1, apa.B.cz, 0, false);
/* 514 */     a(paramaab, paramaek, this.e.d - 1, this.e.b, this.e.c + 1, this.e.d - 1, this.e.e, this.e.c + 1, apa.B.cz, 0, false);
/* 515 */     a(paramaab, paramaek, this.e.d - 1, this.e.b, this.e.f - 1, this.e.d - 1, this.e.e, this.e.f - 1, apa.B.cz, 0, false);
/*     */ 
/*     */ 
/*     */     
/* 519 */     for (int i = this.e.a; i <= this.e.d; i++) {
/* 520 */       for (int j = this.e.c; j <= this.e.f; j++) {
/* 521 */         int k = a(paramaab, i, this.e.b - 1, j, paramaek);
/* 522 */         if (k == 0) {
/* 523 */           a(paramaab, apa.B.cz, 0, i, this.e.b - 1, j, paramaek);
/*     */         }
/*     */       } 
/*     */     } 
/*     */     
/* 528 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aeo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */