/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apo
/*     */   extends apa
/*     */ {
/*  22 */   public static final String[] a = new String[] { "normal", "mossy" };
/*     */ 
/*     */ 
/*     */   
/*     */   public apo(int paramInt, apa paramapa) {
/*  27 */     super(paramInt, paramapa.cO);
/*     */     
/*  29 */     c(paramapa.cA);
/*  30 */     b(paramapa.cB / 3.0F);
/*  31 */     a(paramapa.cM);
/*  32 */     a(ve.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  37 */     if (paramInt2 == 1) {
/*  38 */       return apa.as.m(paramInt1);
/*     */     }
/*  40 */     return apa.A.m(paramInt1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  45 */     return 32;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  50 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  55 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  60 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  65 */     boolean bool1 = d(paramaak, paramInt1, paramInt2, paramInt3 - 1);
/*  66 */     boolean bool2 = d(paramaak, paramInt1, paramInt2, paramInt3 + 1);
/*  67 */     boolean bool3 = d(paramaak, paramInt1 - 1, paramInt2, paramInt3);
/*  68 */     boolean bool4 = d(paramaak, paramInt1 + 1, paramInt2, paramInt3);
/*     */     
/*  70 */     float f1 = 0.25F;
/*  71 */     float f2 = 0.75F;
/*  72 */     float f3 = 0.25F;
/*  73 */     float f4 = 0.75F;
/*  74 */     float f5 = 1.0F;
/*     */     
/*  76 */     if (bool1) {
/*  77 */       f3 = 0.0F;
/*     */     }
/*  79 */     if (bool2) {
/*  80 */       f4 = 1.0F;
/*     */     }
/*  82 */     if (bool3) {
/*  83 */       f1 = 0.0F;
/*     */     }
/*  85 */     if (bool4) {
/*  86 */       f2 = 1.0F;
/*     */     }
/*     */     
/*  89 */     if (bool1 && bool2 && !bool3 && !bool4) {
/*  90 */       f5 = 0.8125F;
/*  91 */       f1 = 0.3125F;
/*  92 */       f2 = 0.6875F;
/*  93 */     } else if (!bool1 && !bool2 && bool3 && bool4) {
/*  94 */       f5 = 0.8125F;
/*  95 */       f3 = 0.3125F;
/*  96 */       f4 = 0.6875F;
/*     */     } 
/*     */     
/*  99 */     a(f1, 0.0F, f3, f2, f5, f4);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 104 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/* 105 */     this.cK = 1.5D;
/* 106 */     return super.b(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean d(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 111 */     int i = paramaak.a(paramInt1, paramInt2, paramInt3);
/* 112 */     if (i == this.cz || i == apa.bz.cz) {
/* 113 */       return true;
/*     */     }
/* 115 */     apa apa1 = apa.r[i];
/* 116 */     if (apa1 != null && 
/* 117 */       apa1.cO.k() && apa1.b()) {
/* 118 */       return (apa1.cO != aif.A);
/*     */     }
/*     */     
/* 121 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 126 */     paramList.add(new wm(paramInt, 1, 0));
/* 127 */     paramList.add(new wm(paramInt, 1, 1));
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/* 132 */     return paramInt;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 137 */     if (paramInt4 == 0) {
/* 138 */       return super.a(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     }
/* 140 */     return true;
/*     */   }
/*     */   
/*     */   public void a(ly paramly) {}
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */