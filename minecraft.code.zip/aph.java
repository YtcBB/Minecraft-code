/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aph
/*     */   extends apa
/*     */ {
/*     */   protected aph(int paramInt) {
/*  12 */     super(paramInt, aif.q);
/*  13 */     b(true);
/*  14 */     a(ve.c);
/*     */   }
/*     */ 
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  19 */     return null;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  24 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  29 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  34 */     return 2;
/*     */   }
/*     */   
/*     */   private boolean m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  38 */     if (paramaab.w(paramInt1, paramInt2, paramInt3)) {
/*  39 */       return true;
/*     */     }
/*  41 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3);
/*  42 */     if (i == apa.bd.cz || i == apa.bF.cz || i == apa.Q.cz || i == apa.cf.cz) {
/*  43 */       return true;
/*     */     }
/*  45 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  50 */     if (paramaab.c(paramInt1 - 1, paramInt2, paramInt3, true))
/*  51 */       return true; 
/*  52 */     if (paramaab.c(paramInt1 + 1, paramInt2, paramInt3, true))
/*  53 */       return true; 
/*  54 */     if (paramaab.c(paramInt1, paramInt2, paramInt3 - 1, true))
/*  55 */       return true; 
/*  56 */     if (paramaab.c(paramInt1, paramInt2, paramInt3 + 1, true))
/*  57 */       return true; 
/*  58 */     if (m(paramaab, paramInt1, paramInt2 - 1, paramInt3)) {
/*  59 */       return true;
/*     */     }
/*     */     
/*  62 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  67 */     int i = paramInt5;
/*     */     
/*  69 */     if (paramInt4 == 1 && m(paramaab, paramInt1, paramInt2 - 1, paramInt3)) i = 5; 
/*  70 */     if (paramInt4 == 2 && paramaab.c(paramInt1, paramInt2, paramInt3 + 1, true)) i = 4; 
/*  71 */     if (paramInt4 == 3 && paramaab.c(paramInt1, paramInt2, paramInt3 - 1, true)) i = 3; 
/*  72 */     if (paramInt4 == 4 && paramaab.c(paramInt1 + 1, paramInt2, paramInt3, true)) i = 2; 
/*  73 */     if (paramInt4 == 5 && paramaab.c(paramInt1 - 1, paramInt2, paramInt3, true)) i = 1;
/*     */     
/*  75 */     return i;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/*  80 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramRandom);
/*  81 */     if (paramaab.h(paramInt1, paramInt2, paramInt3) == 0) a(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  86 */     if (paramaab.h(paramInt1, paramInt2, paramInt3) == 0) {
/*  87 */       if (paramaab.c(paramInt1 - 1, paramInt2, paramInt3, true)) {
/*  88 */         paramaab.b(paramInt1, paramInt2, paramInt3, 1, 2);
/*  89 */       } else if (paramaab.c(paramInt1 + 1, paramInt2, paramInt3, true)) {
/*  90 */         paramaab.b(paramInt1, paramInt2, paramInt3, 2, 2);
/*  91 */       } else if (paramaab.c(paramInt1, paramInt2, paramInt3 - 1, true)) {
/*  92 */         paramaab.b(paramInt1, paramInt2, paramInt3, 3, 2);
/*  93 */       } else if (paramaab.c(paramInt1, paramInt2, paramInt3 + 1, true)) {
/*  94 */         paramaab.b(paramInt1, paramInt2, paramInt3, 4, 2);
/*  95 */       } else if (m(paramaab, paramInt1, paramInt2 - 1, paramInt3)) {
/*  96 */         paramaab.b(paramInt1, paramInt2, paramInt3, 5, 2);
/*     */       } 
/*     */     }
/*  99 */     k(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 104 */     d(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   protected boolean d(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 108 */     if (k(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 109 */       int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 110 */       boolean bool = false;
/*     */       
/* 112 */       if (!paramaab.c(paramInt1 - 1, paramInt2, paramInt3, true) && i == 1) bool = true; 
/* 113 */       if (!paramaab.c(paramInt1 + 1, paramInt2, paramInt3, true) && i == 2) bool = true; 
/* 114 */       if (!paramaab.c(paramInt1, paramInt2, paramInt3 - 1, true) && i == 3) bool = true; 
/* 115 */       if (!paramaab.c(paramInt1, paramInt2, paramInt3 + 1, true) && i == 4) bool = true; 
/* 116 */       if (!m(paramaab, paramInt1, paramInt2 - 1, paramInt3) && i == 5) bool = true;
/*     */       
/* 118 */       if (bool) {
/* 119 */         c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 120 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/* 121 */         return true;
/*     */       } 
/*     */     } else {
/* 124 */       return true;
/*     */     } 
/* 126 */     return false;
/*     */   }
/*     */   
/*     */   protected boolean k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 130 */     if (!c(paramaab, paramInt1, paramInt2, paramInt3)) {
/* 131 */       if (paramaab.a(paramInt1, paramInt2, paramInt3) == this.cz) {
/* 132 */         c(paramaab, paramInt1, paramInt2, paramInt3, paramaab.h(paramInt1, paramInt2, paramInt3), 0);
/* 133 */         paramaab.i(paramInt1, paramInt2, paramInt3);
/*     */       } 
/* 135 */       return false;
/*     */     } 
/* 137 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public ara a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, arc paramarc1, arc paramarc2) {
/* 142 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3) & 0x7;
/*     */     
/* 144 */     float f = 0.15F;
/* 145 */     if (i == 1) {
/* 146 */       a(0.0F, 0.2F, 0.5F - f, f * 2.0F, 0.8F, 0.5F + f);
/* 147 */     } else if (i == 2) {
/* 148 */       a(1.0F - f * 2.0F, 0.2F, 0.5F - f, 1.0F, 0.8F, 0.5F + f);
/* 149 */     } else if (i == 3) {
/* 150 */       a(0.5F - f, 0.2F, 0.0F, 0.5F + f, 0.8F, f * 2.0F);
/* 151 */     } else if (i == 4) {
/* 152 */       a(0.5F - f, 0.2F, 1.0F - f * 2.0F, 0.5F + f, 0.8F, 1.0F);
/*     */     } else {
/* 154 */       f = 0.1F;
/* 155 */       a(0.5F - f, 0.0F, 0.5F - f, 0.5F + f, 0.6F, 0.5F + f);
/*     */     } 
/*     */     
/* 158 */     return super.a(paramaab, paramInt1, paramInt2, paramInt3, paramarc1, paramarc2);
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {
/* 163 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/* 164 */     double d1 = (paramInt1 + 0.5F);
/* 165 */     double d2 = (paramInt2 + 0.7F);
/* 166 */     double d3 = (paramInt3 + 0.5F);
/* 167 */     double d4 = 0.2199999988079071D;
/* 168 */     double d5 = 0.27000001072883606D;
/* 169 */     if (i == 1) {
/* 170 */       paramaab.a("smoke", d1 - d5, d2 + d4, d3, 0.0D, 0.0D, 0.0D);
/* 171 */       paramaab.a("flame", d1 - d5, d2 + d4, d3, 0.0D, 0.0D, 0.0D);
/* 172 */     } else if (i == 2) {
/* 173 */       paramaab.a("smoke", d1 + d5, d2 + d4, d3, 0.0D, 0.0D, 0.0D);
/* 174 */       paramaab.a("flame", d1 + d5, d2 + d4, d3, 0.0D, 0.0D, 0.0D);
/* 175 */     } else if (i == 3) {
/* 176 */       paramaab.a("smoke", d1, d2 + d4, d3 - d5, 0.0D, 0.0D, 0.0D);
/* 177 */       paramaab.a("flame", d1, d2 + d4, d3 - d5, 0.0D, 0.0D, 0.0D);
/* 178 */     } else if (i == 4) {
/* 179 */       paramaab.a("smoke", d1, d2 + d4, d3 + d5, 0.0D, 0.0D, 0.0D);
/* 180 */       paramaab.a("flame", d1, d2 + d4, d3 + d5, 0.0D, 0.0D, 0.0D);
/*     */     } else {
/* 182 */       paramaab.a("smoke", d1, d2, d3, 0.0D, 0.0D, 0.0D);
/* 183 */       paramaab.a("flame", d1, d2, d3, 0.0D, 0.0D, 0.0D);
/*     */     } 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aph.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */