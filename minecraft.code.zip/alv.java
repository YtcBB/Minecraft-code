/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class alv
/*     */   extends akz
/*     */ {
/*  16 */   private lx[] a = new lx[2];
/*     */   
/*     */   public alv(int paramInt) {
/*  19 */     super(paramInt, aif.d);
/*  20 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.375F, 1.0F);
/*  21 */     a(ve.d);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  26 */     a(0.0F, 0.0F, 0.0F, 1.0F, 0.375F, 1.0F);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/*  31 */     return paramaak.h(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void i_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  50 */     if (paramaab.t.f)
/*     */       return; 
/*  52 */     int i = paramaab.h(paramInt1, paramInt2, paramInt3);
/*  53 */     int j = paramaab.b(aam.a, paramInt1, paramInt2, paramInt3) - paramaab.j;
/*  54 */     float f = paramaab.d(1.0F);
/*     */ 
/*     */ 
/*     */     
/*  58 */     if (f < 3.1415927F) {
/*  59 */       f += (0.0F - f) * 0.2F;
/*     */     } else {
/*  61 */       f += (6.2831855F - f) * 0.2F;
/*     */     } 
/*     */     
/*  64 */     j = Math.round(j * kx.b(f));
/*  65 */     if (j < 0) {
/*  66 */       j = 0;
/*     */     }
/*  68 */     if (j > 15) {
/*  69 */       j = 15;
/*     */     }
/*     */     
/*  72 */     if (i != j) {
/*  73 */       paramaab.b(paramInt1, paramInt2, paramInt3, j, 3);
/*     */     }
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  79 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  84 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean f() {
/*  89 */     return true;
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/*  93 */     return new aqb();
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  98 */     if (paramInt1 == 1) {
/*  99 */       return this.a[0];
/*     */     }
/* 101 */     return this.a[1];
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 106 */     this.a[0] = paramly.a("daylightDetector_top");
/* 107 */     this.a[1] = paramly.a("daylightDetector_side");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */