/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class abc
/*    */   extends aav
/*    */ {
/* 13 */   private adj S = new adv(apa.bp.cz, 8);
/*    */   
/*    */   protected abc(int paramInt) {
/* 16 */     super(paramInt);
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/* 21 */     super.a(paramaab, paramRandom, paramInt1, paramInt2);
/*    */ 
/*    */     
/* 24 */     int i = 3 + paramRandom.nextInt(6); int j;
/* 25 */     for (j = 0; j < i; j++) {
/* 26 */       int k = paramInt1 + paramRandom.nextInt(16);
/* 27 */       int m = paramRandom.nextInt(28) + 4;
/* 28 */       int n = paramInt2 + paramRandom.nextInt(16);
/* 29 */       int i1 = paramaab.a(k, m, n);
/* 30 */       if (i1 == apa.x.cz) {
/* 31 */         paramaab.f(k, m, n, apa.bV.cz, 0, 2);
/*    */       }
/*    */     } 
/*    */ 
/*    */     
/* 36 */     for (i = 0; i < 7; i++) {
/* 37 */       j = paramInt1 + paramRandom.nextInt(16);
/* 38 */       int k = paramRandom.nextInt(64);
/* 39 */       int m = paramInt2 + paramRandom.nextInt(16);
/* 40 */       this.S.a(paramaab, paramRandom, j, k, m);
/*    */     } 
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abc.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */