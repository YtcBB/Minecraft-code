/*    */ import net.minecraft.server.MinecraftServer;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class an
/*    */   extends x
/*    */ {
/*    */   public boolean b(ab paramab) {
/* 11 */     return (MinecraftServer.D().I() || super.b(paramab));
/*    */   }
/*    */   
/*    */   public String c() {
/* 15 */     return "seed";
/*    */   }
/*    */ 
/*    */   
/*    */   public int a() {
/* 20 */     return 2;
/*    */   }
/*    */ 
/*    */   
/*    */   public void b(ab paramab, String[] paramArrayOfString) {
/* 25 */     aab aab = (paramab instanceof sq) ? ((sq)paramab).q : MinecraftServer.D().a(0);
/* 26 */     paramab.a("Seed: " + aab.G());
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\an.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */