/*   */ 
/*   */ 
/*   */ 
/*   */ public class anj
/*   */   extends apa
/*   */ {
/*   */   public anj(int paramInt) {
/* 8 */     super(paramInt, aif.f);
/* 9 */     a(ve.b);
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anj.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */