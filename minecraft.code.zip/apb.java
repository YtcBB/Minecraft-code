/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ final class apb
/*    */   extends ape
/*    */ {
/*    */   apb(String paramString, float paramFloat1, float paramFloat2) {
/* 81 */     super(paramString, paramFloat1, paramFloat2);
/*    */   }
/*    */   public String a() {
/* 84 */     return "random.glass";
/*    */   }
/*    */ 
/*    */   
/*    */   public String b() {
/* 89 */     return "step.stone";
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apb.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */