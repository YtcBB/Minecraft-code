/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aln
/*     */   extends akz
/*     */ {
/*  27 */   private final Random b = new Random();
/*     */   public final int a;
/*     */   
/*     */   protected aln(int paramInt1, int paramInt2) {
/*  31 */     super(paramInt1, aif.d);
/*  32 */     this.a = paramInt2;
/*  33 */     a(ve.c);
/*     */     
/*  35 */     a(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c() {
/*  40 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b() {
/*  45 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  50 */     return 22;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/*  55 */     if (paramaak.a(paramInt1, paramInt2, paramInt3 - 1) == this.cz) {
/*  56 */       a(0.0625F, 0.0F, 0.0F, 0.9375F, 0.875F, 0.9375F);
/*  57 */     } else if (paramaak.a(paramInt1, paramInt2, paramInt3 + 1) == this.cz) {
/*  58 */       a(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 1.0F);
/*  59 */     } else if (paramaak.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz) {
/*  60 */       a(0.0F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
/*  61 */     } else if (paramaak.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz) {
/*  62 */       a(0.0625F, 0.0F, 0.0625F, 1.0F, 0.875F, 0.9375F);
/*     */     } else {
/*  64 */       a(0.0625F, 0.0F, 0.0625F, 0.9375F, 0.875F, 0.9375F);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*  70 */     super.a(paramaab, paramInt1, paramInt2, paramInt3);
/*  71 */     f_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     
/*  73 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3 - 1);
/*  74 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3 + 1);
/*  75 */     int k = paramaab.a(paramInt1 - 1, paramInt2, paramInt3);
/*  76 */     int m = paramaab.a(paramInt1 + 1, paramInt2, paramInt3);
/*  77 */     if (i == this.cz) f_(paramaab, paramInt1, paramInt2, paramInt3 - 1); 
/*  78 */     if (j == this.cz) f_(paramaab, paramInt1, paramInt2, paramInt3 + 1); 
/*  79 */     if (k == this.cz) f_(paramaab, paramInt1 - 1, paramInt2, paramInt3); 
/*  80 */     if (m == this.cz) f_(paramaab, paramInt1 + 1, paramInt2, paramInt3);
/*     */   
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {
/*  85 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3 - 1);
/*  86 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3 + 1);
/*  87 */     int k = paramaab.a(paramInt1 - 1, paramInt2, paramInt3);
/*  88 */     int m = paramaab.a(paramInt1 + 1, paramInt2, paramInt3);
/*     */     
/*  90 */     byte b = 0;
/*  91 */     int n = kx.c((paramng.A * 4.0F / 360.0F) + 0.5D) & 0x3;
/*     */     
/*  93 */     if (n == 0) b = 2; 
/*  94 */     if (n == 1) b = 5; 
/*  95 */     if (n == 2) b = 3; 
/*  96 */     if (n == 3) b = 4;
/*     */     
/*  98 */     if (i != this.cz && j != this.cz && k != this.cz && m != this.cz) {
/*  99 */       paramaab.b(paramInt1, paramInt2, paramInt3, b, 3);
/*     */     } else {
/* 101 */       if ((i == this.cz || j == this.cz) && (b == 4 || b == 5)) {
/* 102 */         if (i == this.cz) { paramaab.b(paramInt1, paramInt2, paramInt3 - 1, b, 3); }
/* 103 */         else { paramaab.b(paramInt1, paramInt2, paramInt3 + 1, b, 3); }
/* 104 */          paramaab.b(paramInt1, paramInt2, paramInt3, b, 3);
/*     */       } 
/* 106 */       if ((k == this.cz || m == this.cz) && (b == 2 || b == 3)) {
/* 107 */         if (k == this.cz) { paramaab.b(paramInt1 - 1, paramInt2, paramInt3, b, 3); }
/* 108 */         else { paramaab.b(paramInt1 + 1, paramInt2, paramInt3, b, 3); }
/* 109 */          paramaab.b(paramInt1, paramInt2, paramInt3, b, 3);
/*     */       } 
/*     */     } 
/*     */     
/* 113 */     if (paramwm.t()) {
/* 114 */       ((apy)paramaab.r(paramInt1, paramInt2, paramInt3)).a(paramwm.s());
/*     */     }
/*     */   }
/*     */   
/*     */   public void f_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 119 */     if (paramaab.I) {
/*     */       return;
/*     */     }
/*     */     
/* 123 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3 - 1);
/* 124 */     int j = paramaab.a(paramInt1, paramInt2, paramInt3 + 1);
/* 125 */     int k = paramaab.a(paramInt1 - 1, paramInt2, paramInt3);
/* 126 */     int m = paramaab.a(paramInt1 + 1, paramInt2, paramInt3);
/*     */ 
/*     */     
/* 129 */     byte b = 4;
/* 130 */     if (i == this.cz || j == this.cz) {
/* 131 */       int n = paramaab.a(paramInt1 - 1, paramInt2, (i == this.cz) ? (paramInt3 - 1) : (paramInt3 + 1));
/* 132 */       int i1 = paramaab.a(paramInt1 + 1, paramInt2, (i == this.cz) ? (paramInt3 - 1) : (paramInt3 + 1));
/*     */       
/* 134 */       b = 5;
/*     */       
/* 136 */       int i2 = -1;
/* 137 */       if (i == this.cz) { i2 = paramaab.h(paramInt1, paramInt2, paramInt3 - 1); }
/* 138 */       else { i2 = paramaab.h(paramInt1, paramInt2, paramInt3 + 1); }
/* 139 */        if (i2 == 4) b = 4;
/*     */       
/* 141 */       if ((apa.s[k] || apa.s[n]) && !apa.s[m] && !apa.s[i1]) b = 5; 
/* 142 */       if ((apa.s[m] || apa.s[i1]) && !apa.s[k] && !apa.s[n]) b = 4; 
/* 143 */     } else if (k == this.cz || m == this.cz) {
/* 144 */       int n = paramaab.a((k == this.cz) ? (paramInt1 - 1) : (paramInt1 + 1), paramInt2, paramInt3 - 1);
/* 145 */       int i1 = paramaab.a((k == this.cz) ? (paramInt1 - 1) : (paramInt1 + 1), paramInt2, paramInt3 + 1);
/*     */       
/* 147 */       b = 3;
/* 148 */       int i2 = -1;
/* 149 */       if (k == this.cz) { i2 = paramaab.h(paramInt1 - 1, paramInt2, paramInt3); }
/* 150 */       else { i2 = paramaab.h(paramInt1 + 1, paramInt2, paramInt3); }
/* 151 */        if (i2 == 2) b = 2;
/*     */       
/* 153 */       if ((apa.s[i] || apa.s[n]) && !apa.s[j] && !apa.s[i1]) b = 3; 
/* 154 */       if ((apa.s[j] || apa.s[i1]) && !apa.s[i] && !apa.s[n]) b = 2; 
/*     */     } else {
/* 156 */       b = 3;
/* 157 */       if (apa.s[i] && !apa.s[j]) b = 3; 
/* 158 */       if (apa.s[j] && !apa.s[i]) b = 2; 
/* 159 */       if (apa.s[k] && !apa.s[m]) b = 5; 
/* 160 */       if (apa.s[m] && !apa.s[k]) b = 4;
/*     */     
/*     */     } 
/* 163 */     paramaab.b(paramInt1, paramInt2, paramInt3, b, 3);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 168 */     byte b = 0;
/*     */     
/* 170 */     if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz) b++; 
/* 171 */     if (paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz) b++; 
/* 172 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == this.cz) b++; 
/* 173 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == this.cz) b++;
/*     */     
/* 175 */     if (b > 1) return false;
/*     */     
/* 177 */     if (k(paramaab, paramInt1 - 1, paramInt2, paramInt3)) return false; 
/* 178 */     if (k(paramaab, paramInt1 + 1, paramInt2, paramInt3)) return false; 
/* 179 */     if (k(paramaab, paramInt1, paramInt2, paramInt3 - 1)) return false; 
/* 180 */     if (k(paramaab, paramInt1, paramInt2, paramInt3 + 1)) return false; 
/* 181 */     return true;
/*     */   }
/*     */   
/*     */   private boolean k(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 185 */     if (paramaab.a(paramInt1, paramInt2, paramInt3) != this.cz) return false; 
/* 186 */     if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz) return true; 
/* 187 */     if (paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz) return true; 
/* 188 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == this.cz) return true; 
/* 189 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == this.cz) return true; 
/* 190 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 195 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/* 196 */     apy apy = (apy)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 197 */     if (apy != null) apy.i();
/*     */   
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 202 */     apy apy = (apy)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 203 */     if (apy != null) {
/* 204 */       for (byte b = 0; b < apy.j_(); b++) {
/* 205 */         wm wm = apy.a(b);
/* 206 */         if (wm != null) {
/* 207 */           float f1 = this.b.nextFloat() * 0.8F + 0.1F;
/* 208 */           float f2 = this.b.nextFloat() * 0.8F + 0.1F;
/* 209 */           float f3 = this.b.nextFloat() * 0.8F + 0.1F;
/*     */           
/* 211 */           while (wm.a > 0) {
/* 212 */             int i = this.b.nextInt(21) + 10;
/* 213 */             if (i > wm.a) i = wm.a; 
/* 214 */             wm.a -= i;
/*     */             
/* 216 */             rh rh = new rh(paramaab, (paramInt1 + f1), (paramInt2 + f2), (paramInt3 + f3), new wm(wm.c, i, wm.k()));
/* 217 */             float f = 0.05F;
/* 218 */             rh.x = ((float)this.b.nextGaussian() * f);
/* 219 */             rh.y = ((float)this.b.nextGaussian() * f + 0.2F);
/* 220 */             rh.z = ((float)this.b.nextGaussian() * f);
/* 221 */             if (wm.p()) {
/* 222 */               rh.d().d((bs)wm.q().b());
/*     */             }
/* 224 */             paramaab.d(rh);
/*     */           } 
/*     */         } 
/*     */       } 
/* 228 */       paramaab.m(paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     } 
/* 230 */     super.a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, paramInt5);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 235 */     if (paramaab.I) return true; 
/* 236 */     lt lt = g_(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     
/* 238 */     if (lt != null) {
/* 239 */       paramsq.a(lt);
/*     */     }
/*     */     
/* 242 */     return true;
/*     */   }
/*     */   public lt g_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/*     */     ls ls;
/* 246 */     apy apy = (apy)paramaab.r(paramInt1, paramInt2, paramInt3);
/* 247 */     if (apy == null) return null;
/*     */     
/* 249 */     if (paramaab.u(paramInt1, paramInt2 + 1, paramInt3)) return null; 
/* 250 */     if (m(paramaab, paramInt1, paramInt2, paramInt3)) return null;
/*     */     
/* 252 */     if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz && (paramaab.u(paramInt1 - 1, paramInt2 + 1, paramInt3) || m(paramaab, paramInt1 - 1, paramInt2, paramInt3))) return null; 
/* 253 */     if (paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz && (paramaab.u(paramInt1 + 1, paramInt2 + 1, paramInt3) || m(paramaab, paramInt1 + 1, paramInt2, paramInt3))) return null; 
/* 254 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == this.cz && (paramaab.u(paramInt1, paramInt2 + 1, paramInt3 - 1) || m(paramaab, paramInt1, paramInt2, paramInt3 - 1))) return null; 
/* 255 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == this.cz && (paramaab.u(paramInt1, paramInt2 + 1, paramInt3 + 1) || m(paramaab, paramInt1, paramInt2, paramInt3 + 1))) return null;
/*     */     
/* 257 */     if (paramaab.a(paramInt1 - 1, paramInt2, paramInt3) == this.cz) ls = new ls("container.chestDouble", (apy)paramaab.r(paramInt1 - 1, paramInt2, paramInt3), apy); 
/* 258 */     if (paramaab.a(paramInt1 + 1, paramInt2, paramInt3) == this.cz) ls = new ls("container.chestDouble", ls, (apy)paramaab.r(paramInt1 + 1, paramInt2, paramInt3)); 
/* 259 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 - 1) == this.cz) ls = new ls("container.chestDouble", (apy)paramaab.r(paramInt1, paramInt2, paramInt3 - 1), ls); 
/* 260 */     if (paramaab.a(paramInt1, paramInt2, paramInt3 + 1) == this.cz) ls = new ls("container.chestDouble", ls, (apy)paramaab.r(paramInt1, paramInt2, paramInt3 + 1));
/*     */     
/* 262 */     return ls;
/*     */   }
/*     */   
/*     */   public aqp b(aab paramaab) {
/* 266 */     return new apy();
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean f() {
/* 272 */     return (this.a == 1);
/*     */   }
/*     */ 
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 277 */     if (!f()) return 0;
/*     */     
/* 279 */     int i = ((apy)paramaak.r(paramInt1, paramInt2, paramInt3)).h;
/* 280 */     return kx.a(i, 0, 15);
/*     */   }
/*     */ 
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 285 */     if (paramInt4 == 1) {
/* 286 */       return b(paramaak, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */     }
/* 288 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   private static boolean m(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 293 */     for (qm qm1 : paramaab.a(qm.class, aqx.a().a(paramInt1, (paramInt2 + 1), paramInt3, (paramInt1 + 1), (paramInt2 + 2), (paramInt3 + 1)))) {
/* 294 */       qm qm2 = qm1;
/* 295 */       if (qm2.n()) return true; 
/*     */     } 
/* 297 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean q_() {
/* 302 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 307 */     return tj.b(g_(paramaab, paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 314 */     this.cQ = paramly.a("wood");
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aln.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */