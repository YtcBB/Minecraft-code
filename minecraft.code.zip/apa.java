/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apa
/*     */ {
/*     */   private ve a;
/*  75 */   public static final ape f = new ape("stone", 1.0F, 1.0F);
/*  76 */   public static final ape g = new ape("wood", 1.0F, 1.0F);
/*  77 */   public static final ape h = new ape("gravel", 1.0F, 1.0F);
/*  78 */   public static final ape i = new ape("grass", 1.0F, 1.0F);
/*  79 */   public static final ape j = new ape("stone", 1.0F, 1.0F);
/*  80 */   public static final ape k = new ape("stone", 1.0F, 1.5F);
/*  81 */   public static final ape l = new apb("stone", 1.0F, 1.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*  92 */   public static final ape m = new ape("cloth", 1.0F, 1.0F);
/*  93 */   public static final ape n = new ape("sand", 1.0F, 1.0F);
/*  94 */   public static final ape o = new ape("snow", 1.0F, 1.0F);
/*  95 */   public static final ape p = new apc("ladder", 1.0F, 1.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 101 */   public static final ape q = new apd("anvil", 0.3F, 1.0F);
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/* 157 */   public static final apa[] r = new apa[4096];
/*     */   
/* 159 */   public static final boolean[] s = new boolean[4096];
/* 160 */   public static final int[] t = new int[4096];
/* 161 */   public static final boolean[] u = new boolean[4096];
/* 162 */   public static final int[] v = new int[4096];
/* 163 */   public static boolean[] w = new boolean[4096];
/*     */   
/* 165 */   public static final apa x = (new aov(1)).c(1.5F).b(10.0F).a(j).c("stone");
/* 166 */   public static final amp y = (amp)(new amp(2)).c(0.6F).a(i).c("grass");
/* 167 */   public static final apa z = (new ama(3)).c(0.5F).a(h).c("dirt");
/* 168 */   public static final apa A = (new apa(4, aif.e)).c(2.0F).b(10.0F).a(j).c("stonebrick").a(ve.b);
/*     */   
/* 170 */   public static final apa B = (new apu(5)).c(2.0F).b(5.0F).a(g).c("wood");
/* 171 */   public static final apa C = (new aok(6)).c(0.0F).a(i).c("sapling");
/* 172 */   public static final apa D = (new apa(7, aif.e)).r().b(6000000.0F).a(j).c("bedrock").D().a(ve.b);
/*     */   
/* 174 */   public static final ane E = (ane)(new anf(8, aif.h)).c(100.0F).k(3).c("water").D();
/* 175 */   public static final apa F = (new ang(9, aif.h)).c(100.0F).k(3).c("water").D();
/* 176 */   public static final ane G = (ane)(new anf(10, aif.i)).c(0.0F).a(1.0F).c("lava").D();
/*     */   
/* 178 */   public static final apa H = (new ang(11, aif.i)).c(100.0F).a(1.0F).c("lava").D();
/* 179 */   public static final apa I = (new amt(12)).c(0.5F).a(n).c("sand");
/* 180 */   public static final apa J = (new amq(13)).c(0.6F).a(h).c("gravel");
/* 181 */   public static final apa K = (new ans(14)).c(3.0F).b(5.0F).a(j).c("oreGold");
/* 182 */   public static final apa L = (new ans(15)).c(3.0F).b(5.0F).a(j).c("oreIron");
/* 183 */   public static final apa M = (new ans(16)).c(3.0F).b(5.0F).a(j).c("oreCoal");
/* 184 */   public static final apa N = (new apk(17)).c(2.0F).a(g).c("log");
/* 185 */   public static final ana O = (ana)(new ana(18)).c(0.2F).k(1).a(i).c("leaves");
/* 186 */   public static final apa P = (new aop(19)).c(0.6F).a(i).c("sponge");
/* 187 */   public static final apa Q = (new amo(20, aif.r, false)).c(0.3F).a(l).c("glass");
/* 188 */   public static final apa R = (new ans(21)).c(3.0F).b(5.0F).a(j).c("oreLapis");
/* 189 */   public static final apa S = (new apa(22, aif.e)).c(3.0F).b(5.0F).a(j).c("blockLapis").a(ve.b);
/*     */   
/* 191 */   public static final apa T = (new amb(23)).c(3.5F).a(j).c("dispenser");
/* 192 */   public static final apa U = (new aoj(24)).a(j).c(0.8F).c("sandStone");
/* 193 */   public static final apa V = (new anm(25)).c(0.8F).c("musicBlock");
/* 194 */   public static final apa W = (new ale(26)).c(0.2F).c("bed").D();
/* 195 */   public static final apa X = (new anw(27)).c(0.7F).a(k).c("goldenRail");
/* 196 */   public static final apa Y = (new alx(28)).c(0.7F).a(k).c("detectorRail");
/* 197 */   public static final aqt Z = (aqt)(new aqt(29, true)).c("pistonStickyBase");
/* 198 */   public static final apa aa = (new apq(30)).k(1).c(4.0F).c("web");
/* 199 */   public static final aow ab = (aow)(new aow(31)).c(0.0F).a(i).c("tallgrass");
/* 200 */   public static final alw ac = (alw)(new alw(32)).c(0.0F).a(i).c("deadbush");
/* 201 */   public static final aqt ad = (aqt)(new aqt(33, false)).c("pistonBase");
/* 202 */   public static final aqu ae = new aqu(34);
/* 203 */   public static final apa af = (new alp()).c(0.8F).a(m).c("cloth");
/* 204 */   public static final aqv ag = new aqv(36);
/* 205 */   public static final alh ah = (alh)(new alh(37)).c(0.0F).a(i).c("flower");
/* 206 */   public static final alh ai = (alh)(new alh(38)).c(0.0F).a(i).c("rose");
/* 207 */   public static final alh aj = (alh)(new anl(39, "mushroom_brown")).c(0.0F).a(i).a(0.125F).c("mushroom");
/* 208 */   public static final alh ak = (alh)(new anl(40, "mushroom_red")).c(0.0F).a(i).c("mushroom");
/* 209 */   public static final apa al = (new anj(41)).c(3.0F).b(10.0F).a(k).c("blockGold");
/* 210 */   public static final apa am = (new anj(42)).c(5.0F).b(10.0F).a(k).c("blockIron");
/* 211 */   public static final amr an = (amr)(new aou(43, true)).c(2.0F).b(10.0F).a(j).c("stoneSlab");
/* 212 */   public static final amr ao = (amr)(new aou(44, false)).c(2.0F).b(10.0F).a(j).c("stoneSlab");
/* 213 */   public static final apa ap = (new apa(45, aif.e)).c(2.0F).b(10.0F).a(j).c("brick").a(ve.b);
/*     */   
/* 215 */   public static final apa aq = (new apf(46)).c(0.0F).a(i).c("tnt");
/* 216 */   public static final apa ar = (new alf(47)).c(1.5F).a(g).c("bookshelf");
/* 217 */   public static final apa as = (new apa(48, aif.e)).c(2.0F).b(10.0F).a(j).c("stoneMoss").a(ve.b);
/*     */   
/* 219 */   public static final apa at = (new anr(49)).c(50.0F).b(2000.0F).a(j).c("obsidian");
/* 220 */   public static final apa au = (new aph(50)).c(0.0F).a(0.9375F).a(g).c("torch");
/* 221 */   public static final aml av = (aml)(new aml(51)).c(0.0F).a(1.0F).a(g).c("fire").D();
/* 222 */   public static final apa aw = (new ank(52)).c(5.0F).a(k).c("mobSpawner").D();
/* 223 */   public static final apa ax = (new aoq(53, B, 0)).c("stairsWood");
/* 224 */   public static final aln ay = (aln)(new aln(54, 0)).c(2.5F).a(g).c("chest");
/* 225 */   public static final aoe az = (aoe)(new aoe(55)).c(0.0F).a(f).c("redstoneDust").D();
/*     */   
/* 227 */   public static final apa aA = (new ans(56)).c(3.0F).b(5.0F).a(j).c("oreDiamond");
/* 228 */   public static final apa aB = (new anj(57)).c(5.0F).b(10.0F).a(k).c("blockDiamond");
/* 229 */   public static final apa aC = (new apv(58)).c(2.5F).a(g).c("workbench");
/* 230 */   public static final apa aD = (new alu(59)).c("crops");
/* 231 */   public static final apa aE = (new ami(60)).c(0.6F).a(h).c("farmland");
/* 232 */   public static final apa aF = (new amn(61, false)).c(3.5F).a(j).c("furnace").a(ve.c);
/* 233 */   public static final apa aG = (new amn(62, true)).c(3.5F).a(j).a(0.875F).c("furnace");
/* 234 */   public static final apa aH = (new aol(63, aqm.class, true)).c(1.0F).a(g).c("sign").D();
/* 235 */   public static final apa aI = (new amc(64, aif.d)).c(3.0F).a(g).c("doorWood").D();
/* 236 */   public static final apa aJ = (new amz(65)).c(0.4F).a(p).c("ladder");
/* 237 */   public static final apa aK = (new aob(66)).c(0.7F).a(k).c("rail");
/* 238 */   public static final apa aL = (new aoq(67, A, 0)).c("stairsStone");
/* 239 */   public static final apa aM = (new aol(68, aqm.class, false)).c(1.0F).a(g).c("sign").D();
/* 240 */   public static final apa aN = (new anc(69)).c(0.5F).a(g).c("lever");
/* 241 */   public static final apa aO = (new anx(70, "stone", aif.e, any.b)).c(0.5F).a(j).c("pressurePlate");
/*     */   
/* 243 */   public static final apa aP = (new amc(71, aif.f)).c(5.0F).a(k).c("doorIron").D();
/* 244 */   public static final apa aQ = (new anx(72, "wood", aif.d, any.a)).c(0.5F).a(g).c("pressurePlate");
/*     */   
/* 246 */   public static final apa aR = (new aof(73, false)).c(3.0F).b(5.0F).a(j).c("oreRedstone").a(ve.b);
/*     */   
/* 248 */   public static final apa aS = (new aof(74, true)).a(0.625F).c(3.0F).b(5.0F).a(j).c("oreRedstone");
/*     */   
/* 250 */   public static final apa aT = (new anp(75, false)).c(0.0F).a(g).c("notGate");
/* 251 */   public static final apa aU = (new anp(76, true)).c(0.0F).a(0.5F).a(g).c("notGate").a(ve.d);
/*     */   
/* 253 */   public static final apa aV = (new aos(77)).c(0.5F).a(j).c("button");
/* 254 */   public static final apa aW = (new apg(78)).c(0.1F).a(o).c("snow").k(0);
/* 255 */   public static final apa aX = (new amy(79)).c(0.5F).k(3).a(l).c("ice");
/* 256 */   public static final apa aY = (new aoo(80)).c(0.2F).a(o).c("snow");
/* 257 */   public static final apa aZ = (new alj(81)).c(0.4F).a(m).c("cactus");
/* 258 */   public static final apa ba = (new alo(82)).c(0.6F).a(h).c("clay");
/* 259 */   public static final apa bb = (new aoh(83)).c(0.0F).a(i).c("reeds").D();
/* 260 */   public static final apa bc = (new aoc(84)).c(2.0F).b(10.0F).a(j).c("jukebox");
/* 261 */   public static final apa bd = (new amk(85, "wood", aif.d)).c(2.0F).b(5.0F).a(g).c("fence");
/* 262 */   public static final apa be = (new anz(86, false)).c(1.0F).a(g).c("pumpkin");
/* 263 */   public static final apa bf = (new amv(87)).c(0.4F).a(j).c("hellrock");
/* 264 */   public static final apa bg = (new amu(88)).c(0.5F).a(n).c("hellsand");
/* 265 */   public static final apa bh = (new and(89, aif.r)).c(0.3F).a(l).a(1.0F).c("lightgem");
/* 266 */   public static final ant bi = (ant)(new ant(90)).c(-1.0F).a(l).a(0.75F).c("portal");
/* 267 */   public static final apa bj = (new anz(91, true)).c(1.0F).a(g).a(1.0F).c("litpumpkin");
/* 268 */   public static final apa bk = (new alk(92)).c(0.5F).a(m).c("cake").D();
/* 269 */   public static final aoi bl = (aoi)(new aoi(93, false)).c(0.0F).a(g).c("diode").D();
/* 270 */   public static final aoi bm = (aoi)(new aoi(94, true)).c(0.0F).a(0.625F).a(g).c("diode").D();
/*     */   
/* 272 */   public static final apa bn = (new anh(95)).c(0.0F).a(1.0F).a(g).c("lockedchest").b(true);
/* 273 */   public static final apa bo = (new apj(96, aif.d)).c(3.0F).a(g).c("trapdoor").D();
/*     */   
/* 275 */   public static final apa bp = (new aot(97)).c(0.75F).c("monsterStoneEgg");
/* 276 */   public static final apa bq = (new aon(98)).c(1.5F).b(10.0F).a(j).c("stonebricksmooth");
/* 277 */   public static final apa br = (new amx(99, aif.d, 0)).c(0.2F).a(g).c("mushroom");
/* 278 */   public static final apa bs = (new amx(100, aif.d, 1)).c(0.2F).a(g).c("mushroom");
/* 279 */   public static final apa bt = (new aoz(101, "fenceIron", "fenceIron", aif.f, true)).c(5.0F).b(10.0F).a(k).c("fenceIron");
/*     */   
/* 281 */   public static final apa bu = (new aoz(102, "glass", "thinglass_top", aif.r, false)).c(0.3F).a(l).c("thinGlass");
/* 282 */   public static final apa bv = (new ani(103)).c(1.0F).a(g).c("melon");
/* 283 */   public static final apa bw = (new aor(104, be)).c(0.0F).a(g).c("pumpkinStem");
/* 284 */   public static final apa bx = (new aor(105, bv)).c(0.0F).a(g).c("pumpkinStem");
/* 285 */   public static final apa by = (new apn(106)).c(0.2F).a(i).c("vine");
/* 286 */   public static final apa bz = (new amj(107)).c(2.0F).b(5.0F).a(g).c("fenceGate");
/* 287 */   public static final apa bA = (new aoq(108, ap, 0)).c("stairsBrick");
/* 288 */   public static final apa bB = (new aoq(109, bq, 0)).c("stairsStoneBrickSmooth");
/* 289 */   public static final ann bC = (ann)(new ann(110)).c(0.6F).a(i).c("mycel");
/* 290 */   public static final apa bD = (new app(111)).c(0.0F).a(i).c("waterlily");
/* 291 */   public static final apa bE = (new apa(112, aif.e)).c(2.0F).b(10.0F).a(j).c("netherBrick").a(ve.b);
/*     */   
/* 293 */   public static final apa bF = (new amk(113, "netherBrick", aif.e)).c(2.0F).b(10.0F).a(j).c("netherFence");
/* 294 */   public static final apa bG = (new aoq(114, bE, 0)).c("stairsNetherBrick");
/* 295 */   public static final apa bH = (new ano(115)).c("netherStalk");
/* 296 */   public static final apa bI = (new amf(116)).c(5.0F).b(2000.0F).c("enchantmentTable");
/* 297 */   public static final apa bJ = (new alg(117)).c(0.5F).a(0.125F).c("brewingStand");
/* 298 */   public static final alm bK = (alm)(new alm(118)).c(2.0F).c("cauldron");
/* 299 */   public static final apa bL = (new aox(119, aif.C)).c(-1.0F).b(6000000.0F);
/* 300 */   public static final apa bM = (new aoy(120)).a(l).a(0.125F).c(-1.0F).c("endPortalFrame").b(6000000.0F).a(ve.c);
/*     */   
/* 302 */   public static final apa bN = (new apa(121, aif.e)).c(3.0F).b(15.0F).a(j).c("whiteStone").a(ve.b);
/*     */   
/* 304 */   public static final apa bO = (new ame(122)).c(3.0F).b(15.0F).a(j).a(0.125F).c("dragonEgg");
/*     */   
/* 306 */   public static final apa bP = (new aog(123, false)).c(0.3F).a(l).c("redstoneLight").a(ve.d);
/*     */   
/* 308 */   public static final apa bQ = (new aog(124, true)).c(0.3F).a(l).c("redstoneLight");
/*     */   
/* 310 */   public static final amr bR = (amr)(new apt(125, true)).c(2.0F).b(5.0F).a(g).c("woodSlab");
/* 311 */   public static final amr bS = (amr)(new apt(126, false)).c(2.0F).b(5.0F).a(g).c("woodSlab");
/*     */   
/* 313 */   public static final apa bT = (new alq(127)).c(0.2F).b(5.0F).a(g).c("cocoa");
/* 314 */   public static final apa bU = (new aoq(128, U, 0)).c("stairsSandStone");
/* 315 */   public static final apa bV = (new ans(129)).c(3.0F).b(5.0F).a(j).c("oreEmerald");
/* 316 */   public static final apa bW = (new amg(130)).c(22.5F).b(1000.0F).a(j).c("enderChest").a(0.5F);
/* 317 */   public static final apl bX = (apl)(new apl(131)).c("tripWireSource");
/* 318 */   public static final apa bY = (new apm(132)).c("tripWire");
/* 319 */   public static final apa bZ = (new anj(133)).c(5.0F).b(10.0F).a(k).c("blockEmerald");
/* 320 */   public static final apa ca = (new aoq(134, B, 1)).c("stairsWoodSpruce");
/* 321 */   public static final apa cb = (new aoq(135, B, 2)).c("stairsWoodBirch");
/* 322 */   public static final apa cc = (new aoq(136, B, 3)).c("stairsWoodJungle");
/*     */   
/* 324 */   public static final apa cd = (new alr(137)).c("commandBlock");
/*     */   
/* 326 */   public static final ald ce = (ald)(new ald(138)).c("beacon").a(1.0F);
/* 327 */   public static final apa cf = (new apo(139, A)).c("cobbleWall");
/* 328 */   public static final apa cg = (new amm(140)).c(0.0F).a(f).c("flowerPot");
/* 329 */   public static final apa ch = (new all(141)).c("carrots");
/* 330 */   public static final apa ci = (new anu(142)).c("potatoes");
/* 331 */   public static final apa cj = (new aps(143)).c(0.5F).a(g).c("button");
/* 332 */   public static final apa ck = (new aom(144)).c(1.0F).a(j).c("skull");
/* 333 */   public static final apa cl = (new aky(145)).c(5.0F).a(q).b(2000.0F).c("anvil");
/* 334 */   public static final apa cm = (new aln(146, 1)).c(2.5F).a(g).c("chestTrap");
/* 335 */   public static final apa cn = (new apr(147, "blockGold", aif.f, 64)).c(0.5F).a(g).c("weightedPlate_light");
/*     */   
/* 337 */   public static final apa co = (new apr(148, "blockIron", aif.f, 640)).c(0.5F).a(g).c("weightedPlate_heavy");
/*     */   
/* 339 */   public static final als cp = (als)(new als(149, false)).c(0.0F).a(g).c("comparator").D();
/*     */   
/* 341 */   public static final als cq = (als)(new als(150, true)).c(0.0F).a(0.625F).a(g).c("comparator").D();
/*     */   
/* 343 */   public static final alv cr = (alv)(new alv(151)).c(0.2F).a(g).c("daylightDetector");
/* 344 */   public static final apa cs = (new anv(152)).c(5.0F).b(10.0F).a(k).c("blockRedstone");
/* 345 */   public static final apa ct = (new ans(153)).c(3.0F).b(5.0F).a(j).c("netherquartz");
/* 346 */   public static final amw cu = (amw)(new amw(154)).c(3.0F).b(8.0F).a(g).c("hopper");
/*     */   
/* 348 */   public static final apa cv = (new aoa(155)).a(j).c(0.8F).c("quartzBlock");
/* 349 */   public static final apa cw = (new aoq(156, cv, 0)).c("stairsQuartz");
/* 350 */   public static final apa cx = (new anw(157)).c(0.7F).a(k).c("activatorRail");
/* 351 */   public static final apa cy = (new amd(158)).c(3.5F).a(j).c("dropper");
/*     */   public final int cz;
/*     */   
/*     */   static {
/* 355 */     wk.f[af.cz] = (new va(af.cz - 256)).b("cloth");
/* 356 */     wk.f[N.cz] = (new wt(N.cz - 256, N, apk.a)).b("log");
/* 357 */     wk.f[B.cz] = (new wt(B.cz - 256, B, apu.a)).b("wood");
/* 358 */     wk.f[bp.cz] = (new wt(bp.cz - 256, bp, aot.a)).b("monsterStoneEgg");
/* 359 */     wk.f[bq.cz] = (new wt(bq.cz - 256, bq, aon.a)).b("stonebricksmooth");
/* 360 */     wk.f[U.cz] = (new wt(U.cz - 256, U, aoj.a)).b("sandStone");
/* 361 */     wk.f[cv.cz] = (new wt(cv.cz - 256, cv, aoa.a)).b("quartzBlock");
/* 362 */     wk.f[ao.cz] = (new xm(ao.cz - 256, ao, an, false)).b("stoneSlab");
/* 363 */     wk.f[an.cz] = (new xm(an.cz - 256, ao, an, true)).b("stoneSlab");
/* 364 */     wk.f[bS.cz] = (new xm(bS.cz - 256, bS, bR, false)).b("woodSlab");
/* 365 */     wk.f[bR.cz] = (new xm(bR.cz - 256, bS, bR, true)).b("woodSlab");
/* 366 */     wk.f[C.cz] = (new wt(C.cz - 256, C, aok.a)).b("sapling");
/* 367 */     wk.f[O.cz] = (new wn(O.cz - 256)).b("leaves");
/* 368 */     wk.f[by.cz] = new vc(by.cz - 256, false);
/* 369 */     wk.f[ab.cz] = (new vc(ab.cz - 256, true)).a(new String[] { "shrub", "grass", "fern" });
/*     */ 
/*     */     
/* 372 */     wk.f[aW.cz] = new xj(aW.cz - 256, aW);
/* 373 */     wk.f[bD.cz] = new xq(bD.cz - 256);
/* 374 */     wk.f[ad.cz] = new wv(ad.cz - 256);
/* 375 */     wk.f[Z.cz] = new wv(Z.cz - 256);
/* 376 */     wk.f[cf.cz] = (new wt(cf.cz - 256, cf, apo.a)).b("cobbleWall");
/* 377 */     wk.f[cl.cz] = (new un(cl)).b("anvil");
/* 378 */     for (byte b = 0; b < 'Ā'; b++) {
/* 379 */       if (r[b] != null) {
/* 380 */         if (wk.f[b] == null) {
/* 381 */           wk.f[b] = new xn(b - 256);
/* 382 */           r[b].s_();
/*     */         } 
/*     */         
/* 385 */         boolean bool = false;
/* 386 */         if (b > 0 && r[b].d() == 10) bool = true; 
/* 387 */         if (b > 0 && r[b] instanceof amr) {
/* 388 */           bool = true;
/*     */         }
/* 390 */         if (b == aE.cz) bool = true; 
/* 391 */         if (u[b]) {
/* 392 */           bool = true;
/*     */         }
/* 394 */         if (t[b] == 0) {
/* 395 */           bool = true;
/*     */         }
/* 397 */         w[b] = bool;
/*     */       } 
/*     */     } 
/* 400 */     u[0] = true;
/*     */     
/* 402 */     kf.b();
/*     */   }
/*     */   protected float cA; protected float cB;
/*     */   protected boolean cC = true;
/*     */   protected boolean cD = true;
/*     */   protected boolean cE;
/*     */   protected boolean cF;
/*     */   protected double cG;
/*     */   protected double cH;
/*     */   protected double cI;
/*     */   protected double cJ;
/*     */   protected double cK;
/*     */   protected double cL;
/* 415 */   public ape cM = f;
/*     */   
/* 417 */   public float cN = 1.0F;
/*     */   public final aif cO;
/* 419 */   public float cP = 0.6F;
/*     */   
/*     */   private String b;
/*     */   protected lx cQ;
/*     */   
/*     */   protected apa(int paramInt, aif paramaif) {
/* 425 */     if (r[paramInt] != null) {
/* 426 */       throw new IllegalArgumentException("Slot " + paramInt + " is already occupied by " + r[paramInt] + " when adding " + this);
/*     */     }
/* 428 */     this.cO = paramaif;
/* 429 */     r[paramInt] = this;
/* 430 */     this.cz = paramInt;
/* 431 */     a(0.0F, 0.0F, 0.0F, 1.0F, 1.0F, 1.0F);
/* 432 */     s[paramInt] = c();
/* 433 */     t[paramInt] = c() ? 255 : 0;
/* 434 */     u[paramInt] = !paramaif.b();
/*     */   }
/*     */ 
/*     */   
/*     */   protected void s_() {}
/*     */   
/*     */   protected apa a(ape paramape) {
/* 441 */     this.cM = paramape;
/* 442 */     return this;
/*     */   }
/*     */   
/*     */   protected apa k(int paramInt) {
/* 446 */     t[this.cz] = paramInt;
/* 447 */     return this;
/*     */   }
/*     */   
/*     */   protected apa a(float paramFloat) {
/* 451 */     v[this.cz] = (int)(15.0F * paramFloat);
/* 452 */     return this;
/*     */   }
/*     */   
/*     */   protected apa b(float paramFloat) {
/* 456 */     this.cB = paramFloat * 3.0F;
/* 457 */     return this;
/*     */   }
/*     */   
/*     */   public static boolean l(int paramInt) {
/* 461 */     apa apa1 = r[paramInt];
/* 462 */     if (apa1 == null) return false; 
/* 463 */     return (apa1.cO.k() && apa1.b() && !apa1.f());
/*     */   }
/*     */   
/*     */   public boolean b() {
/* 467 */     return true;
/*     */   }
/*     */   
/*     */   public boolean b(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 471 */     return !this.cO.c();
/*     */   }
/*     */   
/*     */   public int d() {
/* 475 */     return 0;
/*     */   }
/*     */   
/*     */   protected apa c(float paramFloat) {
/* 479 */     this.cA = paramFloat;
/* 480 */     if (this.cB < paramFloat * 5.0F) this.cB = paramFloat * 5.0F; 
/* 481 */     return this;
/*     */   }
/*     */   
/*     */   protected apa r() {
/* 485 */     c(-1.0F);
/* 486 */     return this;
/*     */   }
/*     */   
/*     */   public float l(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 490 */     return this.cA;
/*     */   }
/*     */   
/*     */   protected apa b(boolean paramBoolean) {
/* 494 */     this.cE = paramBoolean;
/* 495 */     return this;
/*     */   }
/*     */   
/*     */   public boolean s() {
/* 499 */     return this.cE;
/*     */   }
/*     */   
/*     */   public boolean t() {
/* 503 */     return this.cF;
/*     */   }
/*     */   
/*     */   protected final void a(float paramFloat1, float paramFloat2, float paramFloat3, float paramFloat4, float paramFloat5, float paramFloat6) {
/* 507 */     this.cG = paramFloat1;
/* 508 */     this.cH = paramFloat2;
/* 509 */     this.cI = paramFloat3;
/* 510 */     this.cJ = paramFloat4;
/* 511 */     this.cK = paramFloat5;
/* 512 */     this.cL = paramFloat6;
/*     */   }
/*     */   
/*     */   public float f(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 516 */     return paramaak.i(paramInt1, paramInt2, paramInt3, v[paramaak.a(paramInt1, paramInt2, paramInt3)]);
/*     */   }
/*     */   
/*     */   public int e(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 520 */     return paramaak.h(paramInt1, paramInt2, paramInt3, v[paramaak.a(paramInt1, paramInt2, paramInt3)]);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 534 */     if (paramInt4 == 0 && this.cH > 0.0D) return true; 
/* 535 */     if (paramInt4 == 1 && this.cK < 1.0D) return true; 
/* 536 */     if (paramInt4 == 2 && this.cI > 0.0D) return true; 
/* 537 */     if (paramInt4 == 3 && this.cL < 1.0D) return true; 
/* 538 */     if (paramInt4 == 4 && this.cG > 0.0D) return true; 
/* 539 */     if (paramInt4 == 5 && this.cJ < 1.0D) return true; 
/* 540 */     return !paramaak.t(paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public boolean a_(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 544 */     return paramaak.g(paramInt1, paramInt2, paramInt3).a();
/*     */   }
/*     */   
/*     */   public lx b_(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 548 */     return a(paramInt4, paramaak.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/* 552 */     return this.cQ;
/*     */   }
/*     */   
/*     */   public final lx m(int paramInt) {
/* 556 */     return a(paramInt, 0);
/*     */   }
/*     */   
/*     */   public aqx c_(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 560 */     return aqx.a().a(paramInt1 + this.cG, paramInt2 + this.cH, paramInt3 + this.cI, paramInt1 + this.cJ, paramInt2 + this.cK, paramInt3 + this.cL);
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, aqx paramaqx, List<aqx> paramList, mp parammp) {
/* 564 */     aqx aqx1 = b(paramaab, paramInt1, paramInt2, paramInt3);
/* 565 */     if (aqx1 != null && paramaqx.a(aqx1)) paramList.add(aqx1); 
/*     */   }
/*     */   
/*     */   public aqx b(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 569 */     return aqx.a().a(paramInt1 + this.cG, paramInt2 + this.cH, paramInt3 + this.cI, paramInt1 + this.cJ, paramInt2 + this.cK, paramInt3 + this.cL);
/*     */   }
/*     */   
/*     */   public boolean c() {
/* 573 */     return true;
/*     */   }
/*     */   
/*     */   public boolean a(int paramInt, boolean paramBoolean) {
/* 577 */     return m();
/*     */   }
/*     */   
/*     */   public boolean m() {
/* 581 */     return true;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, Random paramRandom) {}
/*     */ 
/*     */   
/*     */   public void g(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */ 
/*     */   
/*     */   public int a(aab paramaab) {
/* 600 */     return 10;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {}
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {}
/*     */   
/*     */   public int a(Random paramRandom) {
/* 610 */     return 1;
/*     */   }
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 614 */     return this.cz;
/*     */   }
/*     */   
/*     */   public float a(sq paramsq, aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 618 */     float f = l(paramaab, paramInt1, paramInt2, paramInt3);
/* 619 */     if (f < 0.0F) return 0.0F; 
/* 620 */     if (!paramsq.a(this)) {
/* 621 */       return paramsq.a(this, false) / f / 100.0F;
/*     */     }
/* 623 */     return paramsq.a(this, true) / f / 30.0F;
/*     */   }
/*     */   
/*     */   public final void c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 627 */     a(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, 1.0F, paramInt5);
/*     */   }
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat, int paramInt5) {
/* 631 */     if (paramaab.I)
/* 632 */       return;  int i = a(paramInt5, paramaab.s);
/* 633 */     for (byte b = 0; b < i; b++) {
/* 634 */       if (paramaab.s.nextFloat() <= paramFloat) {
/* 635 */         int j = a(paramInt4, paramaab.s, paramInt5);
/* 636 */         if (j > 0)
/*     */         {
/* 638 */           b(paramaab, paramInt1, paramInt2, paramInt3, new wm(j, 1, a(paramInt4))); } 
/*     */       } 
/*     */     } 
/*     */   }
/*     */   protected void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, wm paramwm) {
/* 643 */     if (paramaab.I || !paramaab.N().b("doTileDrops"))
/*     */       return; 
/* 645 */     float f = 0.7F;
/* 646 */     double d1 = (paramaab.s.nextFloat() * f) + (1.0F - f) * 0.5D;
/* 647 */     double d2 = (paramaab.s.nextFloat() * f) + (1.0F - f) * 0.5D;
/* 648 */     double d3 = (paramaab.s.nextFloat() * f) + (1.0F - f) * 0.5D;
/* 649 */     rh rh = new rh(paramaab, paramInt1 + d1, paramInt2 + d2, paramInt3 + d3, paramwm);
/* 650 */     rh.b = 10;
/* 651 */     paramaab.d(rh);
/*     */   }
/*     */   
/*     */   protected void j(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 655 */     if (!paramaab.I) {
/* 656 */       while (paramInt4 > 0) {
/* 657 */         int i = nc.a(paramInt4);
/* 658 */         paramInt4 -= i;
/* 659 */         paramaab.d(new nc(paramaab, paramInt1 + 0.5D, paramInt2 + 0.5D, paramInt3 + 0.5D, i));
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/* 671 */     return 0;
/*     */   }
/*     */   
/*     */   public float a(mp parammp) {
/* 675 */     return this.cB / 5.0F;
/*     */   }
/*     */   
/*     */   public ara a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, arc paramarc1, arc paramarc2) {
/* 679 */     a(paramaab, paramInt1, paramInt2, paramInt3);
/*     */     
/* 681 */     paramarc1 = paramarc1.c(-paramInt1, -paramInt2, -paramInt3);
/* 682 */     paramarc2 = paramarc2.c(-paramInt1, -paramInt2, -paramInt3);
/*     */     
/* 684 */     arc arc1 = paramarc1.b(paramarc2, this.cG);
/* 685 */     arc arc2 = paramarc1.b(paramarc2, this.cJ);
/*     */     
/* 687 */     arc arc3 = paramarc1.c(paramarc2, this.cH);
/* 688 */     arc arc4 = paramarc1.c(paramarc2, this.cK);
/*     */     
/* 690 */     arc arc5 = paramarc1.d(paramarc2, this.cI);
/* 691 */     arc arc6 = paramarc1.d(paramarc2, this.cL);
/*     */     
/* 693 */     if (!a(arc1)) arc1 = null; 
/* 694 */     if (!a(arc2)) arc2 = null; 
/* 695 */     if (!b(arc3)) arc3 = null; 
/* 696 */     if (!b(arc4)) arc4 = null; 
/* 697 */     if (!c(arc5)) arc5 = null; 
/* 698 */     if (!c(arc6)) arc6 = null;
/*     */     
/* 700 */     arc arc7 = null;
/*     */     
/* 702 */     if (arc1 != null && (arc7 == null || paramarc1.e(arc1) < paramarc1.e(arc7))) arc7 = arc1; 
/* 703 */     if (arc2 != null && (arc7 == null || paramarc1.e(arc2) < paramarc1.e(arc7))) arc7 = arc2; 
/* 704 */     if (arc3 != null && (arc7 == null || paramarc1.e(arc3) < paramarc1.e(arc7))) arc7 = arc3; 
/* 705 */     if (arc4 != null && (arc7 == null || paramarc1.e(arc4) < paramarc1.e(arc7))) arc7 = arc4; 
/* 706 */     if (arc5 != null && (arc7 == null || paramarc1.e(arc5) < paramarc1.e(arc7))) arc7 = arc5; 
/* 707 */     if (arc6 != null && (arc7 == null || paramarc1.e(arc6) < paramarc1.e(arc7))) arc7 = arc6;
/*     */     
/* 709 */     if (arc7 == null) return null;
/*     */     
/* 711 */     byte b = -1;
/*     */     
/* 713 */     if (arc7 == arc1) b = 4; 
/* 714 */     if (arc7 == arc2) b = 5; 
/* 715 */     if (arc7 == arc3) b = 0; 
/* 716 */     if (arc7 == arc4) b = 1; 
/* 717 */     if (arc7 == arc5) b = 2; 
/* 718 */     if (arc7 == arc6) b = 3;
/*     */     
/* 720 */     return new ara(paramInt1, paramInt2, paramInt3, b, arc7.c(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   private boolean a(arc paramarc) {
/* 724 */     if (paramarc == null) return false; 
/* 725 */     return (paramarc.d >= this.cH && paramarc.d <= this.cK && paramarc.e >= this.cI && paramarc.e <= this.cL);
/*     */   }
/*     */   
/*     */   private boolean b(arc paramarc) {
/* 729 */     if (paramarc == null) return false; 
/* 730 */     return (paramarc.c >= this.cG && paramarc.c <= this.cJ && paramarc.e >= this.cI && paramarc.e <= this.cL);
/*     */   }
/*     */   
/*     */   private boolean c(arc paramarc) {
/* 734 */     if (paramarc == null) return false; 
/* 735 */     return (paramarc.c >= this.cG && paramarc.c <= this.cJ && paramarc.d >= this.cH && paramarc.d <= this.cK);
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, zw paramzw) {}
/*     */   
/*     */   public int n() {
/* 742 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, wm paramwm) {
/* 746 */     return c(paramaab, paramInt1, paramInt2, paramInt3, paramInt4);
/*     */   }
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 750 */     return c(paramaab, paramInt1, paramInt2, paramInt3);
/*     */   }
/*     */   
/*     */   public boolean c(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 754 */     int i = paramaab.a(paramInt1, paramInt2, paramInt3);
/* 755 */     return (i == 0 || (r[i]).cO.j());
/*     */   }
/*     */   
/*     */   public boolean a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3) {
/* 759 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {}
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/* 766 */     return paramInt5;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, sq paramsq) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp, arc paramarc) {}
/*     */ 
/*     */   
/*     */   public void a(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {}
/*     */ 
/*     */   
/*     */   public final double u() {
/* 782 */     return this.cG;
/*     */   }
/*     */   
/*     */   public final double v() {
/* 786 */     return this.cJ;
/*     */   }
/*     */   
/*     */   public final double w() {
/* 790 */     return this.cH;
/*     */   }
/*     */   
/*     */   public final double x() {
/* 794 */     return this.cK;
/*     */   }
/*     */   
/*     */   public final double y() {
/* 798 */     return this.cI;
/*     */   }
/*     */   
/*     */   public final double z() {
/* 802 */     return this.cL;
/*     */   }
/*     */   
/*     */   public int o() {
/* 806 */     return 16777215;
/*     */   }
/*     */   
/*     */   public int b(int paramInt) {
/* 810 */     return 16777215;
/*     */   }
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 814 */     return 16777215;
/*     */   }
/*     */   
/*     */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 818 */     return 0;
/*     */   }
/*     */   
/*     */   public boolean f() {
/* 822 */     return false;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp) {}
/*     */   
/*     */   public int c(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 829 */     return 0;
/*     */   }
/*     */ 
/*     */   
/*     */   public void g() {}
/*     */   
/*     */   public void a(aab paramaab, sq paramsq, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 836 */     paramsq.a(kf.C[this.cz], 1);
/* 837 */     paramsq.j(0.025F);
/*     */     
/* 839 */     if (r_() && zb.e(paramsq)) {
/* 840 */       wm wm = c_(paramInt4);
/* 841 */       if (wm != null) {
/* 842 */         b(paramaab, paramInt1, paramInt2, paramInt3, wm);
/*     */       }
/*     */     } else {
/* 845 */       int i = zb.f(paramsq);
/* 846 */       c(paramaab, paramInt1, paramInt2, paramInt3, paramInt4, i);
/*     */     } 
/*     */   }
/*     */   
/*     */   protected boolean r_() {
/* 851 */     return (b() && !this.cF);
/*     */   }
/*     */   
/*     */   protected wm c_(int paramInt) {
/* 855 */     int i = 0;
/* 856 */     if (this.cz >= 0 && this.cz < wk.f.length && wk.f[this.cz].m()) {
/* 857 */       i = paramInt;
/*     */     }
/* 859 */     return new wm(this.cz, 1, i);
/*     */   }
/*     */   
/*     */   public int a(int paramInt, Random paramRandom) {
/* 863 */     return a(paramRandom);
/*     */   }
/*     */   
/*     */   public boolean f(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 867 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, ng paramng, wm paramwm) {}
/*     */ 
/*     */   
/*     */   public void k(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */   
/*     */   public apa c(String paramString) {
/* 877 */     this.b = paramString;
/* 878 */     return this;
/*     */   }
/*     */   
/*     */   public String A() {
/* 882 */     return bo.a(a() + ".name");
/*     */   }
/*     */   
/*     */   public String a() {
/* 886 */     return "tile." + this.b;
/*     */   }
/*     */   
/*     */   public String B() {
/* 890 */     return this.b;
/*     */   }
/*     */   
/*     */   public boolean b(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/* 894 */     return false;
/*     */   }
/*     */   
/*     */   public boolean C() {
/* 898 */     return this.cD;
/*     */   }
/*     */   
/*     */   protected apa D() {
/* 902 */     this.cD = false;
/* 903 */     return this;
/*     */   }
/*     */   
/*     */   public int h() {
/* 907 */     return this.cO.m();
/*     */   }
/*     */   
/*     */   public float i(aak paramaak, int paramInt1, int paramInt2, int paramInt3) {
/* 911 */     return paramaak.u(paramInt1, paramInt2, paramInt3) ? 0.2F : 1.0F;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, mp parammp, float paramFloat) {}
/*     */   
/*     */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 918 */     return this.cz;
/*     */   }
/*     */   
/*     */   public int h(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 922 */     return a(paramaab.h(paramInt1, paramInt2, paramInt3));
/*     */   }
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 926 */     paramList.add(new wm(paramInt, 1, 0));
/*     */   }
/*     */   
/*     */   public ve E() {
/* 930 */     return this.a;
/*     */   }
/*     */   
/*     */   public apa a(ve paramve) {
/* 934 */     this.a = paramve;
/* 935 */     return this;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, sq paramsq) {}
/*     */ 
/*     */ 
/*     */   
/*     */   public void l(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {}
/*     */ 
/*     */   
/*     */   public void g(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {}
/*     */ 
/*     */   
/*     */   public boolean t_() {
/* 951 */     return false;
/*     */   }
/*     */   
/*     */   public boolean l() {
/* 955 */     return true;
/*     */   }
/*     */   
/*     */   public boolean a(zw paramzw) {
/* 959 */     return true;
/*     */   }
/*     */   
/*     */   public boolean i(int paramInt) {
/* 963 */     return (this.cz == paramInt);
/*     */   }
/*     */   
/*     */   public static boolean b(int paramInt1, int paramInt2) {
/* 967 */     if (paramInt1 == paramInt2) {
/* 968 */       return true;
/*     */     }
/* 970 */     if (paramInt1 == 0 || paramInt2 == 0 || r[paramInt1] == null || r[paramInt2] == null) {
/* 971 */       return false;
/*     */     }
/* 973 */     return r[paramInt1].i(paramInt2);
/*     */   }
/*     */   
/*     */   public boolean q_() {
/* 977 */     return false;
/*     */   }
/*     */   
/*     */   public int b_(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 981 */     return 0;
/*     */   }
/*     */   
/*     */   public void a(ly paramly) {
/* 985 */     this.cQ = paramly.a(this.b);
/*     */   }
/*     */   
/*     */   public String u_() {
/* 989 */     return null;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apa.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */