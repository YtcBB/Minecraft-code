/*   */ public class abk
/*   */   extends aav
/*   */ {
/*   */   protected abk(int paramInt) {
/* 5 */     super(paramInt);
/*   */     
/* 7 */     this.I.z = -999;
/* 8 */     this.I.A = 4;
/* 9 */     this.I.B = 10;
/*   */   }
/*   */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */