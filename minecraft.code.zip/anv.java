/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class anv
/*    */   extends anj
/*    */ {
/*    */   public anv(int paramInt) {
/*  9 */     super(paramInt);
/* 10 */     a(ve.d);
/*    */   }
/*    */ 
/*    */   
/*    */   public boolean f() {
/* 15 */     return true;
/*    */   }
/*    */ 
/*    */   
/*    */   public int b(aak paramaak, int paramInt1, int paramInt2, int paramInt3, int paramInt4) {
/* 20 */     return 15;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\anv.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */