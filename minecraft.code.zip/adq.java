/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class adq
/*     */   extends adj
/*     */ {
/*   9 */   private int a = -1;
/*     */   
/*     */   public adq(int paramInt) {
/*  12 */     super(true);
/*  13 */     this.a = paramInt;
/*     */   }
/*     */   
/*     */   public adq() {
/*  17 */     super(false);
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/*  22 */     int i = paramRandom.nextInt(2);
/*  23 */     if (this.a >= 0) i = this.a;
/*     */     
/*  25 */     int j = paramRandom.nextInt(3) + 4;
/*     */     
/*  27 */     boolean bool = true;
/*  28 */     if (paramInt2 < 1 || paramInt2 + j + 1 >= 256) return false; 
/*     */     int k;
/*  30 */     for (k = paramInt2; k <= paramInt2 + 1 + j; k++) {
/*  31 */       byte b = 3;
/*  32 */       if (k <= paramInt2 + 3) b = 0; 
/*  33 */       for (int i1 = paramInt1 - b; i1 <= paramInt1 + b && bool; i1++) {
/*  34 */         for (int i2 = paramInt3 - b; i2 <= paramInt3 + b && bool; i2++) {
/*  35 */           if (k >= 0 && k < 256) {
/*  36 */             int i3 = paramaab.a(i1, k, i2);
/*  37 */             if (i3 != 0 && i3 != apa.O.cz) {
/*  38 */               bool = false;
/*     */             }
/*     */           } else {
/*  41 */             bool = false;
/*     */           } 
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/*  47 */     if (!bool) return false;
/*     */     
/*  49 */     k = paramaab.a(paramInt1, paramInt2 - 1, paramInt3);
/*  50 */     if (k != apa.z.cz && k != apa.y.cz && k != apa.bC.cz) {
/*  51 */       return false;
/*     */     }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */     
/*  60 */     int m = paramInt2 + j;
/*  61 */     if (i == 1)
/*  62 */       m = paramInt2 + j - 3; 
/*     */     int n;
/*  64 */     for (n = m; n <= paramInt2 + j; n++) {
/*  65 */       byte b = 1;
/*  66 */       if (n < paramInt2 + j) b++; 
/*  67 */       if (i == 0) b = 3; 
/*  68 */       for (int i1 = paramInt1 - b; i1 <= paramInt1 + b; i1++) {
/*  69 */         for (int i2 = paramInt3 - b; i2 <= paramInt3 + b; i2++) {
/*  70 */           byte b1 = 5;
/*  71 */           if (i1 == paramInt1 - b) b1--; 
/*  72 */           if (i1 == paramInt1 + b) b1++; 
/*  73 */           if (i2 == paramInt3 - b) b1 -= 3; 
/*  74 */           if (i2 == paramInt3 + b) b1 += 3;
/*     */           
/*  76 */           if (i == 0 || n < paramInt2 + j) {
/*  77 */             if ((i1 == paramInt1 - b || i1 == paramInt1 + b) && (i2 == paramInt3 - b || i2 == paramInt3 + b))
/*  78 */               continue;  if (i1 == paramInt1 - b - 1 && i2 == paramInt3 - b) b1 = 1; 
/*  79 */             if (i1 == paramInt1 - b && i2 == paramInt3 - b - 1) b1 = 1;
/*     */             
/*  81 */             if (i1 == paramInt1 + b - 1 && i2 == paramInt3 - b) b1 = 3; 
/*  82 */             if (i1 == paramInt1 + b && i2 == paramInt3 - b - 1) b1 = 3;
/*     */             
/*  84 */             if (i1 == paramInt1 - b - 1 && i2 == paramInt3 + b) b1 = 7; 
/*  85 */             if (i1 == paramInt1 - b && i2 == paramInt3 + b - 1) b1 = 7;
/*     */             
/*  87 */             if (i1 == paramInt1 + b - 1 && i2 == paramInt3 + b) b1 = 9; 
/*  88 */             if (i1 == paramInt1 + b && i2 == paramInt3 + b - 1) b1 = 9;
/*     */           
/*     */           } 
/*  91 */           if (b1 == 5 && n < paramInt2 + j) b1 = 0; 
/*  92 */           if ((b1 != 0 || paramInt2 >= paramInt2 + j - 1) && 
/*  93 */             !apa.s[paramaab.a(i1, n, i2)]) a(paramaab, i1, n, i2, apa.br.cz + i, b1); 
/*     */           continue;
/*     */         } 
/*     */       } 
/*     */     } 
/*  98 */     for (n = 0; n < j; n++) {
/*  99 */       int i1 = paramaab.a(paramInt1, paramInt2 + n, paramInt3);
/* 100 */       if (!apa.s[i1]) a(paramaab, paramInt1, paramInt2 + n, paramInt3, apa.br.cz + i, 10); 
/*     */     } 
/* 102 */     return true;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\adq.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */