/*    */ 
/*    */ 
/*    */ public class abf
/*    */   extends aav
/*    */ {
/*    */   public abf(int paramInt) {
/*  7 */     super(paramInt);
/*    */     
/*  9 */     this.J.clear();
/* 10 */     this.K.clear();
/* 11 */     this.L.clear();
/* 12 */     this.M.clear();
/*    */     
/* 14 */     this.J.add(new aaw(ry.class, 50, 4, 4));
/* 15 */     this.J.add(new aaw(sc.class, 100, 4, 4));
/* 16 */     this.J.add(new aaw(sa.class, 1, 4, 4));
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abf.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */