/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class alo
/*    */   extends apa
/*    */ {
/*    */   public alo(int paramInt) {
/* 10 */     super(paramInt, aif.z);
/* 11 */     a(ve.b);
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 16 */     return wk.aJ.cp;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 21 */     return 4;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\alo.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */