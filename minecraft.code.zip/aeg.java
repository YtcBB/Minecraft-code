/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class aeg
/*    */   extends adj
/*    */ {
/*    */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2, int paramInt3) {
/* 13 */     int i = paramInt1;
/* 14 */     int j = paramInt3;
/*    */     
/* 16 */     while (paramInt2 < 128) {
/* 17 */       if (paramaab.c(paramInt1, paramInt2, paramInt3)) {
/* 18 */         for (byte b = 2; b <= 5; b++) {
/* 19 */           if (apa.by.c(paramaab, paramInt1, paramInt2, paramInt3, b)) {
/* 20 */             paramaab.f(paramInt1, paramInt2, paramInt3, apa.by.cz, 1 << r.e[s.a[b]], 2);
/*    */             break;
/*    */           } 
/*    */         } 
/*    */       } else {
/* 25 */         paramInt1 = i + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/* 26 */         paramInt3 = j + paramRandom.nextInt(4) - paramRandom.nextInt(4);
/*    */       } 
/* 28 */       paramInt2++;
/*    */     } 
/*    */     
/* 31 */     return true;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aeg.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */