/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class apr
/*    */   extends ala
/*    */ {
/*    */   private final int a;
/*    */   
/*    */   protected apr(int paramInt1, String paramString, aif paramaif, int paramInt2) {
/* 14 */     super(paramInt1, paramString, paramaif);
/*    */     
/* 16 */     this.a = paramInt2;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int e(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 21 */     int i = 0;
/* 22 */     for (rh rh : paramaab.a(rh.class, a(paramInt1, paramInt2, paramInt3))) {
/* 23 */       i += (rh.d()).a;
/*    */       
/* 25 */       if (i >= this.a)
/*    */         break; 
/*    */     } 
/* 28 */     if (i <= 0) {
/* 29 */       return 0;
/*    */     }
/* 31 */     float f = Math.min(this.a, i) / this.a;
/* 32 */     return kx.f(f * 15.0F);
/*    */   }
/*    */ 
/*    */ 
/*    */   
/*    */   protected int c(int paramInt) {
/* 38 */     return paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   protected int d(int paramInt) {
/* 43 */     return paramInt;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(aab paramaab) {
/* 48 */     return 10;
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apr.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */