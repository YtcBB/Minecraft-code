/*     */ import java.io.File;
/*     */ import java.io.FileInputStream;
/*     */ import java.io.FileOutputStream;
/*     */ import java.util.ArrayList;
/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class aju
/*     */   implements aki
/*     */ {
/*     */   protected final File a;
/*     */   
/*     */   public aju(File paramFile) {
/*  19 */     if (!paramFile.exists()) paramFile.mkdirs(); 
/*  20 */     this.a = paramFile;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public List b() {
/*  29 */     ArrayList<akj> arrayList = new ArrayList();
/*     */     
/*  31 */     for (byte b = 0; b < 5; b++) {
/*     */       
/*  33 */       String str = "World" + (b + 1);
/*     */       
/*  35 */       ajv ajv = c(str);
/*  36 */       if (ajv != null) {
/*  37 */         arrayList.add(new akj(str, "", ajv.m(), ajv.h(), ajv.r(), false, ajv.t(), ajv.v()));
/*     */       }
/*     */     } 
/*     */     
/*  41 */     return arrayList;
/*     */   }
/*     */ 
/*     */   
/*     */   public void d() {}
/*     */   
/*     */   public ajv c(String paramString) {
/*  48 */     File file1 = new File(this.a, paramString);
/*  49 */     if (!file1.exists()) return null;
/*     */     
/*  51 */     File file2 = new File(file1, "level.dat");
/*  52 */     if (file2.exists()) {
/*     */       try {
/*  54 */         bs bs1 = cc.a(new FileInputStream(file2));
/*  55 */         bs bs2 = bs1.l("Data");
/*  56 */         return new ajv(bs2);
/*  57 */       } catch (Exception exception) {
/*  58 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */     
/*  62 */     file2 = new File(file1, "level.dat_old");
/*  63 */     if (file2.exists()) {
/*     */       try {
/*  65 */         bs bs1 = cc.a(new FileInputStream(file2));
/*  66 */         bs bs2 = bs1.l("Data");
/*  67 */         return new ajv(bs2);
/*  68 */       } catch (Exception exception) {
/*  69 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*  72 */     return null;
/*     */   }
/*     */   
/*     */   public void a(String paramString1, String paramString2) {
/*  76 */     File file1 = new File(this.a, paramString1);
/*  77 */     if (!file1.exists())
/*     */       return; 
/*  79 */     File file2 = new File(file1, "level.dat");
/*  80 */     if (file2.exists()) {
/*     */       try {
/*  82 */         bs bs1 = cc.a(new FileInputStream(file2));
/*  83 */         bs bs2 = bs1.l("Data");
/*  84 */         bs2.a("LevelName", paramString2);
/*     */         
/*  86 */         cc.a(bs1, new FileOutputStream(file2));
/*  87 */       } catch (Exception exception) {
/*  88 */         exception.printStackTrace();
/*     */       } 
/*     */     }
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean e(String paramString) {
/* 112 */     File file = new File(this.a, paramString);
/* 113 */     if (!file.exists()) return true;
/*     */     
/* 115 */     System.out.println("Deleting level " + paramString);
/*     */     
/* 117 */     for (byte b = 1; b <= 5; b++) {
/* 118 */       System.out.println("Attempt " + b + "...");
/*     */       
/* 120 */       if (a(file.listFiles())) {
/*     */         break;
/*     */       }
/* 123 */       System.out.println("Unsuccessful in deleting contents.");
/*     */ 
/*     */       
/* 126 */       if (b < 5) {
/*     */         try {
/* 128 */           Thread.sleep(500L);
/* 129 */         } catch (InterruptedException interruptedException) {}
/*     */       }
/*     */     } 
/*     */     
/* 133 */     return file.delete();
/*     */   }
/*     */   
/*     */   protected static boolean a(File[] paramArrayOfFile) {
/* 137 */     for (byte b = 0; b < paramArrayOfFile.length; b++) {
/* 138 */       File file = paramArrayOfFile[b];
/* 139 */       System.out.println("Deleting " + file);
/*     */       
/* 141 */       if (file.isDirectory() && 
/* 142 */         !a(file.listFiles())) {
/* 143 */         System.out.println("Couldn't delete directory " + file);
/* 144 */         return false;
/*     */       } 
/*     */ 
/*     */       
/* 148 */       if (!file.delete()) {
/* 149 */         System.out.println("Couldn't delete file " + file);
/* 150 */         return false;
/*     */       } 
/*     */     } 
/*     */     
/* 154 */     return true;
/*     */   }
/*     */   
/*     */   public akf a(String paramString, boolean paramBoolean) {
/* 158 */     return new ajt(this.a, paramString, paramBoolean);
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean b(String paramString) {
/* 166 */     return false;
/*     */   }
/*     */   
/*     */   public boolean a(String paramString, lc paramlc) {
/* 170 */     return false;
/*     */   }
/*     */   
/*     */   public boolean f(String paramString) {
/* 174 */     File file = new File(this.a, paramString);
/* 175 */     return file.isDirectory();
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aju.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */