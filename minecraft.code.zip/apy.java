/*     */ import java.util.List;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apy
/*     */   extends aqp
/*     */   implements lt
/*     */ {
/*  15 */   private wm[] i = new wm[36];
/*     */   
/*     */   public boolean a = false;
/*     */   public apy b;
/*     */   public apy c;
/*     */   public apy d;
/*     */   public apy e;
/*     */   public float f;
/*     */   public float g;
/*     */   public int h;
/*     */   private int j;
/*  26 */   private int r = -1;
/*     */   private String s;
/*     */   
/*     */   public int j_() {
/*  30 */     return 27;
/*     */   }
/*     */   
/*     */   public wm a(int paramInt) {
/*  34 */     return this.i[paramInt];
/*     */   }
/*     */   
/*     */   public wm a(int paramInt1, int paramInt2) {
/*  38 */     if (this.i[paramInt1] != null) {
/*  39 */       if ((this.i[paramInt1]).a <= paramInt2) {
/*  40 */         wm wm2 = this.i[paramInt1];
/*  41 */         this.i[paramInt1] = null;
/*  42 */         k_();
/*  43 */         return wm2;
/*     */       } 
/*  45 */       wm wm1 = this.i[paramInt1].a(paramInt2);
/*  46 */       if ((this.i[paramInt1]).a == 0) this.i[paramInt1] = null; 
/*  47 */       k_();
/*  48 */       return wm1;
/*     */     } 
/*     */     
/*  51 */     return null;
/*     */   }
/*     */   
/*     */   public wm b(int paramInt) {
/*  55 */     if (this.i[paramInt] != null) {
/*  56 */       wm wm1 = this.i[paramInt];
/*  57 */       this.i[paramInt] = null;
/*  58 */       return wm1;
/*     */     } 
/*  60 */     return null;
/*     */   }
/*     */   
/*     */   public void a(int paramInt, wm paramwm) {
/*  64 */     this.i[paramInt] = paramwm;
/*  65 */     if (paramwm != null && paramwm.a > d()) paramwm.a = d(); 
/*  66 */     k_();
/*     */   }
/*     */   
/*     */   public String b() {
/*  70 */     return c() ? this.s : "container.chest";
/*     */   }
/*     */   
/*     */   public boolean c() {
/*  74 */     return (this.s != null && this.s.length() > 0);
/*     */   }
/*     */   
/*     */   public void a(String paramString) {
/*  78 */     this.s = paramString;
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   public void a(bs parambs) {
/*  84 */     super.a(parambs);
/*  85 */     ca ca = parambs.m("Items");
/*  86 */     this.i = new wm[j_()];
/*  87 */     if (parambs.b("CustomName")) this.s = parambs.i("CustomName"); 
/*  88 */     for (byte b = 0; b < ca.c(); b++) {
/*  89 */       bs bs1 = (bs)ca.b(b);
/*  90 */       int i = bs1.c("Slot") & 0xFF;
/*  91 */       if (i >= 0 && i < this.i.length) this.i[i] = wm.a(bs1);
/*     */     
/*     */     } 
/*     */   }
/*     */   
/*     */   public void b(bs parambs) {
/*  97 */     super.b(parambs);
/*  98 */     ca ca = new ca();
/*     */     
/* 100 */     for (byte b = 0; b < this.i.length; b++) {
/* 101 */       if (this.i[b] != null) {
/* 102 */         bs bs1 = new bs();
/* 103 */         bs1.a("Slot", (byte)b);
/* 104 */         this.i[b].b(bs1);
/* 105 */         ca.a(bs1);
/*     */       } 
/*     */     } 
/* 108 */     parambs.a("Items", ca);
/* 109 */     if (c()) parambs.a("CustomName", this.s); 
/*     */   }
/*     */   
/*     */   public int d() {
/* 113 */     return 64;
/*     */   }
/*     */   
/*     */   public boolean a(sq paramsq) {
/* 117 */     if (this.k.r(this.l, this.m, this.n) != this) return false; 
/* 118 */     if (paramsq.e(this.l + 0.5D, this.m + 0.5D, this.n + 0.5D) > 64.0D) return false; 
/* 119 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void i() {
/* 124 */     super.i();
/* 125 */     this.a = false;
/*     */   }
/*     */   
/*     */   private void a(apy paramapy, int paramInt) {
/* 129 */     if (paramapy.r()) {
/* 130 */       this.a = false;
/* 131 */     } else if (this.a) {
/* 132 */       switch (paramInt) {
/*     */         case 2:
/* 134 */           if (this.b != paramapy) this.a = false; 
/*     */           break;
/*     */         case 0:
/* 137 */           if (this.e != paramapy) this.a = false; 
/*     */           break;
/*     */         case 3:
/* 140 */           if (this.c != paramapy) this.a = false; 
/*     */           break;
/*     */         case 1:
/* 143 */           if (this.d != paramapy) this.a = false; 
/*     */           break;
/*     */       } 
/*     */     } 
/*     */   }
/*     */   
/*     */   public void j() {
/* 150 */     if (this.a)
/*     */       return; 
/* 152 */     this.a = true;
/* 153 */     this.b = null;
/* 154 */     this.c = null;
/* 155 */     this.d = null;
/* 156 */     this.e = null;
/*     */     
/* 158 */     if (a(this.l - 1, this.m, this.n)) {
/* 159 */       this.d = (apy)this.k.r(this.l - 1, this.m, this.n);
/*     */     }
/* 161 */     if (a(this.l + 1, this.m, this.n)) {
/* 162 */       this.c = (apy)this.k.r(this.l + 1, this.m, this.n);
/*     */     }
/* 164 */     if (a(this.l, this.m, this.n - 1)) {
/* 165 */       this.b = (apy)this.k.r(this.l, this.m, this.n - 1);
/*     */     }
/* 167 */     if (a(this.l, this.m, this.n + 1)) {
/* 168 */       this.e = (apy)this.k.r(this.l, this.m, this.n + 1);
/*     */     }
/*     */     
/* 171 */     if (this.b != null) this.b.a(this, 0); 
/* 172 */     if (this.e != null) this.e.a(this, 2); 
/* 173 */     if (this.c != null) this.c.a(this, 1); 
/* 174 */     if (this.d != null) this.d.a(this, 3); 
/*     */   }
/*     */   
/*     */   private boolean a(int paramInt1, int paramInt2, int paramInt3) {
/* 178 */     apa apa = apa.r[this.k.a(paramInt1, paramInt2, paramInt3)];
/* 179 */     if (apa == null || !(apa instanceof aln)) return false; 
/* 180 */     return (((aln)apa).a == l());
/*     */   }
/*     */ 
/*     */   
/*     */   public void h() {
/* 185 */     super.h();
/* 186 */     j();
/*     */     
/* 188 */     this.j++;
/* 189 */     if (!this.k.I && this.h != 0 && (this.j + this.l + this.m + this.n) % 200 == 0) {
/*     */ 
/*     */       
/* 192 */       this.h = 0;
/*     */       
/* 194 */       float f1 = 5.0F;
/* 195 */       List list = this.k.a(sq.class, aqx.a().a((this.l - f1), (this.m - f1), (this.n - f1), ((this.l + 1) + f1), ((this.m + 1) + f1), ((this.n + 1) + f1)));
/* 196 */       for (sq sq : list) {
/* 197 */         if (sq.bM instanceof tq) {
/* 198 */           lt lt1 = ((tq)sq.bM).e();
/* 199 */           if (lt1 == this || (lt1 instanceof ls && ((ls)lt1).a(this))) {
/* 200 */             this.h++;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 206 */     this.g = this.f;
/*     */     
/* 208 */     float f = 0.1F;
/* 209 */     if (this.h > 0 && this.f == 0.0F && 
/* 210 */       this.b == null && this.d == null) {
/* 211 */       double d1 = this.l + 0.5D;
/* 212 */       double d2 = this.n + 0.5D;
/* 213 */       if (this.e != null) d2 += 0.5D; 
/* 214 */       if (this.c != null) d1 += 0.5D;
/*     */       
/* 216 */       this.k.a(d1, this.m + 0.5D, d2, "random.chestopen", 0.5F, this.k.s.nextFloat() * 0.1F + 0.9F);
/*     */     } 
/*     */     
/* 219 */     if ((this.h == 0 && this.f > 0.0F) || (this.h > 0 && this.f < 1.0F)) {
/* 220 */       float f1 = this.f;
/* 221 */       if (this.h > 0) { this.f += f; }
/* 222 */       else { this.f -= f; }
/* 223 */        if (this.f > 1.0F) {
/* 224 */         this.f = 1.0F;
/*     */       }
/* 226 */       float f2 = 0.5F;
/* 227 */       if (this.f < f2 && f1 >= f2 && 
/* 228 */         this.b == null && this.d == null) {
/* 229 */         double d1 = this.l + 0.5D;
/* 230 */         double d2 = this.n + 0.5D;
/* 231 */         if (this.e != null) d2 += 0.5D; 
/* 232 */         if (this.c != null) d1 += 0.5D;
/*     */         
/* 234 */         this.k.a(d1, this.m + 0.5D, d2, "random.chestclosed", 0.5F, this.k.s.nextFloat() * 0.1F + 0.9F);
/*     */       } 
/*     */       
/* 237 */       if (this.f < 0.0F) {
/* 238 */         this.f = 0.0F;
/*     */       }
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean b(int paramInt1, int paramInt2) {
/* 245 */     if (paramInt1 == 1) {
/* 246 */       this.h = paramInt2;
/* 247 */       return true;
/*     */     } 
/* 249 */     return super.b(paramInt1, paramInt2);
/*     */   }
/*     */   
/*     */   public void f() {
/* 253 */     if (this.h < 0) {
/* 254 */       this.h = 0;
/*     */     }
/* 256 */     this.h++;
/* 257 */     this.k.d(this.l, this.m, this.n, (q()).cz, 1, this.h);
/* 258 */     this.k.f(this.l, this.m, this.n, (q()).cz);
/* 259 */     this.k.f(this.l, this.m - 1, this.n, (q()).cz);
/*     */   }
/*     */   
/*     */   public void g() {
/* 263 */     if (q() == null || !(q() instanceof aln))
/* 264 */       return;  this.h--;
/* 265 */     this.k.d(this.l, this.m, this.n, (q()).cz, 1, this.h);
/* 266 */     this.k.f(this.l, this.m, this.n, (q()).cz);
/* 267 */     this.k.f(this.l, this.m - 1, this.n, (q()).cz);
/*     */   }
/*     */   
/*     */   public boolean b(int paramInt, wm paramwm) {
/* 271 */     return true;
/*     */   }
/*     */ 
/*     */   
/*     */   public void w_() {
/* 276 */     super.w_();
/* 277 */     i();
/* 278 */     j();
/*     */   }
/*     */   
/*     */   public int l() {
/* 282 */     if (this.r == -1) {
/* 283 */       if (this.k != null && q() instanceof aln) {
/* 284 */         this.r = ((aln)q()).a;
/*     */       } else {
/* 286 */         return 0;
/*     */       } 
/*     */     }
/*     */     
/* 290 */     return this.r;
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apy.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */