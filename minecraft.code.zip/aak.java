public interface aak {
  int a(int paramInt1, int paramInt2, int paramInt3);
  
  aqp r(int paramInt1, int paramInt2, int paramInt3);
  
  int h(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  float i(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
  
  float q(int paramInt1, int paramInt2, int paramInt3);
  
  int h(int paramInt1, int paramInt2, int paramInt3);
  
  aif g(int paramInt1, int paramInt2, int paramInt3);
  
  boolean t(int paramInt1, int paramInt2, int paramInt3);
  
  boolean u(int paramInt1, int paramInt2, int paramInt3);
  
  boolean c(int paramInt1, int paramInt2, int paramInt3);
  
  aav a(int paramInt1, int paramInt2);
  
  int Q();
  
  boolean S();
  
  boolean w(int paramInt1, int paramInt2, int paramInt3);
  
  ard U();
  
  int j(int paramInt1, int paramInt2, int paramInt3, int paramInt4);
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\aak.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */