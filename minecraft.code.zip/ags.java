/*     */ import java.util.HashMap;
/*     */ import java.util.Iterator;
/*     */ import java.util.List;
/*     */ import java.util.Map;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public abstract class ags
/*     */   extends acw
/*     */ {
/*  16 */   protected Map d = new HashMap<Object, Object>();
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   protected void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, byte[] paramArrayOfbyte) {
/*  24 */     if (this.d.containsKey(Long.valueOf(zu.a(paramInt1, paramInt2)))) {
/*     */       return;
/*     */     }
/*     */ 
/*     */     
/*  29 */     this.b.nextInt();
/*     */     
/*     */     try {
/*  32 */       if (a(paramInt1, paramInt2)) {
/*  33 */         agy agy = b(paramInt1, paramInt2);
/*  34 */         this.d.put(Long.valueOf(zu.a(paramInt1, paramInt2)), agy);
/*     */       } 
/*  36 */     } catch (Throwable throwable) {
/*  37 */       b b = b.a(throwable, "Exception preparing structure feature");
/*  38 */       m m = b.a("Feature being prepared");
/*     */       
/*  40 */       m.a("Is feature chunk", new agt(this, paramInt1, paramInt2));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  46 */       m.a("Chunk location", String.format("%d,%d", new Object[] { Integer.valueOf(paramInt1), Integer.valueOf(paramInt2) }));
/*     */       
/*  48 */       m.a("Chunk pos hash", new agu(this, paramInt1, paramInt2));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  54 */       m.a("Structure type", new agv(this));
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */       
/*  60 */       throw new u(b);
/*     */     } 
/*     */   }
/*     */ 
/*     */   
/*     */   public boolean a(aab paramaab, Random paramRandom, int paramInt1, int paramInt2) {
/*  66 */     int i = (paramInt1 << 4) + 8;
/*  67 */     int j = (paramInt2 << 4) + 8;
/*     */     
/*  69 */     boolean bool = false;
/*  70 */     for (agy agy : this.d.values()) {
/*  71 */       if (agy.d() && 
/*  72 */         agy.a().a(i, j, i + 15, j + 15)) {
/*  73 */         agy.a(paramaab, paramRandom, new aek(i, j, i + 15, j + 15));
/*  74 */         bool = true;
/*     */       } 
/*     */     } 
/*     */ 
/*     */     
/*  79 */     return bool;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public boolean a(int paramInt1, int paramInt2, int paramInt3) {
/* 101 */     for (agy agy : this.d.values()) {
/* 102 */       if (agy.d() && 
/* 103 */         agy.a().a(paramInt1, paramInt3, paramInt1, paramInt3)) {
/*     */         
/* 105 */         Iterator<agw> iterator = agy.b().iterator();
/* 106 */         while (iterator.hasNext()) {
/* 107 */           agw agw = iterator.next();
/* 108 */           if (agw.b().b(paramInt1, paramInt2, paramInt3)) {
/* 109 */             return true;
/*     */           }
/*     */         } 
/*     */       } 
/*     */     } 
/*     */     
/* 115 */     return false;
/*     */   }
/*     */ 
/*     */ 
/*     */ 
/*     */   
/*     */   public aat a(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 122 */     this.c = paramaab;
/*     */     
/* 124 */     this.b.setSeed(paramaab.G());
/* 125 */     long l1 = this.b.nextLong();
/* 126 */     long l2 = this.b.nextLong();
/* 127 */     long l3 = (paramInt1 >> 4) * l1;
/* 128 */     long l4 = (paramInt3 >> 4) * l2;
/* 129 */     this.b.setSeed(l3 ^ l4 ^ paramaab.G());
/*     */     
/* 131 */     a(paramaab, paramInt1 >> 4, paramInt3 >> 4, 0, 0, (byte[])null);
/*     */     
/* 133 */     double d = Double.MAX_VALUE;
/* 134 */     aat aat = null;
/*     */     
/* 136 */     for (agy agy : this.d.values()) {
/* 137 */       if (agy.d()) {
/*     */         
/* 139 */         agw agw = agy.b().get(0);
/* 140 */         aat aat1 = agw.a();
/*     */         
/* 142 */         int i = aat1.a - paramInt1;
/* 143 */         int j = aat1.b - paramInt2;
/* 144 */         int k = aat1.c - paramInt3;
/* 145 */         double d1 = (i + i * j * j + k * k);
/*     */         
/* 147 */         if (d1 < d) {
/* 148 */           d = d1;
/* 149 */           aat = aat1;
/*     */         } 
/*     */       } 
/*     */     } 
/* 153 */     if (aat != null) {
/* 154 */       return aat;
/*     */     }
/* 156 */     List list = p_();
/* 157 */     if (list != null) {
/* 158 */       aat aat1 = null;
/* 159 */       for (aat aat2 : list) {
/*     */         
/* 161 */         int i = aat2.a - paramInt1;
/* 162 */         int j = aat2.b - paramInt2;
/* 163 */         int k = aat2.c - paramInt3;
/* 164 */         double d1 = (i + i * j * j + k * k);
/*     */         
/* 166 */         if (d1 < d) {
/* 167 */           d = d1;
/* 168 */           aat1 = aat2;
/*     */         } 
/*     */       } 
/* 171 */       return aat1;
/*     */     } 
/*     */     
/* 174 */     return null;
/*     */   }
/*     */   
/*     */   protected List p_() {
/* 178 */     return null;
/*     */   }
/*     */   
/*     */   protected abstract boolean a(int paramInt1, int paramInt2);
/*     */   
/*     */   protected abstract agy b(int paramInt1, int paramInt2);
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\ags.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */