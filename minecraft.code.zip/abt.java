import java.util.List;

public interface abt {
  boolean a(int paramInt1, int paramInt2);
  
  abw d(int paramInt1, int paramInt2);
  
  abw c(int paramInt1, int paramInt2);
  
  void a(abt paramabt, int paramInt1, int paramInt2);
  
  boolean a(boolean paramBoolean, lc paramlc);
  
  boolean c();
  
  boolean d();
  
  String e();
  
  List a(nn paramnn, int paramInt1, int paramInt2, int paramInt3);
  
  aat a(aab paramaab, String paramString, int paramInt1, int paramInt2, int paramInt3);
  
  int f();
  
  void e(int paramInt1, int paramInt2);
  
  void b();
}


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\abt.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */