/*     */ import java.util.List;
/*     */ import java.util.Random;
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ 
/*     */ public class apk
/*     */   extends apa
/*     */ {
/*  22 */   public static final String[] a = new String[] { "oak", "spruce", "birch", "jungle" };
/*     */ 
/*     */ 
/*     */   
/*  26 */   public static final String[] b = new String[] { "tree_side", "tree_spruce", "tree_birch", "tree_jungle" };
/*     */   
/*     */   private lx[] c;
/*     */   
/*     */   private lx d;
/*     */ 
/*     */   
/*     */   protected apk(int paramInt) {
/*  34 */     super(paramInt, aif.d);
/*  35 */     a(ve.b);
/*     */   }
/*     */ 
/*     */   
/*     */   public int d() {
/*  40 */     return 31;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(Random paramRandom) {
/*  45 */     return 1;
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/*  50 */     return apa.N.cz;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
/*  55 */     byte b = 4;
/*  56 */     int i = b + 1;
/*     */     
/*  58 */     if (paramaab.e(paramInt1 - i, paramInt2 - i, paramInt3 - i, paramInt1 + i, paramInt2 + i, paramInt3 + i))
/*  59 */       for (byte b1 = -b; b1 <= b; b1++) {
/*  60 */         for (byte b2 = -b; b2 <= b; b2++) {
/*  61 */           for (byte b3 = -b; b3 <= b; b3++) {
/*  62 */             int j = paramaab.a(paramInt1 + b1, paramInt2 + b2, paramInt3 + b3);
/*  63 */             if (j == apa.O.cz) {
/*  64 */               int k = paramaab.h(paramInt1 + b1, paramInt2 + b2, paramInt3 + b3);
/*  65 */               if ((k & 0x8) == 0) {
/*  66 */                 paramaab.b(paramInt1 + b1, paramInt2 + b2, paramInt3 + b3, k | 0x8, 4);
/*     */               }
/*     */             } 
/*     */           } 
/*     */         } 
/*     */       }  
/*     */   }
/*     */   
/*     */   public int a(aab paramaab, int paramInt1, int paramInt2, int paramInt3, int paramInt4, float paramFloat1, float paramFloat2, float paramFloat3, int paramInt5) {
/*  75 */     int i = paramInt5 & 0x3;
/*  76 */     byte b = 0;
/*     */     
/*  78 */     switch (paramInt4) {
/*     */       case 2:
/*     */       case 3:
/*  81 */         b = 8;
/*     */         break;
/*     */       case 4:
/*     */       case 5:
/*  85 */         b = 4;
/*     */         break;
/*     */       case 0:
/*     */       case 1:
/*  89 */         b = 0;
/*     */         break;
/*     */     } 
/*     */     
/*  93 */     return i | b;
/*     */   }
/*     */ 
/*     */   
/*     */   public lx a(int paramInt1, int paramInt2) {
/*  98 */     int i = paramInt2 & 0xC;
/*  99 */     int j = paramInt2 & 0x3;
/*     */     
/* 101 */     if (i == 0 && (paramInt1 == 1 || paramInt1 == 0))
/* 102 */       return this.d; 
/* 103 */     if (i == 4 && (paramInt1 == 5 || paramInt1 == 4))
/* 104 */       return this.d; 
/* 105 */     if (i == 8 && (paramInt1 == 2 || paramInt1 == 3)) {
/* 106 */       return this.d;
/*     */     }
/*     */     
/* 109 */     return this.c[j];
/*     */   }
/*     */ 
/*     */   
/*     */   public int a(int paramInt) {
/* 114 */     return paramInt & 0x3;
/*     */   }
/*     */   
/*     */   public static int d(int paramInt) {
/* 118 */     return paramInt & 0x3;
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(int paramInt, ve paramve, List<wm> paramList) {
/* 123 */     paramList.add(new wm(paramInt, 1, 0));
/* 124 */     paramList.add(new wm(paramInt, 1, 1));
/* 125 */     paramList.add(new wm(paramInt, 1, 2));
/* 126 */     paramList.add(new wm(paramInt, 1, 3));
/*     */   }
/*     */ 
/*     */ 
/*     */   
/*     */   protected wm c_(int paramInt) {
/* 132 */     return new wm(this.cz, 1, d(paramInt));
/*     */   }
/*     */ 
/*     */   
/*     */   public void a(ly paramly) {
/* 137 */     this.d = paramly.a("tree_top");
/* 138 */     this.c = new lx[b.length];
/*     */     
/* 140 */     for (byte b = 0; b < this.c.length; b++)
/* 141 */       this.c[b] = paramly.a(b[b]); 
/*     */   }
/*     */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\apk.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */