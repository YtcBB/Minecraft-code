/*    */ import java.util.Random;
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */ public class amx
/*    */   extends apa
/*    */ {
/* 14 */   private static final String[] a = new String[] { "mushroom_skin_brown", "mushroom_skin_red" };
/*    */   
/*    */   private final int b;
/*    */   
/*    */   private lx[] c;
/*    */   
/*    */   private lx d;
/*    */   private lx e;
/*    */   
/*    */   public amx(int paramInt1, aif paramaif, int paramInt2) {
/* 24 */     super(paramInt1, paramaif);
/* 25 */     this.b = paramInt2;
/*    */   }
/*    */ 
/*    */ 
/*    */ 
/*    */ 
/*    */   
/*    */   public lx a(int paramInt1, int paramInt2) {
/* 33 */     if (paramInt2 == 10 && paramInt1 > 1) return this.d; 
/* 34 */     if (paramInt2 >= 1 && paramInt2 <= 9 && paramInt1 == 1) return this.c[this.b]; 
/* 35 */     if (paramInt2 >= 1 && paramInt2 <= 3 && paramInt1 == 2) return this.c[this.b]; 
/* 36 */     if (paramInt2 >= 7 && paramInt2 <= 9 && paramInt1 == 3) return this.c[this.b];
/*    */     
/* 38 */     if ((paramInt2 == 1 || paramInt2 == 4 || paramInt2 == 7) && paramInt1 == 4) return this.c[this.b]; 
/* 39 */     if ((paramInt2 == 3 || paramInt2 == 6 || paramInt2 == 9) && paramInt1 == 5) return this.c[this.b];
/*    */ 
/*    */     
/* 42 */     if (paramInt2 == 14) {
/* 43 */       return this.c[this.b];
/*    */     }
/* 45 */     if (paramInt2 == 15) {
/* 46 */       return this.d;
/*    */     }
/*    */     
/* 49 */     return this.e;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(Random paramRandom) {
/* 54 */     int i = paramRandom.nextInt(10) - 7;
/* 55 */     if (i < 0) i = 0; 
/* 56 */     return i;
/*    */   }
/*    */ 
/*    */   
/*    */   public int a(int paramInt1, Random paramRandom, int paramInt2) {
/* 61 */     return apa.aj.cz + this.b;
/*    */   }
/*    */ 
/*    */   
/*    */   public int d(aab paramaab, int paramInt1, int paramInt2, int paramInt3) {
/* 66 */     return apa.aj.cz + this.b;
/*    */   }
/*    */ 
/*    */   
/*    */   public void a(ly paramly) {
/* 71 */     this.c = new lx[a.length];
/*    */     
/* 73 */     for (byte b = 0; b < this.c.length; b++) {
/* 74 */       this.c[b] = paramly.a(a[b]);
/*    */     }
/*    */     
/* 77 */     this.e = paramly.a("mushroom_inside");
/* 78 */     this.d = paramly.a("mushroom_skin_stem");
/*    */   }
/*    */ }


/* Location:              E:\余天成\我的世界编程\minecraft.jar!\amx.class
 * Java compiler version: 5 (49.0)
 * JD-Core Version:       1.1.3
 */